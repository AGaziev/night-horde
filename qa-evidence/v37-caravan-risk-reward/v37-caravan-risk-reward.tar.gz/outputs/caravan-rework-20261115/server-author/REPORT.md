# Серверная часть каравана — Issue 76

Исполнитель: subagent `caravan_balance_critique`, только разрешённые серверные файлы, текст HUD/квитанции и `pm/CARAVANS.md`. Sprite/render/manifest, Git index/commit/push, GitHub mutations и CTQ не использовались. Начальная база — `cbf25ec1bb48d70f53d949c105b7ad5981722963`; канонический Node — `/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node`, `v24.22.1`.

## Реализация

- Размещение 2600–3200 от выбранного живого героя, ≥2200 от всех участников и ≥1800 от всех до ближайшей точки всего сегмента 900. Downed/split учитываются; после ограниченного случайного поиска есть конечный запас направлений. Окно .35–.55 и скорость 45 сохранены.
- Один состав 32+4(n−1), brute=n+3, shield=2, spitter=min(4,n+1), остальные skel. Native HP ×1.6/damage ×1.25; prep 1.2, leash 520, pursuit 720. При leave сохраняется cohort birth time и доля нанесённого урона. Ordinary budgets и special quotas не меняются.
- Плевуны помечают `caravan:shot`, ограничивают луч кругом 720 вокруг груза в момент выпуска и TTL ≤2.4 с (native spitter TTL=2). Движущийся караван не продлевает выстрел. Существующий native TTL pre-pass не позволяет столкнуться после конца разрешённого пути. Claim/expiry/finale очищают только свои выстрелы с клиентским `epend`.
- Claim ставит статус до эффектов и каждому выдаёт `legendaryReforge('caravan')`, 25% XP threshold и 20% maxHP живым. Max/noRarity pool получает один переброс с явной `fallback` квитанцией. Reconnect только повторяет квитанцию; лог сохраняет source и fallback. Открытые duo/imprint предложения и XP queue используют существующий offerEpoch. Forge/outposts сохраняют прежнее поведение пустого pool.
- HUD, его раскрытый текст и toast называют Караван и фактическую перековку/fallback. Лог переводит caravan damage source как «Охрана каравана».

Логические этапы локально зафиксированы root: `9338a6e0cff87fab9d1f3cc1394aae3ce058154d` (размещение/охрана/выстрелы), `ae591f9a09d601fe16b0f6fd125ff40b46c51a4a` (награда/обратная связь/документация). В коммиты и индекс исполнитель не вмешивался. После этого root интегрирует принятый main; окончательный кандидат и его результаты фиксируются ниже отдельно.

## Адресная проверка этапов

`npm ci --ignore-scripts` выполнен в `app/` с каноническим Node первым в PATH; lockfile не менялся. Установлена единственная зависимость `ws`.

Типовая команда из корня worktree:

```sh
/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node --import ./pm/test-runtime.mjs app/server/caravan-reward-test.js
```

В последовательном пакетном прогоне рабочий каталог — `app`, `server/<suite>`, а детям передан `NODE_OPTIONS=--import=<absolute worktree>/pm/test-runtime.mjs` и собственный `HORDE_RUNS_DIR` вне checkout. Команды/вывод доступны в `stage1/*.log`, `stage2/*.log`; ревизия до commit и exit codes — в `stage1/results.json`, `stage2/results.json`.

- **Этап 1: 13/13 PASS.** Новые caravan threat и прежний caravan; outpost sniper/warning/cohort/budget; contact order; daily/fusion/Horde/Swarm; Horde mode/combat.
- **Этап 2: 18/18 PASS.** Threat/reward/caravan/client/placement; fortune-forge/forge-log/outpost-duo-offer/cohort/budget; contact order; daily/fusion/Horde/Swarm; Horde mode/combat; codec. В новом reward suite шесть тестов, включая both modes/1–8, downed, native weapon +1/reroll, artifact rarity ×3.5 step, reentrancy, maxpool receipt/resources/resync/log, stale/current duo и imprint, XP queue, expiry/finale.
- **Red proof: PASS.** Два новых suite скопированы поверх отдельной app, извлечённой read-only `git archive cbf25ec app`. На неизменённом продукте оба дают exit 1 с assertion failures; исходные файлы baseline не заменялись. Вывод — `baseline-red-caravan-*-test.js.log`, сводка `baseline-red.json`.
- `git diff --check` был PASS перед передачей каждого этапа root.

## Конечные native сцены

Внешний harness `native-bench.mjs` и результаты находятся только в этой папке. Он сохраняет Node, app path, source label и SHA-256 четырёх загруженных серверных/content файлов, а также результат/ошибку после каждой сцены. Подготовленные инвентари и seeds видны в raw JSON. Это проверка конкретных сцен, не оценка live частоты сборок или win rate. Для боевых сцен нет refill HP, invulnerability или принудительных боевых убийств; duo tail отдельно помечает подготовленную предысторию зачистки.

Окончательная пара: baseline **`4454f711267317d3a212dcebee86b08ead2e2325`**, candidate **`5494ed8bc2094168b1821002f581afb2cacea5bc`** (принятые main 55/59 интегрированы root; PROTO36/v37). Baseline извлечён отдельным `git archive <sha> app` в `baseline-4454f71`; продуктовые файлы этой копии не изменялись. Сначала baseline, затем candidate, последовательные процессы Node24.22.1. В каждом процессе те же четыре заранее фиксированные сцены/seeds, без смены параметров по результату.

| Подготовленная сцена | Baseline 4454f71 | Candidate 5494ed8 |
| --- | --- | --- |
| Solo Обед, seed 7111501 | CLAIMED 12/12 за 20.40 активных с; 1 жив | EXPIRED 30/32 за 120.00 с; 1 жив, HP40.85 |
| Solo Ночь, ближняя сборка, seed 7111502 | EXPIRED 10/12 за 180.00 с; 1 жив | CLAIMED 32/32 за 145.23 с; 1 жив, настоящая перековка knives III→IV +reroll |
| 8 участников, split/downed, seed 7111503 | EXPIRED 25/26 за 180.00 с; 7 живы | EXPIRED 58/60 за 180.00 с; 4 живы |
| Duo с открытым предложением, подготовленный последний guard, seed 7111504 | CLAIMED за 16.50 с; перековки/fallback нет; прежний выбор остаётся валидным | CLAIMED за 14.37 с; bolt IV→V, второй участник получает +1 fallback reroll; старый epoch отвергнут, свежая fusion II принимается, resync не повторяет эффекты |

В обоих solo сценариях проверены Esc и естественная level-up пауза: время и маршрут стоят. Native бой включает обычные waves, следующие boss/peak/events; инвентари из подготовленной сцены, а не из реального пользовательского забега. Все дальнейшие upgrades выбирает одна фиксированная политика по настоящим предложениям.

**Это не все зелёные игровые исходы.** Оба процесса harness завершились exit0, потому что записали все сцены и прошли вложенные contract assertions; expiry также законный записываемый исход. Exit0 не означает успешный захват всех караванов. Ориентир первой критики «Обед до100с» здесь не выполнен; это был предложенный reference, а не новый критерий пользователя. Другой исход или среднюю доступность для людей эти сцены не доказывают. Без человеческой/профильной оценки итоговое игровое risk/reward — **NOT VERIFIED**, `READY` этим отчётом не заявляется. Числа продукта после наблюдения исходов не менялись.

### Почему Обед остановился на 30/32

Остались **два Щитоносца**, а не недостижимые Плевуны. Все остальные30 убиты уже за35.80с; первый вход в pursuit через16.83с. Перед последним тактом:

- HP202.382/749.262 и173.120/749.262;
- до героя153.31 и181.84ед.; до повозки520.00 и514.15ед.; координаты и facing сохранены;
- герой почти точно перед обоими щитами: отклонение от facing около1.46° при штатной фронтальной дуге65°, поэтому обычный фронтальный урон умножается на0.2.

К концу политика выбрала настоящие `stingers I` и `guide II` (уровень героя21) вместо исходных bolt IV/knives III/flask III. Все шесть picks сохранены в `replay-candidate-solo-lunch-position.json`: stingers I → bolt V → lantern I/II/III → guide II. Политика оценивает duo/evo выше лечения и обычных passives, движется по орбите относительно повозки и уклоняется от ближайших угроз; отдельного фланга или приоритета щитов у неё нет.

Геометрического запрета урона здесь не найдено: guide II имеет range280, с имеющимся area I — около302ед.; stingers выбирает ближайшую цель в550ед. и выпускает ножи со speed640/life1.1. Оба щита внутри этих расстояний и уже потеряли большую часть HP. При этом guide направляется в наиболее плотную группу, а stingers в ближайшего врага, поэтому фоновые waves отвлекают атаки. Фронтальная защита и выбор целей объясняют медленный хвост, но не доказывают, что иной игрок обязан выиграть. Это граница данного controller, а не установленная частота живой игры. Движущийся leash не делает стрелка недостижимым: стрелков в хвосте вообще нет.

У группы8 также остались два Щитоносца (HP5478.51/9927.63 и5979.58/9927.63; ближайший живой герой324.63/289.30ед.). На baseline8 остался один Щитоносец; baseline solo Night закончился на Громиле и Щитоносце. Положительный факт доступности обоих новых щитов — полный native claim solo Night на кандидатном source, без замены его «обычным человеком».

### Нагрузка как часть сцены8

Дополнительная заранее подготовленная нагрузка seed7111593:8 героев, штатный maximum equipment layout (две duo + четыре обычных оружия и шесть passives),11 активных секунд вокруг .49–.502, real tick/AI/projectiles/snapshot. Без refill HP/godmode, все8 остались живы. Профилирование задаёт ordinary occupancy через реальные spawnEnemy, а не доказывает естественную частоту плотности.

- Baseline: maxima ordinary410, guards26, одновременно436 enemies/snapshot rows; p99 wall tick5.26мс.
- Candidate: maxima ordinary410, guards60, одновременно459 enemies/snapshot rows; p99 wall tick5.90мс при бюджете33.33мс. Maxima ordinary и guards достигались в разные моменты; 470 одновременно не заявляется.

Нативные бой и snapshot под этой ограниченной нагрузкой — **PASS**. Browser FPS/сеть и длительная нагрузка этим замером не проверены.

### Команды, повторы и сохранение неудачных результатов

Точные абсолютные argv, source и exit codes — в `native-final-exits.json`. У baseline дополнительно `CARAVAN_BASELINE=1`; обоим процессам переданы `CARAVAN_SOURCE=<sha>`, собственный `HORDE_RUNS_DIR`, `NODE_OPTIONS=--import=<worktree>/pm/test-runtime.mjs`. Форма команды:

```sh
<canonical-node24> --import <worktree>/pm/test-runtime.mjs <this-directory>/native-bench.mjs <app-directory> <this-directory>/native-final-<baseline-or-candidate>.json
```

Первые полные результаты не перезаписывались: `native-final-baseline.json/.log`, `native-final-candidate.json/.log`. Для разбора хвоста были выполнены observer-only replay тех же seed/scene: candidate Lunch/8, baseline Night/8; исходы, длительность, оставшиеся живые, HP/полученный урон и квитанции совпали дословно (см. `diagnostic-replay-comparison.json`). Дополнительное чтение facing/финальных picks Lunch записано отдельно в `replay-candidate-solo-lunch-position.json`, снова с тем же исходом и ресурсами (`replay-lunch-position-exit.json`). Политика, сцены и параметры продукта не менялись, новые samples/win-rate не строились.

Самый первый ранний запуск до freeze — **DIAGNOSTIC_FAILURE / UNKNOWN EXIT**, сохранён в `initial-diagnostic-unknown.json`. Tool вернул продолжающуюся exec-session, вызывающий код передал только output и потерял session ID; процесс завершился до следующей проверки, JSON не появился. Исторический exit/source/outcome этого запуска не восстановлены, успешным он не считается. Этот факт не удалён и не заменён полным прогоном.

## Границы проверки и очистка

Полный Server CI, окончательная интеграционная проверка, настоящие браузерные sprite/slash симптомы и выпуск — ответственность root/независимых ролей; адресные локальные проверки их не заменяют. Никаких серверов/браузеров исполнитель не поднимал. Все bench/runner subprocess завершились; финальная проверка процессов и чистоты worktree указана в `cleanup.json`. Собственные HORDE_RUNS_DIR не были созданы (игры завершались по событию, записываемого whole-run finish не было); проверены stage1/2 и обе пары native/replay каталогов. Чужие данные и настройки не менялись.
