import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
const app = path.resolve(process.argv[2]), output = path.resolve(process.argv[3]);
const fingerprints = Object.fromEntries(['server/game.js','server/caravans.js','server/runlog.js','public/shared/content.js'].map(file=>[file,createHash('sha256').update(fs.readFileSync(path.join(app,file))).digest('hex')]));
const { Room } = await import(pathToFileURL(path.join(app, 'server/game.js')));
const { CARAVAN, updateCaravan } = await import(pathToFileURL(path.join(app, 'server/caravans.js')));
const { xpForNext, TICK_HZ, DUOS, enemyHpScale } = await import(pathToFileURL(path.join(app, 'public/shared/content.js')));
const dt = 1 / TICK_HZ, originalRandom = Math.random;
function seed(value) { let state = value >>> 0; Math.random = () => ((state = (1664525 * state + 1013904223) >>> 0) / 4294967296); }
function fixture(n, mode, id) {
	seed(id); const sent = [], r = new Room('NATIVE-CARAVAN', (pid, msg, encoded) => { if (msg.t !== 's') sent.push({ pid, msg: structuredClone(msg) }); });
	r.setMode(mode); for (let i = 1; i <= n; i++) r.addPlayer(i, `P${i}`, i % 2 ? 'knight' : 'witch'); r.start();
	r.time = r.runLength * .35; r.bossIdx = r.bossAt.filter(t => t < r.time).length;
	const hs = [...r.heroes.values()];
	for (const h of hs) {
		h.level = n === 8 ? 20 : 15; h.xp = 0;
		let weapons = mode === 'night' ? [['whip', 4], ['aura', 3], ['orbit', 3]] : [['bolt', 4], ['knives', 3], ['flask', 3]];
		if (n === 8) {
			const duo=['thunderslash','spectral','icebomb','orrery','firewheel','aurora','inferno','sunprism'][h.pid-1];
			const parts=DUOS[duo].parts; for(const part of parts)h.fused.add(part);
			weapons=[[duo,1],...['whip','aura','orbit','bolt','knives','flask','lantern'].filter(id=>!parts.includes(id)).slice(0,3).map((id,i)=>[id,i===0?4:3])];
		}
		h.weapons = new Map(weapons.map(([id, lvl]) => [id, { lvl, t: .2 }]));
		h.passives = new Map([['might', 2], ['haste', 2], ['vigor', 2], ['area', 1]]); h.pval = {};
		r.recalcMods(h); r.updateCombos(h); h.hp = h.maxHp;
	}
	r.updateSynergy(); return { r, hs, sent };
}
function pick(r, h) {
	if (!h.offer || h.st !== 0) return;
	const score = c => c.kind === 'duo' || c.kind === 'evo' ? 200 : c.kind === 'weapon' ? (h.weapons.has(c.id) ? 100 : 70) + (c.rar ?? 0) * 5 : c.kind === 'rare' ? 90 : c.kind === 'heal' ? (h.hp < h.maxHp * .5 ? 120 : 10) : 50 + (c.rar ?? 0) * 5;
	const index = h.offer.reduce((best, c, i) => score(c) > score(h.offer[best]) ? i : best, 0);
	r.handle(h.pid, { t: 'pick', i: index, offerEpoch: h.offerEpoch });
}
function steer(r, h, frame, melee = false, rescue = null) {
	if (h.st !== 0 || r.frozen) return;
	const c = r.caravan; if (!c) return;
	const d = Math.hypot(h.x - c.x, h.y - c.y), angle = Math.atan2(h.y - c.y, h.x - c.x) + .45;
	const radius = c.status === 'open' ? 0 : melee ? 150 : 250;
	let tx = d > 850 ? c.x : c.x + Math.cos(angle) * radius, ty = d > 850 ? c.y : c.y + Math.sin(angle) * radius;
	if (rescue?.st === 1) { tx = rescue.x; ty = rescue.y; }
	let vx = tx - h.x, vy = ty - h.y, len = Math.hypot(vx, vy) || 1; vx /= len; vy /= len;
	let nearest = null, nearest2 = Infinity;
	for (const e of r.enemies) {
		if (e.dead) continue; const dx = h.x - e.x, dy = h.y - e.y, dd = dx * dx + dy * dy;
		if (dd < nearest2) { nearest2 = dd; nearest = e; }
		if (dd > 1 && dd < 125 ** 2 && c.status !== 'open' && !rescue) { const w = 100 / Math.sqrt(dd); vx += dx / Math.sqrt(dd) * w; vy += dy / Math.sqrt(dd) * w; }
	}
	for (const s of r.hostile) {
		const dx = h.x - s.x, dy = h.y - s.y, dd = dx * dx + dy * dy;
		if (dd > 1 && dd < 90 ** 2) { vx += dx / Math.sqrt(dd) * 1.6; vy += dy / Math.sqrt(dd) * 1.6; }
	}
	len = Math.hypot(vx, vy) || 1;
	const step = Math.min(Math.hypot(tx - h.x, ty - h.y), h.speed * h.mods.speedMul * dt);
	const aim = nearest ? { x: nearest.x - h.x, y: nearest.y - h.y } : { x: tx - h.x, y: ty - h.y };
	r.handle(h.pid, { t: 'pos', x: h.x + vx / len * step, y: h.y + vy / len * step, fx: aim.x, fy: aim.y, epoch: h.moveEpoch ?? 0, seq: frame + 1 });
}
function combat(name, mode, n, value) {
	const { r, hs, sent } = fixture(n, mode, value), initial = hs.map(h => ({ hero: h.hero, hp: h.hp, level: h.level, weapons: [...h.weapons].map(([id,w])=>[id,w.lvl]), passives: [...h.passives] }));
	if (n === 8) {
		hs.forEach((h, i) => { h.x = i < 4 ? i * 20 : 1800 + i * 20; h.y = i < 4 ? 0 : 900; });
		hs[2].x = 100; hs[2].y = 0; hs[2].st = 1; hs[2].hp = 0;
	}
	updateCaravan(r, hs.filter(h=>h.st===0), 0); const c = r.caravan; assert.ok(c);
	const start = r.time, spawn = { x: c.x, y: c.y, total: c.total }, taken = [], times = [], plan = new Map();
	let firstKill = null, open = null, naturalPause = false, tail = [], firstPursuit = null;
	const timeline=[];
	if (n === 1) { r.setPaused(true); const state = [r.time, c.progress]; for (let i=0;i<30;i++) r.tick(dt); assert.deepEqual([r.time,c.progress],state); r.setPaused(false); }
	for (let frame = 0; frame < TICK_HZ * 230 && r.state === 'play' && !['claimed','expired'].includes(c.status); frame++) {
		for (const h of hs) if (h.offer && n === 1 && !naturalPause) { const t=r.time; r.tick(dt); assert.equal(r.time,t); naturalPause=true; }
		for (const h of hs) pick(r, h);
		for (const h of hs) {
			if (frame % 8 === h.pid % 8) plan.set(h.pid, frame);
			steer(r, h, frame, mode === 'night', n === 8 && h.pid === 1 && hs[2].st === 1 ? hs[2] : null);
		}
		tail=r.enemies.filter(e=>e.caravan&&!e.dead).map(e=>({type:e.def.name,hp:e.hp,maxHp:e.maxHp,x:e.x,y:e.y,fa:e.fa,nearHero:Math.min(...hs.filter(h=>h.st===0).map(h=>Math.hypot(h.x-e.x,h.y-e.y)))}));
		if(firstPursuit===null&&hs.some(h=>h.st===0&&Math.hypot(h.x-c.x,h.y-c.y)<=CARAVAN.pursuit))firstPursuit=r.time-start;
		const killed=c.killed,before = hs.map(h=>h.hp), at=performance.now(); r.tick(dt); if(frame>30)times.push(performance.now()-at);
		if(c.killed!==killed)timeline.push({at:r.time-start,killed:c.killed});
		for (let i=0;i<hs.length;i++) if(hs[i].hp<before[i]) taken.push({time:r.time,pid:hs[i].pid,lost:before[i]-hs[i].hp});
		if (c.killed && firstKill===null) firstKill=r.time-start; if(c.status==='open'&&open===null)open=r.time-start;
	}
	times.sort((a,b)=>a-b);
	return { name, seed:value, mode,n,initial,spawn,firstKill,firstPursuit,open,elapsed:r.time-start,status:c.status,killed:c.killed,total:c.total,
		tailBeforeLastTick:tail,guardKillTimeline:timeline,finalPositions:hs.map(h=>({pid:h.pid,st:h.st,x:h.x,y:h.y,fx:h.fx,fy:h.fy})),finalCaravan:{x:c.x,y:c.y},
		finalBuilds:hs.map(h=>({pid:h.pid,level:h.level,weapons:[...h.weapons].map(([id,w])=>({id,lvl:w.lvl,oc:w.oc??null,parts:w.parts??null})),passives:[...h.passives],offer:h.offer,picks:r.runLog.p.get(h.pid).picks})),
		state:r.state,alive:hs.filter(h=>h.st===0).length, taken:hs.map(h=>({pid:h.pid,hp:h.hp,taken:r.runLog.p.get(h.pid).taken,downs:r.runLog.p.get(h.pid).downs})),
		receipts:hs.map(h=>h.lastReforge??null),reforges:hs.map(h=>r.runLog.p.get(h.pid).reforges),naturalSoloOfferPause:naturalPause,
		p99TickMs:times[Math.floor(times.length*.99)],rewardPackets:sent.filter(x=>x.msg.t==='reforge'),hpRefill:false,invulnerability:false,forcedCombatKills:false };
}
function offerTail() {
	const { r, hs, sent } = fixture(2,'night',7111504), [h, full]=hs;
	updateCaravan(r,hs,0);const c=r.caravan;
	// A prepared encounter tail isolates asynchronous reward semantics; full-cohort fights are scenes 1–3.
	const guards=r.enemies.filter(e=>e.caravan),last=guards.at(-1);
	for(const e of guards)if(e!==last)r.hurtEnemy(e,1e9,h,{weapon:'other',raw:true});
	h.weapons=new Map([['bolt',{lvl:4,t:0}],['orbit',{lvl:3,t:0}]]);h.passives.clear();h.forgeUsed=true;r.recalcMods(h);r.updateCombos(h);
	full.weapons=new Map([['whip',{lvl:5,t:0}]]);full.passives=new Map([['might',5],['echo',1]]);r.recalcMods(full);full.hp=Math.min(full.hp,full.maxHp);h.hp=Math.min(h.hp,h.maxHp);
	h.x=last.x-90;h.y=last.y;full.x=c.x-300;full.y=c.y;h.lastPosT=full.lastPosT=r.time;
	r.grantOffer(h);r.grantOffer(full);const oldEpoch=h.offerEpoch,rerolls=full.rerolls;
	let frames=0;for(;frames<900&&c.status!=='claimed'&&r.state==='play';frames++) {steer(r,h,frames);steer(r,full,frames);r.tick(dt);}
	assert.equal(c.status,'claimed');assert.equal(c.killed,c.total);
	const baseline=Boolean(process.env.CARAVAN_BASELINE);
	if(baseline){assert.equal(full.rerolls,rerolls);assert.equal(full.lastReforge,undefined);}
	else{assert.equal(full.rerolls,rerolls+1);assert.equal(full.lastReforge.fallback.kind,'reroll');}
	const before={weapons:structuredClone([...h.weapons]),queue:h.queue,picks:r.runLog.p.get(h.pid).picks.length};r.handle(h.pid,{t:'pick',i:0,offerEpoch:oldEpoch});
	if(!baseline)assert.deepEqual({weapons:structuredClone([...h.weapons]),queue:h.queue,picks:r.runLog.p.get(h.pid).picks.length},before);
	if(!baseline)r.handle(h.pid,{t:'pick',i:0,offerEpoch:h.offerEpoch});
	const receipts=hs.map(h=>structuredClone(h.lastReforge??null));for(const hero of hs)r.resync(hero.pid);assert.deepEqual(hs.map(h=>h.lastReforge??null),receipts);
	return {name:'duo-open-offer-tail',seed:7111504,preparedTail:true,fullCohortClearClaim:false,finalGuardNativeCombat:last.dead,
		status:c.status,elapsed:frames*dt,receipts,staleEpochRejected:!baseline,freshFusionLevel:h.weapons.get('orrery')?.lvl??null,fullPoolRerolls:[rerolls,full.rerolls],reforges:hs.map(h=>r.runLog.p.get(h.pid).reforges),rewardPacketCount:sent.filter(x=>x.msg.t==='reforge').length};
}
function denseLoad() {
	const {r,hs}=fixture(8,'night',7111593);r.time=r.runLength*.49;r.bossIdx=r.bossAt.filter(t=>t<r.time).length;
	updateCaravan(r,hs,0);const c=r.caravan;
	const pairs=[['spectral','inferno'],['arclaser','crystalchoir'],['sunprism','resonantshield'],['singularity','crystalchoir'],['gravitybell','sunprism'],['blacksnare','spectral'],['minefield','aurora'],['stormlight','firewheel']];
	for(const [i,h] of hs.entries()) {
		const parts=new Set(pairs[i].flatMap(id=>DUOS[id].parts));h.fused=new Set(parts);
		const rest=['whip','aura','orbit','bolt','knives','flask','lantern','frost','sickle','spear'].filter(id=>!parts.has(id)).slice(0,4);
		h.weapons=new Map([...pairs[i].map(id=>[id,{lvl:3,t:.2}]),...rest.map(id=>[id,{lvl:5,t:.2}])]);
		h.passives=new Map(['haste','echo','area','crit','coil','ashseal'].map(id=>[id,5]));r.recalcMods(h);r.updateCombos(h);h.hp=h.maxHp;
		h.x=c.x+Math.cos(i)*80;h.y=c.y+Math.sin(i)*80;h.lastPosT=r.time;
	}
	const maxima={ordinary:0,guards:0,peakOrdinary:0,enemies:0,snapshotRows:0},times=[];let frames=0;
	for(;frames<330&&r.state==='play';frames++) {
		const limit=350+(r.peak?.capAdd??0);let ordinary=r.ordinaryEnemyCount();
		while(ordinary<limit) { const a=ordinary*2.39996;r.spawnEnemy(['skel','ghoul','brute','spitter'][ordinary%4],hs,enemyHpScale(r.nt,8),[c.x+Math.cos(a)*350,c.y+Math.sin(a)*350]);ordinary++; }
		maxima.ordinary=Math.max(maxima.ordinary,ordinary);if(r.peak?.capAdd)maxima.peakOrdinary=Math.max(maxima.peakOrdinary,ordinary);
		maxima.guards=Math.max(maxima.guards,r.enemies.filter(e=>e.caravan&&!e.dead).length);maxima.enemies=Math.max(maxima.enemies,r.enemies.filter(e=>!e.dead).length);
		for(const h of hs){pick(r,h);steer(r,h,frames);}
		const at=performance.now();r.tick(dt);times.push(performance.now()-at);
		if(frames%3===0)maxima.snapshotRows=Math.max(maxima.snapshotRows,r.snapshot().e.length/6);
	}
	times.sort((a,b)=>a-b);return {seed:7111593,preparedLoad:true,seconds:frames*dt,state:r.state,alive:hs.filter(h=>h.st===0).length,maxima,p99TickMs:times[Math.floor(times.length*.99)],tickBudgetMs:1000/TICK_HZ,hpRefill:false,invulnerability:false};
}
try {
	const results=[], jobs=[['solo-lunch',()=>combat('solo-lunch','lunch',1,7111501)],['solo-night-melee',()=>combat('solo-night-melee','night',1,7111502)],['eight-split-downed',()=>combat('eight-split-downed','night',8,7111503)],['duo-open-offer-tail',offerTail]];
	for(const [name,run] of jobs) {
		if(process.env.CARAVAN_SCENE&&process.env.CARAVAN_SCENE!==name)continue;
		let result;try{result=run();if(name==='eight-split-downed')result.load=denseLoad();}catch(error){result={name,status:'ERROR',error:String(error),stack:error.stack};process.exitCode=1;}
		results.push(result);
		fs.writeFileSync(output,JSON.stringify({node:process.version,app,fingerprints,source:process.env.CARAVAN_SOURCE??null,scope:'Four finite prepared native scenes; no win-rate estimates or full-run campaign',results},null,2)+'\n');
		const {status,killed,total,elapsed,alive,error}=result;console.log(JSON.stringify({name,status,killed,total,elapsed,alive,error}));
	}
} finally {Math.random=originalRandom;}
