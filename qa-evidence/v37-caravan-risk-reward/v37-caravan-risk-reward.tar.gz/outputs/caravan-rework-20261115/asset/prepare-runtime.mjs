import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { chromium } from '/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';

const root = '/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe';
const output = path.join(root, 'outputs/caravan-rework-20261115/asset');
const runtime = path.join(root, 'work/night-horde-caravan-rework/app/public/sprites/caravan.png');
const original = path.join(output, 'original-caravan.png');
const generated = '/Users/s.konev/.codex/generated_images/01a1ded9-d4b4-7d10-8617-cf9fb9a14065/exec-20a408e4-1918-4d48-be37-2c12c604d79a.png';
await fs.mkdir(output, { recursive: true });
try { await fs.copyFile(generated, original, fs.constants.COPYFILE_EXCL); }
catch (error) { if (error.code !== 'EEXIST') throw error; }
const input = await fs.readFile(original);
if (!input.equals(await fs.readFile(generated))) throw new Error('Original archive differs from built-in result');
const browser = await chromium.launch({ headless: true, executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', args: ['--mute-audio'] });
let result;
try {
  const page = await browser.newPage();
  result = await page.evaluate(async ({ dataUrl }) => {
    const source = new Image();
    source.src = dataUrl;
    await source.decode();
    const canvas = document.createElement('canvas');
    canvas.width = 192; canvas.height = 136;
    const ctx = canvas.getContext('2d');
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(source, 0, 0, 192, 136);
    const pixels = ctx.getImageData(0, 0, 192, 136).data;
    let alphaMin = 255, alphaMax = 0, transparent = 0;
    let x0 = 192, y0 = 136, x1 = -1, y1 = -1;
    for (let y = 0; y < 136; y++) for (let x = 0; x < 192; x++) {
      const a = pixels[(y * 192 + x) * 4 + 3];
      alphaMin = Math.min(alphaMin, a); alphaMax = Math.max(alphaMax, a);
      if (a === 0) transparent++;
      if (a > 20) { x0 = Math.min(x0,x); y0 = Math.min(y0,y); x1 = Math.max(x1,x); y1 = Math.max(y1,y); }
    }
    return { sourceWidth: source.naturalWidth, sourceHeight: source.naturalHeight, width: 192, height: 136, alphaMin, alphaMax, transparentPixels: transparent, opticalBbox: [x0,y0,x1+1,y1+1], dataUrl: canvas.toDataURL('image/png') };
  }, { dataUrl: 'data:image/png;base64,' + input.toString('base64') });
} finally { await browser.close(); }
const png = Buffer.from(result.dataUrl.split(',')[1], 'base64');
delete result.dataUrl;
await fs.writeFile(runtime, png);
const sha = buffer => crypto.createHash('sha256').update(buffer).digest('hex');
const metadata = { ...result, sourceFile: original, runtimeFile: runtime, originalBytes: input.length, runtimeBytes: png.length, originalSha256: sha(input), runtimeSha256: sha(png), anchor: [79,124], method: 'Google Chrome headless via Playwright; Canvas2D drawImage full-frame 1491x1055 to 192x136; imageSmoothingEnabled=false; canvas.toDataURL(image/png); no semantic edits; original alpha preserved through browser export', nodeVersion: process.version };
await fs.writeFile(path.join(output,'runtime-export.json'), JSON.stringify(metadata,null,2)+'\n');
console.log(JSON.stringify(metadata,null,2));

