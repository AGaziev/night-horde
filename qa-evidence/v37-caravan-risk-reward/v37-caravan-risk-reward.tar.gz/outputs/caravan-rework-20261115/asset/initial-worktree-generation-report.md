# Caravan sprite generation

Mode: built-in image_gen.imagegen (one new image; no reference arguments; transparent_background=true). No CLI or API key used.

Saved asset: app/public/sprites/caravan.png
Source: /Users/s.konev/.codex/generated_images/01a1ded9-d4b4-7d10-8617-cf9fb9a14065/exec-20a408e4-1918-4d48-be37-2c12c604d79a.png

- Dimensions/cell: 1491 × 1055 px; one static frame; fps 0.
- File size: 1,385,599 bytes.
- PNG: 8-bit RGBA, alpha minimum 0, maximum 255. 782,145 fully transparent pixels. Original generated alpha preserved without postprocessing.
- Optical bounds at alpha >20: [71,94,1444,972) => 1373 × 878 px. Margins: left 71, top 94, right 47, bottom 83.
- Very faint generated alpha (<21) extends to canvas edges; use the optical bounds above for composition.
- Proposed ground/contact anchor: [610,965], near the center of the wheel footprint. Optical whole-sprite center: [757.5,533]. If renderer anchors by center rather than feet, [746,528] is the full canvas center.
- At full canvas width 110 world units: full canvas height 77.8; visible body + tow shafts about 101.3 × 64.8 world units. Whole-frame scale is appropriate. Ground bodyRadius about 35–40 world units (runtime owner decides).
- Visual inspection: one complete right-facing wooden wagon, 2 large visible near wheels, rich cargo (sacks, crates, brass-bound chest, folded canvas, small gold cargo), dark outlines and crisp pixel shading. It is closer to a shallow three-quarter/side elevation than a strong top-down view. No people, horse, ground, UI, text, grid, or frame. No alternate open/guarded cell; runtime should use the same sprite for states.

## Final prompt

Use case: stylized-concept.
Asset type: one static pixel-art game sprite, a wealthy cargo wagon for a top-down three-quarter-view dark-fantasy horde survival game, intended to read clearly around 100 by 100 world units.
Primary request: a single sturdy medieval wooden cargo wagon facing RIGHT; two short tow shafts project to the right, with NO horse and NO character. Show the upper cargo bed and near side from above. Several iron-rimmed spoked wooden wheels must be visibly attached to the wagon; show two near wheels and a small farther wheel where perspective allows.
Subject details: thick dark brown wooden planks with worn golden-brown highlights, blackened iron fittings, stout axles. The wagon is richly loaded with tied beige sacks, a couple of small wooden crates, folded weathered canvas, one closed chest with a brass lock and a few readable golden cargo accents. Clear valuable cargo silhouette. Keep cargo compact and secure rather than overflowing.
Style/medium: crisp hand-placed pixel art, chunky deliberate pixel clusters, approximately 128 by 128 logical pixels upscaled cleanly. Dark gothic adventure sprite style, sharp stepped contours and sparse 2-3 tone material shading; almost-black warm purple/brown outer outline; earthy muted colors. Match the small dark fantasy sprite aesthetic of a weathered stump and chipped gravestone rendered in hand-pixel shading.
Composition/framing: exactly ONE isolated wagon, complete silhouette inside a square frame, centered with only small transparent margins, no sprite sheet, no alternate states. Three-quarter top-down perspective, clear right-facing front. The wheels and wooden platform remain structurally readable when shrunk for gameplay.
Lighting/mood: restrained upper-left highlights, dark crevices, no luminous halo. Dark brown, old ochre, beige, soot iron, tiny subdued brass accents.
Background: actual TRANSPARENT alpha background; fully transparent empty pixels outside the wagon, preserve alpha. No checkerboard artwork, no colored backdrop, no floor, no cast ground shadow, no glow or ambient haze.
Avoid: horses, humans, creatures, driver, text, lettering, logo, watermark, UI, border, frame, grid, scenery, grass, ground plane, photorealistic texture, soft edges, smooth illustration, blur, anti-aliased painterly strokes, oversized canopy covering all cargo.

