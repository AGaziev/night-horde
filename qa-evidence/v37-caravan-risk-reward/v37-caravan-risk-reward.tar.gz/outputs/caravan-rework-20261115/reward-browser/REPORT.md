# Reward visibility spot: PASS

Exact frozen source: `5494ed8bc2094168b1821002f581afb2cacea5bc`. Node `v24.22.1`, installed Chrome `157.0.8103.51`, `--mute-audio`. Desktop 1280×800 and mobile/touch 390×844, one co-op Room and one native pickup.

The actual page created/joined/started the room through UI. Test-only owned IPC advanced time to the event, killed the generated 36 guards through native `killEnemy`, removed their fixture gems, positioned the native wagon/heroes and prepared P1 with only Whip level 4, P2 with only maxed Whip level 5, both at half HP. Preparation used native resync/snapshot. P1 then moved by real `KeyD` input from x=-110 to x=-67.5; native `updateCaravan` claimed the open wagon. The fixture never called `claimCaravan` or `legendaryReforge`, and never inserted callback messages or toast text.

| Recipient | Native reward and matching private WS | Resources before → after | Visible DOM |
| --- | --- | --- | --- |
| P1 desktop | Whip 4 → 5, legendary rarity, +1 reroll | HP 70 → 98 of 140; XP 0 → 2 of 8; rerolls 2 → 3 | `Караван · Легендарная перековка: Клинок 4 → 5 ур. · +1 переброс · опыт +25% уровня · лечение живым 20% HP` |
| P2 mobile | No eligible item; fallback +1 reroll | HP 70 → 98 of 140; XP 0 → 2 of 8; rerolls 2 → 3 | `Караван · Все подходящие предметы максимальны · +1 переброс · опыт +25% уровня · лечение живым 20% HP` |

Each client received exactly its own one `reforge` WS message, equal to that hero's native `lastReforge`. Both kept `offer=null`, `queue=0`; the room remained unfrozen. The HUD independently showed `98 / 140` and XP width `25%`. Both toasts fit entirely inside their viewports (desktop 420×73 at x430/y56; mobile 358×73 at x16/y56). Toast/container `pointer-events:none`; actual `elementFromPoint` at toast center reached the game canvas.

Both screenshots were opened and visually inspected:

- `desktop-legendary.png`
- `mobile-fallback.png`

Primary evidence: `result.json` (native before/after, WS payloads, DOM text/geometry), `source.json` (exact SHA/file hashes), `fixture.mjs` (disclosed wrapper), `fixture.log`. The first attempt stopped on an incorrect fixture assertion against the co-op-hidden pause button (`ui.js` intentionally hides it); the fixture was corrected to test pointer pass-through. No product change was needed. First-attempt artifacts remain separately named.

Cleanup independently confirmed in `cleanup-independent.json`: child exited 0, Chrome closed, owned run directory removed, and port 54719 has no listener. No source/Git, production or network configuration changes were made. Reconnect/resource unit suites were not repeated.

This controlled scene proves reward delivery and visibility only. Human encounter difficulty and overall balance remain **NOT VERIFIED**; this evidence does not replace the Draft PR's balance limitation.

Rerun from this folder: `/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node --import ./source-5494ed8/pm/test-runtime.mjs fixture.mjs`.
