import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import net from 'node:net';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {setTimeout as wait} from 'node:timers/promises';
import {chromium} from '/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';

const out=path.dirname(new URL(import.meta.url).pathname),source=path.join(out,'source-5494ed8');
const runs=fs.mkdtempSync(path.join(os.tmpdir(),'caravan-reward-browser-'));
const portProbe=net.createServer();portProbe.listen(0,'127.0.0.1');await once(portProbe,'listening');
const port=portProbe.address().port;await new Promise(resolve=>portProbe.close(resolve));const base='http://127.0.0.1:'+port;
const wrapper=`
const {Room}=await import(${JSON.stringify(source+'/app/server/game.js')});
const {xpForNext}=await import(${JSON.stringify(source+'/app/public/shared/content.js')});
const rooms=new Map(),start=Room.prototype.start;
Room.prototype.start=function(){const v=start.call(this);rooms.set(this.code,this);this.spawn=()=>{};this.events.next=Infinity;this.nextEliteT=this.nextInvasionT=Infinity;return v;};
const read=r=>({state:r.state,time:r.time,frozen:r.frozen,caravan:r.caravan&&{status:r.caravan.status,killed:r.caravan.killed,total:r.caravan.total,x:r.caravan.x,y:r.caravan.y},heroes:[...r.heroes.values()].map(h=>({pid:h.pid,x:h.x,y:h.y,hp:h.hp,maxHp:h.maxHp,xp:h.xp,xpNext:xpForNext(h.level,r.heroes.size),level:h.level,weapons:[...h.weapons].map(([id,w])=>[id,w.lvl]),rerolls:h.rerolls,offer:h.offer,queue:h.queue,lastReforge:h.lastReforge??null}))});
process.on('message',m=>{const r=rooms.get(m.code);if(!r)return;
 try{
  if(m.cmd==='window')r.time=r.runLength*.35;
  if(m.cmd==='prepare'){
   const c=r.caravan;if(!c)throw Error('Missing native caravan');
   for(const e of r.enemies)if(e.caravan===c)r.killEnemy(e,null);
   r.enemies=r.enemies.filter(e=>!e.dead);r.gems=[];
   Object.assign(c,{x:0,y:0,ax:0,ay:0,bx:0,by:0});
   for(const h of r.heroes.values()){
    if(h.offer||h.queue)throw Error('Unexpected pre-existing offer');
    h.weapons=new Map([['whip',{lvl:h.pid===m.p1?4:5,t:999}]]);h.passives.clear();h.pval={};
    h.x=h.pid===m.p1?-110:-140;h.y=h.pid===m.p1?0:90;h.hp=h.maxHp*.5;h.xp=0;h.level=1;
    r.resync(h.pid);
   }
   r.snapshot();
  }
  process.send({request:m.request,data:read(r)});
 }catch(e){process.send({request:m.request,error:e.stack});}
});
await import(${JSON.stringify(source+'/app/server/server.js')});`;
const child=spawn(process.execPath,['--import',source+'/pm/test-runtime.mjs','--input-type=module','-e',wrapper],{cwd:source,env:{...process.env,PORT:String(port),HORDE_RUNS_DIR:runs,VIBE_APP_KEY:''},stdio:['ignore','pipe','pipe','ipc']});
const childExit=once(child,'exit');let log='',browser,request=0;const pending=new Map();
child.stdout.on('data',d=>log+=d);child.stderr.on('data',d=>log+=d);child.on('message',m=>{const p=pending.get(m.request);if(p){pending.delete(m.request);m.error?p.reject(Error(m.error)):p.resolve(m.data);}});
const ipc=(cmd,code,extra={})=>new Promise((resolve,reject)=>{const id=++request;pending.set(id,{resolve,reject});child.send({cmd,code,...extra,request:id});});
const result={sha:'5494ed8bc2094168b1821002f581afb2cacea5bc',node:process.version,base,runs,scope:'Owned frozen final source, real UI create/join/start, real private WS reforge messages, native updateCaravan pickup triggered by keyboard movement. IPC only advances event time, native-kills generated guards, removes their fixture gems, places native caravan and heroes, and prepares eligible/maxed inventories plus half HP. No direct claimCaravan/legendaryReforge calls or fake callback messages. Controlled reward visibility proof, not combat/difficulty/balance acceptance.'};
try{
 let ready=false;for(let i=0;i<100&&!ready;i++){assert.equal(child.exitCode,null);ready=await fetch(base+'/health',{signal:AbortSignal.timeout(1500)}).then(r=>r.ok,()=>false);if(!ready)await wait(50);}assert.ok(ready);
 browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true,args:['--mute-audio','--disable-features=LocalNetworkAccessChecks']});result.chrome=browser.version();
 const contexts=[],pages=[],wire=[[],[]],errors=[[],[]];
 for(const [i,width,height,mobile]of[[0,1280,800,false],[1,390,844,true]]){
  const ctx=await browser.newContext({viewport:{width,height},deviceScaleFactor:1,isMobile:mobile,hasTouch:mobile});contexts.push(ctx);
  await ctx.route('**/*',route=>route.request().url().startsWith(base)?route.continue():route.abort());
  const page=await ctx.newPage();pages.push(page);page.on('pageerror',e=>errors[i].push(e.message));
  page.on('websocket',ws=>ws.on('framereceived',frame=>{try{const m=JSON.parse(frame.payload.toString());if(m.t==='reforge')wire[i].push(m);}catch{}}));
  await page.goto(base);await page.waitForFunction(()=>__nh?.net.connected);
 }
 const [desktop,mobile]=pages;
 await desktop.locator('#menu-create').click();await desktop.locator('#screen-lobby').waitFor({state:'visible'});
 const code=await desktop.evaluate(()=>__nh.state.lobby.code);await mobile.locator('#menu-code').fill(code);await mobile.locator('#menu-join').click();await mobile.locator('#lobby-ready').click();
 await desktop.waitForFunction(()=>__nh.state.lobby.players.length===2);await desktop.locator('#lobby-start').click();
 for(const p of pages)await p.waitForFunction(()=>__nh.game.latest());
 const pids=await Promise.all(pages.map(p=>p.evaluate(()=>__nh.state.me)));result.pids=pids;
 await ipc('window',code);await desktop.waitForFunction(()=>__nh.game.latest()?.cv);
 result.before=await ipc('prepare',code,{p1:pids[0]});
 assert.equal(result.before.caravan.status,'open');assert.equal(result.before.caravan.killed,result.before.caravan.total);assert.equal(result.before.frozen,false);
 for(const h of result.before.heroes){assert.equal(h.offer,null);assert.equal(h.queue,0);assert.equal(h.lastReforge,null);}
 for(const p of pages)await p.waitForFunction(()=>{const g=__nh.game,row=g.latest()?.p.find(r=>r[0]===g.me);return row&&row[3]===70&&row[12][0][1]>=4&&document.querySelector('#hud-hp-text').textContent==='70 / 140';});
 result.domBefore=await Promise.all(pages.map(p=>p.evaluate(()=>({hp:document.querySelector('#hud-hp-text').textContent,xpWidth:document.querySelector('#hud-xp-fill').style.width,inventory:document.querySelector('#hud-weapons').innerText,transport:__nh.net.transport,row:structuredClone(__nh.game.latest().p.find(r=>r[0]===__nh.game.me))}))));
 assert.ok(result.domBefore.every(d=>d.transport==='WS'));
 await desktop.locator('#game').focus();await desktop.keyboard.down('KeyD');
 await Promise.all(pages.map(p=>p.locator('#toasts .toast').filter({hasText:'Караван'}).waitFor({state:'visible',timeout:8000})));
 await desktop.keyboard.up('KeyD');await wait(320);
 result.after=await ipc('read',code);assert.equal(result.after.caravan.status,'claimed');assert.equal(result.after.frozen,false);
 for(const before of result.before.heroes){const after=result.after.heroes.find(h=>h.pid===before.pid);assert.equal(after.rerolls,before.rerolls+1);assert.equal(after.xp-before.xp,before.xpNext*.25);assert.equal(after.hp-before.hp,before.maxHp*.2);assert.equal(after.offer,null);assert.equal(after.queue,0);}
 const first=result.after.heroes.find(h=>h.pid===pids[0]),second=result.after.heroes.find(h=>h.pid===pids[1]);
 assert.deepEqual(first.weapons,[['whip',5]]);assert.deepEqual(second.weapons,[['whip',5]]);
 assert.equal(first.lastReforge.source,'caravan');assert.equal(first.lastReforge.result.from,4);assert.equal(first.lastReforge.result.to,5);
 assert.equal(second.lastReforge.source,'caravan');assert.equal(second.lastReforge.result,null);assert.deepEqual(second.lastReforge.fallback,{kind:'reroll',amount:1});
 result.domAfter=[];
 for(const [i,p]of pages.entries()){
  await p.waitForFunction(()=>document.querySelector('#hud-hp-text').textContent==='98 / 140');
  const dom=await p.evaluate(()=>{
   const toast=[...document.querySelectorAll('#toasts .toast')].find(e=>e.textContent.includes('Караван')),rect=toast.getBoundingClientRect();
   const box=document.querySelector('#toasts'),pick=document.elementFromPoint(rect.x+rect.width/2,rect.y+rect.height/2);
   return{text:toast.textContent,rect:rect.toJSON(),withinViewport:rect.left>=0&&rect.top>=0&&rect.right<=innerWidth&&rect.bottom<=innerHeight,pointerEvents:getComputedStyle(toast).pointerEvents,containerPointerEvents:getComputedStyle(box).pointerEvents,hitPassesThroughToast:!pick?.closest('#toasts'),hitUnderToast:pick?.id||pick?.tagName,pauseHidden:document.querySelector('#hud-pause').hidden,hp:document.querySelector('#hud-hp-text').textContent,xpWidth:document.querySelector('#hud-xp-fill').style.width,inventory:document.querySelector('#hud-weapons').innerText,row:structuredClone(__nh.game.latest().p.find(r=>r[0]===__nh.game.me)),gameRunning:__nh.game.running,offer:__nh.game.offer,screen:__nh.ui.screen,transport:__nh.net.transport};
  });
  assert.ok(dom.withinViewport);assert.equal(dom.pointerEvents,'none');assert.equal(dom.containerPointerEvents,'none');assert.ok(dom.hitPassesThroughToast);assert.equal(dom.offer,null);assert.equal(dom.transport,'WS');assert.match(dom.text,/25%.*20% HP/);
  if(i===0)assert.match(dom.text,/Легендарная перековка.*Клинок 4 → 5.*\+1 переброс/);else assert.match(dom.text,/Все подходящие предметы максимальны.*\+1 переброс/);
  assert.deepEqual(wire[i],[result.after.heroes.find(h=>h.pid===pids[i]).lastReforge]);
  result.domAfter.push(dom);await p.screenshot({path:path.join(out,i===0?'desktop-legendary.png':'mobile-fallback.png')});
 }
 result.privateWs=wire;result.errors=errors;assert.ok(errors.every(e=>e.length===0));
 result.status='PASS: real UI/native claim -> separate private WS legendary/fallback -> visible desktop/mobile reward toasts, HP/XP/rerolls verified';console.log(result.status);
 await Promise.all(contexts.map(c=>c.close()));
}finally{
 await browser?.close();child.kill();result.childExit=await childExit;fs.rmSync(runs,{recursive:true,force:true});result.cleanup={serverStopped:true,browserClosed:true,runsRemoved:!fs.existsSync(runs)};fs.writeFileSync(path.join(out,'result.json'),JSON.stringify(result,null,2));fs.writeFileSync(path.join(out,'server.log'),log);
}
