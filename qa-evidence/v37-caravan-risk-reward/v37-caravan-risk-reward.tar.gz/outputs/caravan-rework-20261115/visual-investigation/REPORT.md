# Caravan / blade visuals: read-only investigation

PASS: reproduced both reported visuals in installed Chrome `157.0.8103.51` with `--mute-audio`, Node `v24.22.1`, exact archived `origin/main` SHA `cbf25ec1bb48d70f53d949c105b7ad5981722963`.

![Native production-renderer frame](native-caravan-and-blade.png)

The fixture opens the actual page, creates and starts a solo lobby through UI, receives native WS snapshots and records a native automatic Whip attack. Test-only server IPC advances the owned Room to the caravan window and translates the generated caravan and guards into the viewport; it does not replace the native caravan or attack implementation. Renderer instrumentation records existing Canvas calls and freezes the first resulting frame without changing those calls. This is reproduction evidence, not natural-run frequency or balance acceptance.

## Causes and minimal change

1. **Caravan sprite was never integrated.** `app/public/js/render.js:641-655` draws only procedural rectangles. Recorded frame: 3 `fillRect`, 2 `strokeRect`, zero `drawImage`. `sprites.ready === true`, all 34 current entries are loaded. There is no caravan/cart/wagon entry or matching file in `app/public/sprites/`. This is not a failed PNG load or broken sprite clipping. The implementation arrived in `b0aee6f` (`Добавить караваны с охраной и командной наградой (#56)`), with no sprite asset. Minimal change: add an intentional cart asset and manifest entry, consume it through `sprites.get(...)` and `blit(...)`, and retain the procedural cart as the unloaded-atlas fallback. Keep the label and status distinction. The art can share one atlas strip with guarded/open variants.

2. **Blade squares are explicit rendered footprint borders.** `app/public/js/render.js:3223-3236` calls `fillRect(box.x, box.y, box.width, box.height)` and `strokeRect(...)` before drawing the white crescent. Recorded native level-1 Whip: `range=110`, `width=40`, `dir=-1`, event position `(0,0)`, age `0.0166s`; draw calls fill `(-110,-20,110,40)` and stroke `(-109.5,-19.5,109,39)` in blue. The rectangle appears independently of sprite loading and survives simplified VFX because this path has no lite guard. It was introduced by `13f6bd06692dae39e5c3465f4a8047cc586c92a1` (`Anchor slash afterimages to their server footprint and clarify shot cores`). Minimal change: remove the visible rectangle fill/stroke only; retain the server event world position and `slashBounds` clipping so the crescent stays inside the actual damage footprint. Do not revert the prior movement anchoring fix or change server damage geometry.

The current checkout's `render.js`, `sprites.js`, and `manifest.json` are identical to archived main (`git diff cbf25ec1 HEAD -- ...` was empty). This rules out a stale local renderer for this reproduction. Production and remote main freshness were not inspected: external network and production were outside the authorized scope.

## Evidence and rerun

- `result.json`: runtime, native slash/caravan snapshot, Canvas calls, all loaded sprite IDs, request statuses, no page errors.
- `source.json`: exact SHA, source extraction location, initial clean worktree status.
- `source-cbf25ec/`: unchanged `git archive` of `app/` and the test preload from the exact SHA. `app/node_modules` links to existing local dependencies.
- `fixture.mjs`: owned native UI/WS/Room fixture. Run with `/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node --import ./source-cbf25ec/pm/test-runtime.mjs fixture.mjs` from this report's folder. It chooses its own unused loopback port and temporary `HORDE_RUNS_DIR`, uses empty `VIBE_APP_KEY`, and blocks non-local browser requests.
- `cleanup-independent.json`: fixture process exited, Chrome closed, owned runs directory removed, no listener remains on recorded port `51723`; independent Node health fetch fails with `EPIPE`. The Python raw `connect_ex` check was inconclusive in this environment and was not used as proof. Worktree remained clean on `codex/17-dash`.

No production files, branch, commit, GitHub state, network settings or shared runtime were changed. Only owned artifacts under this folder were created. No broad performance audit or balance claim was made.
