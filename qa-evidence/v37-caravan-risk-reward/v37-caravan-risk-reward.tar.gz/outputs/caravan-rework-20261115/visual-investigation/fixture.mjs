import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import net from 'node:net';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {setTimeout as wait} from 'node:timers/promises';
import {chromium} from '/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';

const out=path.dirname(new URL(import.meta.url).pathname);
const source=path.join(out,'source-cbf25ec');
const runs=fs.mkdtempSync(path.join(os.tmpdir(),'caravan-visual-owned-'));
const portServer=net.createServer();
portServer.listen(0,'127.0.0.1');
await once(portServer,'listening');
const port=portServer.address().port;
await new Promise(resolve=>portServer.close(resolve));
const base='http://127.0.0.1:'+port;
const wrapper=`
const {Room}=await import(${JSON.stringify(source+'/app/server/game.js')});
const rooms=new Map(),originalStart=Room.prototype.start;
Room.prototype.start=function(){const result=originalStart.call(this);rooms.set(this.code,this);this.spawn=()=>{};this.events.next=Infinity;return result;};
process.on('message',m=>{
 const r=rooms.get(m.code); if(!r)return;
 if(m.cmd==='caravan')r.time=r.runLength*.35;
 if(m.cmd==='position'&&r.caravan){const h=[...r.heroes.values()][0],c=r.caravan,dx=h.x+230-c.x,dy=h.y-80-c.y;for(const k of ['x','ax','bx'])c[k]+=dx;for(const k of ['y','ay','by'])c[k]+=dy;for(const e of r.enemies)if(e.caravan===c){e.x+=dx;e.y+=dy;}r.snapshot();}
});
await import(${JSON.stringify(source+'/app/server/server.js')});`;
const child=spawn(process.execPath,['--import',source+'/pm/test-runtime.mjs','--input-type=module','-e',wrapper],{
 cwd:source,env:{...process.env,PORT:String(port),HORDE_RUNS_DIR:runs,VIBE_APP_KEY:''},stdio:['ignore','pipe','pipe','ipc']
});
const childExit=once(child,'exit');
let serverLog='';
child.stdout.on('data',d=>serverLog+=d);child.stderr.on('data',d=>serverLog+=d);
let browser;
const result={sha:'cbf25ec1bb48d70f53d949c105b7ad5981722963',node:process.version,base,runs,scope:'Owned local real Chrome / native UI -> WS -> Room and native automatic Whip slash -> production renderer. Test-only IPC jumps active time to caravan window and translates generated caravan+guards into the viewport. Renderer recording preserves its draw calls and freezes the rendered frame only. This does not prove natural-run frequency or balance.'};
try{
 let ready=false;
 for(let i=0;i<100&&!ready;i++){ready=await fetch(base+'/health').then(r=>r.ok,()=>false);if(!ready)await wait(50);}
 assert.ok(ready,'owned fixture server health');
 browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true,args:['--mute-audio','--disable-features=LocalNetworkAccessChecks']});
 result.chrome=browser.version();
 const context=await browser.newContext({viewport:{width:1280,height:800},deviceScaleFactor:1});
 const page=await context.newPage();
 const errors=[],requests=[];
 page.on('pageerror',e=>errors.push(e.message));
 page.on('response',r=>requests.push({url:r.url(),status:r.status()}));
 await context.route('**/*',route=>route.request().url().startsWith(base)?route.continue():route.abort());
 await page.goto(base);
 await page.waitForFunction(()=>window.__nh?.net.connected&&window.__nh.renderer.sprites.ready);
 await page.locator('#menu-create').click();
 await page.locator('#lobby-start').click();
 await page.waitForFunction(()=>__nh.game.latest());
 const code=await page.evaluate(()=>__nh.state.lobby.code);
 child.send({cmd:'caravan',code});
 await page.waitForFunction(()=>__nh.game.latest()?.cv);
 child.send({cmd:'position',code});
 await page.waitForFunction(()=>{const {game}=__nh,c=game.latest()?.cv;return c&&Math.abs(c.x-game.local.x)<400;});
 await page.evaluate(()=>{
  const renderer=__nh.renderer,capture=window.__capture={armed:true,frozen:null,calls:{},stage:null};
  for(const method of ['fillRect','strokeRect','drawImage']){
   const original=CanvasRenderingContext2D.prototype[method];
   CanvasRenderingContext2D.prototype[method]=function(...args){
    if(capture.stage)capture.calls[capture.stage].push({method,args:args.map(v=>typeof v==='number'?v:v.constructor.name),fill:this.fillStyle,stroke:this.strokeStyle,alpha:this.globalAlpha});
    return original.apply(this,args);
   };
  }
  for(const [method,stage]of [['drawCaravan','caravan'],['drawEffects','effects']]){
   const original=renderer[method];renderer[method]=function(...args){capture.stage=stage;capture.calls[stage]=[];try{return original.apply(this,args);}finally{capture.stage=null;}};
  }
  const original=renderer.draw;
  renderer.draw=function(game,dt){
   if(capture.frozen)return;
   original.call(this,game,dt);
   if(capture.armed&&game.slashes.some(s=>s.t<.06)&&game.view.b?.cv){
    capture.frozen={slashes:structuredClone(game.slashes),caravan:structuredClone(game.view.b.cv),local:structuredClone(game.local),zoom:this.zoom,canvas:{width:this.canvas.width,height:this.canvas.height}};
   }
  };
 });
 await page.waitForFunction(()=>__capture.frozen,null,{timeout:10000});
 await page.screenshot({path:path.join(out,'native-caravan-and-blade.png')});
 result.render=await page.evaluate(()=>({frozen:__capture.frozen,calls:__capture.calls,sprites:{ready:__nh.renderer.sprites.ready,ids:[...__nh.renderer.sprites.map.keys()]}}));
 result.errors=errors;result.requests=requests;
 assert.equal(result.render.calls.caravan.filter(c=>c.method==='drawImage').length,0);
 assert.ok(result.render.calls.caravan.some(c=>c.method==='fillRect'&&c.args.join(',')==='-41,-19,82,46'));
 assert.ok(result.render.calls.effects.some(c=>c.method==='strokeRect'&&c.stroke==='rgba(144, 202, 249, 0.65)'));
 assert.deepEqual(errors,[]);
 result.status='PASS: both reported visual forms reproduced in native Chrome frame';
 console.log(result.status);
}finally{
 await browser?.close();
 child.kill();
 result.childExit=await childExit;
 fs.rmSync(runs,{recursive:true,force:true});
 result.cleanup={serverStopped:true,runsRemoved:!fs.existsSync(runs),browserClosed:true};
 fs.writeFileSync(path.join(out,'server.log'),serverLog);
 fs.writeFileSync(path.join(out,'result.json'),JSON.stringify(result,null,2));
}
