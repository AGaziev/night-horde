import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import crypto from 'node:crypto';
const [appArg,sceneId,outArg,prefixArg]=process.argv.slice(2);
const app=path.resolve(appArg), out=path.resolve(outArg);
const protocol=JSON.parse(fs.readFileSync(new URL('./protocol.json',import.meta.url)));
const cfg=protocol.scenes.find(x=>x.id===sceneId); if(!cfg)throw Error('Unknown scene');
let seed=cfg.seed>>>0;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
const {Room}=await import(pathToFileURL(path.join(app,'server/game.js')));
const C=await import(pathToFileURL(path.join(app,'public/shared/content.js')));
const dt=1/C.TICK_HZ, messages=[], costs=[], cpuCosts=[], sizes=[];
const r=new Room('I76FIX',(pid,m)=>{if(['reforge','err'].includes(m.t))messages.push({pid,time:r.time,...structuredClone(m)});});
r.setMode(cfg.mode);cfg.players.forEach((hero,i)=>r.addPlayer(i+1,`P${i+1}`,hero));r.start();
const stats={firstHit:null,guardDamage:0,actualDamageTaken:{},shots:0,maxHostile:0,maxOrdinary:0,maxEnemies:0,open:null,claimed:null,expiry:null,pause:null,offerFreezes:0,leave:null,preclaim:null};
const inv=h=>({pid:h.pid,hero:h.hero,level:h.level,xp:h.xp,hp:h.hp,maxHp:h.maxHp,st:h.st,x:h.x,y:h.y,rerolls:h.rerolls,queue:h.queue,epoch:h.offerEpoch,offer:structuredClone(h.offer),weapons:[...h.weapons].map(([id,w])=>[id,{...w}]),passives:[...h.passives],pval:{...h.pval},lastReforge:structuredClone(h.lastReforge)});
const hurtEnemy=r.hurtEnemy;r.hurtEnemy=function(e,...args){const hp=e.hp;const result=hurtEnemy.call(this,e,...args);if(e.caravan){const damage=Math.max(0,hp-Math.max(0,e.hp));if(damage){stats.firstHit??=this.time;stats.guardDamage+=damage;}}return result;};
const hurtPlayer=r.hurtPlayer;r.hurtPlayer=function(h,dmg,from,...args){const hp=h.hp;const result=hurtPlayer.call(this,h,dmg,from,...args);const actual=Math.max(0,hp-h.hp);if(actual)stats.actualDamageTaken[from]=(stats.actualDamageTaken[from]??0)+actual;return result;};
const fire=r.fireHostile;r.fireHostile=function(e,...args){if(e.caravan)stats.shots++;return fire.call(this,e,...args);};
const reforge=r.legendaryReforge;r.legendaryReforge=function(h,...args){if(args[0]==='caravan'&&!stats.preclaim)stats.preclaim=[...this.heroes.values()].map(inv);return reforge.call(this,h,...args);};
function choose(h){let score=-Infinity,best=0;h.offer.forEach((c,i)=>{const owned=c.from??((c.level??1)-1);let s=c.kind==='heal'?(h.hp<h.maxHp*.35?100:0):c.kind==='weapon'?(owned?70:40)+(c.rar??0)*5:c.kind==='passive'?50+(c.rar??0)*5:c.kind==='ovr'?30:c.kind==='ember'?20:10;if(s>score){score=s;best=i;}});return best;}
function drain(){for(let guard=0;guard<100;guard++){let count=0;for(const h of r.heroes.values()){if(!h.offer?.length)continue;const i=choose(h),c=h.offer[i];r.handle(h.pid,{t:'pick',i,offerEpoch:h.offerEpoch,...(c.kind==='swap'?{drop:c.replace?.[0]?.id}:{})});count++;}if(!count)return;}throw Error('offer loop');}
const plan=new Map();
function move(h,frame,stage){if(h.st!==0||r.frozen)return;if(frame%8!==h.pid%8&&plan.has(h.pid)){const p=plan.get(h.pid),s=h.speed*h.mods.speedMul*dt;r.handle(h.pid,{t:'pos',x:h.x+p[0]*s,y:h.y+p[1]*s,fx:p[2],fy:p[3]});return;}
 let vx=0,vy=0;for(const e of r.enemies){if(e.dead)continue;const dx=h.x-e.x,dy=h.y-e.y,d2=dx*dx+dy*dy;if(d2<190**2&&d2>1){const k=(e.r/12)*4000/d2;vx+=dx/Math.sqrt(d2)*k;vy+=dy/Math.sqrt(d2)*k;}}
 for(const s of r.hostile){if((s.id??0)%4===0)continue;const dx=h.x-s.x,dy=h.y-s.y,d2=dx*dx+dy*dy;if(d2<90**2&&d2>1){const k=3000/d2;vx+=dx/Math.sqrt(d2)*k;vy+=dy/Math.sqrt(d2)*k;}}
 let best=null,bd=350**2;for(const g of [...r.gems,...r.items]){const d2=(g.x-h.x)**2+(g.y-h.y)**2;if(d2<bd){best=g;bd=d2;}}if(best){const d=Math.sqrt(bd)||1,k=stage==='prefix'?1.2:.4;vx+=(best.x-h.x)/d*k;vy+=(best.y-h.y)/d*k;}
 let target=null,k=0;const c=r.caravan;
 if(stage!=='prefix'&&c&& !['claimed','expired'].includes(c.status)){
  const elapsed=r.time-startAt;const down=sceneId==='eightSplitLoad'?[...r.heroes.values()].find(x=>x.st===1):null;
  if(down){target=down;k=3;}
  else if(sceneId==='soloNight'&&elapsed>=45){const d=Math.hypot(h.x-c.x,h.y-c.y)||1;target={x:h.x+(h.x-c.x)/d*1000,y:h.y+(h.y-c.y)/d*1000};k=4;}
  else {const d=Math.hypot(h.x-c.x,h.y-c.y);if(c.status==='open'||d>350){target=c;k=c.status==='open'?6:3;}else{const a=elapsed*.9+h.pid*.6;target={x:c.x+Math.cos(a)*100,y:c.y+Math.sin(a)*100};k=2;}}
 }
 if(target){const d=Math.hypot(target.x-h.x,target.y-h.y)||1;vx+=(target.x-h.x)/d*k;vy+=(target.y-h.y)/d*k;}
 const norm=Math.hypot(vx,vy)||1;vx/=norm;vy/=norm;let fx=vx||1,fy=vy;
 let guard=null,near=Infinity;for(const e of r.enemies){if(e.dead||!e.caravan)continue;const d=(h.x-e.x)**2+(h.y-e.y)**2;if(d<near){guard=e;near=d;}}if(guard){const d=Math.sqrt(near)||1;fx=(guard.x-h.x)/d;fy=(guard.y-h.y)/d;}
 plan.set(h.pid,[vx,vy,fx,fy]);const s=h.speed*h.mods.speedMul*dt;r.handle(h.pid,{t:'pos',x:h.x+vx*s,y:h.y+vy*s,fx,fy});}
function tick(measure=false){const t0=performance.now(),cp=measure?process.cpuUsage():null;r.tick(dt);if(measure){costs.push(performance.now()-t0);const used=process.cpuUsage(cp);cpuCosts.push((used.user+used.system)/1000);stats.maxHostile=Math.max(stats.maxHostile,r.hostile.length);stats.maxOrdinary=Math.max(stats.maxOrdinary,r.ordinaryEnemyCount());stats.maxEnemies=Math.max(stats.maxEnemies,r.enemies.length);if(r.tickNo%30===0)sizes.push(Buffer.byteLength(JSON.stringify(r.snapshot())));}}
let prefix={native:true,complete:false};
if(sceneId.startsWith('solo')){
 for(let frame=0;frame<r.runLength*C.TICK_HZ&&r.state==='play'&&r.time<r.runLength*.35-1e-4;frame++){for(const h of r.heroes.values())move(h,frame,'prefix');tick();if(r.frozen&&[...r.heroes.values()].some(h=>h.offer)){const before=r.time;r.tick(1);stats.offerFreezes+=Number(r.time===before);}drain();}
 prefix={native:true,complete:r.state==='play'&&r.time>=r.runLength*.35-1e-4,time:r.time,state:r.state,heroes:[...r.heroes.values()].map(inv),kills:r.kills,enemies:r.enemies.length};
}else{
 r.time=r.runLength*.35;
 if(sceneId==='eightSplitLoad'){
  const p=JSON.parse(fs.readFileSync(prefixArg));const source=p.prefix?.heroes?.[0];if(!source||!p.prefix.complete)throw Error('single native soloLunch prefix unavailable');
  const offsets=[[0,0],[400,0],[-400,0],[0,400],[0,-400],[700,400],[-700,-400],[2600,2100]];
  [...r.heroes.values()].forEach((h,i)=>{h.weapons=new Map(source.weapons.map(([id,w])=>[id,{...w}]));h.passives=new Map(source.passives);h.pval={...source.pval};h.level=source.level;h.xp=source.xp;r.recalcMods(h);h.hp=h.maxHp;[h.x,h.y]=offsets[i];if(i===7){h.st=1;h.hp=0;}});
 }else{
  for(const h of r.heroes.values()){h.weapons=new Map(['whip','tuning','knives','spear','flask','anchor'].map(id=>[id,{lvl:id==='whip'&&h.pid===1?4:5,t:.2}]));h.passives=new Map(['might','haste','area','crit','vigor','echo'].map(id=>[id,5]));h.pval={};r.recalcMods(h);h.hp=h.maxHp;r.updateCombos(h);r.grantOffer(h);}
 }
 prefix={native:false,complete:true,time:r.time,state:r.state,heroes:[...r.heroes.values()].map(inv),description:cfg.fixture};
}
let startAt=r.time,creation=null,replay=null;
if(prefix.complete){
 if(!r.caravan)tick();
 const c=r.caravan;if(c){creation={time:r.time,heroes:[...r.heroes.values()].map(inv),caravan:{...c},roster:{},hpPool:0};for(const e of r.enemies.filter(x=>x.caravan===c)){const id=C.ENEMY_TYPES[e.type];creation.roster[id]=(creation.roster[id]??0)+1;creation.hpPool+=e.maxHp;}
  if(sceneId==='eightSplitLoad'){const hs=[...r.heroes.values()].filter(h=>h.st===0);for(let i=0;i<350;i++)r.spawnEnemy(['skel','ghoul','brute','spitter'][i%4],hs,C.enemyHpScale(r.nt,r.heroes.size));}
  if(sceneId==='soloLunch'){const before=JSON.stringify({t:r.time,p:c.progress,h:r.hostile.map(s=>[s.id,s.x,s.y,s.life])});r.handle(1,{t:'pause',v:true});r.tick(1);stats.pause=before===JSON.stringify({t:r.time,p:c.progress,h:r.hostile.map(s=>[s.id,s.x,s.y,s.life])});r.handle(1,{t:'pause',v:false});}
  const max=sceneId==='soloLunch'?121:r.runLength*.2+1;
  for(let frame=0;frame<max*C.TICK_HZ&&r.state==='play';frame++){
   for(const h of r.heroes.values())move(h,frame,'event');tick(true);
   if(sceneId!=='duoOpenOfferFullPool')drain();
   stats.open??=c.status==='open'?r.time:null;stats.claimed??=c.status==='claimed'?r.time:null;stats.expiry??=c.status==='expired'?r.time:null;
   if(sceneId==='eightSplitLoad'&&r.time-startAt>=60&&!stats.leave&&r.heroes.has(8)){const g=r.enemies.find(e=>e.caravan===c&&!e.dead),old=g?{id:g.id,hp:g.hp,maxHp:g.maxHp,dmg:g.dmg}:null;r.removePlayer(8);stats.leave={time:r.time,old,now:g?{hp:g.hp,maxHp:g.maxHp,dmg:g.dmg}:null,total:c.total};}
   if(c.status==='claimed'){
    const before=[...r.heroes.values()].map(inv),messageStart=messages.length;for(const h of r.heroes.values())r.resync(h.pid);
    if(sceneId==='duoOpenOfferFullPool'){for(const h of r.heroes.values()){const old=stats.preclaim?.find(x=>x.pid===h.pid)?.epoch;r.handle(h.pid,{t:'pick',i:0,offerEpoch:old});}}
    const stale=[...r.heroes.values()].map(inv);for(let i=0;i<6;i++)tick(true);replay={before,afterStale:stale,after:[...r.heroes.values()].map(inv),messages:messages.slice(messageStart)};break;
   }
   if(c.status==='expired')break;
  }
 }
}
const quantile=(xs,p)=>xs.length?xs.slice().sort((a,b)=>a-b)[Math.min(xs.length-1,Math.floor(xs.length*p))]:null;
const report={protocolSha256:crypto.createHash('sha256').update(fs.readFileSync(new URL('./protocol.json',import.meta.url))).digest('hex'),app,sceneId,seed:cfg.seed,node:process.version,sourceHashes:Object.fromEntries(['server/game.js','server/caravans.js','public/shared/content.js'].map(f=>[f,crypto.createHash('sha256').update(fs.readFileSync(path.join(app,f))).digest('hex')])),prefix,creation,stats,final:{state:r.state,time:r.time,caravan:r.caravan?{...r.caravan}:null,heroes:[...r.heroes.values()].map(inv),guards:r.enemies.filter(e=>e.caravan&&!e.dead).length,reforges:[...r.runLog.p].map(([pid,p])=>[pid,p.reforges]),damage:[...r.runLog.p].map(([pid,p])=>[pid,p.taken])},replay,messages,performance:{ticks:costs.length,p99WallMs:quantile(costs,.99),meanWallMs:costs.reduce((a,b)=>a+b,0)/(costs.length||1),p99CpuMs:quantile(cpuCosts,.99),snapshotCount:sizes.length,meanSnapshotBytes:sizes.reduce((a,b)=>a+b,0)/(sizes.length||1)}};
fs.writeFileSync(out,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({sceneId,node:process.version,prefix:prefix.complete,status:r.caravan?.status,time:r.time,guards:report.final.guards,guardDamage:stats.guardDamage,claimed:stats.claimed,performance:report.performance}));
