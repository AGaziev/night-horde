# Preregistered baseline observation

Baseline SHA cbf25ec1bb48d70f53d949c105b7ad5981722963; Node v24.22.1; native Room.tick 30Hz. Protocol SHA256 401aff43adc9c6ed0868d26c88a2c7ea5c027bb19f4fbe46cd490a424d54cff5 was written before these observations. Raw JSON is authoritative.

The fixed ordinary-card policy yielded one weapon (whip5), level12, in both solo prefixes. The lunch prefix's HP was44.65/140; night180.35/240. This is a valid bounded native fixture and is visibly too narrow to establish ordinary-player balance. No parameter or seed is changed after observing it.

- soloLunch: caravan HP2781.71; first actual guard hit216.37; hero died293.17 with8 guards left, no cargo claim. Esc freeze passed;11 natural offer freeze observations. This is a terminal loss for this fixture, not a measured general win-rate.
- soloNight: HP2635.23; first guard hit321.63; withdrawal starts360; hero died443.63 with9 guards left. No cargo claim or cargo reward. Native abandonment expiry was not reached in this solo scene.
- eightSplitLoad: HP60311.51,26guards; first guard hit346; native expiry495, no claim. Fixed7live+1downed roster and350 ordinary seeded load; max483 total/457 ordinary/90 hostile. Leave8->7 at375. p99wall1.13ms is diagnostic, not clean paired performance acceptance.
- duoOpenOfferFullPool: HP5244.65; first guard hit214.07; native open231.10 and75-radius claim231.43. Baseline grants15%XP/10%heal and no reforge as expected. This prepared max-inventory compatibility fixture is not ordinary-build balance.

Limitations found in instrumentation: solo `actualDamageTaken` totals include the prefix; do not label them event-only. Use initial/final native HP and actual guard-damage observations with that boundary. `guardDamage` measures real native calls, but cannot alone establish an accessible encounter. `preclaim` is captured at reforge entry, so it is absent on the baseline which has no caravan reforge; compare prefix/replay states there. Two baseline processes overlapped after PTY yielded, so CPU/wall results must remain diagnostic. This did not change their per-process seeded native state; no performance conclusion based on that pairing is allowed.

No product source changes, production access, HTTP listener, remote writes or retuning performed. Temporary run-log directories are owned and will be deleted after review.
