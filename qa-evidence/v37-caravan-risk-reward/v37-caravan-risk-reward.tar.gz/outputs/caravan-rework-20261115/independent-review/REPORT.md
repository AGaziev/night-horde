# Issue76 independent review — frozen5494ed8

**No confirmed blocking regression. Code/reward and the scoped mobile visual check: PASS. Ordinary-build event accessibility and overall risk/reward acceptance: NOT VERIFIED. Overall STATUS: INCOMPLETE.** This report does not provide whole-game balance READY.

Issue76, dedicated branch/PR. Reviewed immutable commits ec69e9f,9338a6e,ae591f9 and final integrated candidate **5494ed8bc2094168b1821002f581afb2cacea5bc**. Comparison baseline remains **cbf25ec1bb48d70f53d949c105b7ad5981722963**, not4454f7. Current main4454f711267317d3a212dcebee86b08ead2e2325 is included in the candidate. Independent reviewer did not author product code. No source edits, commits, push, GitHub writes, production or CTQ calls.

AGENTS, PROJECT, QUALITY, review-master and Issue76 criteria were read. Source integrity verified217 archived files after all execution against `git archive5494ed8 app pm/test-runtime.mjs`; see `source-integrity.json`. Runtime Nodev24.22.1. Temporary runtime/browser sources are isolated artifacts; actual source worktree stayed clean.

## Findings and technical coverage

No IMPORTANT/CRITICAL regression confirmed after source search and a separate attempt to refute the candidate concerns. No candidate was converted into a finding merely from numerical balance differences or a prepared fixture loss.

- Placement examines every participant including split/downed heroes and the nearest point of the entire900-unit segment. Search/fallback loops are finite;99000 coordinate limit leaves room for520-unit guard leash and bodies inside100000 world. Distances and all1–8 rosters are covered by the executed threat suite, plus independent raw-scene assertions.
- One immutable32+4(n−1) cohort, family HP/damage multipliers and ordinary budgets match the agreement. `creationNt` governs8→7 rescaling, preserving partial HP and composition. No reserves or replacement cohort added.
- Native spitter shots carry `caravan:shot` and ownership, launch-circle720 bound and native TTL clipping. Their limit is min(nativeTTL,2.4,ray-circle intersection). Wagon movement cannot extend it. Native inside/outside hits, preparation, pursuit and selective claim/expiry/finale cleanup executed in the threat suite.
- Reward sets claimed before callbacks, clears owned shots and applies native reforge before25%XP and20%livingHP. Downed vigor, noRarity/max pools, fallback receipt/log, reentrant/replayed claim, expiry/finale, resync, duo/imprint epochs and XP queues are covered by actual final reward tests. No forge/victory flags are consumed or granted.
- New source-specific fallback has no effect on other reforge sources. Runlog labels a real caravan reforge separately from a fallback; final native reward scene logged exactly one entry per recipient.

Five independently executed final suites all exited0: `caravan-reward-test.js` (6 subtests), `caravan-threat-test.js`, `caravans-client-test.js`, `caravans-test.js`, `slash-corner-test.js`. Commands: Node24 `--import ./source/pm/test-runtime.mjs ./source/app/server/<suite>`, cwd this report directory. Raw `final-*.log` and `final-targeted-tests.json` preserve execution. Parent executor owns full final ServerCI and its SHA attribution; it was still pending when this report was written. The5-suite result is not a fullCI substitute.

## Four preregistered native event comparisons

`protocol.json` SHA256 **401aff43adc9c6ed0868d26c88a2c7ea5c027bb19f4fbe46cd490a424d54cff5** was written before observations. Four fixed seeds7601,7602,7608,7620; no seed retry, parameter search or retuning. `native-event.mjs` uses real Room.tick30Hz, native weapon/hostile/contact and speed-limited pos input, retaining waves/bosses/peaks. No direct kill/hurt invocation, HP refill, player teleport or damage override occurs during the measured events. Explicit8-player and max-inventory setup is fixture preparation, not live frequency evidence.

| Fixed scene | Baseline guardHP | Candidate guardHP | First actual hit baseline→candidate | Native outcome |
| --- | ---: | ---: | --- | --- |
| Solo Обед |2781.71|7692.64 (×2.765)|216.37→233.23|Baseline death293.17 with8 guards; candidate death235.33 with32. No claim. |
| Solo Ночь |2635.23|7287.56 (×2.765)|321.63→336.53|Withdrawal at360; baseline death443.63 with9 guards; candidate death392.67 with32. No claim/expiry reached. |
|8 split/downed +350 ordinary|60311.51|197894.54 (×3.281)|346.00→373.00|Baseline expiry495; candidate death438.07 with60 guards. Native shots47; no claim. |
|Duo open offers/fullpool|5244.65|15021.70 (×2.864)|214.07→223.07|Candidate open235.93, native radius claim236.03. Reward compatibility passed. |

All candidate scene starts were2600–3200 from at least one alive anchor, ≥2200 from all participants, with entire route ≥1800. Independent min segment distances were2723.94/2901.26/2728.87/2603.78. Expected32/32/60/36 rosters passed. `comparison.json` and8 raw baseline/candidate JSON files contain all observations.

The fixed native ordinary-card prefix yielded level12, **one whip5**, and lunchHP44.65/140, nightHP180.35/240. Both revisions had byte-equal prefix inventory, XP and HP for the two solo cases. This is a narrow, under-equipped fixture. Its failures do not demonstrate a usual-player failure frequency or justify a new balancing blocker by themselves. No alternative inventory was selected after seeing them. Ordinary accessibility to clear before expiry, intended fight duration and balanced reward value remain **NOT VERIFIED** by these scenes. Candidate8 died before the native.5 peak; sustained350+60+peak load is also **NOT VERIFIED** here. No terminal whole-game outcome/win-rate conclusion is drawn from these event-only observations.

Native caravan contact/shot damage was observed: candidateLunch shot7.25HP; candidateNight contact7.85HP; candidate8 contact70.17+shot10.93HP. Actual measured attacks inflicted433.44/884.40/11977.14 guard damage in those failed scenes. These counters do not replace successful gameplay acceptance. Solo `actualDamageTaken` raw totals include the prefix; they must not be quoted as event-only total damage. Esc freeze passed; natural offer freeze observations were from the native prefix.

The duo scene starts with explicit legal full inventories, one eligible whip4 onP1 and an empty reforge pool onP2. Real native attacks killed every guard, and movement into75-unit cargo radius triggered claim. P1 becamewhip5; P2 received `{result:null,fallback:{kind:'reroll',amount:1}}`; both rerolls2→3. XP moved both fromlevel7/xp75/queue7 tolevel8/xp13.5/queue8, exactly25% of native threshold82. P1 stale epoch1 was rejected at current3 with no resource change. P2 fallback leaves its card identity/current epoch2 valid, so its deliberate old2 pick correctly consumed one queued offer; this is not stale acceptance. Resync replayed receipts, repeated ticks added no reward, and logs stayed one per recipient. HP was already maximum in this strong fixture: fractional heal and downed behavior are established by targeted tests, not a native injured duo acceptance scene. Fresh-epoch duo/imprint acceptance is similarly unit/contract evidence, not the fullpool native inventory.

Performance is diagnostic: candidate8 p99wall1.196ms under the executed fixture (<33.3ms budget), mean.620ms. Two baseline processes overlapped, and the revisions had different survival time/load paths; do not treat their CPU/wall ratios as a clean performance-regression experiment. Snapshots remained finite and were sampled. No packet-loss/reconnect transport journey was added because this diff does not change snapshot codec; parent final integration/network suites cover current protocol36.

## Final native browser spot proof and carry boundary

Installed Chrome157.0.8103.51, `--mute-audio`, mobile390×844, on the exact archived5494ed8 app. `visual-fixture.mjs` is a disclosed adaptation of the author's supplied native fixture, independently executed. Actual create/start UI→WS→Room snapshot/native automatic Whip→production renderer. Owned test IPC advances event time, translates native wagon/guards and selects open state. It does not prove a natural event or native browser reward journey.

`result.json`: **PASS** loaded guarded/open sprite, fallback, current0/32 HUD, no blade border/fill, two crescent ellipses and native slashBounds clip. World-anchored isolated native slash rendered with0 player-position lookups,1552 visible pixels and0 outside bounds. All four images (`mobile-guarded.png`, `mobile-open.png`, `mobile-fallback.png`, `mobile-isolated-native-slash.png`) were opened and visually inspected. Updated reward HUD wraps legibly and keeps gameplay controls available. Browser native award toast/accessibility/focus and a complete mobile/desktop reward flow remain outside this spot proof; contract UI tests and parent's integrated author browser evidence must be attributed separately.

Asset and manifest are byte-identical to the author's final192×136,44039-byte PNG/manifest. Final render differs from ec69e9f only in an imported wardCharges helper/use for an accepted main feature; caravan and slash bodies are unchanged. Author desktop/mobile style evidence can carry for these unchanged visual bodies and sprite, not as an integrated final reward-flow claim. The earlier baseline→4454f7 main delta contains support/control accounting and dash implementation. This policy never requests dash, solo prefixes agree exactly, and the selected ordinary gear has no new dash. Some main code also changes control attribution/caps and collision paths, so the raw cbf→5494ed8 event deltas are not represented as a fully isolated caravan causal comparison. Parent author package4454f7→5494ed8 is the cleaner sibling baseline.

## Cleanup and finite remaining evidence

`cleanup-independent.json`: owned server exited0, Chrome closed, owned temporary run directories removed, no lsof LISTEN on port54083, Node health fetch unreachable EPIPE, final source worktree clean and `git diff --check`0. Raw Python connect_ex0 was inconclusive in this environment and deliberately not used as cleanup proof.

No source fix requested by this reviewer. Parent/CEO should combine the current fullCI and independently assess the author's fixed ordinary gameplay evidence. If no stronger ordinary-build clear and applicable peak/load evidence exists, preserve runs **INCOMPLETE/NOT VERIFIED**; these four fixture results alone do not establish READY. This is a finite coverage boundary, not a request for a new full-run matrix or retuning search.

STATUS: INCOMPLETE
