import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import net from 'node:net';
import crypto from 'node:crypto';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {setTimeout as wait} from 'node:timers/promises';
import {chromium} from '/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';

const out=path.dirname(new URL(import.meta.url).pathname),source=path.join(out,'source');
const runs=fs.mkdtempSync(path.join(os.tmpdir(),'caravan-visual-author-'));
const probe=net.createServer();probe.listen(0,'127.0.0.1');await once(probe,'listening');
const port=probe.address().port;await new Promise(resolve=>probe.close(resolve));
const base='http://127.0.0.1:'+port;
const wrapper=`
const {Room}=await import(${JSON.stringify(source+'/app/server/game.js')});
const rooms=new Map(),start=Room.prototype.start;
Room.prototype.start=function(){const v=start.call(this);rooms.set(this.code,this);this.spawn=()=>{};this.events.next=Infinity;return v;};
process.on('message',m=>{const r=rooms.get(m.code);if(!r)return;
 if(m.cmd==='caravan')r.time=r.runLength*.35;
 if(m.cmd==='position'&&r.caravan){const h=[...r.heroes.values()][0],c=r.caravan,dx=h.x+170-c.x,dy=h.y-100-c.y;for(const k of ['x','ax','bx'])c[k]+=dx;for(const k of ['y','ay','by'])c[k]+=dy;for(const e of r.enemies)if(e.caravan===c){e.x+=dx;e.y+=dy;}r.snapshot();}
 if(m.cmd==='open'&&r.caravan){r.caravan.status='open';r.caravan.killed=r.caravan.total;r.enemies.length=0;r.snapshot();}
});
await import(${JSON.stringify(source+'/app/server/server.js')});`;
const child=spawn(process.execPath,['--import',source+'/pm/test-runtime.mjs','--input-type=module','-e',wrapper],{cwd:source,env:{...process.env,PORT:String(port),HORDE_RUNS_DIR:runs,VIBE_APP_KEY:''},stdio:['ignore','pipe','pipe','ipc']});
const childExit=once(child,'exit');let log='',browser;
child.stdout.on('data',d=>log+=d);child.stderr.on('data',d=>log+=d);
const result={baseline:'cbf25ec1bb48d70f53d949c105b7ad5981722963',node:process.version,base,runs,scenes:[],scope:'Visual-only source snapshot: archived baseline server/shared files plus author render.js, manifest.json, caravan.png. Actual UI -> WS -> Room, native automatic Whip event and production rendering. Test-only IPC advances owned Room time, translates caravan+guards into viewport and selects open state. No natural-run balance acceptance.'};
try{
 let ready=false;for(let i=0;i<100&&!ready;i++){assert.equal(child.exitCode,null,'owned server stays alive');ready=await fetch(base+'/health',{signal:AbortSignal.timeout(1500)}).then(r=>r.ok,()=>false);if(!ready)await wait(50);}assert.ok(ready);
 browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true,args:['--mute-audio','--disable-features=LocalNetworkAccessChecks']});result.chrome=browser.version();
 for(const [name,width,height,mobile]of[['desktop',1280,800,false],['mobile',390,844,true]]){
  const context=await browser.newContext({viewport:{width,height},deviceScaleFactor:1,isMobile:mobile,hasTouch:mobile});
  await context.route('**/*',route=>route.request().url().startsWith(base)?route.continue():route.abort());
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto(base);await page.waitForFunction(()=>__nh?.net.connected&&__nh.renderer.sprites.ready);
  await page.locator('#menu-create').click();await page.locator('#lobby-start').click();await page.waitForFunction(()=>__nh.game.latest());
  const code=await page.evaluate(()=>__nh.state.lobby.code);child.send({cmd:'caravan',code});await page.waitForFunction(()=>__nh.game.latest()?.cv);child.send({cmd:'position',code});
  await page.waitForFunction(()=>{const g=__nh.game,c=g.latest()?.cv;return c&&Math.abs(c.x-g.local.x)<300;});
  await page.evaluate(()=>{
   const renderer=__nh.renderer,capture=window.__capture={armed:true,frozen:null,calls:{},stage:null};
   for(const method of ['fillRect','strokeRect','drawImage','rect','clip','ellipse','fill','strokeText','fillText']){
    const original=CanvasRenderingContext2D.prototype[method];CanvasRenderingContext2D.prototype[method]=function(...args){
     if(capture.stage)capture.calls[capture.stage].push({method,args:args.map(v=>typeof v==='number'||typeof v==='string'?v:v?.constructor?.name),fill:this.fillStyle,stroke:this.strokeStyle,alpha:this.globalAlpha,font:this.font,textWidth:method==='fillText'?this.measureText(args[0]).width:null});
     return original.apply(this,args);
    };
   }
   for(const [method,stage]of[['drawCaravan','caravan'],['drawEffects','effects']]){const original=renderer[method];renderer[method]=function(...args){capture.stage=stage;capture.calls[stage]=[];try{return original.apply(this,args);}finally{capture.stage=null;}};}
   const original=renderer.draw;renderer.draw=function(game,dt){if(capture.frozen)return;original.call(this,game,dt);if(capture.armed&&game.slashes.some(s=>s.t<.06)&&game.view.b?.cv)capture.frozen={slashes:structuredClone(game.slashes),caravan:structuredClone(game.view.b.cv),local:structuredClone(game.local),spriteReady:this.sprites.ready,sprite:!!this.sprites.get('caravan'),zoom:this.zoom};};
  });
  async function scene(state){
   await page.waitForFunction(()=>__capture.frozen,null,{timeout:10000});
   await page.screenshot({path:path.join(out,name+'-'+state+'.png')});
   const row=await page.evaluate(()=>({frozen:__capture.frozen,calls:__capture.calls,fontStatus:document.fonts.status}));row.name=name;row.state=state;
   assert.ok(row.calls.effects.some(c=>c.method==='clip'),'slash clipping stays');
   assert.ok(row.calls.effects.filter(c=>c.method==='ellipse').length>=2,'crescent stays');
   assert.ok(!row.calls.effects.some(c=>c.method==='strokeRect'),'no slash bounding border');
   assert.ok(!row.calls.effects.some(c=>c.method==='fillRect'&&c.fill==='rgba(144, 202, 249, 0.12)'),'no slash rectangular fill');
   if(state==='fallback'){
    assert.equal(row.calls.caravan.filter(c=>c.method==='drawImage').length,0);assert.ok(row.calls.caravan.some(c=>c.method==='fillRect'));
   }else{
    assert.equal(row.calls.caravan.filter(c=>c.method==='drawImage').length,1);assert.ok(!row.calls.caravan.some(c=>c.method==='fillRect'));
   }
   assert.ok(row.calls.caravan.some(c=>c.method==='ellipse'),'shadow stays');
   assert.ok(row.calls.caravan.some(c=>c.method==='fillText'&&c.args[0].includes(row.frozen.caravan.status==='open'?'Заберите груз':'Караван')&&c.fill==='#fff0b8'),'state label and light text stay');
   const label=row.calls.caravan.find(c=>c.method==='fillText'),center=width/2+(row.frozen.caravan.x-row.frozen.local.x)*row.frozen.zoom;
   assert.ok(center-label.textWidth*row.frozen.zoom/2>=0&&center+label.textWidth*row.frozen.zoom/2<=width,'whole caravan label stays within fixture viewport');
   result.scenes.push(row);
  }
  await scene('guarded');
  child.send({cmd:'open',code});child.send({cmd:'position',code});await page.waitForFunction(()=>__nh.game.latest()?.cv?.status==='open'&&Math.abs(__nh.game.latest().cv.x-__nh.game.local.x-170)<10);
  await page.evaluate(()=>__capture.frozen=null);await scene('open');
  child.send({cmd:'position',code});await page.waitForFunction(()=>Math.abs(__nh.game.latest().cv.x-__nh.game.local.x-170)<10);
  await page.evaluate(()=>{__nh.renderer.sprites.ready=false;__capture.frozen=null;});await scene('fallback');
  const anchored=await page.evaluate(()=>{
   const renderer=__nh.renderer,s=structuredClone(__capture.frozen.slashes[0]);s.t=0;
   const canvas=document.createElement('canvas');canvas.width=400;canvas.height=200;const ctx=canvas.getContext('2d');ctx.translate(200,100);
   let playerPosCalls=0;const game={slashes:[s],rings:[],zaps:[],particles:[],numbers:[],playerPos(){playerPosCalls++;throw Error('World-anchored slash must not follow player');}};
   renderer.drawEffects(ctx,game);
   const calls=structuredClone(__capture.calls.effects),data=ctx.getImageData(0,0,400,200).data,bounds={x:s.dir>0?s.x:s.x-s.range,y:s.y-s.width/2,width:s.range,height:s.width};
   let opaque=0,outside=0;for(let y=0;y<200;y++)for(let x=0;x<400;x++)if(data[(y*400+x)*4+3]){opaque++;if(x<bounds.x+200||x>=bounds.x+bounds.width+200||y<bounds.y+100||y>=bounds.y+bounds.height+100)outside++;}
   return{event:s,playerPosCalls,bounds,calls,opaque,outside,png:canvas.toDataURL('image/png')};
  });
  fs.writeFileSync(path.join(out,name+'-isolated-native-slash.png'),Buffer.from(anchored.png.split(',')[1],'base64'));delete anchored.png;
  assert.equal(anchored.playerPosCalls,0);assert.ok(anchored.opaque>0);assert.equal(anchored.outside,0);result.scenes.push({name,state:'isolated-native-slash',...anchored});
  assert.deepEqual(errors,[]);await context.close();
 }
 result.sourceHashes=Object.fromEntries(['app/public/js/render.js','app/public/sprites/manifest.json','app/public/sprites/caravan.png','app/server/game.js','app/public/shared/combat-geometry.js'].map(p=>[p,crypto.createHash('sha256').update(fs.readFileSync(path.join(source,p))).digest('hex')]));
 result.status='PASS: desktop/mobile sprite guarded+open, native fallback, no blade rectangle, crescent clipped at native world origin';console.log(result.status);
}finally{
 await browser?.close();child.kill();result.childExit=await childExit;fs.rmSync(runs,{recursive:true,force:true});
 result.cleanup={serverStopped:true,browserClosed:true,runsRemoved:!fs.existsSync(runs)};fs.writeFileSync(path.join(out,'result.json'),JSON.stringify(result,null,2));fs.writeFileSync(path.join(out,'server.log'),log);
}
