# Issue 76: visual author handoff

PASS for the delegated visual scope. Final runtime asset is `caravan.png`, 192×136, 44,039 bytes, one frame, anchor `[79,124]`. SHA-256: `a2b438defd284fb8b3dfee88bf6a84cdf26e6462b787eee120739b980b12cb5d`.

## Product delta

- `app/public/js/render.js`: `drawCaravan` now consumes `sprites.get('caravan')` through existing `blit`, with full-frame world width 110 and ground anchor y=27. Existing shadow and guarded/open labels remain. Label fill color is explicit so the loaded sprite branch keeps the original readable pale text. Existing procedural guarded/open silhouettes remain when the atlas or sprite is unavailable.
- `app/public/sprites/manifest.json`: single caravan entry, cell `[192,136]`, frames 1, fps 0, anchor `[79,124]`.
- Removed only the visible blue rectangle fill/stroke around ordinary Whip slashes. Event world position, slash lifetime, `slashBounds` clip and the two crescent ellipses remain. The visual changes do not modify server damage code or shared geometry.
- The separate asset author owns `caravan.png`. No `sprites.js` or other product files were changed by the visual author. No commit, push or GitHub mutation was performed by this agent.

## Final primary browser evidence

Installed Chrome `157.0.8103.51`, `--mute-audio`, Node `v24.22.1`. Desktop 1280×800 and touch/mobile 390×844. `source/` is the exact `cbf25ec1bb48d70f53d949c105b7ad5981722963` app archive with only the final render, manifest and PNG overlaid. This isolates visual changes from the concurrently developed caravan balance changes.

Actual page → create/start UI → WS → native Room snapshots and automatic Whip events → production renderer. Owned fixture IPC advances the Room to the caravan window, places its native caravan/guards inside the viewport and selects the open state. Renderer instrumentation records existing draw calls and freezes a rendered frame. It does not replace rendering. No natural-run difficulty, reward, frequency or balance claim is made.

All six final screenshots were opened and visually inspected:

- `desktop-guarded.png`, `desktop-open.png`, `desktop-fallback.png`.
- `mobile-guarded.png`, `mobile-open.png`, `mobile-fallback.png`.

Assertions and captured calls in `result.json` prove:

- Loaded guarded/open states use exactly one `drawImage`, with no procedural cart rectangles.
- The unready-atlas state uses the existing procedural fallback, zero `drawImage` calls, with its shadow and label.
- Guarded/open labels retain pale `#fff0b8` text and fit completely within both fixture viewports; `document.fonts.status` is `loaded`.
- Every native slash frame keeps `clip` and two ellipse calls. No rectangular border or blue rectangular fill remains in the effect.
- Direct rendering of the captured native slash against a deliberately unavailable `playerPos` succeeds with zero position lookups, preserving the event world origin. Both desktop/mobile controls show 1552 visible pixels and zero outside native `slashBounds`. See `desktop-isolated-native-slash.png` and `mobile-isolated-native-slash.png`.

`source.json` and `result.json` contain final hashes. The source copy's `app/server/game.js` and `app/public/shared/combat-geometry.js` were verified byte-for-byte against baseline Git objects. The final working visual files were independently checked to match the captured hashes.

Existing regressions passed: renderer syntax, `caravans-client-test.js`, and `slash-corner-test.js` (24/24). They used the same byte-identical final renderer; only PNG dimensions/manifest anchor changed afterward and were covered by the final browser run. Details in `verification.json`.

## Rerun and cleanup

From this folder: `/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node --import ./source/pm/test-runtime.mjs fixture.mjs`.

The fixture selects a unique loopback port and owned temporary `HORDE_RUNS_DIR`, leaves `VIBE_APP_KEY` empty and blocks non-local browser requests. `cleanup-independent.json` confirms process exit, closed Chrome, deleted run data, no remaining listener and clean `git diff --check`.

The original 1491×1055 iteration, its source and screenshots are retained under `iteration-original/`. It is not the final runtime evidence. No production access or network-setting changes were made. Full integrated balance/UI acceptance and final candidate CI remain with the parent executor.
