// Adds only an explicit input policy; canonical movement/choices/RNG remain unchanged.
const {Room}=await import(process.env.APP+'/server/game.js');
const {DASH}=await import(process.env.APP+'/public/shared/mobility.js');
const originalHandle=Room.prototype.handle,originalTick=Room.prototype.tick;
const records=[],pending=new Map();let attempted=0,rejected=0,cooldownViolations=0,iframesAdded=0;
const damage=(r,pid)=>Object.values(r.runLog?.p?.get(pid)?.taken??{}).reduce((a,b)=>a+b,0);
Room.prototype.handle=function(pid,msg){
 if(msg?.t==='pos'){
  const h=this.heroes.get(pid),dx=msg.x-(h?.x??0),dy=msg.y-(h?.y??0);
  if(h&&this.state==='play'&&!this.frozen&&!this.paused&&!h.offer&&!h.offline&&h.st===0&&!h.dash&&this.time>=(h.dashReadyAt??0)&&Number.isFinite(dx)&&Number.isFinite(dy)&&Math.hypot(dx,dy)>.01){
   attempted++;const epoch=h.moveEpoch??0,beforeIframes=h.iframes,ready=h.dashReadyAt??0;
   originalHandle.call(this,pid,{t:'dash',x:dx,y:dy});
   if((h.moveEpoch??0)>epoch){if(this.time+1e-8<ready)cooldownViolations++;if(h.iframes>beforeIframes+1e-8)iframesAdded++;const rec={pid,at:this.time,readyAt:h.dashReadyAt,from:[h.x,h.y],direction:[dx/Math.hypot(dx,dy),dy/Math.hypot(dx,dy)],hpBefore:h.hp,takenBefore:damage(this,pid),iframesBefore:beforeIframes,epoch:h.moveEpoch};records.push(rec);pending.set(pid,rec);}
   else rejected++;
  }
  // The client uses the server-owned epoch after each accepted dash.
  return originalHandle.call(this,pid,{...msg,epoch:h?.moveEpoch??0});
 }
 return originalHandle.call(this,pid,msg);
};
Room.prototype.tick=function(...args){const value=originalTick.apply(this,args);for(const[pid,rec]of pending){const h=this.heroes.get(pid);if(!h||!h.dash||h.st!==0||this.state!=='play'){Object.assign(rec,{endedAt:this.time,to:h?[h.x,h.y]:null,hpAfter:h?.hp,actualHpDamage:damage(this,pid)-rec.takenBefore,alive:h?.st===0,state:this.state,distance:h?Math.hypot(h.x-rec.from[0],h.y-rec.from[1]):null});pending.delete(pid);}}return value;};
try{await import(new URL('../harness/pm/run-sim.mjs',import.meta.url));}
finally{process.stderr.write('DASH_POLICY_METRICS '+JSON.stringify({policy:'Move direction whenever ready;12 active seconds; skip idle/offer/pause/offline; epoch-compatible pos',version:1,canonicalChoicesAndMovementUnmodified:true,noExtraRngCalls:true,dash:DASH,attempted,accepted:records.length,rejected,cooldownViolations,iframesAdded,damagingDashes:records.filter(r=>r.actualHpDamage>0).length,records})+'\n');}
