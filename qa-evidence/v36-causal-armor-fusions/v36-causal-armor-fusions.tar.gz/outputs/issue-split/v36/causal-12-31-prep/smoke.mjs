import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {pathToFileURL} from 'node:url';import crypto from 'node:crypto';import {verifyBinding,assertEffects,installObserver} from './observer.mjs';
const out=path.dirname(new URL(import.meta.url).pathname),all=JSON.parse(fs.readFileSync(path.join(out,'source-bindings.json'))),variants=all.filter(b=>b.sourceKind==='output-only-patched'),reports=[];
process.env.HORDE_RUNS_DIR=path.join(out,'smoke-data/runs');fs.mkdirSync(process.env.HORDE_RUNS_DIR,{recursive:true});
for(const b of variants){verifyBinding(b);const {Room}=await import(pathToFileURL(b.APP+'/server/game.js')),C=await import(pathToFileURL(b.APP+'/public/shared/content.js'));let observer;
 function scene(observed){let seed=9182,draws=0;const original=Math.random;Math.random=()=>{draws++;seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};try{
  if(observed)observer=installObserver(Room,C,{binding:b,outputFile:path.join(out,'smoke-data',b.variantId+'-counter.json')});
  const r=new Room('SHORT-SMOKE',()=>{});r.setMode('lunch');for(let pid=1;pid<=4;pid++)r.addPlayer(pid,'S'+pid,'ranger');
  if(b.expected.issue===12){r.handle(r.host,{t:'daily',enabled:true});r.lockDaily('2026-11-13T12:00:00Z');assert.equal(r.daily.id,'armor');}
  assertEffects(r,C,b);r.start();assert.equal(r.state,'play');const hs=[...r.heroes.values()],h=hs[0];for(const p of hs){p.x=500+p.pid*100;p.y=0;p.weapons.clear();p.perk.readyAt=Infinity;}
  assert.equal(h.mods.armor,b.expected.issue===12?b.expected.mods.armor:0);assert.equal(h.mods.speedMul,b.expected.issue===12?b.expected.mods.speed:1);
  if(b.expected.issue===31){assert.equal(r.modeHp,b.expected.hpMul);assert.equal(r.modeDmg,b.expected.dmgMul);}
  const foe=r.spawnEnemy('ghoul',hs,C.enemyHpScale(r.nt,4));assert.ok(Math.abs(foe.maxHp-C.ENEMIES.ghoul.hp*C.enemyHpScale(r.nt,4)*r.modeHp)<1e-8);assert.ok(Math.abs(foe.dmg-C.ENEMIES.ghoul.dmg*C.enemyDmgScale(r.nt,4)*r.modeDmg*r.finDmg)<1e-8);foe.x=0;foe.y=0;
  for(let tick=0;tick<3;tick++)r.tick(1/30);
  const startHp=h.hp;h.iframes=0;r.hurtPlayer(h,1,'ghoul');const afterFloor=h.hp;h.iframes=0;r.hurtPlayer(h,9,'spitter:shot');
  h.weapons=new Map([['bolt',{lvl:3,t:0}],['lightning',{lvl:3,t:0}]]);const card=r.duoCard(h,{id:'orb',a:'bolt',b:'lightning'});assert.equal(r.fuseDuo(h,card),true);assert.equal(h.weapons.size,1);
  if(b.expected.issue===31){foe.x=h.x+80;foe.y=h.y;r.rebuildGrid();r.updateWeapon(h,'orb',h.weapons.get('orb'),.5);assert.ok(r.orbs.some(o=>o.owner===h&&o.src.weapon==='orb'));assert.equal(h.dmgBy.bolt??0,0);assert.equal(h.dmgBy.lightning??0,0);}
  h.iframes=0;r.hurtPlayer(h,3,'ghoul');
  const gameplay={time:r.time,state:r.state,heroes:hs.map(p=>({pid:p.pid,x:p.x,y:p.y,hp:p.hp,armor:p.mods.armor,speed:p.mods.speedMul,weapons:[...p.weapons].map(([id,w])=>[id,w.lvl])})),enemies:r.enemies.map(e=>[e.id,e.x,e.y,e.hp,e.maxHp,e.dmg]),fx:r.fx,ward:h.ward};
  let trace;if(observed){trace=observer.flush(r,'short-smoke-no-terminal');assert.equal(trace.payload.rooms[0].finishCalls,0);assert.ok(Object.keys(trace.payload.rooms[0].incoming).some(k=>k.endsWith('beforeFirstTeamDuo')));assert.ok(Object.keys(trace.payload.rooms[0].incoming).some(k=>k.endsWith('afterFirstTeamDuo')));assert.ok(trace.payload.rooms[0].firstTeamDuo!==null);observer.uninstall();}
  return {gameplay,draws,startHp,afterFloor,traceHash:trace?.countertraceSHA256};
 }finally{Math.random=original;}}
 const plain=scene(false),observed=scene(true);assert.deepEqual(observed.gameplay,plain.gameplay,'same APP observer on/off actual gameplay');assert.equal(observed.draws,plain.draws,'same APP observer draws zero additional gameplay RNG');reports.push({variantId:b.variantId,binding:b,shortSmokeOnly:true,notAcceptanceOutcome:true,terminal:false,simulatedSeconds:observed.gameplay.time,observerNeutral:true,draws:observed.draws,armor:observed.gameplay.heroes[0].armor,speed:observed.gameplay.heroes[0].speed,floorHpLoss:observed.startHp-observed.afterFloor,countertraceSHA256:observed.traceHash,sourceManifestVerified:true});console.log(b.variantId+' PASS short native Room smoke + same-source observer neutrality');
}
fs.writeFileSync(path.join(out,'smoke-results.json'),JSON.stringify({runtime:process.version,node:process.execPath,sourceKind:'public-SHA-plus-patch-manifest',reports},null,2));
