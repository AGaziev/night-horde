from pathlib import Path
import subprocess,re,json,hashlib,difflib,shutil,os
out=Path(__file__).resolve().parent;root=out.parents[3];git=root/'work/night-horde-issue-31'
refs={k:subprocess.check_output(['git','rev-parse',r],cwd=git,text=True).strip() for k,r in {'12':'99f8758','31':'f67463e','baseline':'a25f4f6','21':'3160049'}.items()}
def obj(sha,p):return subprocess.check_output(['git','show',sha+':'+p],cwd=git)
def sha(b):return hashlib.sha256(b).hexdigest()
def graph(ref):
 todo=['app/server/game.js','app/package.json'];data={}
 while todo:
  p=todo.pop()
  if p in data:continue
  b=obj(ref,p);data[p]=b
  if p.endswith('.js'):
   for s in re.findall(r"(?:\bfrom\s*|\bimport\s*)['\"]([^'\"]+)['\"]",b.decode()):
    if s.startswith('.'):todo.append(os.path.normpath(str(Path(p).parent/s)))
 return data
bases={k:graph(v) for k,v in refs.items()};records=[]
def freeze(variant,base,changed,expected,targets):
 d=out/'sources'/variant;assert not d.exists(),str(d)
 data=dict(bases[base]);data.update(changed);diff=''
 for p,b in sorted(changed.items()):
  assert b!=bases[base][p];diff+=''.join(difflib.unified_diff(bases[base][p].decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+p,tofile='b/'+p))
 for p,b in data.items():q=d/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
 patch=diff.encode();(d/'patch.diff').write_bytes(patch)
 files=[dict(path=p,bytes=len(b),sha256=sha(b)) for p,b in sorted(data.items())];manifest=dict(publicBaseSHA=refs[base],coverage='canonical Room transitive import graph plus app/package.json; not full HTTP/browser snapshot',files=files)
 mb=(json.dumps(manifest,indent=2)+'\n').encode();(d/'app-manifest.json').write_bytes(mb)
 identity=dict(variantId=variant,sourceKind='output-only-patched' if changed else 'public-sha-import-snapshot',publicBaseSHA=refs[base],patchSHA256=sha(patch),appManifestSHA256=sha(mb),appGraphSHA256=sha(json.dumps(files,sort_keys=True).encode()),snapshotPath=str(d),APP=str(d/'app'),notAGitHead=True,changedPaths=sorted(changed),numericTargets=targets,expected=expected)
 (d/'binding.json').write_text(json.dumps(identity,indent=2)+'\n');records.append(identity)
 for p in d.rglob('*'):
  if p.is_file():p.chmod(0o444)
 for p in sorted(d.rglob('*'),reverse=True):
  if p.is_dir():p.chmod(0o555)
 d.chmod(0o555)
for k in refs:freeze('base-'+k,k,{}, {},[])
p='app/public/shared/daily.js';a=bases['12'][p].decode();assert a.count('{ armor: 2, speed: 0.9 }')==1
for name,mods in [('armorOnly',{'armor':2,'speed':1}),('speedOnly',{'armor':0,'speed':.9})]:
 replacement='{ armor: '+str(mods['armor'])+', speed: '+str(mods['speed'])+' }';b=a.replace('{ armor: 2, speed: 0.9 }',replacement)
 target='DAILY_RULES.armor.mods.speed' if name=='armorOnly' else 'DAILY_RULES.armor.mods.armor'
 freeze('12-'+name,'12',{p:b.encode()},dict(issue=12,dailyRule='armor',dailyDay='2026-11-13',dailyVersion=2,mods=mods,players=[3,4],mode='lunch'),[target])
p='app/public/shared/content.js';a=bases['31'][p].decode();line=next(l for l in a.splitlines(True) if l.lstrip().startswith("lunch: {"));assert 'hpMul: [1.9, 1.8, 2.16, 2.16]' in line and 'dmgMul: [0.75, 0.54, 0.45, 0.48]' in line
for name,hp,dmg in [('B',2.4,.48),('C',2.16,.6),('D',2.4,.6)]:
 new=line.replace('hpMul: [1.9, 1.8, 2.16, 2.16]',f'hpMul: [1.9, 1.8, 2.16, {hp}]').replace('dmgMul: [0.75, 0.54, 0.45, 0.48]',f'dmgMul: [0.75, 0.54, 0.45, {dmg}]')
 targets=[]
 if hp!=2.16:targets.append('MODES.lunch.hpMul[3]')
 if dmg!=.48:targets.append('MODES.lunch.dmgMul[3]')
 freeze('31-'+name,'31',{p:a.replace(line,new).encode()},dict(issue=31,players=[4],mode='lunch',hpMul=hp,dmgMul=dmg,signatureOnly=True),targets)
(out/'source-bindings.json').write_text(json.dumps(records,indent=2)+'\n')
# Exact selected canonical runner and selector source; no choice/movement policy edit.
src=root/'outputs/issue-split/runs/final-14ad/daily';h=out/'harness';(h/'harness/pm').mkdir(parents=True,exist_ok=True)
for p in ['daily-selector.mjs','harness/pm/run-sim.mjs','harness/pm/sim-runner.mjs']:
 b=(src/p).read_bytes();(h/p).write_bytes(b)
runner=dict(node='/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node',runtime='v24.22.1',canonical=str(h/'harness/pm/run-sim.mjs'),dailySelector=str(h/'daily-selector.mjs'),files={p:sha((h/p).read_bytes()) for p in ['daily-selector.mjs','harness/pm/run-sim.mjs','harness/pm/sim-runner.mjs']})
(out/'harness-binding.json').write_text(json.dumps(runner,indent=2)+'\n');print('Immutable sources',len(records),'causal variants5, base snapshots4; no Git/app tree changes')
