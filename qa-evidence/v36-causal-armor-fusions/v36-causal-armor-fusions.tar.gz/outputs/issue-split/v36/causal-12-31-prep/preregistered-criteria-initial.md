# Preregistration: causal probes12/31 (HOLD0)

2026-11-14. Written before inspecting any new causal or replication outcomes. Product REPORT is the stated motivating evidence; this is not an unselected confirmation sample. No numerical balance change is selected here. Existing baseline/A records retain their actual source SHA and selected raw prefixes; they are not rerun, replaced or renamed.

## Original-tuple causal probes

-12: armorOnly(+2,speed1) and speedOnly(armor0,speed.9), each60 original matched tuples in human3 lunch and human4 lunch:240 new attempts. Existing baseline00 and Daily Armor11 complete the2x2 design. Keep other mechanics/hero assignments/harness and RNG identical.
-31: signature-only stays enabled. Existing A=(HP2.16,damage.48) is not rerun. B=(2.4,.48), C=(2.16,.6), D=(2.4,.6), each original human4 lunch60:180 new attempts. D is also compared with legacy baseline at2.4/.6; signatures are the remaining designed difference. No component attacks are restored.

Primary estimands per cell: paired terminal win differences and95% paired bootstrap intervals (fixed resampling seed20261114,10000 paired tuple resamples); Wilson95 for each proportion; exact discordant-pair McNemar as descriptive corroboration. Preserve original errors/UNKNOWN/nonterminal records; replacements only by explicit controller authorization and tuple mapping. No pooling cells or rules; no selecting favorable retries.

12: estimate armor main effect Y10-Y00, speed effect Y01-Y00, and interaction Y11-Y10-Y01+Y00 on the same complete four-arm tuples. Two preselected cells get Holm adjustment if inferential p-values are used. Positive armor-only effect with interval excluding0 and directional survival/incoming evidence supports armor contribution; speed and interaction are evaluated independently. A null/imprecise result is INCOMPLETE, not equivalence. Do not choose a new armor number from this sample and call it confirmed.

31: estimate HP relief (A-B and C-D), damage relief(A-C and B-D), interaction A-B-C+D. Treat these three contrasts as preselected within the selected human4 lunch cell; report simultaneous/multiplicity caveats, no post-hoc winning-arm selection. D-vs-legacy isolates signature behavior at the same pressure. A causal explanation requires coherent paired outcome, pre-first-fusion exposure, survival and boss/finale evidence; a single p-value is not a tuning instruction.

Passive secondary observations: actual incoming attempted/absorbed/HP loss, post-armor floor activations, melee/projectile/other hits, before first fusion, deaths/revives, boss/finale, inventory/received fusion. Counters do not infer prevented damage from control duration. Hook/source/hash/error transparency is mandatory. Observer cannot draw gameplay RNG, change callbacks/state, affect choices or swallow errors. Optional trace cannot replace source identity or tuple completion evidence.

## Independent replication proposal (not execution permission)

Proposed #12 human3 lunch fresh matched60: seeds3120000..3120059, K0=20000+i; proposed #31 human4 lunch fresh matched60:3310000..3310059, K0=24000+i. Both offsets are multiples of8, preserving the original roster rotation distribution. Must check shared seed/tuple ledger before reservation. Conflict or unavailable ledger means NOT RESERVED. Baseline and one prospectively chosen/frozen repaired candidate give120 outcomes per issue. Candidate must be selected/frozen before reading replication outcomes. No selection of candidate parameter values now.

Replication interpretation: report terminal counts,25–40% human target, paired change vs baseline and uncertainty. Exceeding40% with uncertainty that excludes40% supports persistent overshoot; below25% or evidence of a material disadvantage is a regression signal. Otherwise retain uncertainty; being inside the point target is not proof of equivalence/READY. Broader applicable QUALITY cells remain required after the chosen fix freezes. No final nerf number, GAME_VERSION change or readiness verdict is prescribed.

All420 causal attempt plans and both replication reservations remain HOLD with launchLimit0. Only five short sequential native Room smoke cases are authorized now; no full600/900-second match, CPU/FPS profile or long simulation worker is launched.

## Additional prospective replication proposals (root steering)

#21 human4 lunch: baseline vs current3160049,120 outcomes on60 fresh matched tuples, proposed seeds3210000..3210059,K0=22000+i. Swarmv2 human4 night: baseline vs99f8758 with onlySwarm contract active,120 outcomes, proposed seeds3120100..3120159,K0=20064+i. Shared ledger check is required before reservation. No reward/rate/armor tuning is inferred here. Both remain HOLD0, candidate source publicly pinned, and their full mandatory scope stays open. Caravan observer reads real status/killed/guards/proximity and logs native addXp calls without attributing unproved rewards or altering decisions/RNG.
