# READY_TO_PROBE — source/plan preparation only (HOLD0)

Finite output-only preparation for12/31 is complete. No app branch, Git commit, publication or full simulation was changed/launched. Public source bases:12 `99f8758a45e90ee5dc2370d1218837b9f0924128`,31 `f67463eaf00b15304655ba44d6966bfc75090934`, baseline `a25f4f6aeb4e3f61e408905a84f281957844e5e9`. Frozen copies contain only the canonical Room import graph plus package.json; not a full HTTP/browser snapshot.

`source-bindings.json` pins publicBaseSHA + patchSHA256 + appManifestSHA256 + appGraphSHA256. Patched copies are explicitly not Git heads. Source files/manifests are read-only. Each12 copy changes exactly one numeric Daily Armor property.31 B changes lunch4 HP; C changes lunch4 damage; D changes those two intended factorial values. Signature dispatch and every other source file/parameter stay unchanged.

- `causal-plan.json`:240 Armor attempts (armorOnly+2/speed1; speedOnly0/.9, original human3/4 lunch60 each) +180 signature-only31 B/C/D (human4 lunch original60 each). All420 statusnotStarted, HOLD, launchLimit0.
- `existing-measurement-bindings.json`:300 selected physical prefix references retain actual f4a/81823b5/41733a7 SHA and raw/meta hashes. Existing A/baseline are not rerun or relabeled.31 carry proof is linked.12 unpatched99-vs81823b5 canonical selector-path carry must be explicitly reviewed before causal comparison: changes are lobby/day-lock/result metadata, but no blind whole-source equivalence claim is made here.
- `replication-plans.json`:Armor human3 lunch and31 human4 lunch reserve60 fresh matched tuples each, candidate TBD after causal selection;21 human4 lunch baseline/current3160049 andSwarmv2 human4 night baseline/current99f8758 have120 outcomes each planned. All480 prospective outcomes HOLD0. No number is selected as a nerf.
- `seed-reservation-receipt.json`: shared ledger checked all4 ranges, conflicts0, RESERVED_HOLD0 only.12 seeds3120000..59/K020000+i;31 seeds3310000..59/K024000+i;21 seeds3210000..59/K022000+i;Swarm3120100..59/K020064+i. Same rotation within each paired arm.

`preregistered-criteria.md` is written before any probe/replication outcomes. Initial text retained. Root clarification is explicit: same seed/runtime/RNG initialization and no extra observer RNG draws; treatment-dependent gameplay streams may diverge after changed combat. They must never be forcibly synchronized or declared bad merely for differing counts.

Native smoke:5/5 output variants PASS, sequential only,0.1s simulated time each, terminalfalse/notAcceptanceOutcome. Actual Room daily selection/lock/start, applied armor/speed, spawned enemy mode HP/damage and real fusion/signature are checked. Manifest/effect assertions run before Room.start. Same-source observer on/off produces exact gameplay and RNG draw count equality. `smoke-results.json`, `smoke.log`, `smoke-data/*-counter.json` retain native receipts/trace hashes.

Exact already executed smoke command (not a full match):

```
/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node outputs/issue-split/v36/causal-12-31-prep/smoke.mjs
```

Exact future per-attempt argv/environment/stdout/stderr are in each plan row.command. They use the unchanged copied canonical runner or unchanged Daily selector, Node24.22.1, --random-seed, APP, MODE, K0, DAILY_RULE/DAY as appropriate, and --import preload.mjs with binding/trace. All inherited gameplay override knobs must be unset. These commands are templates for ROOT GO after an adapter exists; do not run now.

Observer (`observer.mjs`/`preload.mjs`) is passive: native hurt calls aggregate raw/scaled input, armor/guard formula, actual HP loss and damaging floor activations, split melee/projectile/other and pre/post first team fusion. All incoming calls are aggregated; only16 detailed samples are retained. postArmorBeforeFloor is a formula exposure over ALL calls (including native blocks), not a claim of actual prevented HP. Zero-HP calls and real HP loss are separate. Boss native bossHit totals, down/revive/duo/evolution/finale events and addXp log calls are observed without gameplay RNG or AI choices. Caravan tick status/killed/guards/proximity reads are optional; attribution of XP to a reward is not inferred. Trace writes carry a SHA256 and errors rethrow with explicit stderr. Native smoke deliberately disables hero perks withInfinity; debug JSON samples may encode those asnull and are not used as acceptance counters.

Limits / gates before heavy GO:

1. Generic controller currently requires real candidateSha; output-only-patched needs an explicit reviewed adapter. No synthetic GitHEAD is supplied. Registry launch permission was not registered; max9 remains shared.
2. Review12 selector-path source carry and observer counter/trace consumption. Optional21 caravan-field/reward attribution telemetry is not fully validated by these five causal smokes. No event trace replaces canonical tuples/source/terminal proof.
3. Native smoke is not420 terminal attempts, balance acceptance, wall-clock/FPS/CPU evidence or full QA. No new causal outcomes exist. Future attempts must retain native errors/nonterminal/UNKNOWN and authorized replacements without selecting favorable retries.
4. Armor/31 replication candidate bindings remain null until prospectively frozen. No final parameter or GAME_VERSION change is prescribed.

ROOT owns adapter/GO, execution and analysis. Preparation handed off for the next priority41 source fix; no long job is active from this task.
