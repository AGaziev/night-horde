from pathlib import Path
import json,hashlib,copy,sys
out=Path(__file__).resolve().parent;root=out.parents[3]
def load(p):return json.loads(Path(p).read_text())
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
origin=load(root/'outputs/issue-split/runs/rebase-f4a40dc/plan.json');donor=load(root/'outputs/issue-split/runs/final-a25/issue45-final/plan.json');bindings={b['variantId']:b for b in load(out/'source-bindings.json')};h=load(out/'harness-binding.json');selected=load(root/'outputs/issue-split/v36/product-final-complete/summary.json')['selectedPhysicalAttempts'];node=h['node'];rows=[]
heroes=origin['canonicalHeroes'];tuples={a['id']:a for a in origin['attempts']}
def command(a,b,rule=None,day=None):
 prefix=out/'future-attempts'/a['attemptId'];env={'APP':b['APP'],'MODE':a['mode'],'K0':str(a['K0']),'TZ':'UTC','LANG':'C','PATH':str(Path(node).parent)+':/usr/bin:/bin','HORDE_RUNS_DIR':str(prefix/'runs'),'CAUSAL_BINDING':str(Path(b['snapshotPath'])/'binding.json'),'CAUSAL_TRACE':str(prefix/'countertrace.json')}
 if rule:env.update(DAILY_RULE=rule,DAILY_DAY=day)
 runner=h['dailySelector'] if rule else h['canonical']
 return dict(argv=[node,'--random-seed='+str(a['seed']),'--import',str(out/'preload.mjs'),runner,str(a['players']),'1',a['bot']],env=env,unsetInheritedGameplayOverrides=['MODE_HP','MODE_DMG','FIN_HP','FIN_DMG','FIN_RATE','FIN_REVIVE','LATE_HP','LATE_DMG','H_OVR','FLEE'],stdout=str(prefix/'raw.json'),stderr=str(prefix/'stderr.log'),requiredMetaSourceFields=['sourceKind','publicBaseSHA','patchSHA256','appManifestSHA256','variantId'],notAGitHead=True)
for name,cells in [('12-armorOnly',[5,7]),('12-speedOnly',[5,7]),('31-B',[7]),('31-C',[7]),('31-D',[7])]:
 for c in cells:
  for i in range(60):
   a=copy.deepcopy(tuples[f'c{c:02d}-i{i:02d}']);a={k:a[k] for k in ['id','cell','bot','players','mode','seed','K0','heroes']};a.update(attemptId=name+'/'+a['id'],variantId=name,status='notStarted',sourceBinding=bindings[name]);a['command']=command(a,bindings[name],'armor' if name.startswith('12-') else None,'2026-11-13' if name.startswith('12-') else None);rows.append(a)
assert len(rows)==420
base=dict(schemaVersion=1,sourceKindProtocol='publicSHA+patchHash+manifest; NOT candidateGitHead',runtime=donor['runtime'],node=node,nodeBinarySHA256=donor['nodeBinarySHA256'],canonicalRunnerHashes=h['files'],canonicalHeroes=heroes,launchState='HOLD',launchLimit=0,automaticRetry=False,patchedControllerAdapterRequired=True,tupleOrigin=str(root/'outputs/issue-split/runs/rebase-f4a40dc/plan.json'),criteria=str(out/'preregistered-criteria.md'),criteriaSHA256=digest(out/'preregistered-criteria.md'))
(out/'causal-plan.json').write_text(json.dumps({**base,'attempts':rows,'targetTerminal':420},indent=2))
# Bind already selected measurements using actual source SHA and physical raw-prefix/hash only.
wanted=[]
for r in selected:
 logical=r['logical'];part=logical.split('/')[-1]
 if part.startswith(('c05-','c07-')) and ((r['sourceSha'].startswith('f4a40dc') and logical.startswith('issue-31/')) or(logical.startswith('armor/') and r['sourceSha'].startswith('81823b5')) or(logical.startswith('issue-31/c07-') and r['sourceSha'].startswith('41733a7'))):wanted.append(r)
assert len(wanted)==300,len(wanted)
(out/'existing-measurement-bindings.json').write_text(json.dumps(dict(selectionSnapshot=str(root/'outputs/issue-split/v36/product-final-complete/summary.json'),selectionSHA256=digest(root/'outputs/issue-split/v36/product-final-complete/summary.json'),existingAttemptsNotRerun=True,rawRetainActualSourceSHA=True,records=wanted,carry31Proof=str(root/'outputs/issue-split/v36/ceo-r13/31-merge-applicability.json'),carry12SelectorPathRequiresExplicitReview=True),indent=2))
rep=[]
for key,cell,start,k0,binding,rule,day in [('12',5,3120000,20000,None,None,None),('31',7,3310000,24000,None,None,None),('21',7,3210000,22000,'base-21',None,None),('swarm-v2',6,3120100,20064,'base-12','swarm','2026-11-16')]:
 attempts=[];cfg=origin['cells'][cell]
 for arm in ['baseline','candidate']:
  b=bindings['base-baseline'] if arm=='baseline' else bindings.get(binding)
  for i in range(60):
   K=k0+i;a=dict(id=f'rep-{key}-i{i:02d}',attemptId=f'rep-{key}/{arm}/i{i:02d}',cell=cell,**cfg,seed=start+i,K0=K,heroes=[heroes[(K*cfg['players']+pid)%len(heroes)] for pid in range(cfg['players'])],revision=arm,status='notStarted',sourceBinding=b)
   a['command']=command(a,b,rule if arm=='candidate' else None,day if arm=='candidate' else None) if b else None;attempts.append(a)
 rep.append(dict(replication=key,launchState='HOLD',launchLimit=0,seedRange=[start,start+59],K0Range=[k0,k0+59],candidateFrozen=binding is not None,criteriaSelectionBeforeReplicationOutcomes=True,attempts=attempts))
(out/'replication-plans.json').write_text(json.dumps({**base,'plans':rep,'targetOutcomes':480},indent=2))
ledger=root/'outputs/issue-split/runs/final-a25-r16/seed-ledger.json';reservations=root/'outputs/issue-split/runs/final-a25-r16/seed-reservations.json';res=load(reservations)
for p in rep:
 r=next(r for r in res['reservations'] if r['seedFrom']==p['seedRange'][0]);assert not r['conflicts'] and r['reservationStatus']=='RESERVED_HOLD0'
(out/'seed-reservation-receipt.json').write_text(json.dumps(dict(ledgerPath=str(ledger),ledgerSHA256=digest(ledger),reservationsPath=str(reservations),reservationsSHA256=digest(reservations),reservations=res,noLaunchAuthority=True),indent=2))
print('HOLD0:420 causal attempts,480 prospective replication outcomes;300 existing pointers retained; all4 seed reservations checked')
