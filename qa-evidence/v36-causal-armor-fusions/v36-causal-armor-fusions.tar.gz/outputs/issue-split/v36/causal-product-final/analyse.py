from pathlib import Path
from collections import Counter,defaultdict
import json,hashlib,statistics,math,random,datetime,ast,re,collections
ROOT=Path(__file__).resolve().parents[4];OUT=Path(__file__).resolve().parent;Q=ROOT/'outputs/issue-split/runs/causal-12-31-v1';PREP=ROOT/'outputs/issue-split/v36/causal-12-31-prep'
J=lambda p:json.loads(Path(p).read_text());H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();HB=lambda b:hashlib.sha256(b).hexdigest()
plan=J(Q/'plan.json');fail=[];groups=defaultdict(dict);traces=defaultdict(list);provenance=[]
def check(ok,label):
 if not ok:fail.append(label)
# Pure historical reducers; no application or controller import.
ns=dict(globals());tree=ast.parse((ROOT/'outputs/eight-issues/runs/summarize.py').read_text());exec(compile(ast.Module(body=[x for x in tree.body if isinstance(x,ast.FunctionDef)],type_ignores=[]),'pure-reducers','exec'),ns);ns['MAP']={}
identities={a['variantId']:a['sourceBinding']for a in plan['attempts']}
for name,b in identities.items():
 p=Path(b['snapshotPath']);manifest=J(p/'app-manifest.json');check(H(p/'app-manifest.json')==b['appManifestSHA256'],name+' manifest');check(H(p/'patch.diff')==b['patchSHA256'],name+' patch');check(HB(json.dumps(manifest['files'],sort_keys=True).encode())==b['appGraphSHA256'],name+' graph')
 for f in manifest['files']:check(H(p/f['path'])==f['sha256'],name+' file '+f['path'])
 ns['MAP'][name]=ns['mapping'](str(p))
for a in plan['attempts']:
 p=Q/'raw'/a['variantId']/a['id'];m=J(p/'meta.json');r=J(p/'raw.json');e=J(p/'exit.json');w=J(p/'worker.json');t=J(p/'countertrace.json');b=a['sourceBinding'];c=r['completion'][0];l=r['logs'][0];room=t['payload']['rooms'][0]
 ck=[m['sourceIdentity']==b,m['sourceKind']=='output-only-patched','sourceSha'not in m,'candidateSha'not in m,m['exitCode']==0,e['observedExitCode']==0,e==m['observedExit'],e['nodePID']==w['nodePID'],e['supervisorPID']==w['supervisorPID'],w['command']==a['command']['argv'],m['command']==a['command']['argv'],m['seed']==a['seed'],m['K0']==a['K0'],l['players']==a['players'],l['mode']==a['mode'],r['pick']==a['bot'],[h['hero']for h in l['team']]==a['heroes'],c['terminal']is True,c['state']=='over',c['finishCalls']==1,c['logId']==l['id'],room['finishCalls']==1,room['terminalTransitions']==1,room['final']['terminal'],room['final']['logId']==l['id'],room['source']==b,HB(t['payloadJSON'].encode())==t['countertraceSHA256'],json.loads(t['payloadJSON'])==t['payload'],H(p/'countertrace.json')==m['countertraceFileSHA256'],t['countertraceSHA256']==m['countertracePayloadSHA256'],H(p/'raw.json')==m['rawSHA256'],m['planSHA256']==H(Q/'plan.json'),m['criteriaSHA256']==plan['criteriaSHA256'],m['nodeBinarySHA256']==plan['nodeBinarySHA256'],m['runtime']==plan['runtime']]
 if a['issue']==12:ck += [l['daily']['mods']==b['expected']['mods'],l['daily']['version']==2,l['daily']['id']=='armor',l['daily']['day']==b['expected']['dailyDay'],m['dailyContractProof']is True]
 check(all(ck),a['attemptId']+' tuple/source/hash/receipt/finish/trace/params')
 check(not any(x['type']=='observer-or-native-error'for x in room['events']),a['attemptId']+' observer error')
 key=a['variantId']+'-c'+str(a['cell']);groups[key][a['id']]=l;traces[key].append(room);provenance.append({'attemptId':a['attemptId'],'sourceKind':m['sourceKind'],'publicBaseSHA':m['publicBaseSHA'],'patchSHA256':m['patchSHA256'],'metaSHA256':H(p/'meta.json'),'rawSHA256':H(p/'raw.json'),'traceSHA256':H(p/'countertrace.json')})
# Existing measurements remain measured sources and are not duplicated as independent observations.
existing=J(PREP/'existing-measurement-bindings.json');check(H(existing['selectionSnapshot'])==existing['selectionSHA256'],'existing snapshot hash')
for r in existing['records']:
 p=Path(r['prefix']);m=J(str(p)+'.meta.json');d=J(str(p)+'.json');l=d['logs'][0];c=d['completion'][0];cell=int(m['cell']);sh=r['sourceSha'];label='base'if sh.startswith('f4a')else'12-full'if sh.startswith('818')else'31-A';key=label+'-c'+str(cell)
 check(H(str(p)+'.json')==r['rawSHA256']and H(str(p)+'.meta.json')==r['metaSHA256']and m['sourceSha']==sh and m['exitCode']==0 and c['terminal']and c['state']=='over'and c['finishCalls']==1,'existing '+r['logical'])
 groups[key][m['id']]=l
ns['MAP']['base']=ns['mapping'](str(PREP/'sources/base-baseline'));ns['MAP']['12-full']=ns['mapping'](str(PREP/'sources/base-12'));ns['MAP']['31-A']=ns['mapping'](str(PREP/'sources/base-31'))
# Manifest and adapter bytes, including actual extended observer-neutral exercise source.
ad=J(Q/'adapter-manifest.json')
for f,h in ad['files'].items():check(H(f)==h,'adapter '+f)
ex=J(Q/'native-exercise-results.json');check(ex['pass']and len(ex['rows'])==5 and all(r['pass']for r in ex['rows']),'neutral native exercise')
source=(Q/'observer.mjs').read_text();check('Math.random'not in source,'observer random call')
summary={};
for key,data in groups.items():
 arm=key.rsplit('-c',1)[0];st=ns['stats'](list(data.values()),arm);check(len(data)==60,key+' n60');v={'n':len(data),'wins':sum(int(x['win'])for x in data.values()),'stats':st}
 if key in traces:
  allc=Counter();pre=Counter();events=Counter();first=[]
  for t in traces[key]:
   if t['firstTeamDuo']is not None:first.append(t['firstTeamDuo'])
   for row in t['incoming'].values():
    for name,val in row.items():
     if isinstance(val,(int,float))and name not in ['pid','preFusion']:allc[name]+=val
     if row['preFusion']and isinstance(val,(int,float))and name not in['pid','preFusion']:pre[name]+=val
   events.update(x['type']for x in t['events'])
  v['incomingAll']=dict(allc);v['incomingBeforeFirstTeamFusion']=dict(pre);v['events']=dict(events);v['medianFirstFusionWhenPresent']=statistics.median(first)if first else None
 summary[key]=v
rng=random.Random(20261114);samples=[[rng.randrange(60)for _ in range(60)]for _ in range(10000)];contrasts={}
def contrast(label,terms):
 keys=list(terms);ids=sorted(groups[keys[0]]);check(all(set(groups[k])==set(ids)for k in keys),label+' pairing');v=[sum(terms[k]*int(groups[k][i]['win'])for k in keys)for i in ids];boot=sorted(sum(v[j]for j in ix)/60*100 for ix in samples);out={'nPairs':60,'meanPP':round(statistics.mean(v)*100,4),'pairedBootstrap95':[round(boot[249],4),round(boot[9749],4)],'weights':terms}
 if len(keys)==2 and sorted(terms.values())==[-1,1]:
  plus=next(k for k in keys if terms[k]==1);minus=next(k for k in keys if terms[k]==-1);lost=sum(groups[minus][i]['win']and not groups[plus][i]['win']for i in ids);gain=sum(groups[plus][i]['win']and not groups[minus][i]['win']for i in ids);n=lost+gain;out.update(lostWins=lost,gainedWins=gain,exactMcNemar=min(1,2*sum(math.comb(n,i)for i in range(min(lost,gain)+1))/2**n)if n else 1)
 contrasts[label]=out
for c in [5,7]:
 z='-c'+str(c);contrast('12 armor effect c'+str(c),{'12-armorOnly'+z:1,'base'+z:-1});contrast('12 speed effect c'+str(c),{'12-speedOnly'+z:1,'base'+z:-1});contrast('12 interaction c'+str(c),{'12-full'+z:1,'12-armorOnly'+z:-1,'12-speedOnly'+z:-1,'base'+z:1});contrast('12 full-minus-armorOnly c'+str(c),{'12-full'+z:1,'12-armorOnly'+z:-1})
for label,terms in [('HP relief A-B',{'31-A':1,'31-B':-1}),('HP relief C-D',{'31-C':1,'31-D':-1}),('damage relief A-C',{'31-A':1,'31-C':-1}),('damage relief B-D',{'31-B':1,'31-D':-1}),('interaction',{'31-A':1,'31-B':-1,'31-C':-1,'31-D':1}),('signature D-legacy',{'31-D':1,'base':-1})]:contrast('31 '+label,{k+'-c7':v for k,v in terms.items()})
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'newAttempts':420,'existingDistinctPhysicalReferences':len(existing['records']),'bootstrap':{'seed':20261114,'resamples':10000,'method':'same paired-tuple index resamples; nearest-order 2.5/97.5 percentiles'},'failures':fail,'arms':summary,'contrasts':contrasts,'selectedProvenance':provenance,'interpretationLimits':['Patched output sources, not Git heads.','No incoming trace on original baseline/A/full arms; no invented counter contrast.','Formula exposure includes blocked calls; hpLoss is separate.','Same initial RNG and neutral observer; divergent native treatment streams are not forcibly synchronized.']}
(OUT/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print('FAILURES',fail)
for k,v in summary.items():print('ARM',k,'wins',v['wins'],'down',v['stats']['downs'],'med',v['stats']['medianTerminalSeconds'],'finale',v['stats']['finale'],'boss',v['stats']['meanBossDamagePerRun'],'pre',v.get('incomingBeforeFirstTeamFusion'))
for k,v in contrasts.items():print(k,v)
