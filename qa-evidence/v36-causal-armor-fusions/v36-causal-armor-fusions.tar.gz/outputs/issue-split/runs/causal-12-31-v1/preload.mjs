import fs from 'node:fs';import {pathToFileURL} from 'node:url';import {verifyBinding,installObserver} from './observer.mjs';
if(!process.env.CAUSAL_BINDING||!process.env.CAUSAL_TRACE)throw Error('CAUSAL_BINDING_AND_TRACE_REQUIRED');
for(const key of ['MODE_HP','MODE_DMG','FIN_HP','FIN_DMG','FIN_RATE','FIN_REVIVE','LATE_HP','LATE_DMG','H_OVR','FLEE'])if(process.env[key])throw Error('UNREGISTERED_GAMEPLAY_OVERRIDE '+key);
const binding=JSON.parse(fs.readFileSync(process.env.CAUSAL_BINDING,'utf8'));if(process.env.APP!==binding.APP)throw Error('CAUSAL_APP_MISMATCH');verifyBinding(binding);
const {Room}=await import(pathToFileURL(binding.APP+'/server/game.js')),C=await import(pathToFileURL(binding.APP+'/public/shared/content.js'));
installObserver(Room,C,{binding,outputFile:process.env.CAUSAL_TRACE});process.stderr.write('CAUSAL_SOURCE_IDENTITY '+JSON.stringify({sourceKind:binding.sourceKind,publicBaseSHA:binding.publicBaseSHA,patchSHA256:binding.patchSHA256,appManifestSHA256:binding.appManifestSHA256,variantId:binding.variantId,notAGitHead:binding.notAGitHead})+'\n');
