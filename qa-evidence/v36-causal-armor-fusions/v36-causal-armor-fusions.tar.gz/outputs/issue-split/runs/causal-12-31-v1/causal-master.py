import pathlib,json,sys,os,subprocess,time,datetime,hashlib
from binding_check import sha,atomic,verify,frozen
Q=pathlib.Path(__file__).resolve().parent;P=Q.parent;plan=json.loads((Q/'plan.json').read_text());auth=json.loads((Q/'launch-authorized.json').read_text());assert auth['authorized']is True and auth['planSHA256']==sha(Q/'plan.json');frozen(Q);assert sha(plan['node'])==plan['nodeBinarySHA256'];assert len(plan['attempts'])==420
lock=Q/'controller.lock'
with lock.open('x')as f:json.dump({'pid':os.getpid(),'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'oneShotLaunchd':True},f);f.flush();os.fsync(f.fileno())
pending=[];done={};active={};unknown=[]
def folder(a):return Q/'raw'/a['variantId']/a['id']
for a in plan['attempts']:
 D=folder(a)
 if(D/'meta.json').exists():done[a['attemptId']]=json.loads((D/'meta.json').read_text())
 elif(D/'start.json').exists():unknown.append({'attemptId':a['attemptId'],'reason':'existing unfinished start; no auto retry'})
 else:pending.append(a)
assert not unknown,'Existing unknown start requires explicit recovery'
def dispatch(a):
 b=a['sourceBinding'];verify(b);frozen(Q);D=folder(a);D.mkdir(parents=True);cmd=a['command']['argv'];env=a['command']['env'];assert cmd[0]==plan['node']and cmd[1]=='--random-seed='+str(a['seed'])and cmd[-3:]==[str(a['players']),'1',a['bot']];assert env['APP']==b['APP']and env['MODE']==a['mode']and env['K0']==str(a['K0']);assert json.loads(pathlib.Path(env['CAUSAL_BINDING']).read_text())==b
 m={**{k:v for k,v in a.items()if k not in['command','sourceBinding','status']},**{k:b[k]for k in['sourceKind','publicBaseSHA','patchSHA256','appManifestSHA256','appGraphSHA256','variantId','notAGitHead']},'isNotGit':True,'sourceIdentity':b,'status':'started','runtime':plan['runtime'],'nodeBinarySHA256':plan['nodeBinarySHA256'],'canonicalRunnerHashes':plan['canonicalRunnerHashes'],'command':cmd,'environment':env,'argvSHA256':hashlib.sha256(json.dumps(cmd,separators=(',',':')).encode()).hexdigest(),'planSHA256':sha(Q/'plan.json'),'criteriaSHA256':plan['criteriaSHA256'],'adapterManifestSHA256':sha(Q/'adapter-manifest.json'),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with(D/'start.json').open('x')as f:json.dump(m,f,indent=2);f.flush();os.fsync(f.fileno())
 cfg={'planDir':str(Q),'folder':str(D),'command':cmd,'environment':env,'metadata':m};cp=D/'dispatch.json';atomic(cp,cfg);log=(D/'supervisor.log').open('ab');p=subprocess.Popen([sys.executable,str(Q/'causal-supervisor.py'),str(cp)],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);log.close();atomic(D/'supervisor-launch.json',{'pid':p.pid,'masterPID':os.getpid(),'config':str(cp)});return p
try:
 while pending or active:
  control=json.loads((Q/'execution-control.json').read_text());budget=control['dispatchBudget'];assert budget in[1,420];assert budget==1 or control['fullGo']is True
  cap=max(0,min(9,int((Q/'worker-limit.json').read_text())))
  if not(Q/'PAUSE').exists()and not(P/'PAUSE').exists():
   while pending and len(active)<cap and len(done)+len(active)<budget:
    a=pending.pop(0)
    try:active[a['attemptId']]=(a,dispatch(a))
    except Exception as e:unknown.append({'attemptId':a['attemptId'],'reason':'dispatch interrupted/unknown','error':repr(e)});atomic(Q/'PAUSE',{'kind':'DISPATCH_UNKNOWN','attemptId':a['attemptId']});break
  for key,(a,p)in list(active.items()):
   D=folder(a)
   if(D/'meta.json').exists():
    m=json.loads((D/'meta.json').read_text());done[key]=m;del active[key]
    if m.get('exitUnknown'):unknown.append({'attemptId':key,'reason':'Node exit unobserved'})
   elif p.poll()is not None:unknown.append({'attemptId':key,'reason':'supervisor exited without metadata','observedSupervisorExit':p.returncode});del active[key];atomic(Q/'PAUSE',{'kind':'SUPERVISOR_UNKNOWN','attemptId':key})
  if len(done)>=1 and not active and not control['fullGo']and not(Q/'pilot-complete.json').exists():
   first=plan['attempts'][0];m=done[first['attemptId']];atomic(Q/'pilot-complete.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'attemptId':first['attemptId'],'countedOnceIn420':True,'terminalProof':m.get('terminalProof'),'nativeMeta':str(folder(first)/'meta.json'),'metaSHA256':sha(folder(first)/'meta.json'),'remainingNotStarted':len(pending),'requiresRootReadbackForFullGO':True});(Q/'worker-limit.json').write_text('0\n')
   if m.get('terminalProof'):atomic(Q/'PAUSE',{'kind':'PILOT_REVIEW_HOLD','reason':'pilot counted in420; remaining419 HOLD until root fullGO'})
  state={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'done':len(done),'terminal':sum(m.get('terminalProof')is True for m in done.values()),'failed':sum(not m.get('terminalProof')for m in done.values()),'active':len(active),'pending':len(pending),'unknown':unknown,'masterPID':os.getpid(),'scopeTarget':420,'scopeTerminal':sum(m.get('terminalProof')is True for m in done.values()),'executionScope':[12,31],'stage':control['stage'],'dispatchBudget':budget,'sourceKind':'publicSHA+patch+manifest, no synthetic GitHead','activeAttempts':[{'attemptId':k,'supervisorPID':p.pid,'folder':str(folder(a))}for k,(a,p)in active.items()]};atomic(Q/'controller-state.json',state);time.sleep(.25)
 atomic(Q/'controller-complete.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'planned':420,'completed':len(done),'scopeTarget':420,'scopeTerminal':sum(m.get('terminalProof')is True for m in done.values()),'unknown':unknown,'noAutomaticRetries':True})
 if unknown or any(not m.get('terminalProof')for m in done.values()):raise SystemExit(2)
finally:
 if lock.exists():lock.rename(Q/('controller-finished-'+str(os.getpid())+'.json'))
