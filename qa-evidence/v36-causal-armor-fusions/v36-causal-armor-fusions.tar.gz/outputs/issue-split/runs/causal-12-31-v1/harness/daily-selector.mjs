import assert from 'node:assert/strict';
const APP=process.env.APP;
const {Room}=await import(APP+'/server/game.js');
const C=await import(APP+'/public/shared/content.js');
const {dailyFor,DAILY_VERSION}=await import(APP+'/public/shared/daily.js');
const day=process.env.DAILY_DAY,rule=process.env.DAILY_RULE;
assert.match(day??'',/^\d{4}-\d{2}-\d{2}$/);
assert.equal(dailyFor(day+'T12:00:00Z').id,rule);assert.equal(DAILY_VERSION,2);
const start=Room.prototype.start,finish=Room.prototype.finish,tick=Room.prototype.tick,addXp=Room.prototype.addXp;
const records=[],state=new WeakMap();
function observed(r){let s=state.get(r);if(!s){s={record:null,pending:[],awarded:new Set(),allXpCalls:0,allXpInput:0};state.set(r,s);}return s;}
Room.prototype.start=function(...args){
 this.handle(this.host,{t:'daily',enabled:true});assert.equal(this.dailySelected,true);
 this.lockDaily(day+'T12:00:00Z');const result=start.apply(this,args);
 assert.equal(this.state,'play');assert.equal(this.daily.id,rule);assert.equal(this.daily.day,day);
 assert.equal(this.daily.version,2);assert.equal(this.daily.mode,this.mode);assert.equal(this.daily.players,this.heroes.size);
 const rec={contract:this.daily,startedAt:this.time,awards:[],resolutions:[],initialCohorts:(this.swarm?.cohorts??[]).map(c=>({...c}))};
 records.push(rec);observed(this).record=rec;return result;
};
Room.prototype.addXp=function(h,amount){
 const s=observed(this),candidate=s.pending.find(c=>c.resolved&&c.success&&!s.awarded.has(c.id+':'+c.end+':'+h.pid));
 let award=null;
 if(candidate){
  const expected=C.xpForNext(h.level,this.heroes.size)*.15;
  assert.ok(Math.abs(amount-expected)<1e-8,'native first award at successful precombat resolution has exact15%next-level amount');
  s.awarded.add(candidate.id+':'+candidate.end+':'+h.pid);
  award={cohort:candidate.id,at:this.time,pid:h.pid,amount,expected,levelBefore:h.level,xpBefore:h.xp,down:h.st!==0,offline:!!h.offline};
 }
 s.allXpCalls++;s.allXpInput+=amount;const value=addXp.call(this,h,amount);
 if(award){Object.assign(award,{levelAfter:h.level,xpAfter:h.xp});s.record.awards.push(award);}return value;
};
Room.prototype.tick=function(dt,...args){
 const s=observed(this);s.pending=(this.swarm?.cohorts??[]).filter(c=>!c.resolved&&c.end<=this.time+dt+1e-7);
 const value=tick.call(this,dt,...args);
 for(const c of s.pending)if(c.resolved)s.record?.resolutions.push({...c,at:this.time});
 s.pending=[];return value;
};
Room.prototype.finish=function(...args){
 const value=finish.apply(this,args),s=observed(this),rec=s.record;
 if(this.lastLog&&rec){assert.equal(this.lastLog.daily?.id,rule);assert.equal(this.lastLog.daily?.day,day);
  Object.assign(rec,{finished:true,terminalState:this.state,activeSeconds:this.time,logId:this.lastLog.id,loggedContract:this.lastLog.daily,
   finalCohorts:(this.swarm?.cohorts??[]).map(c=>({...c})),swarmWins:this.swarm?.wins??0,allXpCalls:s.allXpCalls,allXpInput:s.allXpInput});
  assert.ok(rec.swarmWins<=2);assert.ok(rec.resolutions.length<=2);
 }
 return value;
};
try{
 if(process.env.CONTRACT_SMOKE==='1'){
  const n=+(process.env.SMOKE_N??1),r=new Room('SMOKE',()=>{});r.setMode(process.env.MODE??'night');
  for(let pid=1;pid<=n;pid++)r.addPlayer(pid,'S'+pid,'knight');r.start();
  r.spawn=()=>{};r.bossAt=[];r.peaks=[];r.nextEliteT=r.nextInvasionT=Infinity;r.events.tick=()=>{};
  for(const h of r.heroes.values()){h.weapons.clear();h.perk.readyAt=Infinity;}
  if(rule==='swarm')for(const cohort of r.swarm.cohorts){cohort.spawned=10;cohort.killed=7;r.time=cohort.end-1/30;r.tick(1/30);}
  else r.tick(1/30);
  r.finish(false,0);assert.equal(records.length,1);
  if(rule==='swarm'){assert.equal(records[0].swarmWins,2);assert.equal(records[0].awards.length,2*n);}
  console.log(JSON.stringify({smokeOnly:true,notPlayedWinOrFullSimulation:true,rule,players:n,mode:r.mode,version:r.daily.version,contract:r.daily,swarmWins:records[0].swarmWins,awards:records[0].awards}));
 }else await import(new URL('./harness/pm/run-sim.mjs',import.meta.url));
}finally{process.stderr.write('DAILY_SELECTOR_METRICS '+JSON.stringify({rule,day,version:2,actualHostSelector:true,actualLockDaily:true,canonicalChoicesAndMovementUnmodified:true,noExtraRngCalls:true,observerOnly:true,records})+'\n');}
