# Causal420 operational handoff — running, no sampling wait

Master **70833**, launchd entry **70810**, service `gui/502/com.codex.nighthorde.causal1231v1`, long-worker cap **9**. Latest checkpoint 2026-11-14T15:38:57.840459+00:00: **198/420 terminal**, active9, pending213, failed0, UNKNOWN0. Root approved the checked pilot in `root-pilot-readback.json`; full GO is recorded in `full-go-record.json` / `execution-control.json`. First preregistered `12-armorOnly/c05-i00` remains counted ONCE; no replay, parameter or seed change. Do not rerun `causal-full` or bootstrap this job. External one-shot job continues independently of this agent turn; no KeepAlive/watcher/retry loop.

Source identity is **not a synthetic Git head**: sourceKind/publicBaseSHA/patchSHA256/appManifestSHA256/appGraphSHA256/variantId/isNotGit are retained per attempt. Public bases12=99f8758a45e90ee5dc2370d1218837b9f0924128 and31=f67463eaf00b15304655ba44d6966bfc75090934; exact5variant identities/hashes in `candidate-bindings.json` and prep's read-only binding.json files.420 frozen tuples are240 ArmorOnly/SpeedOnly human3/4 lunch +180 B/C/D31 human4 lunch. No candidateSha/sourceSha is fabricated for patched copies. Node24.22.1 SHA and unchanged canonical drivers/argv/env are frozen in `plan.json` / `adapter-manifest.json`; inherited gameplay override knobs are blocked.

`source-and-selector-proof.json` independently verifies every manifest/file/patch and intended numeric-only delta. Entire native99 Room graph equals609; prior818→609 canonical actual-selector carry is linked. Native host daily input explicitly prelocks planned UTCday; version2/modifiers/mode/player/log identity are checked per attempt. This is native/core outcome applicability, no HTTP/browser/CPU/FPS claim. Root owns statistical analysis; existing baseline/Daily/45 datasets were neither rerun nor reanalysed here.

Observer proof: `native-exercise-results.json` plus final stdout/stderr. All5 variants exercise native Wardblock, damaging melee/projectile before/after real duo, native boss log damage, down/dawnrevive/XP/finish; observer on/off physical checkpoints and RNG draw counts match. Treatment-dependent gameplay RNG streams may diverge; they are not synchronized. Boss counter uses actual native boss-log increment. Incoming postArmorBeforeFloor is formula exposure including blocked calls, not actual prevented HP. Actual loss/zero-loss/floor calls are separate. Trace includes exact payloadJSON and SHA; supervisor validates source, trace payload/file hashes, native actual Node exit, Room.finish/state/log/tuple, play budget and daily contract. All errors/UNKNOWN remain, no auto fallback or retry.

**Known hard holds:**0c source remains243terminal/357notStarted, idle master45999;307 remains278/322, idle master68550. Both active0/cap0, PAUSE, registrylaunchable=false/phaseEligible=false, rootArmed=false and SHA-forbidden. No worker was killed. Do not resume, alter bindings, clear their holds or call normal complete600 cleanup.60041 at7e2 is completed/receipt0/outcomes-only; support.control acceptance excluded. Later30d code/physical carry is separate root/peer evidence. Historical16 UNKNOWN +2 observed-15 interruptions +oldheld2 remain preserved.

## Commands

```sh
RUNS_CAUSAL='/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/issue-split/runs/causal-12-31-v1'
RUNS_QA='/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/issue-split/runs/final-a25-r16/qa-control.py'
cat "$RUNS_CAUSAL/controller-state.json"  # strictly read-only progress
python3 "$RUNS_QA" status               # refresh checkpoint; no dispatch
python3 "$RUNS_QA" phase                # finite event-based allocation, no held-source resume
python3 "$RUNS_QA" pause                # graceful global dispatch pause; inflight persists
python3 "$RUNS_QA" resume               # clears global pause only, preserves local/source holds
```

All public old control/phase entrypoints delegate to this one registry/budget/operator.lock. It counts max(configuredLimit,inflightActive) for every managed old/new plan, never>9. Missing master/currentUNKNOWN/nonzero exit blocks new starts. Do not modify running source/variant/adapter hashes or manually write caps to bypass the operator.420complete requires native proofs, active0 and actual master exit receipt0; then `phase` releases cap0. Once fully inactive, cleanup exact owned service:

```sh
python3 "$RUNS_QA" cleanup causal-420
```

Future guard: create a **new** immutable600 plan on a new public SHA; never rebind0c/307. Independently verify600 original tuples, Node/runner/core bytes, source/public snapshot manifest, native actualDate.now run/request/expiry ACK180→ordinary185 and play/finish/log smoke; require current primaryCI/merge-tree + independent exact-source READY + explicit rootGO. Under the shared operator.lock add a new registry key with planDir, sourceKind=git-archive, role=guarded17, higher rolePriority, readinessPath, launchable/phaseEligible only after gates. Latch file must have plans[KEY] with rootArmed, exact sourceHeads, ownSmoke(path/hash/pass), exact CI(sourceSha/runId/SUCCESS/primaryVerified), independentReview(READY/sourceHeads/evidence). Source SHA must not be forbidden. Preserve old entries. Rename only the new INITIAL_READINESS_HOLD after gates; never clear SOURCE_HARDHOLD. To share longworkers: `limit causal-420 6`, read until its active<=6, then `phase` may launch new eligible guard3. It resolves the latest eligible role, not hardcoded0c. If root has not approved futureguard, keep current causal9; source-hold flags prevent auto resume.

`replication-21-swarm-HOLD240.json` is **HARDHOLD0/not registered**:60 fresh pairs21h4lunch seeds3210000..59/K022000+i, and60 fresh Swarmh4night pairs3120100..59/K020064+i. Never start before fixed420complete and separate gates/GO; public-arm contract/240-scope adapter still required. Optional caravan trace reads real room.enemies matching e.caravan; XP sourceAttribution staysnull and is NOT native reward attribution.56group/perf remains a separate platform HOLD workflow; its8paired seeds4565800..07/K058000..07 are RESERVED_HOLD0 only.

Pilot path: `raw/12-armorOnly/c05-i00/meta.json`; root readback, pilot-complete, sourceproof, nativeproof and adapter hashes are adjacent. Raw and per-attempt .start/dispatch/worker/exit/meta/countertrace/stdout/stderr are durable under raw/variant/id. No overall balance/product READY is asserted by this completed adapter/start subtask.
