import pathlib,json,hashlib,os
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def atomic(p,o):
 p=pathlib.Path(p);t=p.with_name(p.name+'.tmp-'+str(os.getpid()))
 with t.open('w')as f:json.dump(o,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 os.replace(t,p)
def verify(b):
 S=pathlib.Path(b['snapshotPath']);assert b['notAGitHead']is True;assert b['sourceKind']in['output-only-patched','public-sha-import-snapshot'];assert b['APP']==str(S/'app');assert sha(S/'patch.diff')==b['patchSHA256'];assert sha(S/'app-manifest.json')==b['appManifestSHA256'];m=json.loads((S/'app-manifest.json').read_text());assert m['publicBaseSHA']==b['publicBaseSHA'];assert hashlib.sha256(json.dumps(m['files'],sort_keys=True).encode()).hexdigest()==b['appGraphSHA256']
 for f in m['files']:assert sha(S/f['path'])==f['sha256']
 assert json.loads((S/'binding.json').read_text())==b
 return True
def frozen(Q):
 Q=pathlib.Path(Q);f=json.loads((Q/'adapter-manifest.json').read_text())
 for path,h in f['files'].items():assert sha(path)==h,('ADAPTER_HASH_MISMATCH',path)
 return f
