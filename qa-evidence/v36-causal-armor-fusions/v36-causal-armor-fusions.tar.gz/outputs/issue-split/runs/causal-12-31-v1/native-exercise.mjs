import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {pathToFileURL} from 'node:url';import crypto from 'node:crypto';
import {verifyBinding,assertEffects,installObserver} from './observer.mjs';
const Q=path.dirname(new URL(import.meta.url).pathname),all=JSON.parse(fs.readFileSync(path.join(Q,'candidate-bindings.json'))).variants,rows=[];
process.env.HORDE_RUNS_DIR=path.join(Q,'native-exercise-runs');
for(const b of Object.values(all).filter(b=>b.sourceKind==='output-only-patched')){
 verifyBinding(b);const {Room}=await import(pathToFileURL(b.APP+'/server/game.js')),C=await import(pathToFileURL(b.APP+'/public/shared/content.js'));
 function scene(on){let value=9182,draws=0,obs;const random=Math.random;Math.random=()=>{draws++;value=(Math.imul(value,1664525)+1013904223)>>>0;return value/4294967296;};const physical=[];
  try{if(on)obs=installObserver(Room,C,{binding:b,outputFile:path.join(Q,'native-exercise',b.variantId+'-counter.json')});
   const r=new Room('EXTENDED-NATIVE',()=>{});r.setMode('lunch');for(let pid=1;pid<=4;pid++)r.addPlayer(pid,'R'+pid,'ranger');if(b.expected.issue===12){r.handle(r.host,{t:'daily',enabled:true});r.lockDaily('2026-11-13T12:00:00Z');}assertEffects(r,C,b);r.start();assert.equal(r.state,'play');
   const hs=[...r.heroes.values()],h=hs[0];for(const p of hs){p.x=500+p.pid*100;p.y=0;p.weapons.clear();p.perk.readyAt=Infinity;}
   const snap=label=>physical.push({label,time:r.time,state:r.state,heroes:hs.map(p=>({pid:p.pid,x:p.x,y:p.y,hp:p.hp,st:p.st,ward:p.ward,guard:p.guard,blockCharge:p.blockCharge,weapons:[...p.weapons].map(([id,w])=>[id,w.lvl])})),enemies:r.enemies.map(e=>[e.id,e.x,e.y,e.hp,e.maxHp,e.dmg,!!e.dead]),bosses:r.runLog.bosses.map(e=>({group:e.group,hp:e.hp,dmg:e.dmg,by:e.by})),xp:h.xp,level:h.level});
   for(let i=0;i<3;i++)r.tick(1/30);h.iframes=0;h.ward=1;const hp=h.hp;r.hurtPlayer(h,99,'spitter:shot');assert.equal(h.hp,hp);snap('native-ward-block');
   h.iframes=0;const old=h.hp;r.hurtPlayer(h,1,'ghoul');assert.ok(h.hp<old);h.iframes=0;r.hurtPlayer(h,9,'spitter:shot');snap('native-melee-projectile-before-duo');
   h.weapons=new Map([['bolt',{lvl:3,t:0}],['lightning',{lvl:3,t:0}]]);const card=r.duoCard(h,{id:'orb',a:'bolt',b:'lightning'});assert.equal(r.fuseDuo(h,card),true);h.iframes=0;r.hurtPlayer(h,3,'ghoul');snap('native-fusion-and-postfusion-hit');
   const type=Object.keys(C.ENEMIES).find(k=>C.ENEMIES[k].boss);assert.ok(type);const boss=r.spawnBoss(type,hs,0);boss.x=h.x+80;boss.y=h.y;r.rebuildGrid();const before=boss.hp;r.hurtEnemy(boss,7,h);assert.ok(boss.hp<before);assert.ok(r.runLog.bosses.some(e=>e.dmg>0));snap('native-boss-hit');
   h.ward=0;h.iframes=0;r.hurtPlayer(h,1e6,'ghoul');assert.equal(h.st,1);snap('native-down');assert.equal(r.dawnRevive(),1);assert.equal(h.st,0);r.addXp(h,2);snap('native-dawn-revive-xp');
   for(let i=0;i<3;i++)r.tick(1/30);r.finish(false,0);assert.equal(r.state,'over');assert.ok(r.lastLog.id);snap('native-finish');
   let trace;if(on){trace=obs.flush(r,'extended-native-postfinish');const s=trace.payload.rooms[0];assert.equal(s.finishCalls,1);assert.equal(s.terminalTransitions,1);assert.equal(s.final.terminal,true);assert.equal(s.final.logId,r.lastLog.id);assert.ok(s.events.some(e=>e.type==='duo'));assert.ok(s.events.some(e=>e.type==='down'));assert.ok(s.events.some(e=>e.type==='revive'));assert.ok(Object.values(s.bossDamage).some(n=>n>0));assert.ok(Object.values(s.incoming).some(x=>x.zeroHpLossCalls>0));assert.ok(Object.values(s.incoming).some(x=>x.hpLoss>0));assert.ok(Object.values(s.incoming).some(x=>x.preFusion));assert.ok(Object.values(s.incoming).some(x=>!x.preFusion));}
   return {physical,draws,traceHash:trace?.countertraceSHA256,terminal:r.state==='over'};
  }finally{obs?.uninstall();Math.random=random;}
 }
 const off=scene(false),on=scene(true);assert.deepEqual(on.physical,off.physical,'observer on/off native gameplay must match at every exercised transition');assert.equal(on.draws,off.draws,'observer adds no RNG calls in hurt/block/duo/boss/down/revive/finish paths');rows.push({variantId:b.variantId,sourceKind:b.sourceKind,publicBaseSHA:b.publicBaseSHA,patchSHA256:b.patchSHA256,appManifestSHA256:b.appManifestSHA256,pass:true,physicalCheckpoints:on.physical.map(x=>x.label),rngDraws:on.draws,countertraceSHA256:on.traceHash,smokeOnly:true,acceptanceOutcome:false,manualNativeFinish:true});console.log(b.variantId+' extended native observer-neutral PASS');
}
const doc={pass:true,runtime:process.version,node:process.execPath,rows,noFullSimulationAttempts:true,noCPUorFPSclaims:true};fs.writeFileSync(path.join(Q,'native-exercise-results.json'),JSON.stringify(doc,null,2));
