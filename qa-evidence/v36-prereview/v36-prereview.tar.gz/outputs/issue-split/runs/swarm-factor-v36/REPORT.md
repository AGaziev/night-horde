# Swarm: predefined factor probe v36

Измеренный исходник #12 `8d1c3a559ff0722dfe856e12121f122dcc0d22d5`, baseline `f4a40dc3cd743a114b5df7417acd65e0c08bceae`.180/180 новых terminal исходов,0errors/unknown;60fixed human1night на каждую из3копий. Ordinarycontrol26/60 взят один раз из freshf4a600. Это отдельный причинный эксперимент, не приёмка #12 и не полная матрица2400.

| Arm | enemyRate / xp | Wins/60 | Wilson95% | Δpp к ordinary [paired95] |
|---|---|---|---|---|
| ordinary | 1 / 1 | 26/60 (43.33%) | [31.57, 55.9] | control |
| densityOnly | 1.15 / 1 | 29/60 (48.33%) | [36.17, 60.69] | 5.0 [-10.75, 20.75] |
| xpOnly | 1 / 1.15 | 27/60 (45.0%) | [33.09, 57.51] | 1.67 [-14.13, 17.46] |
| combined | 1.15 / 1.15 | 38/60 (63.33%) | [50.68, 74.38] | 20.0 [1.48, 38.52] |

Combined vsdensityOnly:+15ppCI[−1.68,31.68]; vsxpOnly:+18.33ppCI[0.60,36.07]. Факторное взаимодействие combined−densityOnly−xpOnly+ordinary=+13.33ppCI[−8.25,34.92]. Супераддитивность не доказана; XP-alone не установлен как единственная причина. Номинальные32.25% дополнительного XP-потенциала(1.15×1.15) требуют одинаковой структуры убитых врагов и не являются измеренным фактическим XP.

Meanfinallevel ordinary/density/xp/combined=43.30/46.85/46.75/53.23. Финальные уровни зависят от времени жизни; условные поминутные уровни/kill/taken и denominators находятся в summary. Terminalraw не содержит полного счётчика выданногоXP, поэтому это не доказательство медиаторного канала через XP.

Во всех180: actualhost handle daily + lockDailyUTC2026-11-16, реальнаяnativeсимуляция/каноническиеchoices/movement/RNG, exactmods/day/mode/players/logId иterminal/finish. Sourcecopy-патчи меняют только Swarm enemyRate/xp; ни один иной параметр не менялся. У combined patch пустой, sourcebytes исходные. UIописания в mechanicalcopies не переписывались, эти копии не публиковались.

| Variant | Patch SHA256 |
|---|---|
| densityOnly | `ab4ede2505a9500bf1282c94ff21fab45bb6f3f2f0844c4d8cebac030eb51b84` |
| xpOnly | `17cba6a96c277da8037eee7d304e1d4e8b1dec8c2f6db61773a8309093385ed6` |
| combined | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |

Node `v24.22.1` binarySHA256 `cf52d093e9b728a7e6929a4371fa37d271304383e7e7c9f0f0e32fb00373b32c`. Source/runtime/runner/selector hashes зафиксированы доlaunch и после сверены. Все source manifests неизменны. Одни seeds130000+i/K0=i/канонические8героев, args1 1 human, по60терминальных пар. Все initialattempts сохранены, без повторов и адаптации по seed.

В исходном tuple-шаблоне по ошибке осталось неиспользуемое поле revision=baseline. Источник каждой попытки однозначно задан sourceSha8d1/variantAPP/patchhash и фактическим dailycontract; эти180 относятся к candidateVariant. Замороженный план/raw не переписаны; [явная классификация](execution-role-binding.json) и provenance отражают ошибочную исходную метку. Команды, sourcebytes, seeds и модификаторы от неё не зависели.

Первичные доказательства: [plan](plan.json),[summary](summary.json),[provenance180](provenance.json),[sourceaudit](source-audit.json),[ordinarycontrol semanticproof](ordinary-control-proof.json),[controllercomplete](complete.json). Intervals unadjusted: выводы по одной ячейке не принимают остальные9 и не заменяют full12/2400. Конкурентные wall/CPU timings не являются performance-проверкой.

Exact paired sensitivity: {'densityOnlyVsOrdinary': {'discordant': 23, 'p': 0.6776394844055176}, 'xpOnlyVsOrdinary': {'discordant': 23, 'p': 1}, 'combinedVsOrdinary': {'discordant': 34, 'p': 0.05761267291381955}, 'xpOnlyVsDensityOnly': {'discordant': 26, 'p': 0.8450189828872681}, 'combinedVsDensityOnly': {'discordant': 27, 'p': 0.12207812070846558}, 'combinedVsXpOnly': {'discordant': 31, 'p': 0.07075554598122835}}. Этиp также без поправки на множественные сравнения. CombinedWilson95=[50.68, 74.38] исключает human target25–40, даже если парная популяционная разница к ordinary остаётся неопределённой.
