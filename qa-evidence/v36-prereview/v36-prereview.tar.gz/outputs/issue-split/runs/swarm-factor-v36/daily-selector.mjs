// Harness only: choose the real optional host setting and lock a reproducible UTC day.
import assert from 'node:assert/strict';
const {Room}=await import(process.env.APP+'/server/game.js');
const {dailyFor}=await import(process.env.APP+'/public/shared/daily.js');
const day=process.env.DAILY_DAY,rule=process.env.DAILY_RULE;
assert.match(day??'',/^\d{4}-\d{2}-\d{2}$/);assert.equal(dailyFor(day+'T12:00:00Z').id,rule);
const start=Room.prototype.start,finish=Room.prototype.finish,records=[];
Room.prototype.start=function(...args){
 this.handle(this.host,{t:'daily',enabled:true});assert.equal(this.dailySelected,true);this.lockDaily(day+'T12:00:00Z');
 const result=start.apply(this,args);assert.equal(this.daily?.id,rule);assert.equal(this.daily?.day,day);assert.equal(this.daily?.mode,this.mode);assert.equal(this.daily?.players,this.heroes.size);
 records.push({contract:this.daily,startedAt:this.time,players:[...this.heroes.values()].map(h=>({pid:h.pid,hero:h.hero,maxHp:h.maxHp,damage:h.mods.dmgMul,speed:h.mods.speedMul,armor:h.mods.armor,pickup:h.mods.magnetMul}))});return result;
};
Room.prototype.finish=function(...args){const result=finish.apply(this,args);if(this.lastLog){assert.equal(this.lastLog.daily?.id,rule);assert.equal(this.lastLog.daily?.day,day);const record=records.at(-1);if(record){record.finished=true;record.terminalState=this.state;record.activeSeconds=this.time;record.logId=this.lastLog.id;record.loggedContract=this.lastLog.daily;}}return result;};
try{await import(new URL('../harness/pm/run-sim.mjs',import.meta.url));}
finally{process.stderr.write('DAILY_SELECTOR_METRICS '+JSON.stringify({rule,day,actualHostSelector:true,actualLockDaily:true,canonicalChoicesAndMovementUnmodified:true,noExtraRngCalls:true,records})+'\n');}
