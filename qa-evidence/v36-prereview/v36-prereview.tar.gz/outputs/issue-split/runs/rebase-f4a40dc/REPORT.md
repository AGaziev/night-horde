# Fresh v36 baseline600

PASS for measurement completeness only. Actual measured source `f4a40dc3cd743a114b5df7417acd65e0c08bceae`;600/600 planned attempts terminal,0errors,0unknown,0notStarted. No candidate launched or approved. Old dca/515 results remain historical.

Node `v24.22.1`, binary SHA256 `cf52d093e9b728a7e6929a4371fa37d271304383e7e7c9f0f0e32fb00373b32c`. Fixed original seeds `130000+i+cell*1000`,K0=i and canonical eight-hero rotation. Canonical run-sim/sim-runner bytes unchanged. Source app+pm archive frozen before launch; full manifest unchanged after measurement.

Every attempt independently audited: actual players/heroes/mode/bot, exact command/APP/seed/K0/runtime hashes, exit0, terminal=true,state=over,finishCalls>=1 and matching logId.0budget overruns; all reconstructed final inventories match saved final inventories.13midpoint imprint reconstructions remain explicitly uncertain in statistics; no terminal exclusions.

| Cell | New f4a wins/60 | Percent [Wilson95] | Historical wins/60 | Paired delta pp [95%] |
|---|---|---|---|---|
| human1 night | 26/60 | 43.33 [31.57, 55.9] | 26/60 | 0 [-6.59, 6.59] |
| human1 lunch | 17/60 | 28.33 [18.51, 40.77] | 19/60 | -3.33 [-11.36, 4.69] |
| human2 night | 24/60 | 40.0 [28.57, 52.63] | 26/60 | -3.33 [-13.72, 7.05] |
| human2 lunch | 22/60 | 36.67 [25.62, 49.32] | 24/60 | -3.33 [-13.72, 7.05] |
| human3 night | 12/60 | 20.0 [11.83, 31.78] | 16/60 | -6.67 [-15.83, 2.49] |
| human3 lunch | 25/60 | 41.67 [30.06, 54.27] | 25/60 | 0 [-8.07, 8.07] |
| human4 night | 20/60 | 33.33 [22.73, 45.94] | 17/60 | 5.0 [-5.85, 15.85] |
| human4 lunch | 17/60 | 28.33 [18.51, 40.77] | 22/60 | -8.33 [-20.91, 4.25] |
| smart1 night | 40/60 | 66.67 [54.06, 77.27] | 41/60 | -1.67 [-7.36, 4.02] |
| smart1 lunch | 36/60 | 60.0 [47.37, 71.43] | 37/60 | -1.67 [-10.37, 7.04] |

Historicalcomparison is descriptive net effect of main changes, not graph carry or a separate causal estimate of sniper/forge changes. Old baseline was measured515 and accepted dca by prior exact graph proof; currentf4a is freshly measured. All paired intervals above cross0; that does not establish equivalence. Point human3night20% is below25–40; h1night43.33%/h3lunch41.67% above40. Candidate comparisons must use these new controls and disclose baseline deviations.

Rich [summary](summary.json) contains death minutes/causes, midpoint weapons with denominators/uncertainty, boss damage/nearDPS and finale outcomes. These metrics depend on survival/progression. Wall/CPU durations under9 concurrentworkers are not performance acceptance. No liveplayer or GPU evidence is claimed.

Primary evidence: [frozenplan](plan.json),[authorization](launch-authorized.json),[600rawprovenance](provenance.json),[allattemptstatuses](attempt-status.json),[source/runtimeproof](baseline-proof.json),[complete](complete.json),[runtime delta](runtime-delta.json). Rawprefixes under `raw/baseline`, each with start/meta/JSON/stderr. Successful attempts not rerun; no automatic retries.

CPU_FREE: baseline controller completed and every Node child exited. Old daily master remains aliveidle with its ownPAUSE/worker-limit0 and1040terminal/1360notStarted. All candidateplans remain HOLD pending root final8HEADs and explicitGO.
