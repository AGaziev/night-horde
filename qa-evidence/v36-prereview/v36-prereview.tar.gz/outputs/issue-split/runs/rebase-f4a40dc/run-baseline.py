import pathlib,json,subprocess,datetime,concurrent.futures,hashlib,time,traceback,os
D=pathlib.Path(__file__).resolve().parent;P=D.parent;plan=json.loads((D/'plan.json').read_text());AUTH=json.loads((D/'launch-authorized.json').read_text());assert AUTH['authorized']is True and AUTH['sourceSha']==plan['baseline'];plan['attempts']=[{**a,'version':'baseline','snapshotPath':plan['snapshot'],'runner':plan['canonicalRunner']}for a in plan['attempts']];node=plan['node'];assert hashlib.sha256(pathlib.Path(node).read_bytes()).hexdigest()==plan['nodeBinarySHA256']
lock=D/'controller.lock'
with lock.open('x')as f:json.dump({'pid':os.getpid(),'at':datetime.datetime.now(datetime.timezone.utc).isoformat()},f)
unknown=[];done=[];pending=[];active={}
def stem(a):return D/'raw'/a['version']/a['id']
for a in plan['attempts']:
 s=stem(a)
 if s.with_suffix('.meta.json').exists():done.append(json.loads(s.with_suffix('.meta.json').read_text()))
 elif s.with_suffix('.start.json').exists():unknown.append(a)
 else:pending.append(a)
def run(a):
 s=stem(a);s.parent.mkdir(parents=True,exist_ok=True);cmd=[node,'--random-seed='+str(a['seed']),a['runner'],str(a['players']),'1',a['bot']];env={'PATH':str(pathlib.Path(node).parent)+':/usr/bin:/bin','APP':a['snapshotPath']+'/app','MODE':a['mode'],'K0':str(a['K0']),'TZ':'UTC','LANG':'C'};m={**a,'command':cmd,'environment':env,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runtime':plan['runtime'],'nodeBinarySHA256':plan['nodeBinarySHA256'],'canonicalRunnerHashes':plan['canonicalRunnerHashes']};s.with_suffix('.start.json').open('x').write(json.dumps(m,indent=2));out='';err='';t=time.monotonic()
 try:
  r=subprocess.run(cmd,env=env,cwd=P,capture_output=True,text=True,timeout=240);out=r.stdout;err=r.stderr;data=json.loads(out);l=data['logs'][0];c=data['completion'][0];actual={'players':len(l['team']),'heroes':[h['hero']for h in l['team']],'mode':l['mode'],'bot':data['pick']};m.update(exitCode=r.returncode,actualTuple=actual,tupleProof=actual=={k:a[k]for k in ['players','heroes','mode','bot']},completion=c);m['terminalProof']=r.returncode==0 and len(data['logs'])==len(data['completion'])==1 and c['terminal']is True and c['state']=='over'and c['finishCalls']>=1 and c['logId']==l['id']and m['tupleProof'];m.update(win=l['win'],simulatedSeconds=l['time'],runLength=l['runLength'],budgetOverrun=l['time']>l['runLength']+.11)
 except Exception as e:m.update(terminalProof=False,error=repr(e));err+='\n'+traceback.format_exc()
 s.with_suffix('.json').write_text(out);s.with_suffix('.stderr.txt').write_text(err);m.update(durationSeconds=time.monotonic()-t,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());s.with_suffix('.meta.tmp').write_text(json.dumps(m,indent=2)+'\n');s.with_suffix('.meta.tmp').replace(s.with_suffix('.meta.json'));return m
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=9)as ex:
  while pending or active:
   while pending and len(active)<min(9,max(0,int((D/'worker-limit.json').read_text()))) and not(P/'PAUSE').exists() and not(D/'PAUSE').exists():
    a=pending.pop(0);active[ex.submit(run,a)]=a
   if not active:time.sleep(.25);continue
   fs,_=concurrent.futures.wait(active,timeout=.25,return_when=concurrent.futures.FIRST_COMPLETED)
   for f in fs:
    a=active.pop(f)
    try:m=f.result();done.append(m);print(a['version'],a['id'],m['terminalProof'],'win',m.get('win'),flush=True)
    except Exception as e:unknown.append({**a,'controllerError':repr(e)})
   state={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'done':len(done),'active':len(active),'pending':len(pending),'unknown':unknown};(D/'state.tmp').write_text(json.dumps(state,indent=2)+'\n');(D/'state.tmp').replace(D/'state.json')
 (D/'complete.json').write_text(json.dumps({'planned':len(plan['attempts']),'done':len(done),'terminal':sum(m.get('terminalProof')is True for m in done),'errors':sum(m.get('terminalProof')is not True for m in done),'unknown':unknown},indent=2)+'\n')
finally:
 if lock.exists():lock.rename(D/('controller-finished-'+str(os.getpid())+'.json'))
