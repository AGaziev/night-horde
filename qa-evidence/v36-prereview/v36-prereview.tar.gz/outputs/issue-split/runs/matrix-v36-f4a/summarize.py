import pathlib,json,datetime,collections,sys
P=pathlib.Path(__file__).resolve().parent;W=pathlib.Path('/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe');OLD=W/'outputs/eight-issues/runs';PLAN=json.loads((P/'plan.json').read_text());BIND=json.loads((P/'candidate-bindings.json').read_text());defs=(OLD/'summarize.py').read_text().split('rows=[];statuses=[]')[0];ns={'__file__':str(OLD/'summarize.py')};exec(defs,ns);ns['MAP']['baseline']=ns['mapping'](str(P/'baseline'));BASE={a['id']:json.loads((P/'raw/baseline'/a['id']).with_suffix('.json').read_text())['logs'][0]for a in PLAN['attempts']if a['issue']==PLAN['matrixIssues'][0]};allReports=[];statuses=[]
for issue in PLAN['matrixIssues']:
 binding=BIND['issues'][str(issue)];sha=binding['candidateSha'];ns['MAP']['candidate']=ns['mapping'](binding['snapshotPath']);rows=[];raw=P/f'raw/issue-{issue}'/sha
 for ci,cell in enumerate(PLAN['cells']):
  A=[a for a in PLAN['attempts']if a['issue']==issue and a['cell']==ci];rs={};failed=[];notstarted=[];unknown=[]
  for a in A:
   stem=raw/a['id'];mf=stem.with_suffix('.meta.json');m=json.loads(mf.read_text())if mf.exists()else None
   status='terminal'if m and m.get('terminalProof')is True else'failed'if m else'unknownStarted'if stem.with_suffix('.start.json').exists()else'notStarted';statuses.append({'attemptId':a['attemptId'],'issue':issue,'sourceSha':sha,'seed':a['seed'],'K0':a['K0'],'status':status})
   if status=='terminal':
    assert m['sourceSha']==sha;rs[a['id']]=json.loads(stem.with_suffix('.json').read_text())['logs'][0]
   elif status=='failed':failed.append(m)
   elif status=='unknownStarted':unknown.append(a['id'])
   else:notstarted.append(a['id'])
  b=ns['stats']([BASE[a['id']]for a in A],'baseline');c=ns['stats'](list(rs.values()),'candidate');paired=ns['pairStats']([(BASE[id],r)for id,r in rs.items()]);rows.append({'cell':ci,**cell,'baseline':b,'candidate':c,'paired':paired,'failed':failed,'notStarted':notstarted,'activeOrUnknownStarted':unknown,'complete':len(rs)==60 and not failed})
 tiers={}
 for tier,cells in [('human1',[0,1]),('human2',[2,3]),('human3',[4,5]),('human4',[6,7]),('smartSolo',[8,9])]:
  r=[x for x in rows if x['cell']in cells];tiers[tier]={'terminal':sum(x['candidate']['terminal']for x in r),'wins':sum(x['candidate']['wins']for x in r),'errors':sum(len(x['failed'])for x in r),'completedCells':sum(x['complete']for x in r),'planned':120,'note':'descriptive aggregate only; compare confidence intervals per homogeneous cell'}
 report={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'issue':issue,'baseline':PLAN['baseline'],'measuredBaseline':PLAN['measuredBaseline'],'candidate':sha,'runtime':PLAN['runtime'],'canonicalRunnerHashes':PLAN['canonicalRunnerHashes'],'matrixComplete':all(x['complete']for x in rows),'terminal':sum(x['candidate']['terminal']for x in rows),'errors':sum(len(x['failed'])for x in rows),'tiers':tiers,'rows':rows,'combinedCandidateEvidenceUsed':False,'metricsNotes':['Death means all down events; minutes=floor(t/60)+1','Midpoint inventories exclude runs ending earlier; denominators and imprint uncertainty explicit','End inventory reconstruction is validated against saved final inventory','Boss damage totals depend on survival/progression, not isolated causal DPS','Wilson intervals for rates; paired normal intervals for binary differences only when both revisions terminal','CPU/wall duration of these concurrent jobs is not a performance acceptance']};R=P/f'reports/issue-{issue}'/sha;R.mkdir(parents=True,exist_ok=True);(R/'summary.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n');allReports.append(report)
(P/'attempt-status.json').write_text(json.dumps(statuses,indent=2)+'\n');index={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'planned':len(PLAN['attempts']),'terminal':sum(x['terminal']for x in allReports),'failed':sum(x['errors']for x in allReports),'issues':[{k:r[k]for k in ['issue','candidate','matrixComplete','terminal','errors','tiers']}for r in allReports]};(P/'matrix-index.json').write_text(json.dumps(index,indent=2)+'\n')
for r in allReports:
 print('ISSUE',r['issue'],r['candidate'],'terminal',r['terminal'],'errors',r['errors'])
 for x in r['rows']:
  n=x['candidate']['terminal']
  if n:print(' ',x['cell'],x['bot'],x['players'],x['mode'],x['candidate']['wins'],'/',n,'baseline',x['baseline']['wins'],'/60','paired',x['paired'])
print('ALL',index['terminal'],'/2400 errors',index['failed'])
