// Input policy only. Observations are a subset of the canonical human bot's current view.
export const POLICY = Object.freeze({ version: 1, enemySight: 190, shotSight: 90,
  reactionTicks: 8, threatSeconds: 0.25, trajectorySeconds: 0.15,
  enemyVelocity: 'two consecutive visible observations; zero for a new ID',
  projectileVelocity: 'current public eshot velocity; conservative no expiry prediction',
  visibility: 'human circle and the same ignored quarter of projectiles' });

const d2 = (a, b) => (a.x - b.x) ** 2 + (a.y - b.y) ** 2;
function segment2(ax, ay, bx, by) {
  const dx = bx - ax, dy = by - ay, ll = dx * dx + dy * dy;
  const t = ll ? Math.max(0, Math.min(1, -(ax * dx + ay * dy) / ll)) : 0;
  return (ax + dx * t) ** 2 + (ay + dy * t) ** 2;
}

export function createGuard({ DASH, PLAYER_RADIUS, HOSTILE_R, REVIVE_RADIUS, clampToRing }) {
  const rooms = new WeakMap();
  return function decide(room, h, dx, dy) {
    if (!h || room.state !== 'play') return { press: false, reason: 'inactive' };
    let heroes = rooms.get(room); if (!heroes) rooms.set(room, heroes = new Map());
    let old = heroes.get(h.pid);
    const fresh = !old || room.tickNo % POLICY.reactionTicks === h.pid % POLICY.reactionTicks;
    if (!fresh) return { press: false, reason: 'reaction-hold' };
    const enemies = [], previous = new Map();
    for (const e of room.enemies) {
      if (e.dead || d2(e, h) >= POLICY.enemySight ** 2) continue;
      // Quantize as the public snapshot does. No AI state, target, cooldown or future RNG is read.
      const x = Math.round(e.x), y = Math.round(e.y), before = old?.previous.get(e.id);
      const elapsed = before ? room.time - before.at : 0;
      const vx = elapsed > 0 && elapsed <= 0.5 ? (x - before.x) / elapsed : 0;
      const vy = elapsed > 0 && elapsed <= 0.5 ? (y - before.y) / elapsed : 0;
      enemies.push({ kind: 'enemy', id: e.id, x, y, vx, vy, r: e.r });
      previous.set(e.id, { x, y, at: room.time });
    }
    heroes.set(h.pid, { previous });
    if (room.frozen || room.paused || h.offer || h.offline || h.st !== 0 || h.dash)
      return { press: false, reason: 'native-guard' };
    if (room.time < (h.dashReadyAt ?? 0)) return { press: false, reason: 'cooldown' };
    if (h.iframes !== 0) return { press: false, reason: 'iframes' };
    if (![dx, dy].every(Number.isFinite) || Math.hypot(dx, dy) <= 0.01)
      return { press: false, reason: 'idle' };
    for (const o of room.heroes.values()) {
      if (o !== h && o.st === 1 && d2(o, h) < REVIVE_RADIUS ** 2)
        return { press: false, reason: 'reviving' };
    }
    const shots = [];
    for (const s of room.hostile) {
      if ((s.id ?? 0) % 4 === 0 || d2(s, h) >= POLICY.shotSight ** 2) continue;
      shots.push({ kind: 'shot', id: s.id, x: Math.round(s.x), y: Math.round(s.y),
        vx: Math.round(s.vx), vy: Math.round(s.vy), r: s.r ?? HOSTILE_R });
    }
    const hazards = [...enemies, ...shots];
    const threat = hazards.find(e => segment2(e.x - h.x, e.y - h.y,
      e.x + e.vx * POLICY.threatSeconds - h.x,
      e.y + e.vy * POLICY.threatSeconds - h.y) < (PLAYER_RADIUS + e.r) ** 2);
    if (!threat) return { press: false, reason: 'no-near-threat' };
    const length = Math.hypot(dx, dy), ux = dx / length, uy = dy / length;
    const x = h.x + ux * DASH.distance, y = h.y + uy * DASH.distance;
    // A clipped dash follows a different, possibly curved wall path. This policy skips
    // that uncertainty rather than pretending the clipped endpoint gives a straight path.
    if (Math.abs(x) > 100000 || Math.abs(y) > 100000)
      return { press: false, reason: 'boundary' };
    if (room.fin) {
      const [cx, cy] = clampToRing(x, y, room.fin.cx, room.fin.cy, room.fin.r - PLAYER_RADIUS);
      if (Math.hypot(cx - x, cy - y) > 1e-6) return { press: false, reason: 'boundary' };
    }
    let clearMargin = Infinity;
    for (const e of hazards) {
      const ex = e.x + e.vx * DASH.duration, ey = e.y + e.vy * DASH.duration;
      const distance = segment2(e.x - h.x, e.y - h.y, ex - x, ey - y);
      clearMargin = Math.min(clearMargin, Math.sqrt(distance) - PLAYER_RADIUS - e.r);
      if (distance < (PLAYER_RADIUS + e.r) ** 2)
        return { press: false, reason: 'unsafe-path', hazard: e.kind };
      if ((ex - x) ** 2 + (ey - y) ** 2 < (PLAYER_RADIUS + e.r) ** 2)
        return { press: false, reason: 'unsafe-end', hazard: e.kind };
    }
    return { press: true, reason: 'guarded-use', direction: [ux, uy],
      threat: { kind: threat.kind, id: threat.id }, predictedEnd: [x, y], clearMargin };
  };
}
