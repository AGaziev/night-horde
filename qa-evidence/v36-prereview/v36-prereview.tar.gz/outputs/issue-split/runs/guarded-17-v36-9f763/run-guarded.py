import pathlib,json,subprocess,concurrent.futures,datetime,time,threading,os,hashlib,traceback
P=pathlib.Path(__file__).resolve().parent;PLAN=json.loads((P/'plan.json').read_text());AUTH=json.loads((P/'launch-authorized.json').read_text());BIND=json.loads((P/'candidate-bindings.json').read_text());assert AUTH['authorized']is True;NODE=PLAN['node'];RUNNER=PLAN['canonicalRunner'];assert hashlib.sha256(pathlib.Path(NODE).read_bytes()).hexdigest()==PLAN['nodeBinarySHA256']
for name,h in PLAN['canonicalRunnerHashes'].items():assert hashlib.sha256((P/'harness/pm'/name).read_bytes()).hexdigest()==h
for issue in PLAN['matrixIssues']:
 b=BIND['issues'][str(issue)];assert b['base']==PLAN['baseline']and b['candidateSha']==AUTH['candidateShas'][str(issue)];assert pathlib.Path(b['snapshotPath'],'SOURCE_SHA').read_text().strip()==b['candidateSha']
lock=P/'controller.lock'
with lock.open('x')as f:json.dump({'pid':os.getpid(),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'bindings':BIND},f,indent=2)
WRITE=threading.Lock();tasks=sorted(PLAN['attempts'],key=lambda a:(a['cell'],a['K0'],PLAN['matrixIssues'].index(a['issue'])));pending=[];unknown=[];done={};active={};cellResults={};errors=0

def stem_for(a):
 b=BIND['issues'][str(a['issue'])];return P/'raw'/('issue-'+str(a['issue']))/b['candidateSha']/a['id']
for a in tasks:
 stem=stem_for(a)
 if stem.with_suffix('.meta.json').exists():done[a['attemptId']]=json.loads(stem.with_suffix('.meta.json').read_text())
 elif stem.with_suffix('.start.json').exists():unknown.append({'attemptId':a['attemptId'],'reason':'existing start without completed metadata; never auto-rerun','prefix':str(stem)})
 else:pending.append(a)

def run(a):
 b=BIND['issues'][str(a['issue'])];stem=stem_for(a);stem.parent.mkdir(parents=True,exist_ok=True);start=datetime.datetime.now(datetime.timezone.utc).isoformat();cmd=[NODE,'--random-seed='+str(a['seed']),RUNNER,str(a['players']),'1',a['bot']];env={'PATH':str(pathlib.Path(NODE).parent)+':/usr/bin:/bin','APP':str(pathlib.Path(b['snapshotPath'])/'app'),'MODE':a['mode'],'K0':str(a['K0']),'LANG':'C','TZ':'UTC'}
 with stem.with_suffix('.start.json').open('x')as f:json.dump({**a,'candidateSha':b['candidateSha'],'command':cmd,'environment':env,'startedAt':start},f,indent=2)
 m={**a,'policySHA256':PLAN.get('policySHA256'),'canonicalBaseRunner':PLAN.get('canonicalBaseRunner'),'status':'started','revision':'candidate','sourceSha':b['candidateSha'],'baselineSha':PLAN['baseline'],'runtime':PLAN['runtime'],'nodeBinarySHA256':PLAN['nodeBinarySHA256'],'canonicalRunnerHashes':PLAN['canonicalRunnerHashes'],'command':cmd,'environment':env,'startedAt':start};t=time.monotonic();stdout='';stderr=''
 try:
  r=subprocess.run(cmd,env=env,capture_output=True,text=True,cwd=P,timeout=180);stdout=r.stdout;stderr=r.stderr;m['exitCode']=r.returncode
  try:
   data=json.loads(stdout);logs=data.get('logs',[]);cs=data.get('completion',[]);proof=len(logs)==len(cs)==1 and cs[0].get('terminal')is True and cs[0].get('state')=='over'and cs[0].get('finishCalls',0)>=1 and logs[0].get('id')==cs[0].get('logId');actual={'players':len(logs[0].get('team',[])),'heroes':[h['hero']for h in logs[0].get('team',[])],'mode':logs[0].get('mode'),'bot':data.get('pick')};expected={k:a[k]for k in ['players','heroes','mode','bot']};tupleOK=actual==expected;m.update(completionProof=proof,tupleProof=tupleOK,actualTuple=actual,expectedTuple=expected,terminalProof=proof and tupleOK and r.returncode==0,completion=cs,win=logs[0].get('win')if logs else None,budgetOverrun=bool(logs and logs[0]['time']>logs[0]['runLength']+.11))
   lines=[x for x in stderr.splitlines()if x.startswith('DASH_POLICY_METRICS ')];assert len(lines)==1;dm=json.loads(lines[0].split(' ',1)[1]);policyProof=dm['parameters']==PLAN['guardPolicyParameters']and dm['dash']==PLAN['dashParameters']and dm['canonicalChoicesAndMovementUnmodified']is True and dm['noExtraRngCalls']is True and dm['attempted']==dm['accepted']+dm['rejected']and dm['accepted']==len(dm['records'])and dm['cooldownViolations']==dm['iframesAdded']==dm['unfinishedDashes']==0;m.update(guardedPolicyProof=policyProof,guardedInputMetrics={k:dm[k]for k in ['attempted','accepted','rejected','cooldownViolations','iframesAdded','damagingDashes','unfinishedDashes','vetoes']},policyCoreSHA256=PLAN['policyCoreSHA256'],terminalProof=m['terminalProof']and policyProof)
  except Exception as e:m.update(terminalProof=False,parseError=repr(e))
 except Exception as e:
  m.update(terminalProof=False,error=repr(e));stdout=getattr(e,'stdout',None)or'';stderr=getattr(e,'stderr',None)or'';stdout=stdout.decode(errors='replace')if isinstance(stdout,bytes)else stdout;stderr=stderr.decode(errors='replace')if isinstance(stderr,bytes)else stderr;stderr+='\nHARNESS_ERROR '+traceback.format_exc()
 stem.with_suffix('.json').write_text(stdout);stem.with_suffix('.stderr.txt').write_text(stderr);m.update(durationSeconds=time.monotonic()-t,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='terminal'if m.get('terminalProof')else'failed');tmp=stem.with_suffix('.meta.tmp');tmp.write_text(json.dumps(m,indent=2)+'\n');tmp.replace(stem.with_suffix('.meta.json'))
 with WRITE:
  with(P/'progress.jsonl').open('a')as f:f.write(json.dumps({k:m.get(k)for k in ['attemptId','issue','id','cell','sourceSha','terminalProof','win','exitCode','durationSeconds','error','parseError']})+'\n')
 return m

def eligible(a):return not(P/'PAUSE').exists()and not(P.parent/'PAUSE').exists()and not(P/('PAUSE-issue-'+str(a['issue']))).exists()
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=6)as ex:
  while pending or active:
   while len(active)<min(6,max(0,int((P/'worker-limit.json').read_text())if(P/'worker-limit.json').exists()else 6)):
    pos=next((i for i,a in enumerate(pending)if eligible(a)),None)
    if pos is None:break
    a=pending.pop(pos);active[ex.submit(run,a)]=a
   if not active:time.sleep(.25);continue
   finished,_=concurrent.futures.wait(active,timeout=.25,return_when=concurrent.futures.FIRST_COMPLETED)
   for f in finished:
    a=active.pop(f)
    try:m=f.result()
    except Exception as e:
     unknown.append({'attemptId':a['attemptId'],'reason':'controller exception after dispatch; never auto-rerun','error':repr(e)});print('DISPATCH_UNKNOWN',a['attemptId'],repr(e),flush=True);continue
    done[a['attemptId']]=m;key=(a['issue'],a['cell']);cellResults.setdefault(key,[]).append(m)
    rows=[x for x in done.values()if x['issue']==a['issue']and x['cell']==a['cell']]
    if len(rows)==60:print('CELL_COMPLETE',json.dumps({'issue':a['issue'],'cell':a['cell'],'candidateSha':m['sourceSha'],'attempts':60,'terminal':sum(x.get('terminalProof')is True for x in rows),'wins':sum(x.get('terminalProof')is True and x.get('win')is True for x in rows),'errors':sum(x.get('terminalProof')is not True for x in rows)}),flush=True)
   state={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'done':len(done),'active':len(active),'pending':len(pending),'unknown':unknown,'paused':(P/'PAUSE').exists(),'activeAttempts':[a['attemptId']for a in active.values()]};tmp=P/'controller-state.tmp';tmp.write_text(json.dumps(state,indent=2)+'\n');tmp.replace(P/'controller-state.json')
 (P/'controller-complete.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'completed':len(done),'planned':len(tasks),'terminal':sum(x.get('terminalProof')is True for x in done.values()),'failed':sum(x.get('terminalProof')is not True for x in done.values()),'unknown':unknown,'noAutomaticRetry':True},indent=2)+'\n');print('CONTROLLER_COMPLETE',len(done),flush=True)
finally:
 if lock.exists():lock.rename(P/('controller-finished-'+str(os.getpid())+'.json'))
