import assert from 'node:assert/strict';
import { createGuard } from './guard-core.mjs';
const APP = new URL('../candidates/issue-17/948f2f74554b3ce992bc9b9061fdcac6d9da68a0/app/', import.meta.url);
const constants = await import(new URL('public/shared/content.js', APP));
const { DASH } = await import(new URL('public/shared/mobility.js', APP));
const cfg = { ...constants, DASH };
function fixture() {
  const h = { pid: 1, x: 0, y: 0, st: 0, iframes: 0 };
  const room = { state: 'play', tickNo: 1, time: 0, enemies: [], hostile: [], heroes: new Map([[1, h]]) };
  return { h, room, decide: createGuard(cfg) };
}
const oldRandom = Math.random;
Math.random = () => { throw Error('policy must not consume RNG'); };
try {
  {
    const { h, room, decide } = fixture();
    room.enemies = [{ id: 1, x: 40, y: 0, r: 10 }];
    assert.equal(decide(room, h, -1, 0).press, false);
    room.time = 8 / 30; room.tickNo += 8; room.enemies[0].x = 30;
    const d = decide(room, h, -1, 0);
    assert.equal(d.press, true); assert.deepEqual(d.direction, [-1, 0]);
    assert.deepEqual(d.predictedEnd, [-180, 0]);
  }
  {
    const { h, room, decide } = fixture();
    room.hostile = [{ id: 1, x: 40, y: 0, vx: -100, vy: 0 }];
    assert.equal(decide(room, h, -1, 0).press, true, 'a known incoming shot permits a clear escape');
    room.tickNo += 8; room.time += 8 / 30;
    assert.equal(decide(room, h, 1, 0).reason, 'unsafe-path', 'no dash through the incoming shot');
  }
  for (const [id, x] of [[4, 40], [1, 100]]) {
    const { h, room, decide } = fixture();
    room.hostile = [{ id, x, y: 0, vx: -1000, vy: 0 }];
    assert.equal(decide(room, h, -1, 0).reason, 'no-near-threat', 'ignored/off-view shots cannot trigger a dash');
  }
  {
    const { h, room, decide } = fixture();
    room.enemies = [{ id: 1, x: 200, y: 0, r: 30 }];
    assert.equal(decide(room, h, -1, 0).reason, 'no-near-threat');
  }
  {
    const { h, room, decide } = fixture();
    room.hostile = [{ id: 1, x: 40, y: 0, vx: -100, vy: 0 }];
    room.heroes.set(2, { pid: 2, st: 1, x: constants.REVIVE_RADIUS / 2, y: 0 });
    assert.equal(decide(room, h, -1, 0).reason, 'reviving');
  }
  for (const [key, value, reason] of [['iframes', 0.1, 'iframes'], ['dashReadyAt', 12, 'cooldown']]) {
    const { h, room, decide } = fixture(); h[key] = value;
    room.hostile = [{ id: 1, x: 40, y: 0, vx: -100, vy: 0 }];
    assert.equal(decide(room, h, -1, 0).reason, reason);
  }
  {
    const { h, room, decide } = fixture();
    room.hostile = [{ id: 1, x: -40, y: 0, vx: 100, vy: 0 }];
    room.enemies = [{ id: 1, x: 180, y: 0, r: 10 }];
    assert.equal(decide(room, h, 1, 0).reason, 'unsafe-path', 'endpoint occupancy is vetoed');
  }
  {
    const { h, room, decide } = fixture();
    room.hostile = [{ id: 1, x: 40, y: 0, vx: -100, vy: 0 }];
    room.fin = { cx: 0, cy: 0, r: 100 };
    assert.equal(decide(room, h, -1, 0).reason, 'boundary');
  }
  console.log('Guard policy: observation velocity, threat, current direction, path/end, sight, revive radius, cooldown/iframes, boundary and zero RNG: PASS');
} finally { Math.random = oldRandom; }
