from pathlib import Path
import subprocess,json,datetime,sys
out=Path(__file__).resolve().parent
repo=Path('/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/work/night-horde-issue-44')
node='/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip();assert head=='486ff20b99ac7db82305e81f15438581d50ac735'
commands=[('native',[node,'--test','app/server/lobby-invites-test.js','app/server/lobby-invites-client-test.js']),('strict-browser',[node,'--import','./pm/test-runtime.mjs',str(out/'browser-recovery.mjs')])]
import os
env=dict(os.environ,VIBE_APP_KEY='',HORDE_BROWSER_CHECK='1')
records=[]
for label,command in commands:
 record={'label':label,'command':command,'head':head,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (out/(label+'.log')).open('w') as log:
  process=subprocess.Popen(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
  record['pid']=process.pid;record['exitCode']=process.wait()
 record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();records.append(record)
 (out/'recovery-results.json').write_text(json.dumps({'additionalRecoveryRun':True,'head':head,'records':records},indent=2))
 print(json.dumps(record),flush=True)
 if record['exitCode']!=0:sys.exit(record['exitCode'])
