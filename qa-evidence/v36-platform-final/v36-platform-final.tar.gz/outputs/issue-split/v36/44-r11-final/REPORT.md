# Issue44 r11 author correction and freeze

Frozen head **486ff20b99ac7db82305e81f15438581d50ac735**, branch codex/44-invite-delivery, worktree work/night-horde-issue-44. Author start7dfbc6880582e7b623eef506e6b0b68c6297dcf1 already merged main14ad26604d7cc32cfe6830bf9684cba30ed80158. Worktree clean. No push/amend/force; root owns publication, current CI and independent acceptance. Issue10 and its historical/fresh performance artifacts are untouched.

## Comment6874503958 — P2 corrected, author gates PASS

[CEO case](https://github.com/AGaziev/night-horde/pull/53#issuecomment-6874503958): A3min, advance exactly120000ms, cancel, B1min with identical millisecond deadline; stale retry A previously returned200 and notified B's failed recipient.

Commit **e9835d7e900db63f7eefceb3cbd29f9cda9194d5** assigns a fresh server crypto.randomUUID to each batch. GET, POST/retry and additive lobby metadata carry batch identity and monotonic lobby revision. Retry requires both opaque ID and deadline, and exact batch/room/host/session are checked before and after access lookup. Notification tags also distinguish equal-deadline batches. Legacy startsAt-only retries get409 and a concrete page-refresh message, never a new batch. Successful and unknown recipients remain protected by existing per-recipient delivery history.

Actual HTTP/WS fixture uses a test-only frozen clock. A has1sent/1failed/1unknown; B at the exact same deadline has2sent/1failed/0unknown. Old A retry gets409 with no notification; A/B UUIDs differ. Correct B retry sends only103, preserving already sent/unknown outcomes. Additional controlled races pass: old all-failed completion cannot auto-cancel or claim activity for same-deadline B; a retry gated in real access HTTP rejects409 after cancellation/restart even with identical deadlines.

Generic scheduler lifecycle is covered directly through actual Hub.scheduleStart with no invite batch: cancel A, schedule same-deadline generic countdown, assert old inviteBatch cleared, lobby nonce null and revision advanced. Source audit finds no production WS scheduling command; production WS cancellation is real, while the generic scheduling edge is a native Hub-path control, not a claim of an invented WS route. GET cannot inherit old delivery because generic schedule clears room.inviteBatch synchronously before broadcast; the HTTP stale retry check requires a current batch. This limitation is explicit for independent follow-up.

## Comment6874452878 — same-room P3 corrected, author gates PASS

[CEO case](https://github.com/AGaziev/night-horde/pull/53#issuecomment-6874452878): hold real partial200 active result A; same session cancels/replaces countdown; late A must not restore old status/retry in the same room.

Commit **486ff20b99ac7db82305e81f15438581d50ac735** reconciles HTTP/WS state by batch ID and monotonic revision as well as existing room/host/viewer/form generation. A cancelled/replaced result cannot restore obsolete delivery text or retry IDs, unlock a newer request or alter the current countdown. Closing a pending form releases its UI generation so a fresh form can read current state; old callbacks/finally remain inert. Both WS-before-HTTP and HTTP-before-WS are retained, including meaningful all-failed auto-cancellation errors. A delayed current-batch HTTP response cannot extend an already observed countdown.

Native client regressions cover both delivery orders, same-room cancellation and identical-deadline replacement, reopen/new retry while old result is held, previous room/guest/host-change cases, normal all-failed response in both orders, nonce capture on retry, and the delayed countdown bound.

Strict actual browser desktop1280x900 and mobile390x844 uses the full app and real local server HTTP/WS with --mute-audio. Every held result explicitly asserts200 +active +1sent/1failed. A second HTTP caller of the same session performs cancellation through the real /api/send transport while original WS receives lobby changes. Same-room cancellation and replacement with the exact same deadline both preserve current status/countdown, disable obsolete retry and emit no additional notification after stale response delivery. Old A→different room B coverage remains. Six screenshots and raw records persist here. Native unit coverage controls HTTP-before-WS; actual browser gates specifically hold HTTP until WS cancellation/replacement arrives. No claim substitutes unit ordering for a browser ordering run.

## Primary recovery run and cleanup

The original successful author logs in /tmp disappeared after steering for unknown cause. They are not reconstructed. LOG-RECOVERY.md preserves that distinction and root's authorization of one additional short recovery run. The additional run on the frozen current head wrote directly here:

- Node24.22.1 native **21/21 PASS**, exit0, pid30303, native.log.
- Strict actual HTTP/browser **1/1 PASS**, exit0, pid30306, ~5.27s, strict-browser.log. Includes both desktop/mobile and exact-deadline fixture assertions.
- raw.json contains actual batch IDs/deadlines/results, held partial200 bodies, final UI status/disabled state and local mock notification calls.
- source-hashes.json pins the original production/test modules plus output-only instrument and patch. browser-recovery.mjs changes import paths and evidence writes only; instrumentation.patch is reviewable. run-recovery.py and recovery-results.json preserve exact commands, timestamps, PIDs and exits.
- cleanup.json: native/browser runner30303/30306 and fixture server30307 exited; no owned test processes, port34381 free, isolated runs directory removed; browser.close awaited and local fixture closed. Source hashes still match and worktree remains clean.

All notifications went to the local fixture; no real recipient, key, production access or external mutation. No full native/simulation/performance run. The current head is not yet author-pushed, and old CI success on7df is not claimed for486ff20. Root must run current full Server CI and independent delta acceptance before READY. Existing owner/OAuth/collaborator capability limits remain as previously documented; no identity is guessed.
