# Addendum: fresh phase/group gate for independent issue #10

This supplements ../ceo-fixes/REPORT.md. Historical dca/57 measurements are not relabelled as v36 evidence. It does not overwrite the earlier three-repeat measurements or substitute old combined-branch results. Product head remains36e991bf2fb986f1450aa348c0b9d8c9566803d7; baseline remainsf4a40dc3cd743a114b5df7417acd65e0c08bceae. No tracked or product file changed for this gate. Only this output-local QA instrument was added. Author verification; independent product acceptance remains separate.

Outcome: 24/24 completed, 0 failed, 12 prepared-world hashes match exactly between revisions. Exact revisions, runtime module hashes, instrument hash and patch hash are frozen in manifest.json. Every cell stores the complete runtime-source hash map; renderer/content/events/outposts hash equality is independently asserted by analyse.py. Main and candidate were alternated for each scene.

Matrix: 1/4/8 players x packed/spread x near-final/finale x main/candidate. All scenes use Lunch. Near-final starts at516s, runs8s warmup and measures approximately524–528s (phase0, before real prelude530; the warning at526 is allowed). Finale starts staging at529.5s and uses actual Room.tick through prelude530, ring shrink and Lord540 until580s, then8s real-time warmup and4s measurement around588–592s (09:48, actual dawn phase4). The ring was not manually relabeled or expanded at588. Its actual radius after warmup is440/515/615 for1/4/8, and all heroes satisfy the playable circle.

Near-final uses bolt/lightning/flask/orbit level5; finale uses aura/lantern/ward/frost level5. Both have area/haste level3 and alternating knight/herald hero definitions. Build IDs and actual player coordinates are stored in preparedWorld and world.start/middle/end. For1player packed/spread are necessarily the same geometry. Multiplayer packed places other heroes within30 units of hero1. Spread requests a1800-unit ring before the finale; the real finale wall constrains it to the legal arena boundary. No claim equates those final distances with1800 units.

Performance fixture limits: heroes are invulnerable; seeded ordinary enemy HP100000 and boss HP10000000 maintain load and prevent accidental termination. Ambient events/elites/invasions are disabled,450 regular actors are seeded; in the finale the actual Lord absorption removes them and actual finale pack/call logic populates the arena. Final counts are the true measured counts, not forced91 or450 labels. This is a controlled late-build performance fixture, not a natural completed run or a balance trial. One browser renders hero1; the Room fully simulates all n heroes.

Each cell has one8s-warmup/4s-sample run and two descriptive half-window cadence slices. The finite gate supplies scene/phase coverage with measured frame CPU/interval,30Hz tick work, snapshot work and actual WS arrival/sequence evidence. It does NOT establish a statistically reliable p95 or mean improvement; the prior old-head three-repeat result remains historical and is not attributed to v36. No60FPS promise or distance-causality claim is made.

Transport aggregate: sent=2908, received=2908, decoded=2908; missing wire=0, missing decoded=0, decode rejects=0, sequence gaps=0, duplicates=0, reorder=0, logical tm gaps=0. These are actual sent/received/decoded sequence comparisons, not inferred packet loss from HTTP status. The local matrix intentionally injects no loss/delay. Production loss is not verified. The earlier independent delayed-WS reproduction and codec missing-delta tests remain separately reported.

Maximum cell p95: server tick=1.630ms, snapshot=0.397ms, actual arrival gap=127.900ms, post-send local delivery latency=73.0ms. Browser JS errors=0. QA transport serialization is measured separately outside product tick timing; its cost is retained in raw. No threat draw layer, core, outline or hit area is modified. Seeded cosmetic RNG is shared as an initial condition; frame-dependent cosmetic draws and small end-tick timing differences need not be pixel-identical.

| Cell | Phase | Active seconds | Frame mean / p95 ms | Tick p95 ms | Visible / snapshot enemies | Hostile objects / visible | DPR |
|---|---:|---|---:|---:|---:|---:|---:|
| near-final-n1-packed-baseline | 0 | 523.967–528.000 | 22.07 / 34.90 | 1.376 | 450/450 | 404/357 | 1.5 |
| near-final-n1-packed-candidate | 0 | 523.967–527.967 | 22.22 / 49.80 | 1.630 | 450/450 | 379/343 | 1.5 |
| near-final-n1-spread-baseline | 0 | 523.967–527.967 | 21.94 / 33.60 | 1.393 | 450/450 | 379/343 | 1.5 |
| near-final-n1-spread-candidate | 0 | 523.967–528.000 | 22.04 / 33.50 | 1.276 | 450/450 | 404/357 | 1.5 |
| near-final-n4-packed-baseline | 0 | 523.967–528.000 | 22.53 / 49.90 | 0.872 | 449/450 | 393/358 | 1.5 |
| near-final-n4-packed-candidate | 0 | 523.967–527.967 | 21.48 / 33.40 | 0.963 | 449/450 | 373/355 | 1.25 |
| near-final-n4-spread-baseline | 0 | 523.967–527.967 | 16.73 / 17.50 | 0.941 | 113/450 | 373/89 | 2 |
| near-final-n4-spread-candidate | 0 | 523.967–527.967 | 16.74 / 17.50 | 1.008 | 113/450 | 373/89 | 2 |
| near-final-n8-packed-baseline | 0 | 523.967–527.967 | 22.44 / 33.50 | 1.124 | 450/450 | 376/358 | 1.25 |
| near-final-n8-packed-candidate | 0 | 523.967–528.000 | 22.53 / 33.60 | 1.406 | 450/450 | 405/358 | 1.25 |
| near-final-n8-spread-baseline | 0 | 523.967–527.967 | 16.67 / 17.40 | 0.979 | 57/450 | 365/45 | 2 |
| near-final-n8-spread-candidate | 0 | 523.967–527.967 | 16.67 / 17.30 | 0.926 | 57/450 | 365/45 | 2 |
| finale-n1-packed-baseline | 4 | 587.967–591.967 | 16.67 / 17.30 | 0.834 | 178/178 | 20/20 | 2 |
| finale-n1-packed-candidate | 4 | 587.967–591.967 | 16.67 / 16.90 | 1.124 | 178/178 | 20/20 | 2 |
| finale-n1-spread-baseline | 4 | 587.967–591.967 | 16.67 / 17.20 | 0.803 | 178/178 | 20/20 | 2 |
| finale-n1-spread-candidate | 4 | 587.967–591.967 | 16.67 / 16.80 | 0.845 | 178/178 | 20/20 | 2 |
| finale-n4-packed-baseline | 4 | 587.967–592.000 | 16.67 / 17.20 | 0.869 | 120/120 | 20/18 | 2 |
| finale-n4-packed-candidate | 4 | 587.967–592.000 | 16.67 / 17.30 | 0.725 | 120/120 | 20/18 | 2 |
| finale-n4-spread-baseline | 4 | 587.967–591.967 | 16.67 / 17.10 | 0.502 | 118/119 | 18/14 | 2 |
| finale-n4-spread-candidate | 4 | 587.967–591.967 | 16.67 / 17.10 | 0.613 | 118/119 | 19/15 | 2 |
| finale-n8-packed-baseline | 4 | 587.967–592.000 | 18.68 / 33.40 | 0.913 | 120/120 | 19/16 | 2 |
| finale-n8-packed-candidate | 4 | 587.967–591.967 | 17.24 / 17.30 | 0.920 | 120/120 | 19/17 | 1.5 |
| finale-n8-spread-baseline | 4 | 587.967–591.967 | 16.67 / 17.20 | 0.527 | 97/120 | 19/17 | 2 |
| finale-n8-spread-candidate | 4 | 587.967–591.967 | 16.67 / 16.90 | 0.636 | 97/120 | 19/17 | 2 |

Every planned attempt and exit is preserved in progress.json/run.log; no failed attempt was replaced. Raw per-cell JSON includes all flags, actual phases and clocks, world geometry/build/player state, immutable prepared-world hash, full packet ledgers, cadence frames/slices, DPR timeline, image readiness, threat counts and renderer-method CPU timings. n8 screenshots are supplemental visual readback. Environment: Node24.22.1, bundled Chromium headless --mute-audio,1440x900@native2, local port34385, VIBE_APP_KEY empty, isolated temporary baseline and runs directory. Root coordinated a global heavy-job pause before actual start. Cleanup/CPU-free status is recorded separately after completion. No push, GitHub comment/action or production operation was performed.
