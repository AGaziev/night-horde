import fs from 'node:fs';import assert from 'node:assert/strict';import crypto from 'node:crypto';import {pathToFileURL} from 'node:url';
const out=new URL('./',import.meta.url),manifest=JSON.parse(fs.readFileSync(new URL('manifest.json',out)));
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
assert.equal(hash(fs.readFileSync(new URL('profile-matrix.mjs',out))),manifest.driverSha256);
assert.equal(hash(fs.readFileSync(new URL('instrumentation.patch',out))),manifest.instrumentationPatchSha256);
const results=[];
for(const revision of manifest.revisions){
 for(const[file,expected]of Object.entries(revision.sourceHashes))assert.equal(hash(fs.readFileSync(revision.app+'/'+file)),expected,file);
 const{Room}=await import(pathToFileURL(revision.app+'/server/game.js'));
 const{GAME_VERSION,finaleRingR,PLAYER_RADIUS}=await import(pathToFileURL(revision.app+'/public/shared/content.js'));
 const{PROTO}=await import(pathToFileURL(revision.app+'/server/snapshot-codec.js'));
 assert.equal(GAME_VERSION,'v36');assert.equal(PROTO,revision.label==='baseline'?25:28);
 for(const n of[1,4,8]){const room=new Room('CHECK',()=>{});room.setMode('lunch');for(let i=1;i<=n;i++)room.addPlayer(i,'P'+i,i%2?'knight':'herald');room.start();const snap=room.snapshot();assert.equal(room.state,'play');assert.equal(room.finPhase(),0);assert.equal(room.runLength,600);assert.equal(snap.p.length,n);assert.ok(snap.p.every(row=>row.length===15));assert.ok(finaleRingR(n)>PLAYER_RADIUS);results.push({revision:revision.label,n,version:GAME_VERSION,proto:PROTO,playerStride:15,runLength:room.runLength,ring:finaleRingR(n)});}
}
fs.writeFileSync(new URL('cheap-validation.json',out),JSON.stringify({pass:true,profileStarted:false,results},null,2));console.log('Cheap module/version/protocol/player-stride/room-mode validation PASS; no browser/profile launched.');
