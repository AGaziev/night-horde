from pathlib import Path
import json, shutil, subprocess, hashlib, tempfile, tarfile, io, datetime, difflib
root=Path('/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe');out=Path(__file__).resolve().parent
old=root/'outputs/issue-split/10/phase-gate'
for name in ['profile-matrix.mjs','run-matrix.py','analyse.py']:shutil.copy2(old/name,out/name)
sha=lambda b:hashlib.sha256(b).hexdigest()
heads={'baseline':'f4a40dc3cd743a114b5df7417acd65e0c08bceae','candidate':'36e991bf2fb986f1450aa348c0b9d8c9566803d7'}
repo=root/'work/night-horde-issue-10'
assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()==heads['candidate']
assert not subprocess.check_output(['git','-C',str(repo),'status','--porcelain'],text=True).strip()
owned=Path(tempfile.mkdtemp(prefix='horde-v36-final-phase-'));revs=[]
for label,head in heads.items():
 folder=owned/label;folder.mkdir();data=subprocess.check_output(['git','-C',str(repo),'archive',head,'app'])
 with tarfile.open(fileobj=io.BytesIO(data)) as tar:
  assert all(not m.name.startswith('/') and '..' not in Path(m.name).parts for m in tar.getmembers())
  tar.extractall(folder)
 app=folder/'app';(app/'node_modules').symlink_to(repo/'app/node_modules',target_is_directory=True)
 files=[p for d in ['server','public/js','public/shared'] for p in (app/d).glob('*.js') if not p.name.endswith('-test.js')]+[app/'public/style.css',app/'package-lock.json']
 hashes={str(p.relative_to(app)):sha(p.read_bytes()) for p in sorted(files)}
 revs.append({'label':label,'sha':head,'app':str(app),'sourceHashes':hashes})
for name in ['public/js/render.js','public/shared/content.js','server/events.js','server/outposts.js']:assert revs[0]['sourceHashes'][name]==revs[1]['sourceHashes'][name]
tracked=subprocess.check_output(['git','-C',str(repo),'show',heads['candidate']+':pm/profile-scenes.mjs'],text=True)
patch=''.join(difflib.unified_diff(tracked.splitlines(True),(out/'profile-matrix.mjs').read_text().splitlines(True),fromfile=heads['candidate']+':pm/profile-scenes.mjs',tofile='output-only:profile-matrix.mjs'))
(out/'instrumentation.patch').write_text(patch);cells=json.loads((old/'manifest.json').read_text())['cells']
manifest={'schema':2,'frozenAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'productHeadFrozen':heads['candidate'],'baseline':heads['baseline'],'node':'/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node','nodeVersion':subprocess.check_output(['/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node','--version'],text=True).strip(),'port':34385,'seed':44010,'warmupMs':8000,'sampleMs':4000,'independentRepeatsPerCell':1,'descriptiveSlicesPerSample':2,'quietDurationRequestedSeconds':360,'expectedRuntimeSeconds':[310,360],'cells':cells,'revisions':revs,'ownedSourceRoot':str(owned),'driverSha256':sha((out/'profile-matrix.mjs').read_bytes()),'instrumentationPatchSha256':sha(patch.encode()),'profilingStatus':'PREPARED_NOT_STARTED','limits':['Single sampled window per cell supplies descriptive coverage, not statistical evidence of frame or p95 improvement.','All old dca/57 matrices are historical and not transferred to v36.','Synthetic controlled builds and invulnerability preserve phase for performance; not natural completion or balance evidence.','No external platform key or production access.']}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(out/'analysis-source.sha256').write_text(sha((out/'analyse.py').read_bytes())+'  analyse.py\n')
print(json.dumps({'out':str(out),'frozenSources':str(owned),'cells':len(cells),'heads':heads,'driverSha256':manifest['driverSha256'],'rendererIdentical':True,'contentIdentical':True,'requestedQuietSeconds':360},indent=2))
