// Output-only QA instrument. Product code is imported from the selected exact revision.
import { createHash } from 'node:crypto';
import { createServer } from 'node:http';
import { readFileSync, writeFileSync, readdirSync } from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { setTimeout as delay } from 'node:timers/promises';
const app=process.env.APP, sha=process.env.PERF_SHA, output=process.env.OUTPUT;
const cell=JSON.parse(process.env.MATRIX_CELL), seed=44010, dt=1/30;
if(!app||!sha||!output||!cell.id)throw Error('Frozen app/revision/cell/output required');
const digest=x=>createHash('sha256').update(x).digest('hex');
const sourceHashes={};
for(const folder of ['server','public/js','public/shared'])for(const name of readdirSync(path.join(app,folder)))if(name.endsWith('.js')&&!name.endsWith('-test.js'))sourceHashes[folder+'/'+name]=digest(readFileSync(path.join(app,folder,name)));
for(const file of ['public/style.css','package-lock.json'])sourceHashes[file]=digest(readFileSync(path.join(app,file)));
const {Room}=await import(pathToFileURL(path.join(app,'server/game.js')));
const {finaleRingR,PLAYER_RADIUS,ST}=await import(pathToFileURL(path.join(app,'public/shared/content.js')));
const {WebSocketServer}=await import(pathToFileURL(path.join(app,'node_modules/ws/wrapper.mjs')));
const {chromium}=await import('/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs');
let rng=seed;Math.random=()=>{rng=(Math.imul(rng,1664525)+1013904223)>>>0;return rng/4294967296;};
const quantile=(a,q)=>[...a].sort((a,b)=>a-b)[Math.min(a.length-1,Math.floor(a.length*q))]??0;
const stats=a=>({n:a.length,mean:a.reduce((a,b)=>a+b,0)/(a.length||1),p50:quantile(a,.5),p95:quantile(a,.95),max:Math.max(0,...a)});
let room,ws,streaming=false,measuring=false,queue=[],sent=[],ticks=[],tickIntervals=[],snapWork=[],qaWork=[],lastTick=0,catchupDropMs=0;
function world(){
 const heroes=[...room.heroes.values()];const f=room.fin;
 const positions=heroes.map(h=>({pid:h.pid,hero:h.hero,x:h.x,y:h.y,st:h.st,weapons:[...h.weapons].map(([id,w])=>({id,lvl:w.lvl}))}));
 let min=Infinity,max=0;for(let i=0;i<heroes.length;i++)for(let j=i+1;j<heroes.length;j++){const d=Math.hypot(heroes[i].x-heroes[j].x,heroes[i].y-heroes[j].y);min=Math.min(min,d);max=Math.max(max,d);}
 return {time:room.time,minute:Math.floor(room.time/60)+':'+String(Math.floor(room.time%60)).padStart(2,'0'),state:room.state,mode:room.mode,runLength:room.runLength,left:room.runLength-room.time,phase:room.finPhase(),peak:room.peak?.id??null,finPlan:room.finPlan,ring:f?{cx:f.cx,cy:f.cy,r:f.r,r1:f.r1,playable:f.r-PLAYER_RADIUS,allHeroesInside:heroes.every(h=>Math.hypot(h.x-f.cx,h.y-f.cy)<=f.r-PLAYER_RADIUS+1e-5)}:null,worldLimit:100000,positions,pairDistance:{min:Number.isFinite(min)?min:0,max},enemies:room.enemies.filter(e=>!e.dead).length,enemyTypes:Object.fromEntries([...new Set(room.enemies.filter(e=>!e.dead).map(e=>e.type))].map(t=>[t,room.enemies.filter(e=>!e.dead&&e.type===t).length])),serverHostile:room.hostile.length,lord:f?.lord?{id:f.lord.id,x:f.lord.x,y:f.lord.y,hp:f.lord.hp,maxHp:f.lord.maxHp,dead:f.lord.dead}:null};
}
function sustain(){for(const h of room.heroes.values()){h.hp=h.maxHp;h.iframes=9;let n=0;while(h.offer){if(++n>1000)throw Error('Offer drain limit');room.handle(h.pid,{t:'skip'});}}}
function flush(){const start=performance.now();for(const q of queue){const p=JSON.parse(q.json);p.__bench=cell.id;p.__sentAt=Date.now();sent.push({sq:p.sq,tm:p.tm,key:p.K===1,phase:q.phase,productBytes:Buffer.byteLength(q.json),sample:measuring});ws.send(JSON.stringify(p));}queue=[];if(measuring)qaWork.push(performance.now()-start);}
const http=createServer((req,res)=>{if(req.url==='/'){res.setHeader('Content-Type','text/html');res.end('<!doctype html><link rel="stylesheet" href="/style.css"><canvas id="game"></canvas>');return;}try{const f=path.join(app,'public',req.url.split('?')[0]);res.setHeader('Content-Type',f.endsWith('.js')?'text/javascript':f.endsWith('.css')?'text/css':'application/octet-stream');res.end(readFileSync(f));}catch{res.writeHead(404);res.end();}});
const wss=new WebSocketServer({server:http});wss.on('connection',s=>{ws=s;s.on('message',raw=>{const m=JSON.parse(raw);if(m.t==='pos'&&m.__bench===cell.id)room?.handle(1,m);});});
http.listen(34385,'127.0.0.1');await new Promise(r=>http.once('listening',r));
const browser=await chromium.launch({headless:true,args:['--mute-audio']});
const page=await browser.newPage({viewport:{width:1440,height:900},deviceScaleFactor:2});
const errors=[];page.on('pageerror',e=>errors.push(e.message));
let interval, preparedWorld, preparedWorldHash, startWorld, midWorld, endWorld, client, ledger, geometry=[];
try{
 await page.goto('http://127.0.0.1:34385/');
 await page.evaluate(async ({id,seed,windup})=>{
  let rng=seed;Math.random=()=>{rng=(Math.imul(rng,1664525)+1013904223)>>>0;return rng/4294967296;};
  const {Game}=await import('/js/game.js'),{Renderer}=await import('/js/render.js'),{SnapshotDecoder}=await import('/js/snapshot-codec.js');
  let ws;const decoder=new SnapshotDecoder(),g=new Game({send(m){if(ws?.readyState===1)ws.send(JSON.stringify({...m,__bench:id}));}});g.me=1;
  const r=new Renderer(document.getElementById('game'));window.probe={id,g,r,capture:false,frames:[],draw:[],update:[],arrivals:[],latencies:[],methods:{},timeline:[],allWire:[],allDecoded:[],decodeRejects:[],wireGaps:[],wireDuplicates:[],wireReorders:[],logicalTmGaps:[],samplePhases:[],sampleTms:[],lastSq:null,lastTm:null};
  for(const name of Object.getOwnPropertyNames(Renderer.prototype))if(name.startsWith('draw')||name==='updateMinimap'){
   const original=r[name].bind(r);r[name]=(...args)=>{const t=performance.now();const value=original(...args);if(probe.capture)(probe.methods[name]??=[]).push(performance.now()-t);return value;};
  }
  ws=new WebSocket(`ws://${location.host}`);ws.onmessage=e=>{
   const p=JSON.parse(e.data);if(p.__bench!==id)return;
   const now=performance.now();probe.allWire.push(p.sq);
   if(probe.lastSq!==null){if(p.sq>probe.lastSq+1)probe.wireGaps.push([probe.lastSq,p.sq]);if(p.sq===probe.lastSq)probe.wireDuplicates.push(p.sq);if(p.sq<probe.lastSq)probe.wireReorders.push([probe.lastSq,p.sq]);}probe.lastSq=p.sq;
   const s=decoder.decode(p);if(!s){probe.decodeRejects.push(p.sq);return;}probe.allDecoded.push(p.sq);
   if(probe.lastTm!==null&&s.tm-probe.lastTm>.15)probe.logicalTmGaps.push([probe.lastTm,s.tm]);probe.lastTm=s.tm;
   if(probe.capture){probe.arrivals.push(now);probe.latencies.push(Date.now()-p.__sentAt);probe.samplePhases.push(s.fin?.[0]??0);probe.sampleTms.push(s.tm);}
   g.onSnapshot(s);
  };
  let last=performance.now();const loop=now=>{const d=now-last;last=now;if(g.running){const t=performance.now();g.update(Math.min(.05,d/1000),{vector:()=>({x:0,y:0})});const u=performance.now()-t;const a=performance.now();r.draw(g,Math.min(.05,d/1000));if(probe.capture){probe.frames.push(d);probe.update.push(u);probe.draw.push(performance.now()-a);}probe.timeline.push({at:now,dpr:r.dpr,tm:g.view.tm,phase:g.view.b?.fin?.[0]??0});}requestAnimationFrame(loop);};requestAnimationFrame(loop);
  probe.begin=m=>{g.begin(m);r.dprCtl.lock(0);};
  probe.mark=()=>{probe.capture=true;probe.frames=[];probe.draw=[];probe.update=[];probe.arrivals=[];probe.latencies=[];probe.methods={};probe.samplePhases=[];probe.sampleTms=[];};
  probe.read=()=>({frames:probe.frames,draw:probe.draw,update:probe.update,arrivals:probe.arrivals,latencies:probe.latencies,methods:probe.methods,timeline:probe.timeline,tms:probe.sampleTms,phases:probe.samplePhases,dpr:r.dpr,spritesReady:r.sprites.ready,visibleEnemies:[...r.ecount].reduce((a,b)=>a+b,0)+r.elites.length,snapshotEnemies:g.latest()?.e.length/6,hostileObjects:g.hostile.size,visibleHostile:[...g.hostile.values()].filter(s=>s.show&&r.visible(s.x,s.y)).length,warnings:g.warns.length,windupEnemies:(g.latest()?.e??[]).filter((_,i)=>i%6===5&&((g.latest().e[i]|0)&windup)).length,clientRing:g.latest()?.fin??null,positions:[...g.players.keys()].map(pid=>({pid,...g.playerPos(pid,{})}))});
 },{id:cell.id,seed,windup:ST.windup});
 for(let i=0;i<100&&!ws;i++)await delay(10);if(!ws)throw Error('WS not ready');
 room=new Room('QA10',(pid,msg,json)=>{if(streaming&&pid===1&&msg.t==='s')queue.push({json:json??JSON.stringify(msg),phase:room.finPhase()});});
 room.setMode('lunch');for(let i=0;i<cell.n;i++)room.addPlayer(i+1,'P'+(i+1),i%2?'herald':'knight');room.start();
 room.events.next=Infinity;room.nextEliteT=room.nextInvasionT=Infinity;room.bossIdx=room.bossAt.length-1;
 const heroes=[...room.heroes.values()];
 for(let i=0;i<heroes.length;i++){
  const h=heroes[i],radius=cell.group==='packed'?30:1800,a=(i-1)/Math.max(1,cell.n-1)*Math.PI*2;
  h.x=i===0?0:Math.cos(a)*radius;h.y=i===0?0:Math.sin(a)*radius;
  h.weapons=new Map((cell.build==='ranged'?['bolt','lightning','flask','orbit']:['aura','lantern','ward','frost']).map(id=>[id,{lvl:5,t:0}]));h.passives=new Map([['area',3],['haste',3]]);room.recalcMods(h);
 }
 const spawn=room.spawnEnemy.bind(room);room.spawnEnemy=(...args)=>{const e=spawn(...args);e.hp=e.maxHp=e.boss?10000000:100000;return e;};
 room.time=cell.stage==='near-final'?516:529.5;
 for(let i=0;i<450;i++){const h=heroes[i%heroes.length],e=room.spawnEnemy(['ghoul','skel','brute','spitter','sniper'][i%5],heroes,1),a=i*2.399963;e.x=h.x+Math.cos(a)*(160+i%500);e.y=h.y+Math.sin(a)*(160+i%500);}
 room.rebuildGrid();
 if(cell.stage==='finale'){let steps=0;while(room.time+1e-7<580){if(++steps>2000||room.state!=='play')throw Error('Staging did not progress');sustain();room.tick(dt);}}
 preparedWorld=world();preparedWorldHash=digest(JSON.stringify({world:preparedWorld,enemies:room.enemies.filter(e=>!e.dead).map(e=>[e.id,e.type,e.x,e.y,e.hp,e.windT,e.shotT]),hostile:room.hostile.map(s=>[s.id,s.x,s.y,s.vx,s.vy]),traps:room.traps.map(t=>[t.id,t.x,t.y,t.kind])}));
 if(room.state!=='play'||(cell.stage==='near-final'?room.finPhase()!==0:!room.fin?.lord||room.fin.r!==finaleRingR(cell.n)))throw Error('Prepared phase/geometry incorrect');
 const snap=room.snapshot.bind(room);room.snapshot=()=>{const t=performance.now();const s=snap();if(measuring)snapWork.push(performance.now()-t);return s;};
 await page.evaluate(m=>probe.begin(m),room.startMsg());room.snapCodec=null;room.needKey=new Set();streaming=true;room.snapshot();flush();
 let last=performance.now(),acc=0;
 interval=setInterval(()=>{
  const now=performance.now(),delta=Math.max(0,(now-last)/1000);last=now;if(acc+delta>.25)catchupDropMs+=(acc+delta-.25)*1000;acc=Math.min(.25,acc+delta);
  while(acc>=dt){acc-=dt;sustain();const at=performance.now();if(measuring&&lastTick)tickIntervals.push(at-lastTick);lastTick=at;room.tick(dt);if(measuring)ticks.push(performance.now()-at);flush();}
 },1000/30);
 await delay(8000);startWorld=world();measuring=true;await page.evaluate(()=>probe.mark());
 await delay(2000);midWorld=world();geometry.push(midWorld);
 await delay(2000);endWorld=world();client=await page.evaluate(()=>{probe.capture=false;return probe.read();});
 measuring=false;clearInterval(interval);interval=null;streaming=false;flush();
 await delay(200);ledger=await page.evaluate(()=>({wire:probe.allWire,decoded:probe.allDecoded,rejected:probe.decodeRejects,wireGaps:probe.wireGaps,duplicates:probe.wireDuplicates,reorders:probe.wireReorders,logicalTmGaps:probe.logicalTmGaps}));
 if(cell.n===8)await page.screenshot({path:output.replace('.json','.png')});
 await page.evaluate(()=>probe.g.stop());
}finally{if(interval)clearInterval(interval);streaming=false;await browser.close();for(const s of wss.clients)s.terminate();wss.close();await new Promise(r=>http.close(r));}
const sentSq=sent.map(s=>s.sq),wireSet=new Set(ledger.wire),decodedSet=new Set(ledger.decoded);
const missingWire=sentSq.filter(s=>!wireSet.has(s)),missingDecoded=sentSq.filter(s=>!decodedSet.has(s));
const flags={playing:[startWorld,midWorld,endWorld].every(w=>w.state==='play'),expectedPhase:client.phases.every(p=>p===cell.expectedPhase)&&[startWorld,midWorld,endWorld].every(w=>w.phase===cell.expectedPhase),clockInWindow:cell.stage==='near-final'?startWorld.time>=523&&endWorld.time<530:startWorld.time>=587&&endWorld.time<594,legalFinaleGeometry:cell.stage!=='finale'||[startWorld,midWorld,endWorld].every(w=>w.ring?.r===finaleRingR(cell.n)&&w.ring.allHeroesInside),enoughTicks:ticks.length>=90,enoughPackets:client.arrivals.length>=25,enoughFrames:client.frames.length>=30,cleanDecode:ledger.rejected.length===0&&missingWire.length===0&&missingDecoded.length===0&&ledger.wireGaps.length===0&&ledger.duplicates.length===0&&ledger.reorders.length===0,sprites:client.spritesReady,noBrowserErrors:errors.length===0};
const middle=client.frames.length>>1;
const result={sha,cell,seed,node:process.version,browser:browser.version(),viewport:{width:1440,height:900,nativeDpr:2},at:new Date().toISOString(),driverSha256:digest(readFileSync(new URL(import.meta.url))),sourceHashes,fixture:{invulnerableHeroes:true,fixedOrdinaryHp:100000,fixedBossHp:10000000,ambientEventsAndElitesDisabled:true,initialOrdinaryEnemies:450,warmupMs:8000,sampleMs:4000,independentRepeats:1,measurementSlices:2,synthetic:true},preparedWorld,preparedWorldHash,world:{start:startWorld,middle:midWorld,end:endWorld},frame:stats(client.frames),frameRaw:client.frames,frameSlices:[stats(client.frames.slice(0,middle)),stats(client.frames.slice(middle))],draw:stats(client.draw),update:stats(client.update),methods:Object.fromEntries(Object.entries(client.methods).map(([k,v])=>[k,stats(v)])),serverTick:stats(ticks),serverTickInterval:stats(tickIntervals),snapshot:stats(snapWork),qaTransportOverhead:stats(qaWork),serverCatchupDroppedMs:catchupDropMs,networkArrivalGap:stats(client.arrivals.slice(1).map((x,i)=>x-client.arrivals[i])),networkLatency:stats(client.latencies),wire:{sent:sent.length,received:ledger.wire.length,decoded:ledger.decoded.length,missingWireSequences:missingWire,missingDecodedSequences:missingDecoded,rejectedSequences:ledger.rejected,wireSequenceGaps:ledger.wireGaps,duplicates:ledger.duplicates,reorders:ledger.reorders,logicalServerTimeGaps:ledger.logicalTmGaps,productBytes:stats(sent.filter(s=>s.sample).map(s=>s.productBytes)),ledger:sent},client:{visibleEnemies:client.visibleEnemies,snapshotEnemies:client.snapshotEnemies,hostileObjects:client.hostileObjects,visibleHostile:client.visibleHostile,warnings:client.warnings,windupEnemies:client.windupEnemies,positions:client.positions,ring:client.clientRing,dpr:client.dpr,dprTimeline:client.timeline,tmRange:[Math.min(...client.tms),Math.max(...client.tms)],phases:[...new Set(client.phases)]},errors,assertions:flags,pass:Object.values(flags).every(Boolean)};
writeFileSync(output,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({id:cell.id,sha,pass:result.pass,assertions:flags,phase:result.client.phases,time:[startWorld.time,endWorld.time],visible:client.visibleEnemies,frameMean:result.frame.mean,frameP95:result.frame.p95,tickP95:result.serverTick.p95}));
if(!result.pass)process.exitCode=1;
