from pathlib import Path
import os,subprocess,json,hashlib,datetime
out=Path(__file__).resolve().parent
manifest=json.loads((out/'manifest.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha((out/'profile-matrix.mjs').read_bytes())==manifest['driverSha256']
assert sha((out/'instrumentation.patch').read_bytes())==manifest['instrumentationPatchSha256']
revisions={r['label']:r for r in manifest['revisions']}
records=[]
(out/'progress.json').write_text(json.dumps({'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'completed':0,'planned':len(manifest['cells']),'records':records},indent=2))
for i,cell in enumerate(manifest['cells']):
 rev=revisions[cell['revision']];target=out/(cell['id']+'.json')
 env=dict(os.environ,APP=rev['app'],PERF_SHA=rev['sha'],OUTPUT=str(target),MATRIX_CELL=json.dumps(cell),VIBE_APP_KEY='',PORT='34385',HORDE_RUNS_DIR=str(out/'owned-runs'))
 with (out/(cell['id']+'.log')).open('w') as log:
  try:result=subprocess.run([manifest['node'],'--import','/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/work/night-horde-issue-10/pm/test-runtime.mjs',str(out/'profile-matrix.mjs')],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=75);code=result.returncode
  except subprocess.TimeoutExpired:code=124
 record={'id':cell['id'],'exitCode':code,'pass':False}
 if target.exists():
  data=json.loads(target.read_text());record['sourceHashesMatch']=data['sourceHashes']==rev['sourceHashes'];record['pass']=data['pass'] and record['sourceHashesMatch'];record['time']=[data['world']['start']['time'],data['world']['end']['time']];record['phases']=data['client']['phases']
 records.append(record)
 (out/'progress.json').write_text(json.dumps({'updated':datetime.datetime.now(datetime.timezone.utc).isoformat(),'completed':i+1,'planned':len(manifest['cells']),'records':records},indent=2)+'\n')
 print(json.dumps({'completed':i+1,'planned':len(manifest['cells']),**record}),flush=True)
if any(not r['pass'] for r in records):raise SystemExit(1)
