import assert from 'node:assert/strict';
import {createServer} from 'node:http'; import {spawn} from 'node:child_process'; import {once} from 'node:events'; import {setTimeout as delay} from 'node:timers/promises'; import {mkdtempSync,rmSync,writeFileSync} from 'node:fs'; import {tmpdir} from 'node:os'; import {join} from 'node:path';
import WebSocket from '../../../../work/night-horde-issue-44/app/node_modules/ws/wrapper.mjs';
import {PROTO} from '../../../../work/night-horde-issue-44/app/server/snapshot-codec.js';
const app=new URL('../../../../work/night-horde-issue-44/',import.meta.url).pathname, calls=[]; let phase='A';
const fixture=createServer(async(req,res)=>{let raw='';for await(const b of req)raw+=b;let data={};
 if(req.url==='/v1/me')data={owner:{userId:'900',name:'Owner'}};
 else if(req.url.endsWith('/access'))data={users:[{userId:'101',userName:'Host'},{userId:'103',userName:'Failed'},{userId:'104',userName:'Unknown'}]};
 else if(req.url==='/v1/infra/servers/fixture')data={accessPolicy:'NAMED_USERS'};
 else if(req.url==='/v1/notifications'){const n=JSON.parse(raw);calls.push({phase,...n});if(n.userId===103){res.writeHead(422,{'Content-Type':'application/json'});res.end(JSON.stringify({success:false,error:{code:'NOTIFICATION_NOT_DELIVERED'}}));return;} if(phase==='A'){req.socket.destroy();return;}data={notificationId:calls.length};}
 res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({success:true,data}));});
fixture.listen(0,'127.0.0.1');await once(fixture,'listening'); const dir=mkdtempSync(join(tmpdir(),'horde-independent-')); const base='http://127.0.0.1:34384';
const child=spawn(process.execPath,['--import',app+'pm/test-runtime.mjs','--import',new URL('./clock.mjs',import.meta.url).pathname,app+'app/server/server.js'],{env:{...process.env,PORT:'34384',HORDE_RUNS_DIR:dir,VIBE_APP_KEY:'isolated-fixture-key',HORDE_VIBE_SERVER_ID:'fixture',HORDE_APP_ORIGIN:'https://game.example',HORDE_TEST_PLATFORM_URL:`http://127.0.0.1:${fixture.address().port}`},stdio:['ignore','pipe','pipe','ipc']});let err='';child.stderr.on('data',b=>err+=b);const exited=once(child,'exit');let ws;
try{
 for(let i=0;i<70;i++){if(await fetch(base+'/health').then(r=>r.ok,()=>false))break;await delay(40);}const headers={'X-Vibe-User-Id':'101','X-Vibe-User-Name':'Host','X-Vibe-Authorization':'Bearer vibe_session_fixture'};
 const {sid}=await(await fetch(base+'/api/session',{headers})).json();ws=new WebSocket(base.replace('http','ws')+`/ws?sid=${sid}&v=${PROTO}`,{headers});const messages=[];ws.on('message',r=>messages.push(JSON.parse(r)));await once(ws,'open');ws.send(JSON.stringify({t:'create',hero:'knight'}));
 const wait=async f=>{for(let i=0;i<100&&!f();i++)await delay(5);assert.ok(f());};await wait(()=>messages.some(m=>m.t==='lobby'));const code=messages.findLast(m=>m.t==='lobby').code,route=base+`/api/lobby/invites?sid=${sid}&room=${code}`;
 const post=async body=>{const r=await fetch(route,{method:'POST',headers:{...headers,'Content-Type':'application/json'},body:JSON.stringify(body)});return {status:r.status,body:await r.json()};};
 const A=await post({minutes:3,ids:['103','104']});assert.equal(A.status,200);assert.equal(A.body.failed,1);assert.equal(A.body.unknown,1);
 child.send({t:'advance',ms:120000});await once(child,'message');ws.send(JSON.stringify({t:'cancel-start'}));await wait(()=>messages.findLast(m=>m.t==='lobby').startsAt===null);
 const count=calls.length;const cancelled=await post({minutes:3,ids:['103','104'],startsAt:A.body.startsAt});assert.equal(cancelled.status,409);assert.equal(calls.length,count);
 phase='B';const B=await post({minutes:1,ids:['103','104']});assert.equal(B.status,200);assert.equal(B.body.failed,1);assert.equal(B.body.sent,1);assert.equal(B.body.startsAt,A.body.startsAt);
 const before=calls.length;const stale=await post({minutes:3,ids:['103','104'],startsAt:A.body.startsAt});const result={A,B,cancelled,stale,newNotifications:calls.slice(before),allCalls:calls};writeFileSync(new URL('./http-independent.json',import.meta.url),JSON.stringify(result,null,2));console.log(JSON.stringify(result));
 assert.equal(stale.status,200,'independent defect reproduction: old A action accepted against B');assert.equal(calls.length,before+1);assert.equal(calls.at(-1).userId,103);
}finally{ws?.terminate();child.kill();await exited;await new Promise(r=>fixture.close(r));rmSync(dir,{recursive:true,force:true});console.log('CLEANUP',dir,'removed; child exited;',err);}
