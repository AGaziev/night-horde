import fs from 'node:fs'; import {execFileSync} from 'node:child_process';import assert from 'node:assert/strict';
import {Room} from '../../../../work/night-horde-issue-10/app/server/game.js';
import {SnapshotDecoder} from '../../../../work/night-horde-issue-10/app/public/js/snapshot-codec.js';
const repo=new URL('../../../../work/night-horde-issue-10',import.meta.url).pathname;
const content=new URL('../../../../work/night-horde-issue-10/app/public/shared/content.js',import.meta.url).href;
async function client(rev){const src=execFileSync('git',['-C',repo,'show',rev+':app/public/js/game.js'],{encoding:'utf8'}).replace("'/shared/content.js'",JSON.stringify(content));return (await import('data:text/javascript;base64,'+Buffer.from(src).toString('base64'))).Game;}
const netSrc=fs.readFileSync(repo+'/app/public/js/net.js','utf8').replace("'./snapshot-codec.js'",JSON.stringify(new URL('../../../../work/night-horde-issue-10/app/public/js/snapshot-codec.js',import.meta.url).href));const {Net}=await import('data:text/javascript;base64,'+Buffer.from(netSrc).toString('base64'));
const results=[];
for(const rev of ['f15a657c4fe9c9d4824d29c2c8522b42e7745692','36e991bf2fb986f1450aa348c0b9d8c9566803d7']){
const Game=await client(rev);
for(const mode of ['outage0','outage1100','normal1100','pause1100']){
let now=0,pending=[],blocked=[],stall=false,accepted=0,maxX=0,maxTail=0,maxRollback=0,frozenX=null,preRecovery=null;
const old=globalThis.performance;globalThis.performance={now:()=>now*1000};
const net=Object.create(Net.prototype);Object.assign(net,{handlers:new Map(),snapDec:new SnapshotDecoder(),keyAskedAt:-Infinity,outbox:[]});
const room=new Room('INDP',(pid,msg,json)=>{if(pid!==1)return;if(msg.t==='s'||msg.t==='pause')pending.push({at:now+(mode.includes('1100')?1.1:0),wire:json??JSON.stringify(msg)});});room.addPlayer(1,'One','ranger');room.start();room.spawn=()=>{};const h=room.heroes.get(1);h.x=h.y=0;
net.send=m=>{if(stall&&m.t==='pos')blocked.push(m);else room.handle(1,m);};
const game=new Game(net);game.me=1;game.begin({players:[{pid:1,hero:'ranger',x:0,y:0}]});net.on('s',msg=>{const x=game.local.x;game.onSnapshot(msg);maxRollback=Math.max(maxRollback,x-game.local.x);});net.on('pause',msg=>game.setPause(msg.on,msg.menu));
const start=mode==='outage0'?1:241,end=start+288;
try{for(let frame=1;frame<=720;frame++){
 now=frame/60;
 if(mode.startsWith('outage')&&frame===start){stall=true;accepted=h.x;}
 if(mode.startsWith('outage')&&frame===end){preRecovery=game.local.x;stall=false;blocked.length=0;}
 if(mode==='pause1100'&&frame===240){room.setPaused(true);frozenX=h.x;}
 if(mode==='pause1100'&&frame===390)room.setPaused(false);
 while(pending[0]?.at<=now)net.receive(pending.shift().wire);
 game.update(1/60,{vector:()=>({x:mode==='pause1100'&&frame>=330?0:1,y:0})});
 if(stall){maxX=Math.max(maxX,game.local.x);maxTail=Math.max(maxTail,game.local.x-accepted);}
 if(frame%2===0)room.tick(1/30);
 }
results.push({rev,mode,accepted,preRecovery,maxX,maxTail,maxRollback,serverX:h.x,clientX:game.local.x,frozenX,pauseReplay:frozenX===null?null:h.x-frozenX,ackSeq:game.ackSeq,pending:game.pendingPositions.size});
}finally{globalThis.performance=old;}
}}
fs.writeFileSync(new URL('./movement-independent.json',import.meta.url),JSON.stringify(results,null,2));console.log(JSON.stringify(results,null,2));
const final=results.filter(r=>r.rev.startsWith('36e'));assert.ok(final.find(r=>r.mode==='outage0').maxTail<100);assert.ok(final.find(r=>r.mode==='outage1100').maxTail<300);assert.ok(Math.abs(final.find(r=>r.mode==='pause1100').pauseReplay)<1);assert.ok(final.find(r=>r.mode==='normal1100').maxRollback<1);
