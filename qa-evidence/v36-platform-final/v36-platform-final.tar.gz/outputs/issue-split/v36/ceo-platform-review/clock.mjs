let clock=1800000000000; Date.now=()=>clock; process.on("message",m=>{if(m?.t==="advance"){clock+=m.ms;process.send?.({clock});}});
const originalFetch=globalThis.fetch;
globalThis.fetch=(url,options)=>originalFetch(String(url).startsWith('https://vibecode.bitrix24.tech/v1/')?String(url).replace('https://vibecode.bitrix24.tech',process.env.HORDE_TEST_PLATFORM_URL):url,options);
