# Main54 integration closure for PR55 / PR59

Owner accepted and merged PR54 as cbf25ec1bb48d70f53d949c105b7ad5981722963 during the previous4dc integration. PR58 already merged4dc70c7; neither merged PR was changed. New residuals55/6893086879 and59/6893087081 ask only preservation of Daily plus the accepted feature, a combined snapshot, agreed protocol and fresh exact-candidate CI. All older game/data acceptances remain source-attributed; no new matrix, seed expansion, balance tuning or39-fusion audit.

PROTO34 refreshes both prior main33 and feature33 clients. GAME_VERSION remainsv37. Ordinary merges preserve Daily v5/old versions/UTC/locked terms/records/Swarm/Horde exclusion together with signature fusions and the respective dash/support feature. No force/reset/stash/rebase, main merge or deploy.

| PR | Frozen head | CI | Checkout |
|---|---|---|---|
| #55 | `f0c69a89fbba79c99b5bd15bbb4a3005314d3f8b` | [101/101 PASS](https://github.com/AGaziev/night-horde/actions/runs/43705337978) | `b0cf7dd31f0c72b0b2f428f0fc1d8562e5115494` |
| #59 | `4c46cc855085ef445eed903757e474ac60e2481a` | [96/96 PASS](https://github.com/AGaziev/night-horde/actions/runs/43705460948) | `2c8caa20c71815d28f41981db8cc6f6813d2a69b` |

Both Linux Node24.22.2 artifacts are complete; exact basecbf/head, checkout parents[base,head] and tree equality are verified. All expected suites PASS/exit0. Deploy jobs SKIPPED. Full source/revision/result/job proofs under ci/.

Dash merge f0c69a8 resolves three conflicts: Game.reset/begin retain Daily plus dash state; Room.startMsg retains Daily and mobility identity; snapshot retains Swarm/result plus mob/cv/pa and retirement. Duplicate contact-time import is eliminated. Main Daily-fusion test's Net prototype fixture now initializes outbox because the existing epoch2 snapshot invokes native prediction discard; no assertion or product path is weakened.18 scoped author suites pass, including all relevant Daily/fusion/Horde/native protocol controls plus numerical-zero and real24/40 original controls. The initial fixture TypeError is retained. No other dash gameplay changed.


See parent REPORT for independent/currentCI/browser proofs. No remaining product edit; source f0c69a8 frozen.
