# PR59 / Issue41 — integration of accepted main54

**PASS, scoped author verification; frozen head `4c46cc855085ef445eed903757e474ac60e2481a`, tree `2cfafdfa8abc38ce8d8064be2055b4597b0793e0`.** Full current Linux CI and independent review remain with root. No author READY, push, GitHub write, main merge or deployment.

## Precondition and source

Before edits, `gh api repos/AGaziev/night-horde/pulls/59 --jq '{state,merged,merged_at,head:.head.sha,base:.base.sha,draft,title}'` returned `state=open`, `merged=false`, `merged_at=null`, `head=7b46ace9722abef98a64dca0cea647b628a90709`, `base=4dc70c76a534d064899435e398225f72231b62c6`, `draft=true`. Assigned `work/night-horde-issue-41` was clean on that exact head.

Ordinary `git merge --no-commit --no-ff cbf25ec1bb48d70f53d949c105b7ad5981722963` integrated the newly accepted Daily base. Merge commit `ca3a697b0b1ee7f9ad4d2ba79918611ccc27d4fc` has parents `7b46ace9722abef98a64dca0cea647b628a90709 cbf25ec1bb48d70f53d949c105b7ad5981722963`. `git merge-base --is-ancestor cbf25ec1bb48d70f53d949c105b7ad5981722963 HEAD` PASS. Final commit `4c46cc855085ef445eed903757e474ac60e2481a` adds only the joint native regression test. Previous report remains at `outputs/review-remarks-20261115/support-author/REPORT.md`; it was not rewritten.

## Conflict resolutions

- `public/index.html`: retain support HUD and Daily/Swarm HUD together.
- `public/js/snapshot-codec.js`: root-agreed **PROTO34**, forcing both main33 Daily and feature33 support pages to reload. Updated actual welcome/legacy33/current34 checks and the version assertions in v20/v22/finale/sniper suites.
- `server/game.js`: keep `controlCredited.clear()` and `resolveSwarm(this)` after advancing time, before contact frames and native combat. Preserve all auto-merged Daily modifiers/locks/state alongside support gift/own-charge separation, exact contact time, read-only control, extended support statistics and metadata. `wardAbsorb -> wardAnswer(..., contactAt)` remains intact.
- `server/runlog.js`: retain both Daily and support imports. Daily v5, prior locked versions, UTC categorization, Swarm, ordinary-progress exclusion and Horde exclusion remain unchanged from accepted main.

No change to #68/#75/#74, accepted coefficients, Daily rules or balance evidence. No new bot matrix, full39 content audit, local full suite or performance benchmark.

## Scoped verification

**22 distinct suites PASS** on canonical Node **v24.22.1/macOS**, executable `/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node`. Common `NODE_OPTIONS='--import /Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/work/night-horde-issue-41/pm/test-runtime.mjs'`; run-store paths isolated under this artifact directory. Actual commands from `app/`: `<canonical-node> server/<suite>-test.js`. `minimum-checks.json` records21 argv/exits and raw logs; `checks-summary.json` adds frozen-head/tree attribution, product source hashes and final joint suite. The merge verification product sources equal the frozen head; only the test file was added afterward.

- Daily, client, native fusion, Horde separation, Swarm, review and real legacy HTTP/WS/SSE suites: PASS. Covers v5 terms, retained old locks and versions, UTC, progress exclusion, coherent lobby/start/results/history and old33 transport handling.
- Support-fusion, exact contact-time, client and Horde suites: PASS. Native signatures, gift before own Ward, live/expiry contacts, shield glyphs, gap/key recovery and source attribution retained.
- Control-separation: PASS (pure projection preserves state/query cache, no added RNG, delivered movement boundaries). Observer code unchanged by this merge.
- Run-history, codec, actual welcome/offer identity, Horde compatibility/resync, sniper, v20/v22 and finale suites: PASS.
- **New `daily-support-test.js`:3/3 PASS.** Real Daily Swarm v5 lobby/start; production `grantOffer` exposes the ready WardIII+AuraIII Dome, actual epoch pick fuses while preserving the gift. At age7.99 the gift blocks and credits its donor; at exact age8 own Ward blocks without donor credit. Snapshot wire carries Swarm plus separate gift/support; saved log/card retain Daily, one native duo and equal support fields; ordinary achievements/totals stay absent. A real Swarm ring cohort reaches70% by native kills, then one normal boundary `Room.tick` grants the XP reward and accounts the newly delivered control interval together.

No fresh browser session in this author round. Production UI consumers use the existing native client suites; real local WS/SSE paths exercised. Full new-candidate Linux CI and independent acceptance: **NOT VERIFIED by author**, root will run them after authorized push.

## Cleanup

`cleanup.json`: clean assigned worktree, no matching child server remains, isolated minimum/joint/final run-store paths absent. Native transport tests terminate sockets/children and remove their own ephemeral directories. Only this assigned worktree changed. Artifacts remain under `/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/review-remarks-20261115/main54/support-author`.
