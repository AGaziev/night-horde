import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import net from 'node:net';
import {spawn,execFileSync} from 'node:child_process';
import {once} from 'node:events';
import {setTimeout as delay} from 'node:timers/promises';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
const out=path.dirname(new URL(import.meta.url).pathname),manifest=JSON.parse(fs.readFileSync(path.join(out,'frozen-sources.json'),'utf8'));
const oldRepo=manifest.repo,base=manifest.base;
const oldCodec=execFileSync('git',['show',`${base}:app/public/js/snapshot-codec.js`],{cwd:oldRepo,encoding:'utf8'});
const oldNet=execFileSync('git',['show',`${base}:app/public/js/net.js`],{cwd:oldRepo,encoding:'utf8'}).replace("'./snapshot-codec.js'",JSON.stringify('data:text/javascript;base64,'+Buffer.from(oldCodec).toString('base64')));
const {Net:OldNet}=await import('data:text/javascript;base64,'+Buffer.from(oldNet).toString('base64'));
assert.match(oldCodec,/export const PROTO = 33/);
const rows=[];
for(const [group,src] of Object.entries(manifest.sources)){
 const data=fs.mkdtempSync(path.join(os.tmpdir(),`nh-r34-proto-${group}-`)),clients=[];
 const preload=path.join(data,'ephemeral.mjs');
 fs.writeFileSync(preload,`import {Server} from 'node:net';const listen=Server.prototype.listen;Server.prototype.listen=function(...args){if(typeof args[0]==='number'){args[0]=0;this.once('listening',()=>console.log('R34_PORT:'+this.address().port));}return listen.apply(this,args);};`);
 const args=['--import',path.join(src.path,'pm/test-runtime.mjs'),'--import',preload,path.join(src.path,'app/server/server.js')];
 const child=spawn(process.execPath,args,{cwd:path.join(src.path,'app'),env:{...process.env,PORT:'3000',HORDE_RUNS_DIR:data,VIBE_APP_KEY:''},stdio:['ignore','pipe','pipe']});
 const exited=once(child,'exit');let output='',port,error;
 child.stdout.on('data',d=>{output+=d;port=Number(output.match(/R34_PORT:(\d+)/)?.[1]);});child.stderr.on('data',d=>output+=d);
 const row={group,sha:src.sha,command:[process.execPath,...args],data,runtime:process.version,executable:process.execPath};
 async function wait(fn){for(let i=0;i<400;i++){const v=await fn();if(v)return v;await delay(10);}throw Error('transport deadline: '+output);}
 try{
  await wait(()=>port);row.port=port;const origin=`http://127.0.0.1:${port}`;
  await wait(()=>fetch(origin+'/health').then(r=>r.ok).catch(()=>false));
  const {PROTO}=await import(pathToFileURL(path.join(src.path,'app/public/js/snapshot-codec.js')));assert.equal(PROTO,34);
  const WebSocket=createRequire(path.join(src.path,'app/package.json'))('ws');
  const sid=(await(await fetch(origin+'/api/session')).json()).sid;
  const ws=new WebSocket(`ws://127.0.0.1:${port}/ws?sid=${sid}&v=33`),frames=[];clients.push(ws);
  ws.on('message',raw=>frames.push(JSON.parse(String(raw))));ws.on('error',()=>{});
  const welcome=await wait(()=>frames.find(m=>m.t==='welcome'));assert.equal(welcome.v,34);
  await wait(()=>frames.find(m=>m.t==='err'&&/обновите/.test(m.msg)));
  let reloads=0;const storage=new Map();globalThis.location={reload(){reloads++;}};globalThis.sessionStorage={getItem:k=>storage.get(k)??null,setItem:(k,v)=>storage.set(k,v)};
  const legacy=Object.create(OldNet.prototype);legacy.handlers=new Map();let delivered=0;legacy.on('welcome',()=>delivered++);
  legacy.receive(JSON.stringify(welcome));assert.equal(reloads,1);assert.equal(delivered,0);legacy.receive(JSON.stringify(welcome));assert.equal(reloads,1);
  const {Net}=await import(pathToFileURL(path.join(src.path,'app/public/js/net.js')));const current=Object.create(Net.prototype);current.handlers=new Map();let currentDelivered=0;current.on('welcome',()=>currentDelivered++);current.receive(JSON.stringify(welcome));assert.equal(reloads,1);assert.equal(currentDelivered,1);
  row.protocol={announced:33,serverWelcome:welcome.v,old33NativeNetReloads:reloads,oldWelcomeSuppressed:true,current34WelcomeAccepted:true,guardAvoidsRepeat:true};
  assert.doesNotMatch(output,/handle error|TypeError|ReferenceError/);row.pass=true;
 }catch(e){error={message:e.message,stack:e.stack};row.error=error;row.pass=false;}
 finally{
  for(const ws of clients)ws.terminate();child.kill();await exited;
  fs.writeFileSync(path.join(out,`${group}-protocol-server.log`),output);fs.rmSync(data,{recursive:true,force:true});row.dataRemoved=!fs.existsSync(data);row.childExited=child.exitCode!==null||child.signalCode!==null;
  if(port){const server=net.createServer();await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});await new Promise(resolve=>server.close(resolve));row.portRebound=true;}
  rows.push(row);fs.writeFileSync(path.join(out,'protocol-transport.json'),JSON.stringify({runtime:process.version,oldSource:base,scope:'Actual native HTTP/WS server welcome; exact committed old33 Net receives the wire welcome with location/storage substitutes. No DOM/browser claim.',rows},null,2));
 }
 console.log(group,row.pass?'PASS':'FAIL','native protocol33 ->34 welcome/reload; cleanup',row.dataRemoved,row.portRebound);
 if(error)throw Error(error.stack);
}
