import {spawnSync} from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const out=path.dirname(new URL(import.meta.url).pathname);
const attribution=JSON.parse(fs.readFileSync(path.join(out,'frozen-sources.json'),'utf8'));
const group=process.argv[2], src=attribution.sources[group];
if(!src)throw Error('unknown frozen group');
const defaults={12:['daily-horde','daily-swarm','daily-client','fusion-key-recovery','codec','horde-compatibility','horde-transport'],17:['mobility-numeric-zero','mobility-horde-integration','fusion-key-recovery','codec','horde-transport'],41:['support-horde','support-client','control-separation','fusion-effect-source','fusion-shield-state','fusion-key-recovery','codec','horde-resync','horde-transport']};
const selected=process.argv.length>3?process.argv.slice(3):defaults[group],resultFile=path.join(out,`${group}-targeted-results.json`),results=fs.existsSync(resultFile)?JSON.parse(fs.readFileSync(resultFile,'utf8')).filter(row=>!selected.includes(row.name)):[];
for(const name of selected){
 const runDir=fs.mkdtempSync(path.join(os.tmpdir(),`nh-r34-independent-${group}-`));
 const preload=path.join(src.path,'pm/test-runtime.mjs');
 const args=['--import',preload,path.join(src.path,'app/server',`${name}-test.js`)];
 const command=[process.execPath,...args],started=Date.now();
 const result=spawnSync(process.execPath,args,{cwd:path.join(src.path,'app'),env:{...process.env,HORDE_RUNS_DIR:runDir,NODE_OPTIONS:`--import=${preload}`},encoding:'utf8',timeout:120000});
 const log=path.join(out,`${group}-${name}.log`);
 fs.writeFileSync(log,`SHA ${src.sha}\nNode ${process.version}\nExecutable ${process.execPath}\nCommand ${JSON.stringify(command)}\nCWD ${src.path}/app\nHORDE_RUNS_DIR ${runDir}\n\n${result.stdout??''}${result.stderr??''}${result.error?`\n${result.error.stack}`:''}`);
 fs.rmSync(runDir,{recursive:true,force:true});
 const row={group,sha:src.sha,name,status:result.status,signal:result.signal,command,cwd:path.join(src.path,'app'),runtime:process.version,executable:process.execPath,ms:Date.now()-started,log,runDir,removed:!fs.existsSync(runDir)};
 results.push(row);fs.writeFileSync(path.join(out,`${group}-targeted-results.json`),JSON.stringify(results,null,2));
 console.log(`${group} ${name}: ${result.status===0?'PASS':'FAIL'} ${row.ms}ms`);
}
if(results.some(r=>r.status!==0))process.exitCode=1;
