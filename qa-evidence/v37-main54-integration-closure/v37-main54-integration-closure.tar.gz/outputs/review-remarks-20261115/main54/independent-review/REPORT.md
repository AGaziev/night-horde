# Independent finite main54 integration review

**STATUS: PASS — only the new Daily merge/PROTO34/combined-metadata scope for PR55 and PR59. No new confirmed blocker.** Reviewer `/root/r34_integration_review` did not implement these heads. This is not a whole-PR READY or publication/deployment verdict. Only output evidence/harnesses were written; no product code, Git, GitHub, CTQ, runtime or network settings were changed. The prior accepted4dc dossier is untouched.

## Exact sources

New accepted base `cbf25ec1bb48d70f53d949c105b7ad5981722963` has exactly the tree of accepted Daily head `dbf008cb31a1bac46ff4faee67dd56dc28c922e4`.

| PR / Issue | Frozen head | Accepted feature parent | Current CI / checkout |
| --- | --- | --- | --- |
| 55 / 17 Dash | `f0c69a89fbba79c99b5bd15bbb4a3005314d3f8b` | `8661183cb26ef351336769430d0ee2f9850b549c` | 101/101, run43705337978, `b0cf7dd31f0c72b0b2f428f0fc1d8562e5115494` |
| 59 / 41 Support | `4c46cc855085ef445eed903757e474ac60e2481a` | `7b46ace9722abef98a64dca0cea647b628a90709` | 96/96, run43705460948, `2c8caa20c71815d28f41981db8cc6f6813d2a69b` |

Both contain cbf as an ancestor; diff-check passes. Runtime uses `git archive` copies of these exact SHAs, with archive/tree/file hashes recorded in `frozen-sources.json` and `source-carry.json`. Implementation worktrees were not used as the final runtime. Applicable AGENTS and QUALITY are unchanged; owner residual comments6893086879/6893087081 request only the new merge/common snapshot/current CI. #74/#68/#75 stay outside this scope.

## Actual independent verification

Canonical macOS Node **v24.22.1**, `/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node`. **15/15 targeted suite executions PASS:** Dash7, Support8. Exact argv/cwd/SHA/exit/log/store are in `*-targeted-results.json` and `final-attribution.json`.

- Dash: Daily fusion/client/Horde separation, mobility-fusion integration, codec, actual Horde transport and Daily legacy HTTP/WS/SSE pass. The Net-prototype fixture change in daily-fusion adds only outbox initialization required when the preserved dash epoch causes prediction discard; assertions remain intact.
- Support: new daily-support3/3, Daily fusion, support-client, run-history, Daily/Horde separation, codec, actual Horde transport and Daily legacy HTTP/WS/SSE pass. Real grantOffer/pick retains the existing gift through Dome fusion; gift age7.99 credits its donor, exact age8 consumes own Ward. A normal native boundary tick both resolves the successful Swarm cohort/reward and credits the delivered control interval. Saved Daily/support log/card and ordinary-progress exclusion remain coherent.
- **Four own real-WS scenes PASS:** Daily Swarm and Horde at each head. The Daily scene creates an active native cohort and actual caravan, performs a native fusion pick, deliberately loses its cancellation delta, then requests a key and reconnects. The same key preserves Swarm/caravan/pa/retirement with either Game.requestDash/Net/Room mob epoch or actual Bastion wardGift/support. Unrelated shots survive; retired shots cannot resurrect. Native finish preserves Daily and support in its saved record.
- **Two actual stock native servers PASS PROTO33→34:** WS33 receives welcome34. Exact committed old33 Net from cbf calls reload once and suppresses outdated welcome; matching34 accepts it. This independent native Net check uses location/storage substitutes, without a DOM/browser claim.

`source-carry.json` proves Daily rules/Swarm/server routing and the selected Daily methods, including recalcMods and native spawning, exactly match accepted main54. Client speedMul matches Daily main. Mobility/Input/Net, support/control-observation/hero-perks and the selected combat/contact methods, including WardAbsorb/WardAnswer, exactly match their accepted4dc feature parents. Accepted fusion core/content remain unchanged. Original finite30/24/40, observer state/RNG, historical outcomes and earlier4dc acceptance therefore carry on their original SHAs; they were not rerun or relabeled. No new balance, tuning,39-recipe or performance campaign was performed.

## Current external proof and cleanup

**Fresh CI197/197 suites PASS**, Linux Node24.22.2. Root downloaded/live-verified the primary artifacts. Reviewer independently checked each run metadata, revisions, checkout parents `[cbf, head]`, tree equality, exact complete suite filename set, PASS/exit0 and every log's presence. See `ci-source-readback.json`; no independent remote fetch was made.

Actual Chrome151/muted current stock UI/server old33→reload→34, Daily Glass HUD/contract and touch dash180/epoch1 are **root evidence**, `../protocol-browser-final.json`, bound to both exact frozen heads. Reviewer read this proof and cleanup without another browser run.

**Cleanup PASS:** six owned WS/server ports independently rebound and closed,19 owned state paths absent, no persistent archive-source server, both original worktrees clean at the frozen heads. See `cleanup-final.json`. Old4dc report/data remain unchanged; source archives and new evidence remain. No new agent was spawned.
