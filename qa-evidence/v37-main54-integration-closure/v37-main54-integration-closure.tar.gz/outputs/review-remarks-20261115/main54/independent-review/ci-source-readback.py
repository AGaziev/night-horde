from pathlib import Path
import json

out = Path(__file__).resolve().parent
manifest = json.loads((out / 'frozen-sources.json').read_text())
rows, pending = [], []
for pr, n, short in [(55, 17, 'f0c69a8'), (59, 41, '4c46cc8')]:
    p = out.parent / f'ci/pr{pr}-{short}'
    if not all((p / name).is_file() for name in ['run-metadata.json', 'checkout-commit.json', 'results.json', 'revisions.txt']):
        pending.append(pr)
        continue
    src = manifest['sources'][str(n)]
    run = json.loads((p / 'run-metadata.json').read_text())
    commit = json.loads((p / 'checkout-commit.json').read_text())
    results = json.loads((p / 'results.json').read_text())
    revisions = (p / 'revisions.txt').read_text()
    assert run['headSha'] == src['sha'] and run['status'] == 'completed' and run['conclusion'] == 'success'
    server = [j for j in run['jobs'] if j['name'] == 'Server tests (Node 24, Linux)']
    assert len(server) == 1 and server[0]['status'] == 'completed' and server[0]['conclusion'] == 'success'
    assert [x['sha'] for x in commit['parents']] == [manifest['base'], src['sha']]
    assert commit['tree']['sha'] == src['tree']
    assert 'Checkout: ' + commit['sha'] in revisions and 'PR head: ' + src['sha'] in revisions and 'PR base: ' + manifest['base'] in revisions
    expected = sorted(f.name for f in (Path(src['path']) / 'app/server').glob('*-test.js'))
    actual = sorted(row['suite'] for row in results['results'])
    assert actual == expected
    assert all(row['status'] == 'PASS' and row['exitCode'] == 0 for row in results['results'])
    assert all((p / (suite[:-3] + '.log')).is_file() and (p / (suite[:-3] + '.log')).stat().st_size > 0 for suite in actual)
    rows.append({'pr': pr, 'issue': n, 'head': src['sha'], 'base': manifest['base'], 'checkout': commit['sha'], 'parents': [x['sha'] for x in commit['parents']], 'tree': commit['tree']['sha'], 'treeMatchesFrozenArchive': True, 'node': results['node'], 'run': run['databaseId'], 'url': run['url'], 'expectedSuites': len(expected), 'recordedPassSuites': len(actual), 'allLogsPresent': True, 'source': 'Root-downloaded/live-verified primary CI artifacts; independently checked locally; no independent remote fetch', 'pass': True})
result = {'rows': rows, 'pendingRootArtifacts': pending, 'allAvailablePass': all(row['pass'] for row in rows)}
(out / 'ci-source-readback.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
