# Issue41 gift-window final review — CODE / READY_TO_MEASURE

Final **a99697894432856a05a7a4356bef10634d3c1a9c**, before `9683cbc14a228b22e4ea9eb977f4ac976158c1c4`, base `0ab5f6fd29c293511b149664c42f7a2268e527d8`. Independent reviewer `/root/batch_product` did not author41. Worktree clean; no APP/Git/operator/registry changes.

**Latest general PR59 comments were fetched live before source/evidence review.** Latest ID **6881354360**, previous6880837720; live head exactlya996/base0ab. Primary copies `latest-general-comments.json`, `latest-pr.json`, `live-read.json`. Scope is that final gift timestamp family, including its conditional future grant. No confirmed important regression in the assigned scope.

## Calling-chain closure

The accepted contact time now reaches incoming gift eligibility, wardAbsorb, recipient-window checks and new gift birth/expiry. Windows are `[grantedAt,until)`, expiry=actualAt+8. Exact-expiry contact cannot spend an old token; exact/late donor renewal remains legal. Recipient range/liveness/offline/own capacity is checked before touching a foreign token. A consumed gift credits its actual donor once, keeps own charge accounting separate and cannot gift back.

Native AI retains its existing early phase. Its endpoint grant is a private conditional reservation, unavailable to earlier projectile contacts. Pure projection preserves an old token still live at an earlier contact. An earlier B gift that survives to A's birth rejects future A; if B is spent beforehand A activates. Endpoint settlement processes all recipients, including downed ones, removes rejected pending state and cannot revive a canceled gift later. No room-clock rewind, AI/damage/collision replay or speculative RNG occurs. Birth/range/reservation fields remain private; player row15, wardGift pair shape, PROTO30 and v36 remain.

## Independently executed evidence

- **Author fixture replay, honestly attributed:** final test source verified identical in immutable before/current and equal to Git a996. Before graph's15 leaves were independently checked against9683 Git objects. `before-replay.log` reproduces **16PASS/42FAIL/58**; `current-replay.log` gives **58/58 PASS**. Raw case JSON and `replay-execution.json` retained. Cases cover both modes/reversed projectile arrays, two donors inside/outside range, before/exact/after expiry, receiver ordering, legal renewal, duplicate consumption, future birth, pending activation/rejection and old-window preservation. Actual snapshots and one completed RunStore record are checked in48 chronological cases.
- **Own10 bounded before/current native families**, not author's fixture functions: `own-native.mjs/json` and `own-native-final.log`. Actual native Bastion offer/pick/evolution, real fireHostile and Room.step. Four two-donor inside/outside cases across both modes preserve original donor credit and protection; before either deleted the out-of-range foreign token or credited both hits to B. Four native Star birth/own0/1 cases assert actual run-log incoming damage even though the later shared20HP heal hides it in final HP, preserve the future gift, then consume it on a later hit. Two native lethal receiver cases cancel the unborn gift at endpoint, revive through updateRevive and prove no token/pending state survives revival/new run. Source incoming damage uses the native shot amount, without normalization. Initial exact floating-point credit equality differed only2.7599488888888892 versus2.759948888888889; its source/log are retained and corrected with1e-8 comparison, not called a product defect.
- **Retained26/26 PASS**: gift state7, previous contact clocks14, client snapshot/render4, support1. No full suite or new browser/performance campaign. Local canonical Node24.22.1.

Reproduction from workspace uses canonical Node `/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node`:

```sh
node outputs/issue-split/v36/41-window-final-review/own-native.mjs
python3 outputs/issue-split/v36/41-window-final-review/preservation.py
```

The recorded replay commands and separate cwd/source bindings are in `replay-execution.json`; output JSON paths are supplied by GIFT_CHAIN_OUTPUT, without writing author artifacts.

## Preservation and compatibility

`preservation.py/json/log` independently restores six explicitly classified gift-only regions and recovers the entire old game.js byte-for-byte. Existing support code is exact after excluding the new gift helpers. **13/15 runtime leaves**, **223 Room methods**, AI/contact pipeline, own recharge/retaliation and Math.random call sites are unchanged. All public client and server-codec bytes are unchanged from9683. This carries the already observed real main29→30 reload and current WS glyph/HUD proof in `../41-final-review/`; it does not carry prior combat outcomes. No repeated UI campaign was needed for a private server gift-window change.

Live current check is SUCCESS for [Server CI43626996107](https://github.com/AGaziev/night-horde/actions/runs/43626996107), `current-checks.json`. That is a live check result, not a new independent primary-artifact audit here; root owns final checkout/base/head/artifact verification. Old9683 CI/results are historical. In particular the old384 partial match results do not apply to this changed cooperative protection.

`cleanup-final-source.json`: exact final source and script hashes, worktree clean, owned Node workers0; no HTTP/browser/ports created, full matches0/performance0. New independent code cases are complete. Current primary CI binding, new immutable measurement source, fresh cooperative balance/5–8 load and CEO verdict remain owner gates.

**STATUS: CODE / READY_TO_MEASURE, scoped to owner6881354360 family. Balance not READY.**
