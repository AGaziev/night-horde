# READY_TO_REGISTER_HOLD0 — issue41-a996978-latest

Prepared one fresh immutable600 candidate plan for **a99697894432856a05a7a4356bef10634d3c1a9c**, base `0ab5f6fd29c293511b149664c42f7a2268e527d8`. Plan SHA256 `f649dcc9c86c113f3e000230fdfdea1f8d2420d39f60f6e82fe77b7bf9fcb4d8`. `FINAL-PREPARED.json` records all bindings and final checks.

Before preparation, live general+inline PR59 comments were fetched. Latest general **6882422495** closes code findings on this exact source; inline comments0. Nonblocking reservation/extra-flash debt is explicitly Issue68 and was not changed. Primary read receipt: `../../../v36/41-window-final-review/plan-preflight/read-receipt.json`.

## Exact CI primary

Server CI [43626996107](https://github.com/AGaziev/night-horde/actions/runs/43626996107), attempt1, **63/63 PASS**, Linux Node24.22.2. All63 suites match the frozen source suite list and exit0. Checkout `e373f9bf3b0bb3cf30c80fb0f420e2b63ec48764`, parents base0ab/head a996; checkout tree equals head tree. Critical gift-chain/contact/control/client logs were read. Downloaded ZIP SHA256 `46f09aab69321977dca1eb042635640a7e8f9e65ac3266eec6b398ac6a19b541` matches GitHub's artifact digest.

Primary files: `../../../v36/current-fixes-ci/41/43626996107/`, including run/artifacts/checkout metadata, ZIP, all logs, revisions/results and `primary-proof.json`; summary `../../../v36/current-fixes-ci/audit-41-a996.json`.

## Plan and smoke

- Exactly600 fresh notStarted attempts,10 cells×60; canonical seed/K0/heroes/tuple order byte-equivalent by projected tuple to accepted baseline plan. Formula130000+i+cell*1000, K0=i. FixedN, no stop on success, no outcome search or historical carry.
- Canonical ordinary run-sim/sim-runner hashes unchanged. No dash/daily adapter or policy imported. Existing shared durable-master-v5/supervise-v3 read-only hashes verified; neither controller changed.
- git archive app+pm from actuala996,291 manifested files. Archive SHA256 `383325ada92e795b2b30316a1ca4598a85bb8f236c1b56499d4664baf7fcdc03`; manifest `b8998454ff7f6f84f9e1684f666607dcec27c6e4bc9778a2ad3cc94167243538`. All extracted hashes verified again after smoke.
- Pristine canonical Node24.22.1 binary SHA256 `cf52d093e9b728a7e6929a4371fa37d271304383e7e7c9f0f0e32fb00373b32c`, clean child environment. Two bounded native play→finish smokes (solo night,4-player lunch),5 ticks each, manual smoke finish, real matching Room.finish/log identity and PROTO30. `own-smoke.log/meta.json`; explicitly zero full simulation attempts and not counted in600.
- Baseline measureda957/public-tree main0ab carry reference unchanged; no baseline rerun. Old9683 partial384 outcomes/source/plan/raw were neither read as results nor overwritten/rebound/carried. Other plans, including17, were not modified.

## Current state and root next step

**NOT REGISTERED.** worker-limit0, rootArmedfalse, authorizedfalse, INITIAL_READINESS_HOLD present, raw empty, no bootstrap/master/supervisor/Node workers. All600 remain notStarted. CI primary/own smoke/code-independent evidence are populated; root arming and explicit capacity/start authorization are intentionally absent.

Prepared registration script was syntax-checked without executing it. It acquires the existing operator.lock, adds only this HOLD0 entry, verifies all old registry entries/root keys are unchanged, and never bootstraps. **Root's next step**, when authorized to register:

```sh
python3 /Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/issue-split/runs/latest-source-20261114/register-41-a996.py
```

Root must then verify current gates/shared capacity, arm only this plan's readiness and separately authorize start through the sole operator. Future command form, **not run or authorized by this preparation**:

```sh
python3 /Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/issue-split/runs/final-a25-r16/qa-control.py start-verified-current issue41-a996978-latest N --root-confirmed
```

N must fit the live shared maximum9, including every reserved/inflight worker. No direct bootstrap, second operator or automatic retry. Preparation invoked neither operator nor registration; full attempts0, owned CPU workers0, app worktree clean.
