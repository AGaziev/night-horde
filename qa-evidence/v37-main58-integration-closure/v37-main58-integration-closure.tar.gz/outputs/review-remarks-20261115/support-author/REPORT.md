# PR59 / Issue41 — author integration handoff

**PASS, scoped author verification.** Frozen branch `codex/41-support-control`, head `7b46ace9722abef98a64dca0cea647b628a90709`, tree `1f57f4602622655fd31b9b1f479b946f6d96b6cd`. Independent acceptance and full current Linux Server CI remain with root. No author READY, push, GitHub mutation, main merge or deployment.

## Authority and exact sources

- Assigned worktree: `/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/work/night-horde-issue-41`; live Issue41 assignee `SergeyKonev`; one open Draft PR59 confirmed before edit. Initial clean head `eda4dadc4716e05030bf595792a626f724abd8d2`.
- Owner residual [6892625241](https://github.com/AGaziev/night-horde/pull/59#issuecomment-6892625241): four prior READY and accepted600 outcomes retained; only new-main integration and affected paths requested. #68/#75 left unchanged.
- Ordinary merge of fixed main `4dc70c76a534d064899435e398225f72231b62c6`; merge commit `8d96cc53d445fcb19b87041056cc2f1396d1c7f7` has parents `[eda4dadc4716e05030bf595792a626f724abd8d2, 4dc70c76a534d064899435e398225f72231b62c6]`. Main ancestry verified with `git merge-base --is-ancestor` (exit0).
- Test-only commit `7b46ace9722abef98a64dca0cea647b628a90709` adds `server/support-fusion-test.js` (7 native cases); `git diff 8d96cc5..HEAD --stat` contains only that file.

## Resolved integration

Four conflicts: shared codec PROTO, content Night coefficients, game cold-wave attribution/WardAnswer, sim expectations. Retained main58 signature dispatch/retirement/resonance sources and its accepted coefficients (solo Night damage0.65 and all main group/Lunch values). Retained support gift/own-state separation, exact contact time, owner attribution, bounded control, read-only projection and barrier mark accounting. No new balance tuning.

Root agreed **PROTO33**: both earlier main32 and support-feature32 pages must reload. Shared server/client constant, welcome33, old32 reload, current33 resume, old32 WS/SSE rejection checked.

The first integration run found `ReferenceError: contactAt is not defined`: main58 extracted `wardAnswer`, while the support gift body still used caller contact time. Fixed by forwarding `contactAt` from `wardAbsorb` to `wardAnswer`; initial failing logs preserved (`support-gift-state-minimum.log`, `support-contact-time-minimum.log`, `support-client-minimum.log`, `support-horde-minimum.log`). Original earlier/live/expiry/late projectile contacts and donation times now pass. The harness also had one command typo `support-test-test.js`; the correct `support-test.js` was run successfully and is separately logged.

## Verification and primary evidence

Canonical runtime `/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node` **v24.22.1/macOS**. Common env: `NODE_OPTIONS=--import /Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/work/night-horde-issue-41/pm/test-runtime.mjs`, isolated `HORDE_RUNS_DIR` under this report directory; child server tests use distinct ephemeral ports and `VIBE_APP_KEY=''`. Commands from `app/`: `<canonical-node> server/<name>-test.js`. The manifests record every actual argv/exit and logs retain assertions.

**34 distinct scoped suites PASS**. `checks-summary.json` indexes the latest successful execution of each; `final-checks.json` is bound directly to frozen head/tree. Earlier fixed executions have the same product source as the merge commit; the only subsequent change adds the native test file.

- New native joint suite7/7: gift issued before actual pick survives Phalanx/Dome/Riposte/Rod/Resonantshield fusion; live gift spends first without native counter or own charge loss; next own hit triggers the signature source; no retired component damage rows; run metadata retains one duo weapon and fusion pick. Real Crystal Choir cast/wave preserves slow/freeze owner and signature resonance, including boss slow cap.
- Native signature-only dispatch, retirement/cancel key recovery, shield recharge and resonance source suites PASS. This is impacted-path verification, not a new full39 content/balance audit.
- Gift state, actual contact before/at/after expiry, duplicate contact ordering, chain prevention, native Horde frost/venom, client Ward glyph/radius and gift delta-gap/key recovery PASS.
- Control delivery/contact/boundaries/separation/shield turn/state suites PASS: no observer query-cache/state mutation or additional RNG draw; clamped caravan/Horde movement has no phantom credit; positive inset control still earns contribution. Observer code itself unchanged by integration.
- Horde review-game covers real additional HP mark damage through barrier; mark-attacker, reaction-support and flash-support PASS.
- Codec, offer identity actual welcome, real WS/SSE compatibility, transport/reconnect, horde resync, client command transport PASS. PROTO32 is included in old-page welcome/rejection checks.
- sim, finale, v20/v22, sniper warning, solo Night pressure PASS. No new full-run balance/5–8/FPS simulations requested or run.

Full new-candidate Linux CI and independent review: **NOT VERIFIED by author**, to be completed by root after authorized push. No fresh browser session in this author round; native production Game/Renderer/Net paths and real local transports exercised by the named suites.

## Cleanup

`cleanup.json`: assigned worktree clean; no matching local server child remains; owned test store paths absent. Tests terminate their sockets/servers and remove their ephemeral directories via teardown. Source-check store path was also checked absent after final verification. Only this assigned worktree was modified. Artifacts remain under `/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/review-remarks-20261115/support-author`.
