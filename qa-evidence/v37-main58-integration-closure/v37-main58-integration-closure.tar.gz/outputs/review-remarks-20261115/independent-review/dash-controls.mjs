import fs from'node:fs';import path from'node:path';import assert from'node:assert/strict';import crypto from'node:crypto';import{pathToFileURL}from'node:url';
const root='/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/review-remarks-20261115/independent-review/source-17',here=path.dirname(new URL(import.meta.url).pathname),dir=path.join(here,'controls-data');process.env.HORDE_RUNS_DIR=dir;fs.mkdirSync(dir,{recursive:true});
const{Room}=await import(pathToFileURL(root+'/app/server/game.js')),{hasActualDash}=await import(pathToFileURL(root+'/app/server/mobility.js')),{clipDash,hasDashMovement}=await import(pathToFileURL(root+'/app/public/shared/mobility.js'));
const dt=1/30,rows=[];
function native({kind,x,y=0,direction=1,ring=null,enemy=null,press=true}){
 const r=new Room('FINITE-CONTROL',()=>{});r.addPlayer(1,'P','witch');r.start();r.time=100;r.spawn=()=>{};r.breakAround=()=>{};r.events.next=Infinity;r.peaks=[];r.bossIdx=r.bossAt.length;
 const h=r.heroes.get(1);Object.assign(h,{x,y,hp:100,maxHp:100,iframes:0,ward:0});h.weapons.clear();h.perk.readyAt=Infinity;if(ring)r.fin={cx:0,cy:0,r:ring,r1:ring,nextAdd:Infinity};
 let e;if(enemy){e=r.spawnEnemy('ghoul',[h],1);Object.assign(e,{...enemy,speed:0});}
 const calls=[],hurt=r.hurtPlayer;r.hurtPlayer=function(...a){calls.push({at:a[3],roomTime:this.time,dmg:a[1],from:a[2]});return hurt.apply(this,a);};
 if(press)r.handle(1,{t:'dash',x:direction,y:0,run:r.runLog.id,request:1,expiresAt:Date.now()+1500});
 r.step(dt);return{kind,x:h.x,y:h.y,hp:h.hp,iframes:h.iframes,path:h.dashPath,actual:hasActualDash(h),calls,time:r.time,enemy:e&&{x:e.x,y:e.y,dmg:e.dmg,distance:Math.hypot(e.x-h.x,e.y-h.y)}};
}
for(const distance of[24,40]){
 const out=native({kind:'positive'+distance,x:435-distance,ring:449,enemy:{x:436-distance,y:27}});
 assert.equal(out.path.moveX,distance);assert.equal(out.path.moveY,0);assert.equal(out.path.duration,distance/1200);assert.equal(out.actual,true);assert.ok(out.enemy.distance>28);assert.equal(out.calls.length,1);assert.equal(out.calls[0].at,100);assert.ok(out.calls[0].at<out.time);assert.equal(out.hp,100-out.enemy.dmg);rows.push(out);
}
const ordinary=native({kind:'ordinary-body-endpoint',x:40,press:false,enemy:{x:55,y:0}});assert.equal(ordinary.calls.length,1);assert.equal(ordinary.calls[0].at,ordinary.time);assert.equal(ordinary.actual,false);assert.equal(ordinary.iframes,.4);rows.push(ordinary);
const inward=native({kind:'inward-boundary-real-sweep',x:435,ring:449,direction:-1,enemy:{x:415,y:27}});assert.equal(inward.path.moveX,-40);assert.equal(inward.path.duration,dt);assert.equal(inward.actual,true);assert.ok(inward.enemy.distance>28);assert.equal(inward.calls.length,1);assert.ok(inward.calls[0].at>100&&inward.calls[0].at<inward.time);assert.equal(inward.hp,100-inward.enemy.dmg);rows.push(inward);
const partial=native({kind:'partial2px-native',x:433,ring:449});assert.equal(partial.path.moveX,2);assert.equal(partial.path.duration,2/1200);assert.equal(partial.actual,true);assert.equal(partial.x,435);rows.push(partial);
const full=native({kind:'ordinary-full-dash',x:0});assert.equal(full.path.moveX,40);assert.equal(full.path.duration,dt);assert.equal(full.actual,true);assert.equal(full.hp,100);rows.push(full);
const tiny=clipDash(435-1e-6,0,1,0,dt,{cx:0,cy:0,r:435});assert.ok(tiny.x>tiny.startX&&tiny.duration>0);rows.push({kind:'subpixel-partial',result:tiny});
// Directly challenge the admission consumer with the observed old residual; it must reject it independently of clipDash.
assert.equal(hasActualDash({dashPath:{x:459.18495211037146,y:235.92676943396296,moveX:5.684341886080802e-14,moveY:2.842170943040401e-14}}),false);
assert.equal(hasDashMovement(24,0,100000),true);assert.equal(hasDashMovement(40,0,100000),true);rows.push({kind:'consumer-residual-denied-real24and40-retained',pass:true});
fs.rmSync(dir,{recursive:true,force:true});fs.writeFileSync(path.join(here,'controls.json'),JSON.stringify({node:process.version,source:root,head:'8661183cb26ef351336769430d0ee2f9850b549c',scope:'Fixed24/40 positivebody,ordinaryendpoint,inward,partial2,fulldash,subpixel and observedresidual admission; no angles/grid',rows,pass:true,dataRemoved:!fs.existsSync(dir)},null,2));console.log('PASS finite controls',rows.length,rows.map(r=>({kind:r.kind,move:r.path?.moveX,bodyClock:r.calls?.[0]?.at,roomTime:r.time,hp:r.hp})));
