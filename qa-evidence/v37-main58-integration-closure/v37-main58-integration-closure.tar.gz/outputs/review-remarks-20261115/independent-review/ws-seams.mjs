import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import net from 'node:net';
import {once} from 'node:events';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {setTimeout as delay} from 'node:timers/promises';
const out=path.dirname(new URL(import.meta.url).pathname),manifest=JSON.parse(fs.readFileSync(path.join(out,'frozen-sources.json'),'utf8'));
const group=process.argv[2],src=manifest.sources[group];if(!src)throw Error('group');
const data=fs.mkdtempSync(path.join(os.tmpdir(),`nh-r34-seam-${group}-`));process.env.HORDE_RUNS_DIR=data;
const imp=p=>import(pathToFileURL(path.join(src.path,'app',p)));
const {Room}=await imp('server/game.js'),{Net}=await imp('public/js/net.js'),{SnapshotDecoder,PROTO}=await imp('public/js/snapshot-codec.js');assert.equal(PROTO,33);
const gameSource=fs.readFileSync(path.join(src.path,'app/public/js/game.js'),'utf8').replaceAll("'/shared/","'"+pathToFileURL(path.join(src.path,'app/public/shared/')).href);
const {Game}=await import('data:text/javascript;base64,'+Buffer.from(gameSource).toString('base64'));
const {WebSocketServer}=createRequire(path.join(src.path,'app/package.json'))('ws');
const dt=1/30,rows=[],cleanup=[];
async function until(fn){for(let i=0;i<500;i++){if(fn())return;await delay(2);}throw Error('WS seam delivery deadline');}
async function scene(horde){
 let peer,dropNext=false;const fromClient=[],fromServer=[],keyWires=[],events=[];
 const wss=new WebSocketServer({host:'127.0.0.1',port:0});await once(wss,'listening');const port=wss.address().port;
 const pid=2,r=new Room('R34-SEAM',(to,msg,json)=>{if(to!==pid||peer?.readyState!==1)return;const wire=json??JSON.stringify(msg);fromServer.push(JSON.parse(wire));if(msg.t==='s'&&dropNext){dropNext=false;events.push('drop-cancel-snapshot');return;}if(msg.t==='s'&&JSON.parse(wire).K)keyWires.push(JSON.parse(wire));peer.send(wire);});
 if(horde){r.addPlayer(1,'Director','witch');r.setRuleset('horde');}
 r.addPlayer(pid,'Hero','witch');r.addPlayer(3,'Ally','witch');
 if(group==='12'){
  assert.equal(horde,false);const {dailyFor}=await imp('public/shared/daily.js');r.handle(pid,{t:'daily',enabled:true});
  let day=Date.UTC(2026,10,15);while(dailyFor(day).id!=='swarm')day+=86400000;r.lockDaily(day);assert.equal(r.daily.id,'swarm');
 }
 assert.equal(r.start(),true);r.time=100;const h=r.heroes.get(pid),ally=r.heroes.get(3);
 for(const hero of [h,ally]){hero.weapons.clear();hero.perk.readyAt=Infinity;hero.mods.critChance=0;hero.x=hero.y=0;}
 h.weapons=new Map([['bolt',{lvl:3,t:0}],['lightning',{lvl:3,t:0}],['knives',{lvl:3,t:0}]]);
 h.posAck=17;
 let supportExpected=null;
 if(group==='41'){
  const e=r.spawnEnemy('skel',[h,ally],1,[0,0]);Object.assign(e,{hp:100,maxHp:100,hordeSource:'manual',hordePack:'bones',hordeBuild:{packs:{},weapons:{},artifacts:{}},hordeBarrier:10,markT:r.time+2,markMul:.5,markOwner:ally});
  const before=ally.support.allyDamage;r.hurtEnemy(e,20,h,{weapon:'test',tags:[]});assert.equal(ally.support.allyDamage-before,10);supportExpected=ally.support.allyDamage;
 }
 let connections=0;wss.on('connection',ws=>{peer=ws;connections++;ws.on('message',raw=>{const m=JSON.parse(String(raw));fromClient.push(m);r.handle(pid,m);if(m.t==='barrier')ws.send(JSON.stringify(m));});});
 let ws,client,game,barrier=0,seq=0;
 async function connect(){
  ws=new WebSocket('ws://127.0.0.1:'+port);await once(ws,'open');await until(()=>peer?.readyState===1);
  client=Object.create(Net.prototype);Object.assign(client,{outbox:[],connected:true,transport:'WS',ws,handlers:new Map(),snapDec:new SnapshotDecoder(),keyAskedAt:-Infinity});
  ws.addEventListener('message',e=>client.receive(e.data));client.on('barrier',m=>barrier=m.n);
  game=new Game(client);game.me=pid;game.onEvent=()=>{};client.on('start',m=>game.begin(m));client.on('s',m=>game.onSnapshot(m));client.on('dash',m=>game.acceptDash(m));
  peer.send(JSON.stringify(r.startMsg()));await flush();
 }
 async function flush(){const n=++seq;client.send({t:'barrier',n});await until(()=>barrier===n);}
 function snap(){r.time+=.1;const expected=r.snapshot();return expected;}
 try{
  await connect();
  r.addProjectile(h,'bolt',0,100,10,1,2,null);r.addProjectile(h,'knife',0,100,10,1,2,null);
  const retired=r.projectiles.find(p=>p.src.weapon==='bolt').id,unrelated=r.projectiles.find(p=>p.src.weapon==='knives').id;
  snap();await flush();assert.ok(game.shots.has(retired)&&game.shots.has(unrelated));
  if(group==='17'){
   assert.equal(game.requestDash({vector:()=>({x:1,y:0})}),true);await flush();assert.ok(h.dash);assert.equal(game.moveEpoch,h.moveEpoch);
  }
  const card=r.duoCard(h,{id:'orb',a:'bolt',b:'lightning'});h.offer=[card];r.sendOffer(h);
  client.send({t:'pick',i:0,offerEpoch:h.offerEpoch});await flush();assert.deepEqual([...h.weapons.keys()],['orb','knives']);assert.ok(r.projectiles.every(p=>p.src.weapon==='knives'));assert.ok(r.consumedAttacks.has(`0:${retired}`));
  dropNext=true;snap();await flush();assert.ok(game.shots.has(retired));snap();await flush();assert.ok(fromClient.some(m=>m.t==='kf'));snap();await flush();
  assert.equal(game.shots.has(retired),false);assert.ok(game.shots.has(unrelated));assert.ok(game.consumedAttacks.has(`0:${retired}`));
  const wire=keyWires.at(-1),decoded=new SnapshotDecoder().decode(wire);assert.ok(decoded.consumedAttacks.some(([k,id])=>k===0&&id===retired));assert.deepEqual(decoded.pa,[[pid,17,h.moveEpoch??0]]);
  if(group==='12'){assert.equal(game.daily.id,'swarm');assert.deepEqual(decoded.swarm,r.snapshot().swarm);assert.ok(r.daily);}
  if(group==='17'){assert.equal(decoded.mob[0][1],1);assert.ok(decoded.mob[0][3]>0);}
  if(group==='41'){assert.equal(decoded.support.find(row=>row[0]===3)[5],supportExpected);}
  game.shotEvent(['shot',retired,0,0,0,100,0,3,0,r.time]);assert.equal(game.shots.has(retired),false);
  ws.close();await once(ws,'close');await connect();r.resync(pid);snap();await flush();
  const recovered=keyWires.at(-1),again=new SnapshotDecoder().decode(recovered);assert.ok(again.consumedAttacks.some(([k,id])=>k===0&&id===retired));assert.ok(game.consumedAttacks.has(`0:${retired}`));
  if(group==='12')assert.equal(game.daily.id,'swarm');if(group==='17')assert.equal(again.mob[0][1],1);if(group==='41')assert.equal(again.support.find(row=>row[0]===3)[5],supportExpected);
  rows.push({horde,port,connections,retired,unrelated,clientCommands:fromClient.length,keyRequests:fromClient.filter(m=>m.t==='kf').length,keyCount:keyWires.length,snapshotFields:Object.keys(again),daily:game.daily??null,mob:again.mob??null,support:again.support??null,events,pass:true});
 }finally{
  if(ws&&ws.readyState!==3){ws.close();await once(ws,'close');}for(const p of wss.clients)p.terminate();await new Promise(resolve=>wss.close(resolve));
  const probe=net.createServer();await new Promise((resolve,reject)=>{probe.once('error',reject);probe.listen(port,'127.0.0.1',resolve);});await new Promise(resolve=>probe.close(resolve));cleanup.push({port,serverClosed:!wss.address(),socketClosed:ws?.readyState===3,independentPortRebound:true});
 }
}
let error;
try{for(const horde of group==='12'?[false]:[false,true])await scene(horde);}catch(e){error={message:e.message,stack:e.stack?.replace(/data:text\/javascript;base64,[^\n]+/g,'[native Game module]')};}
finally{fs.rmSync(data,{recursive:true,force:true});fs.writeFileSync(path.join(out,`${group}-ws-seams.json`),JSON.stringify({sha:src.sha,runtime:process.version,executable:process.execPath,source:src.path,scope:'Native pick/dash and Room serialization -> real loopback WS -> exact client Net/Game; one deliberately dropped cancellation; key request and reconnect. No DOM/browser or live-frequency claim.',rows,cleanup,data,dataRemoved:!fs.existsSync(data),error,pass:!error},null,2));}
if(error)throw Error(error.stack);console.log('PASS',group,'native feature/fusion WS loss/key/reconnect',rows.length);
