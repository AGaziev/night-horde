import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {pathToFileURL} from 'node:url';
const out=path.dirname(new URL(import.meta.url).pathname),manifest=JSON.parse(fs.readFileSync(path.join(out,'frozen-sources.json'),'utf8')),src=manifest.sources[41];
const data=fs.mkdtempSync(path.join(os.tmpdir(),'nh-r34-support-seams-'));process.env.HORDE_RUNS_DIR=data;
const imp=(dir,p)=>import(pathToFileURL(path.join(dir,'app',p)));
const {Room}=await imp(src.path,'server/game.js'),{Room:Main}=await imp(path.join(out,'source-main'),'server/game.js');
const {HORDE_ARENA}=await imp(src.path,'public/shared/horde-content.js'),{CARAVAN}=await imp(src.path,'server/caravans.js');
const rows=[],close=(a,b,m)=>assert.ok(Math.abs(a-b)<1e-8,`${m}: ${a} vs ${b}`);let error;
try{
 for(const [barrier,hp] of [[10,100],[25,100],[30,100],[10,5]]){
  const r=new Room('R34-SUNPRISM',()=>{});r.addPlayer(1,'Director','witch');r.setRuleset('horde');r.addPlayer(2,'Attacker','witch');r.addPlayer(3,'Marker','witch');r.start();r.time=100;
  const h=r.heroes.get(2),marker=r.heroes.get(3);for(const p of [h,marker]){p.weapons.clear();p.perk.readyAt=Infinity;p.mods.critChance=0;p.x=p.y=0;}r.synergy=0;
  marker.weapons=new Map([['prism',{lvl:3,t:0}],['lantern',{lvl:3,t:0}]]);marker.offer=[r.duoCard(marker,{id:'sunprism',a:'prism',b:'lantern'})];r.sendOffer(marker);r.handle(3,{t:'pick',i:0,offerEpoch:marker.offerEpoch});assert.ok(marker.weapons.has('sunprism'));
  const e=r.spawnEnemy('skel',[h,marker],1,[100,0]);Object.assign(e,{x:100,y:0,hp:1e6,maxHp:1e6,hordeSource:'manual',hordePack:'bones',hordeBuild:{packs:{},weapons:{},artifacts:{}}});r.rebuildGrid();
  r.updateWeapon(marker,'sunprism',marker.weapons.get('sunprism'),1/30);assert.equal(e.markOwner,marker);assert.ok(e.markT>r.time);assert.ok(marker.dmgBy.sunprism>0);assert.equal(marker.dmgBy.prism??0,0);assert.equal(marker.dmgBy.lantern??0,0);
  Object.assign(e,{hp,maxHp:hp,hordeBarrier:barrier});const mark=e.markMul,before=marker.support.allyDamage,beforeHp=e.hp,baseDamage=20*(1+r.synergy);
  r.hurtEnemy(e,20,h,{weapon:'test',tags:[]});const expected=Math.max(0,Math.min(hp,Math.max(0,baseDamage*(1+mark)-barrier))-Math.min(hp,Math.max(0,baseDamage-barrier)));
  close(marker.support.allyDamage-before,expected,'signature actual HP boost');rows.push({name:'native SunPrism mark through Horde barrier',barrier,hp,mark,synergy:r.synergy,baseDamage,actualExtraHp:marker.support.allyDamage-before,expected,hpDamage:beforeHp-e.hp,pass:true});
 }
 const random=Math.random;
 function observe(Clazz,horde,controlled){let state=123456789,draws=0;Math.random=()=>{draws++;state=(Math.imul(state,1664525)+1013904223)>>>0;return state/4294967296;};try{
  const r=new Clazz('R34-OBSERVER',()=>{});if(horde){r.addPlayer(1,'Director','witch');r.setRuleset('horde');}r.addPlayer(2,'Hero','witch');r.start();r.time=100;
  const h=r.heroes.get(2);h.weapons.clear();const e=r.spawnEnemy('spitter',[h],1,[0,0]);e.x=horde?HORDE_ARENA.maxX-e.r:CARAVAN.leash;e.y=0;h.x=e.x-40;h.y=0;e.shotT=100;
  if(!horde)e.caravan={x:0,y:0};if(controlled)Object.assign(e,{slow:.7,slowT:110,slowOwner:h});
  const pre=draws;for(let i=0;i<6;i++){r.moveEnemies(.1,[h]);r.time+=.1;}
  return {state:{x:e.x,y:e.y,hp:e.hp,fa:e.fa,bs:e.bs,bt:e.bt,shotT:e.shotT,windT:e.windT,fx:r.fx},draws:draws-pre,rng:state};
 }finally{Math.random=random;}}
 for(const horde of [false,true])for(const controlled of [false,true]){const actual=observe(Room,horde,controlled),baseline=observe(Main,horde,controlled);assert.deepEqual(actual,baseline);rows.push({name:'support observer equals accepted main state/RNG',horde,controlled,actual,pass:true});}
}catch(e){error={message:e.message,stack:e.stack};}
finally{fs.rmSync(data,{recursive:true,force:true});fs.writeFileSync(path.join(out,'support-seams.json'),JSON.stringify({sha:src.sha,main:manifest.base,runtime:process.version,executable:process.execPath,source:src.path,rows,error,data,dataRemoved:!fs.existsSync(data),pass:!error},null,2));}
if(error)throw Error(error.stack);console.log('PASS support signature/barrier actual HP and accepted-main observer state/RNG',rows.length);
