import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import net from 'node:net';
import {execFileSync} from 'node:child_process';
const out=path.dirname(new URL(import.meta.url).pathname),manifest=JSON.parse(fs.readFileSync(path.join(out,'frozen-sources.json'),'utf8')),ports=[],paths=[],worktrees=[];
const read=file=>JSON.parse(fs.readFileSync(path.join(out,file),'utf8'));
for(const group of ['12','17','41']){
 for(const row of read(`${group}-targeted-results.json`)){assert.equal(row.status,0);assert.equal(fs.existsSync(row.runDir),false);paths.push({path:row.runDir,absent:true});}
 const seam=read(`${group}-ws-seams.json`);assert.equal(seam.pass,true);assert.equal(fs.existsSync(seam.data),false);paths.push({path:seam.data,absent:true});for(const row of seam.cleanup)ports.push({kind:group+'-ws',port:row.port});
 const cwd=path.join(path.dirname(manifest.repo),`night-horde-issue-${group}`),head=execFileSync('git',['rev-parse','HEAD'],{cwd,encoding:'utf8'}).trim(),status=execFileSync('git',['status','--porcelain'],{cwd,encoding:'utf8'});assert.equal(head,manifest.sources[group].sha);assert.equal(status,'');worktrees.push({group,head,status});
}
for(const row of read('protocol-transport.json').rows){assert.equal(row.pass,true);assert.equal(row.childExited,true);assert.equal(fs.existsSync(row.data),false);paths.push({path:row.data,absent:true});ports.push({kind:row.group+'-protocol',port:row.port});}
const finite=read('dash-current-green.json');assert.equal(finite.pass,true);assert.equal(finite.dataDirRemoved,true);for(const row of finite.cleanup)ports.push({kind:'dash-finite30',port:row.port});
for(const p of ['data-dash-current-green','controls-data']){const owned=path.join(out,p);assert.equal(fs.existsSync(owned),false);paths.push({path:owned,absent:true});}
for(const row of ports){const server=net.createServer();await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(row.port,'127.0.0.1',resolve);});await new Promise(resolve=>server.close(resolve));row.independentRebind=true;}
const processes=execFileSync('ps',['-axo','pid=,command='],{encoding:'utf8'}).split('\n').filter(line=>/\/node\s+.*\/independent-review\/source-.*\/server\/server\.js/.test(line));assert.deepEqual(processes,[]);
const result={runtime:process.version,executable:process.execPath,ports,ownedPaths:paths,worktrees,persistentSourceServerProcesses:processes,pass:true};fs.writeFileSync(path.join(out,'cleanup-final.json'),JSON.stringify(result,null,2));console.log('PASS cleanup',ports.length,'ports independently rebound,',paths.length,'owned paths absent, frozen worktrees clean');
