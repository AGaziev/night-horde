import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {once} from 'node:events';
import {createRequire} from 'node:module';
import {setTimeout as delay} from 'node:timers/promises';
const here=path.dirname(new URL(import.meta.url).pathname),repo='/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/review-remarks-20261115/independent-review/source-17';
const root=process.env.QA_SOURCE||repo, label=process.env.QA_LABEL||'prepared-red', expect=process.env.QA_EXPECT||'red';
const dataDir=path.join(here,'data-'+label);fs.mkdirSync(dataDir,{recursive:true});process.env.HORDE_RUNS_DIR=dataDir;
const mod=p=>import(pathToFileURL(path.join(root,'app',p)));
const [{Room},{Input},{Net},{SnapshotDecoder},{clipDash},{hasActualDash}]=await Promise.all([mod('server/game.js'),mod('public/js/input.js'),mod('public/js/net.js'),mod('public/js/snapshot-codec.js'),mod('public/shared/mobility.js'),mod('server/mobility.js')]);
const gs=fs.readFileSync(path.join(root,'app/public/js/game.js'),'utf8').replaceAll("'/shared/", "'"+pathToFileURL(root+'/app/public/shared/').href);
const {Game}=await import('data:text/javascript;base64,'+Buffer.from(gs).toString('base64'));
const {WebSocketServer}=createRequire(repo+'/app/package.json')('ws');
const dt=1/30,angle=Math.PI/6,dx=Math.cos(angle),dy=Math.sin(angle), rows=[],cleanup=[];
function stick(x=dx,y=dy){const i=Object.create(Input.prototype);i.held={};i.joy={active:true,dx:x,dy:y};i.out={x:0,y:0};return i;}
async function until(f){for(let i=0;i<500;i++){if(f())return;await delay(1);}throw Error('local WS delivery timed out');}
async function scene(hp,press){
 const wire=[],back=[],calls=[];let peer,g;
 const wss=new WebSocketServer({host:'127.0.0.1',port:0});await once(wss,'listening');const port=wss.address().port;
 const r=new Room('FINITE30',(pid,msg)=>{if(pid===1&&peer?.readyState===1){back.push(structuredClone(msg));peer.send(JSON.stringify(msg));}});
 for(let pid=1;pid<=2;pid++)r.addPlayer(pid,'P'+pid,'witch');r.start();r.spawn=()=>{};r.breakAround=()=>{};r.events.next=Infinity;r.peaks=[];r.bossIdx=r.bossAt.length;r.nextEliteT=r.nextInvasionT=Infinity;
 for(const h of r.heroes.values()){h.weapons.clear();h.perk.readyAt=Infinity;}
 wss.on('connection',ws=>{peer=ws;ws.on('message',raw=>{const m=JSON.parse(String(raw));wire.push(m);r.handle(1,m);if(m.t==='qa-barrier')ws.send(JSON.stringify({t:'qa-barrier',n:m.n}));});});
 const ws=new WebSocket('ws://127.0.0.1:'+port);await once(ws,'open');
 const net=Object.create(Net.prototype);Object.assign(net,{outbox:[],connected:true,transport:'WS',ws,handlers:new Map(),snapDec:new SnapshotDecoder(),keyAskedAt:-Infinity});
 ws.addEventListener('message',e=>net.receive(e.data));let barrier=0;net.on('qa-barrier',m=>barrier=m.n);
 g=new Game(net);g.me=1;g.begin(r.startMsg());net.on('s',m=>g.onSnapshot(m));net.on('dash',m=>g.acceptDash(m));
 let seq=0;async function flush(){const n=++seq;net.send({t:'qa-barrier',n});await until(()=>barrier===n);}
 try{
  r.snapshot();await flush();const input=stick();
  for(let n=0;n<96;n++){g.update(dt,input);await flush();r.step(dt);r.snapshot();await flush();}
  const h=r.heroes.get(1),pos=wire.filter(m=>m.t==='pos').at(-1);
  assert.equal(pos.x,493.4);assert.equal(pos.y,256);assert.equal(pos.seq,49);assert.equal(h.posAck,49);assert.equal(g.ackSeq,49);
  r.time=815.3;r.startFinale([...r.heroes.values()]);Object.assign(r.fin,{cx:40,cy:-10,r:500,r1:465});r.finaleWall();
  Object.assign(h,{hp,maxHp:100,iframes:0,ward:0});
  const e=r.spawnEnemy('ghoul',[...r.heroes.values()],1);Object.assign(e,{x:h.x+dx*27,y:h.y+dy*27});
  const before={x:h.x,y:h.y,hp:h.hp,st:h.st,enemy:{x:e.x,y:e.y,r:e.r,dmg:e.dmg},fin:{...r.fin},time:r.time,hostilePos:{...h.hostilePos}};
  const numeric=clipDash(h.x,h.y,dx,dy,dt,{cx:40,cy:-10,r:486});
  const hurt=r.hurtPlayer;r.hurtPlayer=function(...a){calls.push({at:a[3],roomTime:this.time,dmg:a[1],from:a[2]});return hurt.apply(this,a);};
  r.snapshot();await flush();
  if(press){assert.equal(g.requestDash(input),true);await flush();assert.ok(h.dash);assert.equal(g.moveEpoch,h.moveEpoch);assert.equal(g.pendingDash,0);}
  r.step(dt);r.snapshot();await flush();
  const result={hp,press,input:{...input.vector()},pos,ack:{server:h.posAck,client:g.ackSeq},before,numeric:{...numeric,moveX:numeric.x-numeric.startX,moveY:numeric.y-numeric.startY},dashAck:back.filter(m=>m.t==='dash').at(-1),after:{x:h.x,y:h.y,hp:h.hp,st:h.st,iframes:h.iframes,path:h.dashPath,actualDash:hasActualDash(h),enemy:{x:e.x,y:e.y,distance:Math.hypot(e.x-h.x,e.y-h.y)},taken:r.runLog.p.get(1).taken},calls,wireCount:wire.length,port};
  assert.ok(result.after.enemy.distance>e.r+14,'enemy is outside contact at native endpoint');
  if(!press||expect==='green'){assert.equal(h.hp,hp);assert.equal(h.st,0);assert.equal(calls.length,0);}else{assert.ok(h.hp<hp);assert.equal(calls.length,1);assert.ok(calls[0].at<r.time);}
  if(press&&expect==='green'){assert.equal(result.after.actualDash,false);assert.equal(result.after.path.moveX,0);assert.equal(result.after.path.moveY,0);assert.equal(result.after.path.duration,0);}
  return result;
 }finally{
  ws.close();await once(ws,'close');for(const p of wss.clients)p.close();await new Promise(res=>wss.close(res));
  cleanup.push({port,socketClosed:ws.readyState===3,serverClosed:!wss.address()});
 }
}
let error;
try{for(const hp of[10,100])for(const press of[false,true])rows.push(await scene(hp,press));}catch(e){error={message:e.message,stack:e.stack?.replace(/data:text\/javascript;base64,[^\n]+/g,'[native Game module]')};}
fs.rmSync(dataDir,{recursive:true,force:true});
const hashes=Object.fromEntries(['server/game.js','server/mobility.js','public/shared/mobility.js','public/js/game.js','public/js/net.js','public/js/input.js'].map(p=>[p,crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'app',p))).digest('hex')]));
fs.writeFileSync(path.join(here,label+'.json'),JSON.stringify({node:process.version,root,label,expect,scope:'Fixed30deg Input.vector and Game.update -> native Net.send/receive -> real loopback WS -> Room.handle; controlled finale, no DOM/browser/live-frequency claim',rows,hashes,cleanup,dataDirRemoved:!fs.existsSync(dataDir),error,pass:!error},null,2));
if(error)throw Error(error.stack);console.log('PASS finite30',label,rows.map(r=>({hp:r.hp,dash:r.press,after:r.after.hp,st:r.after.st,move:r.after.path&&[r.after.path.moveX,r.after.path.moveY],duration:r.after.path?.duration,ack:r.ack})));
