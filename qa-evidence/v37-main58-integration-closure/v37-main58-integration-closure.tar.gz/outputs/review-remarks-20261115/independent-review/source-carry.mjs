import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import os from 'node:os';
import {execFileSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
const out=path.dirname(new URL(import.meta.url).pathname),manifest=JSON.parse(fs.readFileSync(path.join(out,'frozen-sources.json'),'utf8')),repo=manifest.repo;
const data=fs.mkdtempSync(path.join(os.tmpdir(),'nh-r34-source-carry-'));process.env.HORDE_RUNS_DIR=data;
const mainPath=path.join(out,'source-main'),rows=[],hashes=[];
const git=(sha,file)=>execFileSync('git',['show',`${sha}:${file}`],{cwd:repo,encoding:'utf8'});
const imp=(dir,file)=>import(pathToFileURL(path.join(dir,file)));
async function oldModule(src,file){const url=pathToFileURL(path.join(src.path,file));const code=git(src.oldAcceptedHead,file).replace(/(from\s+|import\s*)['"](\.[^'"]+)['"]/g,(_all,prefix,spec)=>`${prefix}'${new URL(spec,url).href}'`);return import(`data:text/javascript;base64,${Buffer.from(code).toString('base64')}#${src.sha}-${file}`);}
function sameMethod(now,old,names,label){for(const name of names){assert.equal(typeof now.prototype[name],'function',name);assert.equal(now.prototype[name].toString(),old.prototype[name].toString(),`${label}:${name}`);}}
let error;
try{
 const {Room:Main}=await imp(mainPath,'app/server/game.js'),baseContent=await imp(mainPath,'app/public/shared/content.js');
 for(const [group,src] of Object.entries(manifest.sources)){
  const {Room:Now}=await imp(src.path,'app/server/game.js'),{Room:Old}=await oldModule(src,'app/server/game.js');
  const exactMain=['app/server/confluences.js','app/public/shared/confluences.js','app/server/caravans.js','app/server/horde-mode.js','app/public/shared/horde-content.js'];
  for(const file of exactMain)assert.equal(fs.readFileSync(path.join(src.path,file),'utf8'),git(manifest.base,file),group+file);
  const content=await imp(src.path,'app/public/shared/content.js');for(const name of ['DUOS','MODES','EVOS','WEAPONS','PASSIVES','FINALE'])assert.deepEqual(content[name],baseContent[name],`${group}:${name}`);
  const mainMethods=['fuseDuo','updateWeapon','weaponSource','currentDuoCard'];sameMethod(Now,Main,mainMethods,group+'main');
  const featureFiles={12:['app/public/shared/daily.js','app/server/daily-swarm.js'],17:['app/public/shared/mobility.js','app/server/mobility.js','app/public/js/input.js','app/public/js/net.js'],41:['app/server/support.js','app/server/control-observation.js','app/server/hero-perks.js']}[group];
  for(const file of featureFiles)assert.equal(fs.readFileSync(path.join(src.path,file),'utf8'),git(src.oldAcceptedHead,file),`${group}:${file}`);
  const featureMethods={12:['lockDaily','setPaused'],17:['handle','tick','step','onPos','moveEnemies','updateHostile','updatePlayers','hurtPlayer'],41:['healSupport','hurtEnemy','hurtPlayer','reactionSource','root','slowEnemy','moveEnemies','updatePlayers']}[group];
  sameMethod(Now,Old,featureMethods,group+'feature');
  for(const file of ['app/server/game.js','app/public/js/game.js','app/public/js/snapshot-codec.js',...featureFiles]){
   const actual=fs.readFileSync(path.join(src.path,file)),expected=Buffer.from(git(src.sha,file));assert.deepEqual(actual,expected,`${group}:${file}:archive`);hashes.push({group,file,sha256:crypto.createHash('sha256').update(actual).digest('hex'),gitExact:true});
  }
  rows.push({group,sha:src.sha,acceptedFeature:src.oldAcceptedHead,main:manifest.base,exactMainFiles:exactMain,mainMethods,acceptedFeatureFiles:featureFiles,featureMethods,mainDefinitions:['DUOS','MODES','EVOS','WEAPONS','PASSIVES','FINALE'],pass:true});
 }
}catch(e){error={message:e.message,stack:e.stack?.replace(/data:text\/javascript;base64,[^\n]+/g,'[committed module]')};}
finally{fs.rmSync(data,{recursive:true,force:true});fs.writeFileSync(path.join(out,'source-carry.json'),JSON.stringify({runtime:process.version,executable:process.execPath,rows,hashes,error,dataRemoved:!fs.existsSync(data),pass:!error},null,2));}
if(error)throw Error(error.stack);console.log('PASS exact main definitions/fusion core and accepted feature carry',rows.length);
