import json,os,subprocess,time,pathlib,tempfile,shutil
root=pathlib.Path(__file__).resolve().parents[3]/"work/night-horde-issue-12"
node="/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node"
out=pathlib.Path(__file__).resolve().parent
suites=["daily-test.js","daily-review-test.js","daily-horde-test.js","daily-legacy-http-test.js","daily-client-test.js","daily-swarm-test.js","daily-glass-test.js","daily-armor-test.js","fusion-signature-test.js","fusion-key-recovery-test.js","fusion-effect-source-test.js","fusion-shield-state-test.js","fusion-focus-test.js","solo-night-pressure-test.js","codec-test.js","offer-identity-test.js","sniper-lowfps-warning-test.js","horde-transport-test.js","horde-compatibility-test.js","caravans-test.js","v20-test.js","v22-test.js","finale-test.js"]
data={"node":subprocess.check_output([node,"--version"],text=True).strip(),"source_head":subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip(),"merge_head":subprocess.check_output(["git","rev-parse","MERGE_HEAD"],cwd=root,text=True).strip(),"platform":os.uname().sysname+" "+os.uname().release,"results":[]}
sandbox=tempfile.mkdtemp(prefix="daily-r34-")
try:
 for suite in suites:
  cmd=[node,"--import",str(root/"pm/test-runtime.mjs"),"server/"+suite]
  start=time.time();r=subprocess.run(cmd,cwd=root/"app",env={**os.environ,"VIBE_APP_KEY":"","HORDE_RUNS_DIR":sandbox},text=True,capture_output=True,timeout=120)
  (out/(suite+".log")).write_text("$ "+" ".join(cmd)+"\n"+r.stdout+r.stderr+"\nexit="+str(r.returncode)+"\n")
  row={"suite":suite,"exit":r.returncode,"elapsed":round(time.time()-start,3)};data["results"].append(row);print(row,flush=True)
  if r.returncode:print((r.stdout+r.stderr)[-3000:],flush=True)
finally:
 shutil.rmtree(sandbox);data["cleanup"]={"own_runs_dir":sandbox,"exists":os.path.exists(sandbox)};(out/"targeted-results.json").write_text(json.dumps(data,indent=2)+"\n")
raise SystemExit(any(row["exit"] for row in data["results"]))
