import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {spawn, execFileSync} from 'node:child_process';
import {once} from 'node:events';
import {setTimeout as wait} from 'node:timers/promises';
import assert from 'node:assert/strict';
const {chromium} = await import('/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs');
const root = '/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe';
const out = path.dirname(new URL(import.meta.url).pathname), rows = [], cleanups = [];
const issues = (process.env.QA_ISSUES || '12,17,41').split(',').map(Number);
let browser, error;
try {
 browser = await chromium.launch({headless: true, args: ['--mute-audio']});
 for (const issue of issues) {
  const repo = path.join(root, 'work/night-horde-issue-' + issue);
  const head = execFileSync('git', ['rev-parse', 'HEAD'], {cwd: repo, encoding: 'utf8'}).trim();
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'r34-browser-'));
  const preload = path.join(dir, 'ephemeral.mjs');
  fs.writeFileSync(preload, `import {Server} from 'node:net'; const listen=Server.prototype.listen; Server.prototype.listen=function(...args){if(typeof args[0]==='number'){args[0]=0;this.once('listening',()=>console.log('QA_PORT:'+this.address().port));}return listen.apply(this,args);};`);
  const child = spawn(process.execPath, ['--import', path.join(repo, 'pm/test-runtime.mjs'), '--import', preload, 'app/server/server.js'],
   {cwd: repo, env: {...process.env, PORT: '3000', HORDE_RUNS_DIR: dir, VIBE_APP_KEY: ''}, stdio: ['ignore', 'pipe', 'pipe']});
  const exited = once(child, 'exit'); let serverLog = '', context, port;
  child.stdout.on('data', b => {serverLog += b; port = Number(serverLog.match(/QA_PORT:(\d+)/)?.[1]);});
  child.stderr.on('data', b => serverLog += b);
  try {
   for (let n = 0; n < 80 && !port; n++) await wait(50);
   assert.ok(port, serverLog); const url = 'http://127.0.0.1:' + port;
   assert.equal((await fetch(url + '/health')).status, 200);
   context = await browser.newContext({viewport: issue === 17 ? {width: 390, height: 844} : {width: 1000, height: 800}, hasTouch: issue === 17, isMobile: issue === 17});
   const page = await context.newPage(), errors = [], socketVersions = [], welcomes = [];
   let servedOld = 0;
   page.on('pageerror', e => errors.push(e.message));
   page.on('websocket', ws => {
    socketVersions.push(new URL(ws.url()).searchParams.get('v'));
    ws.on('framereceived', event => {try {const msg = JSON.parse(String(event.payload)); if (msg.t === 'welcome') welcomes.push(msg.v);} catch {}});
   });
   await page.route('**/js/main.js*', async route => {
    const response = await route.fetch();
    await route.fulfill({response, body: (await response.text()) + '\nwindow.__r34={game,net,input,ui};'});
   });
   await page.route('**/js/snapshot-codec.js*', async route => {
    const response = await route.fetch(); let body = await response.text();
    assert.ok(body.includes('export const PROTO = 33;'));
    if (!servedOld) {body = body.replace('export const PROTO = 33;', 'export const PROTO = 32;'); servedOld++;}
    await route.fulfill({response, body});
   });
   await page.goto(url);
   for (let n = 0; n < 100 && !socketVersions.includes('33'); n++) await wait(50);
   assert.ok(socketVersions.includes('33'), 'wait for the actual reload navigation before reading its document');
   await page.waitForFunction(() => window.__r34?.net.connected);
   const proto = await page.evaluate(async () => (await import('/js/snapshot-codec.js')).PROTO);
   assert.equal(proto, 33); assert.deepEqual(socketVersions.slice(0, 2), ['32', '33']);
   assert.equal(welcomes[0], 33); assert.equal(servedOld, 1);
   await page.locator('#menu-create').click();
   await page.waitForSelector('#screen-lobby:not([hidden])');
   await page.locator('#lobby-start').click();
   await page.waitForFunction(() => window.__r34.game.running && window.__r34.game.latest());
   let dash = null;
   if (issue === 17) {
    const before = await page.evaluate(() => window.__r34.game.local.x);
    await page.locator('#hud-dash').tap();
    await page.waitForFunction(() => window.__r34.game.moveEpoch === 1 && window.__r34.game.dashTravel === null);
    await wait(150);
    dash = await page.evaluate(() => ({x: window.__r34.game.local.x, server: window.__r34.game.myRow()[1], epoch: window.__r34.game.moveEpoch}));
    assert.ok(Math.abs(dash.x - before - 180) < 2); assert.ok(Math.abs(dash.server - before - 180) < 2);
   }
   assert.deepEqual(errors, []);
   await page.screenshot({path: path.join(out, `protocol-${issue}-33.png`)});
   rows.push({issue, head, proto, servedOld, socketVersions, welcomes, errors, nativeRoomStarted: true, dash});
  } finally {
   await context?.close(); child.kill(); await exited;
   fs.writeFileSync(path.join(out, `protocol-${issue}-server.log`), serverLog);
   fs.rmSync(dir, {recursive: true, force: true});
   let absent = false; try {process.kill(child.pid, 0);} catch (e) {absent = e.code === 'ESRCH';}
   let listeners = ''; try {listeners = execFileSync('/usr/sbin/lsof', ['-nP', '-iTCP:' + port, '-sTCP:LISTEN'], {encoding: 'utf8'});} catch (e) {listeners = e.stdout || '';}
   cleanups.push({issue, pid: child.pid, port, processAbsent: absent, listenerAbsent: !listeners.trim(), temporaryDataRemoved: !fs.existsSync(dir)});
  }
 }
} catch (e) {error = {message: e.message, stack: e.stack};}
finally {
 await browser?.close();
 fs.writeFileSync(path.join(out, 'protocol-browser-results.json'), JSON.stringify({runtime: process.version, browser: browser?.version(), rows, cleanups, error,
  scope: 'Actual local production UI/server and real WS; first browser codec response announces old32 to trigger native reload, then exact33 source. Main response exposes existing objects only for observation. No build fixture, outcome matrix or physical-device claim.'}, null, 2));
}
if (error) throw Error(error.stack);
assert.equal(rows.length, issues.length); assert.ok(cleanups.every(c => c.processAbsent && c.listenerAbsent && c.temporaryDataRemoved));
console.log('PASS old32->33 reload, native UI start x3 and touch dash; all resources released');
