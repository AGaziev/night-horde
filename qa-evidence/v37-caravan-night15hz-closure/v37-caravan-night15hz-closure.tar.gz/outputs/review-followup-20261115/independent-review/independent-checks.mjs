import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';
const root='/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe';
const output=path.join(root,'outputs/review-followup-20261115/independent-review');
const main='e19e0041505acc30bd7e6d950eedcf2feabdb395';
const runDir=fs.mkdtempSync(path.join(os.tmpdir(),'nh-independent-own-'));
process.env.HORDE_RUNS_DIR=runDir;
const results=[];
const wd=n=>path.join(root,`work/night-horde-issue-${n}`);
const current=(n,file)=>import(pathToFileURL(path.join(wd(n),file)).href);
const gitText=(n,sha,file)=>execFileSync('git',['show',`${sha}:${file}`],{cwd:wd(n),encoding:'utf8'});
async function fromGit(n,sha,file){
 const fileurl=pathToFileURL(path.join(wd(n),file));
 const source=gitText(n,sha,file).replace(/(from\s+|import\s*)['"](\.[^'"]+)['"]/g,(_all,prefix,spec)=>`${prefix}'${new URL(spec,fileurl).href}'`);
 return import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}#${n}-${sha}-${file}`);
}
async function check(name,fn){const before=Date.now();await fn();results.push({name,status:'PASS',ms:Date.now()-before});console.log(`PASS ${name}`);}
const close=(a,b,msg)=>assert.ok(Math.abs(a-b)<1e-8,`${msg}: ${a} vs ${b}`);
try {
 await check('main module carry: exact bytes across all three heads',async()=>{
  const files=['app/server/caravans.js','app/server/horde-mode.js','app/server/horde-combat.js','app/public/shared/horde-content.js','app/public/js/net.js','app/public/js/horde-ui.js','app/server/lobby-invites.js'];
  for(const n of [12,31,41])for(const file of files)assert.equal(fs.readFileSync(path.join(wd(n),file),'utf8'),gitText(n,main,file),`${n}:${file}`);
  results.push({mainModuleCarry:{heads:[12,31,41],files}});
 });
 await check('selected native main Room methods retained at each head',async()=>{
  const byGroup={12:['onPos','moveEnemies','updateHostile','rescaleGroup','bossTick','bossStep','confineGuard'],31:['tick','onPos','moveEnemies','updateHostile','rescaleGroup','bossTick','bossStep','updatePlayers','spawnEnemy'],41:['onPos','rescaleGroup','spawnEnemy','confineGuard']};
  for(const n of [12,31,41]){const {Room:Base}=await fromGit(n,main,'app/server/game.js');const {Room:Now}=await current(n,'app/server/game.js');for(const m of byGroup[n])assert.equal(Now.prototype[m]?.toString(),Base.prototype[m]?.toString(),`${n}:${m}`);}
  results.push({mainMethodCarry:byGroup});
 });
 await check('accepted feature content and core methods retained',async()=>{
  const olds={12:'2b59642ea1ab6552c4fe337cf044d8f280fa766b',31:'1c93a575bb811a6992134e636b2423aa893e054d',41:'67f707db349255356f539cc384d42734853a6495'};
  for(const file of ['app/public/shared/daily.js','app/server/daily-swarm.js'])assert.equal(fs.readFileSync(path.join(wd(12),file),'utf8'),gitText(12,olds[12],file));
  assert.equal(fs.readFileSync(path.join(wd(41),'app/server/support.js'),'utf8'),gitText(41,olds[41],'app/server/support.js'));
  const {Room:Old}=await fromGit(31,olds[31],'app/server/game.js');const {Room:Now}=await current(31,'app/server/game.js');
  for(const name of ['fuseDuo','updateWeapon','weaponSource','currentDuoCard'])assert.equal(Now.prototype[name].toString(),Old.prototype[name].toString(),name);
  const a=await fromGit(31,olds[31],'app/public/shared/content.js'),b=await current(31,'app/public/shared/content.js');
  for(const name of ['DUOS','MODES','EVOS','PASSIVES','WEAPONS','FINALE'])assert.deepEqual(b[name],a[name],name);
  results.push({acceptedFeatureSource:olds,fusionDefinitions:Object.keys(b.DUOS).length});
 });
 await check('Daily gather caravan: native guard HP, actual reward once, no resurrection',async()=>{
  const {Room}=await current(12,'app/server/game.js'),{dailyFor}=await current(12,'app/public/shared/daily.js');
  const {updateCaravan,claimCaravan}=await current(12,'app/server/caravans.js');
  const {enemyHpScale,xpForNext}=await current(12,'app/public/shared/content.js');
  const r=new Room('OWN-D-GATHER',()=>{});r.setMode('lunch');r.addPlayer(1,'One','witch');r.addPlayer(2,'Two','witch');r.handle(1,{t:'daily',enabled:true});
  let day=Date.UTC(2026,10,15);while(dailyFor(day).id!=='gather')day+=86400000;r.lockDaily(day);assert.equal(r.start(),true);
  const hs=[...r.heroes.values()];r.time=r.runLength*.4;updateCaravan(r,hs,1/30);const c=r.caravan;assert.ok(c);assert.equal(c.total,14);
  for(const e of r.enemies){close(e.maxHp,e.def.hp*enemyHpScale(r.nt,2)*r.modeHp*1.35*1.15,'daily caravan HP');r.killEnemy(e,hs[0]);}
  assert.equal(c.status,'open');const h=hs[0],down=hs[1];h.hp=h.maxHp*.5;h.xp=0;down.st=1;down.hp=0;const xp=xpForNext(h.level,2);
  assert.equal(claimCaravan(r),true);assert.equal(claimCaravan(r),false);close(h.hp,h.maxHp*.6,'living healing');close(h.xp,xp*.15,'caravan XP');assert.equal(down.hp,0);
  h.posAck=17;h.moveEpoch=2;const s=r.snapshot();assert.equal(s.cv,null);assert.equal(s.swarm,null);assert.deepEqual(s.pa,[[1,17,2]]);
 });
 await check('Daily Swarm caravan guards excluded from the cohort through native spawn/death',async()=>{
  const {Room}=await current(12,'app/server/game.js'),{dailyFor}=await current(12,'app/public/shared/daily.js');
  const {updateCaravan}=await current(12,'app/server/caravans.js'),{tagSwarmEnemy}=await current(12,'app/server/daily-swarm.js');
  const r=new Room('OWN-D-SWARM',()=>{});r.setMode('lunch');r.addPlayer(1,'One','witch');r.handle(1,{t:'daily',enabled:true});let day=Date.UTC(2026,10,15);while(dailyFor(day).id!=='swarm')day+=86400000;r.lockDaily(day);r.start();
  r.time=r.runLength*.4;const hs=[...r.heroes.values()];updateCaravan(r,hs,1/30);assert.ok(r.caravan);
  // Place a known active finite cohort at this same instant to exercise exclusion.
  const cohort=r.swarm.cohorts[0];cohort.at=r.time-1;cohort.end=r.time+1;const spawned=cohort.spawned,killed=cohort.killed;
  for(const e of r.enemies){tagSwarmEnemy(r,e);r.killEnemy(e,hs[0]);}
  assert.equal(cohort.spawned,spawned);assert.equal(cohort.killed,killed);
 });
 await check('fusion caravan: native offer pick, consumed-source retirement and kill/reward dispatch',async()=>{
  const {Room}=await current(31,'app/server/game.js'),{updateCaravan,claimCaravan}=await current(31,'app/server/caravans.js');
  const {SnapshotDecoder}=await current(31,'app/public/js/snapshot-codec.js');
  const wire=[];const r=new Room('OWN-F-CARAVAN',(_pid,msg,json)=>{if(msg.t==='s'&&json)wire.push(JSON.parse(json));});r.setMode('lunch');r.addPlayer(1,'One','witch');r.start();const h=r.heroes.get(1);
  h.weapons=new Map([['bolt',{lvl:3,t:0}],['lightning',{lvl:3,t:0}],['knives',{lvl:3,t:0}]]);r.time=240;updateCaravan(r,[h],1/30);
  r.addProjectile(h,'bolt',0,100,10,1,2,null);r.addProjectile(h,'knife',0,100,10,1,2,null);const retired=r.projectiles.find(p=>p.src.weapon==='bolt').id;
  h.offer=[r.duoCard(h,{id:'orb',a:'bolt',b:'lightning'})];r.sendOffer(h);r.handle(1,{t:'pick',i:0,offerEpoch:h.offerEpoch});
  assert.deepEqual([...h.weapons.keys()],['orb','knives']);assert.ok(r.projectiles.every(p=>p.src.weapon==='knives'));assert.ok(r.consumedAttacks.has(`0:${retired}`));
  // Actual damage entry point keeps caravan bookkeeping and signature attribution.
  h.mods.critChance=0;for(const e of [...r.enemies])r.hurtEnemy(e,1e9,h,{weapon:'orb',tags:[]});assert.equal(r.caravan.status,'open');assert.ok(h.dmgBy.orb>0);assert.equal(h.dmgBy.bolt,undefined);assert.equal(h.dmgBy.lightning,undefined);
  h.posAck=33;h.moveEpoch=3;r.snapshot();const dec=new SnapshotDecoder(),s=dec.decode(wire.at(-1));assert.equal(s.cv.status,'open');assert.deepEqual(s.pa,[[1,33,3]]);assert.ok(s.consumedAttacks.some(([k,id])=>k===0&&id===retired));
  assert.equal(claimCaravan(r),true);assert.equal(claimCaravan(r),false);
 });
 await check('support mark through actual Horde barrier: local/inherited bonus and HP cap',async()=>{
  const {Room}=await current(41,'app/server/game.js');const r=new Room('OWN-S-BARRIER',()=>{});r.addPlayer(1,'Director','witch');r.setRuleset('horde');r.addPlayer(2,'Attacker','witch');r.addPlayer(3,'Marker','witch');r.start();r.time=100;
  const [h,owner]=r.heroes.values();h.weapons.clear();owner.weapons.clear();h.mods.critChance=0;r.synergy=0;
  for(const [barrier,hp,expected] of [[10,100,10],[25,100,5],[30,100,0],[10,5,0]]){
   const e=r.spawnEnemy('skel',[h,owner],1,[0,0]);Object.assign(e,{hp,maxHp:hp,hordeSource:'manual',hordePack:'bones',hordeBuild:{packs:{},weapons:{},artifacts:{}},hordeBarrier:barrier,markT:r.time+2,markMul:.5,markOwner:owner});
   const before=owner.support.allyDamage;const ownBefore=owner.supportDamage;r.hurtEnemy(e,20,h,{weapon:'test',tags:[]});close(owner.support.allyDamage-before,expected,'local actual boost');close(owner.supportDamage-ownBefore,expected,'total actual boost');
  }
  const e=r.spawnEnemy('skel',[h,owner],1,[0,0]);Object.assign(e,{hp:100,maxHp:100,hordeSource:'manual',hordePack:'bones',hordeBuild:{packs:{},weapons:{},artifacts:{}},hordeBarrier:10});
  const before=owner.support.allyDamage;r.hurtEnemy(e,30,h,{weapon:'test',tags:[],markSupport:{owner,fraction:1/3}});close(owner.support.allyDamage-before,10,'inherited actual boost');
 });
 await check('support control observer preserves native movement state and RNG at caravan/Horde constraints',async()=>{
  const {Room:Base}=await fromGit(41,main,'app/server/game.js'),{Room:Now}=await current(41,'app/server/game.js');
  const {HORDE_ARENA}=await current(41,'app/public/shared/horde-content.js'),{CARAVAN}=await current(41,'app/server/caravans.js');
  const native=Math.random;
  function run(Room,horde,controlled){let state=123456789,draws=0;Math.random=()=>{draws++;state=(Math.imul(state,1664525)+1013904223)>>>0;return state/4294967296;};try{
   const r=new Room('OWN-S-OBSERVE',()=>{});if(horde){r.addPlayer(1,'Director','witch');r.setRuleset('horde');}r.addPlayer(2,'Hero','witch');r.start();r.time=100;
   const h=r.heroes.get(2);h.weapons.clear();const e=r.spawnEnemy('spitter',[h],1,[0,0]);e.x=horde?HORDE_ARENA.maxX-e.r:CARAVAN.leash;e.y=0;h.x=e.x-40;h.y=0;e.shotT=100;
   if(!horde)e.caravan={x:0,y:0};if(controlled)Object.assign(e,{slow:.7,slowT:110,slowOwner:h});
   const pre=draws;for(let i=0;i<6;i++){r.moveEnemies(.1,[h]);r.time+=.1;}
   return {state:{x:e.x,y:e.y,hp:e.hp,fa:e.fa,bs:e.bs,bt:e.bt,shotT:e.shotT,windT:e.windT,fx:r.fx},draws:draws-pre,rng:state};
  }finally{Math.random=native;}}
  for(const horde of [false,true])for(const controlled of [false,true])assert.deepEqual(run(Now,horde,controlled),run(Base,horde,controlled),`${horde}/${controlled}`);
 });
 fs.writeFileSync(path.join(output,'independent-results.json'),JSON.stringify({runtime:process.version,executable:process.execPath,main,results},null,2));
} finally {fs.rmSync(runDir,{recursive:true,force:true});fs.writeFileSync(path.join(output,'independent-cleanup.json'),JSON.stringify({runDir,absent:!fs.existsSync(runDir)},null,2));}
