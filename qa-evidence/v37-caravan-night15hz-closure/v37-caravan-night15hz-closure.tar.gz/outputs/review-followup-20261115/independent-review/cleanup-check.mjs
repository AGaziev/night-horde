import fs from 'node:fs';
import net from 'node:net';
import {execFileSync} from 'node:child_process';
const root='/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe';
const out=root+'/outputs/review-followup-20261115/independent-review';
const rows=[];
for(const label of ['dash-current-green','dash-old-red']){
 const data=JSON.parse(fs.readFileSync(out+'/'+label+'.json','utf8'));for(const prior of data.cleanup){
  const server=net.createServer();await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(prior.port,'127.0.0.1',resolve);});await new Promise(resolve=>server.close(resolve));
  rows.push({label,...prior,independentRebind:true});
 }
}
const heads={};for(const n of [12,17,31,41])heads[n]={head:execFileSync('git',['rev-parse','HEAD'],{cwd:root+'/work/night-horde-issue-'+n,encoding:'utf8'}).trim(),status:execFileSync('git',['status','--porcelain'],{cwd:root+'/work/night-horde-issue-'+n,encoding:'utf8'}).trim()};
fs.writeFileSync(out+'/cleanup-final.json',JSON.stringify({node:process.version,ports:rows,heads,ownDataAbsent:['data-dash-current-green','data-dash-old-red','controls-data'].every(p=>!fs.existsSync(out+'/'+p))},null,2));console.log('PASS eight released WS ports rebound and closed; own data absent; recorded git heads/status');
