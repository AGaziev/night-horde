import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const root='/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe';
const repo=root+'/work/night-horde-issue-17',out=root+'/outputs/review-followup-20261115/independent-review';
const data=fs.mkdtempSync(path.join(os.tmpdir(),'nh-independent-dash-'));process.env.HORDE_RUNS_DIR=data;
const imp=p=>import(pathToFileURL(repo+'/app/'+p));
const {Room}=await imp('server/game.js'),{SnapshotDecoder}=await imp('public/js/snapshot-codec.js'),{updateCaravan}=await imp('server/caravans.js');
const results=[];
try{
 for(const horde of [false,true]){
  const wire=[];const r=new Room('OWN-DASH-META',(pid,msg,json)=>{if(pid===2&&msg.t==='s'&&json)wire.push(JSON.parse(json));});
  if(horde){r.addPlayer(1,'Director','witch');r.setRuleset('horde');}r.addPlayer(2,'Hero','witch');r.start();r.time=360;const h=r.heroes.get(2);h.weapons.clear();
  if(!horde)updateCaravan(r,[h],1/30);
  r.handle(2,{t:'dash',run:r.runLog.id,request:1,expiresAt:Date.now()+1500,x:1,y:0});assert.ok(h.dash);r.tick(1/30);h.posAck=9;
  const expected=r.snapshot(),dec=new SnapshotDecoder();let got=dec.decode(wire.at(-1));assert.deepEqual(got.mob,expected.mob);assert.deepEqual(got.cv,expected.cv);assert.deepEqual(got.pa,expected.pa);
  assert.equal(got.mob[0][1],1);assert.ok(got.mob[0][3]>0);assert.equal(Boolean(got.cv),!horde);
  r.tick(1/30);r.snapshot();assert.notEqual(wire.at(-1).K,1);got=dec.decode(wire.at(-1));assert.equal(got.mob[0][1],1);
  r.resync(2);r.snapshot();assert.equal(wire.at(-1).K,1);got=new SnapshotDecoder().decode(wire.at(-1));assert.equal(got.mob[0][1],1);assert.deepEqual(got.cv,r.snapshot().cv);assert.deepEqual(got.pa,[[2,9,1]]);
  results.push({horde,pass:true});
 }
 fs.writeFileSync(out+'/dash-seams.json',JSON.stringify({node:process.version,results},null,2));console.log('PASS native PvE/Horde mob + cv + pa key/delta/resync');
}finally{fs.rmSync(data,{recursive:true,force:true});fs.writeFileSync(out+'/dash-seams-cleanup.json',JSON.stringify({data,absent:!fs.existsSync(data)},null,2));}
