# Independent finite integration review, 2026-11-15

**STATUS: PASS — assigned integration scope only. No confirmed important regression.** This is independent of the implementing authors. This report does not declare whole-PR READY, verify remote CI, or replace the owners' existing product acceptance. No product code, commits, pushes, GitHub/CTQ state or network configuration were changed. Only evidence and harnesses in this output folder were written.

## Frozen sources

Shared integrated main: `e19e0041505acc30bd7e6d950eedcf2feabdb395`. GAME v37 / PROTO32. Main is an ancestor of every final head. Every final worktree is clean and `git diff --check e19e004..HEAD` passed; exact readback is in `final-attribution.json`.

| PR / Issue | Final head | Production source executed | Accepted feature parent |
|---|---|---|---|
| #54 / 12 Daily | `312dfaf2831da06c3d9861c5f355974a5e1526e6` | same | `2b59642ea1ab6552c4fe337cf044d8f280fa766b` |
| #55 / 17 Dash | `d9a0203f752d5cb1fbdbb9e14f5582174d3994c1` | `d3b451957f25d15104b755a35d7932cecbcf001f` | `ea9c168ee11ca762ed94b750ba8967ffbb1ec45d` |
| #58 / 31 Fusions | `54fc25b9f0af42b0a5d7d46e83ae7b9434973884` | same | `1c93a575bb811a6992134e636b2423aa893e054d` |
| #59 / 41 Support | `eda4dadc4716e05030bf595792a626f724abd8d2` | `0281938e787710d7508acf3e7e3329c0eb1f40b4` | `67f707db349255356f539cc384d42734853a6495` |

The two last test-only deltas were independently read. Dash changes exactly two browser-import rewrites in `offer-identity-test.js`, preserving assertions. Support isolates the killed-Bloater clock in a fresh native Room in `sim-test.js`, retaining warning/explosion and damage assertions. Their production diffs are empty, so the earlier runtime integration evidence carries to the final heads. The affected suites were independently rerun on those final heads and passed.

## Actual independent execution

Canonical macOS Node **v24.22.1**, executable `/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node`.

**37/37 targeted native suite executions PASS**, no skipped/failed execution. Exact command arrays, cwd, head, exit, timing and log paths are in `final-attribution.json` and the per-group `*-results.json`. Each suite used a separate owned temporary `HORDE_RUNS_DIR`; all were removed. Commands were:

```sh
NODE=/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node
OUT=/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/review-followup-20261115/independent-review
$NODE "$OUT/run-targeted.mjs" 12
$NODE "$OUT/run-targeted.mjs" 31
$NODE "$OUT/run-targeted.mjs" 41
$NODE "$OUT/run-targeted.mjs" 17
$NODE "$OUT/run-targeted.mjs" 41 sim
$NODE "$OUT/run-targeted.mjs" 17 offer-identity
$NODE "$OUT/independent-checks.mjs"
$NODE "$OUT/dash-seams.mjs"
QA_LABEL=dash-current-green QA_EXPECT=green $NODE "$OUT/dash-finite30.mjs"
QA_LABEL=dash-old-red QA_EXPECT=red QA_SOURCE=/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/issue-split/v36/17-r30-zero-tolerance-independent/source421 $NODE "$OUT/dash-finite30.mjs"
$NODE "$OUT/dash-controls.mjs"
$NODE "$OUT/cleanup-check.mjs"
```

`run-targeted.mjs` records the actual child command: `node --import <repo>/pm/test-runtime.mjs <repo>/app/server/<suite>-test.js`, cwd `<repo>/app`, with the same preload in NODE_OPTIONS for child servers. The preload only handles macOS loopback IP_TOS EINVAL in test processes.

Coverage by PR:

- **Daily, 11 suites:** Daily/Horde mutual exclusion and locked countdown, actual legacy WS/HTTP denial, client state, finite Swarm, caravan/server/client, actual Horde transport and compatibility, invitations HTTP, movement network and native archive/history. Own additional native scenes prove gather multiplies real caravan guard HP, native caravan deaths open the reward, reward grants once, living heroes heal and downed heroes stay down. A deliberately active Swarm cohort does not count caravan guards on spawn/death. Native snapshots retain caravan/Swarm/movement ACK together.
- **Fusions, 8 suites:** signature dispatch, effect attribution, consumed-shot key recovery, solo Night pressure including native 2→1 rescaling, caravan, Horde integration/client transport and actual offer identity. An independently prepared caravan scene accepts a native `offerEpoch` fusion pick, retires only component projectiles, preserves the independent knife, damages guards through the real signature source, opens/claims the caravan once and carries the retirement ledger plus caravan/movement ACK over the actual codec.
- **Support, 8 integration suites plus final changed sim suite:** gift/Horde damage/status ordering, actual contact clocks, independent control separation, body-phase union budget, client state, Horde transport/resync and caravan. Own native Horde barrier scenes cover local and inherited mark bonus, full absorption and HP clipping: allyDamage equals the actual additional HP damage. Four controlled movement comparisons (caravan/Horde, plain/slowed) match main actor state and RNG exactly. Final `sim-test.js` passed at eda4dad in 2.511s; the reported original gold-XP cause was read from the author's primary CI evidence and is not misrepresented as a newly discovered product defect.
- **Dash, 8 integration suites plus final changed offer suite:** numeric zero, Horde integration, stale position intervals, saved sniper origin, caravan, guard requeue, body birth and request lifetime. Native `mob + cv + pa` full/delta/resync checks pass for both PvE and Horde. Main control/snapshots and actual dash travel use the same inset arena bounds; director rejection, preparation windows, paid formation wait and real venom crossing have direct native checks.

## Source proof and finite old-defect closure

`independent-results.json` records **8 own checks PASS**. Seven main modules are byte-identical at each of Daily/Fusion/Support: caravans, Horde mode/combat/content, Net, Horde UI and invitations service. Selected Room methods are exactly equal to e19: see the explicit per-branch method lists in that JSON; this claim does not include intentionally changed support observers or feature dispatch. Daily rules/Swarm and Support token/control helpers are byte-identical to their accepted feature parents. All39 fusion definitions, MODES, EVOS, PASSIVES, WEAPONS and FINALE match the accepted fusion parent; native fuse/update/source/card methods match too. These are narrow equality claims, not a new39-recipe/full-run audit.

The existing independent finite30 harness was copied into this folder and adapted only to map all new browser shared imports. It was re-executed against old committed421 and current committed d3. Twelve runtime-source hashes (six files per source) match Git exactly: `dash-source-hashes.json`.

The same real loopback WS path Input.vector → Game.update → Net → Room.handle emits rounded `pos493.4,256,seq49`; server/client ACK both49. In the fixed translated-ring scene (time815.3, center40/-10, radius500/r1=465, ghoul27 away), old421 reproduces residual travel `(5.684341886080802e-14,2.842170943040401e-14)`, duration `4.737066566181659e-17`, early body hit and HP10→2.32 /100→92.32. Without dash, HP stays10/100. Current d3 passes all four branches with exact zero travel/duration, no body hit and unchanged10/100HP. This is the previously documented finite equivalent of the owner's cause: the original owner's radius was unavailable, so this report does not claim an identical original12.48-damage scene or live frequency.

Eight positive/adjacent controls pass: genuine24/40 travel retains swept-only body damage at100 before endpoint100.03333333333333, ordinary body contact stays at the endpoint, inward travel retains its actual early entry clock, partial2/full40/subpixel movement stays real, and the observed old residual is rejected directly by the consumer. No new angle/seed/geometry matrix was introduced.

## Carry, remaining boundaries and cleanup

This pass supports carrying the owners' **unchanged feature contracts** plus the specifically verified e19 integration paths above. It does not rename historical completed13c/other-source outcomes as measurements of e19 or these final heads. Caravans can change PvE RNG/rewards; the accepted main lastCrit correction also changes a known timeline. No new full balance conclusion, universal native equality, FPS/performance claim or completed outcome percentage is asserted. Existing outcome/data publication remains a separate root task with original manifests and labels.

Fresh desktop/mobile product-browser evidence is author/root evidence, not independently rerun here. Full Server CI was executed/read from GitHub by root, not launched by this reviewer. The final root artifact `../ci/final-proof.json` reports PASS on Linux Node24.22.2: #54 run43699136680 74/74, #55 run43699797116 85/85, #58 run43699212273 72/72, #59 run43699769448 79/79. This reviewer independently checked each artifact head and tree against the exact local final head/tree (`ci-source-readback.json`); all four match. Root owns the CI checkout/parent and remote result verification: those checkout objects are not available in these feature clones, so an attempted direct local lookup could not verify them. The artifact consistently reports `[e19, head]` parents. No whole-PR READY is issued here.

Cleanup PASS: all suite-owned state directories removed; custom native state removed; all eight WS/socket pairs closed and their ports independently rebound/closed (`cleanup-final.json`). Four final source trees clean; no owned persistent process was created. The archived source and evidence files are retained in output directories. No extra reviewer was spawned because no candidate finding required confirmation. The implementing authors' reports were read as evidence; this reviewer independently executed and checked the scoped behavior described here.
