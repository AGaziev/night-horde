import { spawnSync, execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const root='/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe';
const out=path.join(root,'outputs/review-followup-20261115/independent-review');
const groups={
 '17':['mobility-numeric-zero','mobility-horde-integration','horde-movement-gap','horde-sniper-origin','caravans','mobility-guard-requeue','mobility-body-birth','mobility-request'],
 '12':['daily-horde','daily-client','daily-legacy-http','daily-swarm','caravans','caravans-client','horde-compatibility','horde-transport','lobby-invites-http','movement-net','run-history'],
 '31':['fusion-key-recovery','fusion-signature','fusion-effect-source','solo-night-pressure','caravans','horde-review-game','horde-client-transport','offer-identity'],
 '41':['support-horde','support-contact-time','control-separation','control-contact-phase','support-client','horde-transport','horde-resync','caravans'],
};
const group=process.argv[2], wd=path.join(root,`work/night-horde-issue-${group}`);
if(!groups[group])throw Error('group');
const sha=execFileSync('git',['rev-parse','HEAD'],{cwd:wd,encoding:'utf8'}).trim();
const results=[];
const override=process.argv.slice(3),selected=override.length?override:groups[group];
for(const name of selected){
 const runDir=fs.mkdtempSync(path.join(os.tmpdir(),`nh-independent-${group}-`));
 const preload=path.join(wd,'pm/test-runtime.mjs');
 const args=['--import',preload,path.join(wd,'app/server',`${name}-test.js`)];
 const start=Date.now();
 const r=spawnSync(process.execPath,args,{cwd:path.join(wd,'app'),env:{...process.env,HORDE_RUNS_DIR:runDir,NODE_OPTIONS:`--import=${preload}`},encoding:'utf8',timeout:120000});
 const logfile=path.join(out,`${group}-${name}.log`);
 fs.writeFileSync(logfile,`SHA ${sha}\nNode ${process.version}\nExecutable ${process.execPath}\nCWD ${wd}/app\nCOMMAND ${JSON.stringify([process.execPath,...args])}\nHORDE_RUNS_DIR ${runDir}\n\n${r.stdout??''}${r.stderr??''}${r.error?`\n${r.error.stack}`:''}`);
 fs.rmSync(runDir,{recursive:true,force:true});
 const row={group,name,sha,runtime:process.version,executable:process.execPath,command:[process.execPath,...args],cwd:path.join(wd,'app'),status:r.status,signal:r.signal,ms:Date.now()-start,log:logfile,cleanup:!fs.existsSync(runDir)};
 results.push(row);fs.writeFileSync(path.join(out,`${group}${override.length?'-addendum':''}-results.json`),JSON.stringify(results,null,2));
 console.log(`${group} ${name}: ${r.status===0?'PASS':'FAIL'} ${row.ms}ms`);
}
if(results.some(r=>r.status!==0))process.exitCode=1;
