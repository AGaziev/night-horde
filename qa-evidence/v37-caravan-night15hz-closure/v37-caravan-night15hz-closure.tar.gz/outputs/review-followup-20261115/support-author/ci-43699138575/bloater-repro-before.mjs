import assert from 'node:assert/strict';
import {Room} from 'file:///Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/work/night-horde-issue-41/app/server/game.js';
import {TICK_HZ,ENEMIES,ST} from 'file:///Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/work/night-horde-issue-41/app/public/shared/content.js';
Math.random=()=>Number(process.argv[2]);
const dtt=1/TICK_HZ;
const mkRoom=()=>{const r=new Room('NEW',()=>{});r.addPlayer(1,'N1','knight');r.start();r.spawn=()=>{};const h=r.heroes.get(1);h.x=h.y=0;return r;};
const put=(r,type,x,y,hp=1000)=>{const e=r.spawnEnemy(type,[...r.heroes.values()],1);Object.assign(e,{x,y,hp,maxHp:hp,speed:0});return e;};
	// Bloater: contact lights a fuse, blast hurts players and enemies; killing it leaves a delayed blast.
	{
		const r = mkRoom();
		const h = r.heroes.get(1);
		h.weapons = new Map();
		const b = put(r, 'bloater', 20, 0, 10);
		const other = put(r, 'brute', 40, 30, 1000);
		r.tick(dtt);
		assert.ok(b.fuseT > 0 && (r.enemyState(b) & ST.windup), 'fuse lit on contact');
		const hp = h.hp;
		r.fx = [];
		for (let i = 0; i < TICK_HZ; i++) r.tick(dtt);
		assert.ok(b.dead, 'bloater blew up');
		assert.ok(hp - h.hp >= ENEMIES.bloater.blastDmg * b.dmgMul - 0.01, 'player hurt by the blast');
		assert.equal(other.hp, 1000 - ENEMIES.bloater.blastEnemyDmg, 'enemies hurt by the blast');
		const b2 = put(r, 'bloater', 300, 0, 10);
		r.fx = [];
		r.hurtEnemy(b2, 50, h);
		assert.ok(r.fx.some((f) => f[0] === 'warn') && r.blasts.length === 1, 'kill leaves a telegraphed blast');
		for (let i = 0; i < TICK_HZ; i++) r.tick(dtt);
		console.log(JSON.stringify({time:r.time,frozen:r.frozen,offer:!!h.offer,level:h.level,xp:h.xp,blasts:r.blasts.length,due:r.blasts.map(b=>b.t)}));
		assert.equal(r.blasts.length, 0);
		console.log('bloater: ok');
	}
