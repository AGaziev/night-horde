# CI failure follow-up for PR59

Frozen local head: `eda4dadc4716e05030bf595792a626f724abd8d2`; parent `0281938e787710d7508acf3e7e3329c0eb1f40b4`. One test-only commit; product files unchanged. Tree clean, no push or GitHub write.

Primary failure: [Server CI 43699138575](https://github.com/AGaziev/night-horde/actions/runs/43699138575) ran merge candidate `cb2cc296cd4adf71d9a235b8c19fc24cd4467923`, PR head `0281938e787710d7508acf3e7e3329c0eb1f40b4`, base `e19e0041505acc30bd7e6d950eedcf2feabdb395`, Node v24.22.2/Linux. Artifact originals are in this directory: `revisions.txt`, `results.json`, `sim-test.log`, and the other suite logs. **78/79 passed; sole failure sim-test.js:790**, expected blasts.length0, actual1.

Exact cause: the first contact Bloater can drop a golden XP gem (2% native chance). Picking up its10XP raises the solo hero to level2 and opens the real improvement offer. Room.step then correctly stops time during solo pause. The second killed-Bloater scene reused that paused room but expected one second of progress after30 attempted ticks.

Focused reproduction copies the original Bloater block and its fixtures, without changing application code. Forced gold RNG0.01 fails with `time=0.6, frozen=true, offer=true, level=2, xp=5, blasts=1, due=[1.1]`; forced non-gold0.99 passes with room time2.0333 and no pending blast. See `bloater-repro-before.mjs`, `bloater-before-0.01.log`, `bloater-before-0.99.log` and `bloater-repro-before-results.json`.

Fix: isolate the independent killed-Bloater scene in a fresh native Room with an unarmed hero. All previous warning, player/enemy damage and eventual explosion assertions remain. No game clock, pause behavior, loot or damage logic was changed. The scene at x300 cannot collect its killed enemy loot while testing the delayed blast.

Validation on Node v24.22.1/macOS:

- Focused original block after fix: forced gold0.01 and non-gold0.99 both PASS (`bloater-repro-after-results.json` and associated logs).
- Entire affected suite: `/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node --import ../pm/test-runtime.mjs server/sim-test.js`, cwd app: exit0, 2.716s (`local-sim-test-after.log` and metadata JSON). The executed suite blob `bd68cb386983fd79299ddab34c794542e968f2e3` equals the committed suite blob at frozen head.
- `git diff --check`: PASS. No additional matrices or unrelated suites rerun.

Cleanup: no Node/server process has this checkout as cwd; owned local state directory removed; git clean. Full new-head Server CI and independent acceptance remain with root. This report is author evidence only.
