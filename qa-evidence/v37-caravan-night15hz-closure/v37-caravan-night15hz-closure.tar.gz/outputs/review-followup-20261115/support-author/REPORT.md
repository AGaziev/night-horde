# Issue 41 / PR 59: author integration handoff

Author work complete; independent acceptance and full Server CI remain with root. No self-READY.

- Repository: `/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/work/night-horde-issue-41`
- Branch: `codex/41-support-control`
- Previous head: `67f707db349255356f539cc384d42734853a6495`
- Main integrated by ordinary merge: `e19e0041505acc30bd7e6d950eedcf2feabdb395`
- Merge commit: `c197ecbdc9ce01aa3ccab8a3ddfbb19a51cf8feb`
- Final head: `0281938e787710d7508acf3e7e3329c0eb1f40b4`
- Final second commit: `0281938e787710d7508acf3e7e3329c0eb1f40b4` (regressions for support/Horde contract intersections).
- Runtime: Node v24.22.1 on macOS, executable `/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node`.
- Contracts: GAME_VERSION v37; PROTO32 reloads prior Horde31 clients.

## Changes and checks

Main caravan dispatch, Horde interval position budgets, saved sniper aim, PvE progress tracking, barrier damage and lastCrit fix are preserved. Feature gift lifetime/owner, actual contactAt and non-retroactive birth windows, own-charge Dome behavior, support snapshots/history, union control budget and stack limits are preserved.

Merge conflicts required matching control observers to main's real confinement: both independently projected endpoints now apply the outpost/caravan leash and, for Horde, the arena clamp. Horde unit speed modifiers also feed lock observation. This is read-only observation; native movement, actor/grid state and RNG are not replayed or changed. Local mark and inherited mark contribution use main's pre-barrier counterfactual, and allyDamage follows the same actual HP gain.

The support-client fixture maps all browser /shared imports, including new Horde shared content. It retains the actual Game/Renderer/Net/codec path and all own-charge/Dome/gift/key-recovery assertions.

Final exact-head verification: **41/41 suites PASS**. See `final-results.json` for every command, exit code, duration, source SHA and runtime; individual `final-*.log` files are primary logs. Each command uses `node --import ../pm/test-runtime.mjs server/<suite>-test.js` from app with isolated HORDE_RUNS_DIR. Checks cover support/control, all Horde suites (including real transports/recovery), caravans, contact ordering/footprints, native hero perks, codec/movement, offers/finale and version contracts. `git diff --check e19e004..HEAD` passed.

New scoped regressions prove: gift absorbs before native Ward for Horde frost/venom, no debuff passes a blocked hit, an unprotected hit still debuffs and slow bounds movement, hostile slow earns no hero contribution; outward retreat at caravan/Horde confinement earns zero while an inset retreat earns actual control; ally mark credit through the Horde barrier equals additional actual HP damage; PROTO30/31 pages reload to PROTO32.

Before integration commit: 25/25 support/control/Horde suites PASS after adapting the loader. Three coverage suites also passed before the second commit. Early fixture development failures were undefined-vs-null and floating-point assertions and were corrected without changing product behavior; final primary logs above are on the committed head.

## Evidence limits

No new outcome matrices, full-run simulation batches, balance tuning, FPS campaigns, Issue68 work, browser playtest or deployment were performed. This targeted pass is author evidence, not independent product acceptance. Full Server CI on the pushed candidate is pending root.

Historical 600 attempts at a996978 retain their original source/runtime attribution. They were not rerun or relabelled to this head. The merged accepted main includes a lastCrit correction known to alter PvE trajectories, so exact old outcome percentages cannot be asserted as fresh results for this head. Support-specific contact, gift, stack and client-state proofs remain directly covered by scoped regressions. Root owns publication and the assessment of statistical evidence carry limitations.

## Cleanup and authority

`cleanup.json` confirms clean git status, no Node/server process with this checkout as its cwd, no remaining owned state directory, and no persistent data directory created. Test servers and ephemeral ports are released by their fixture cleanup; no server remains from this checkout. Installed ignored node_modules contains only npm dependencies and is retained for independent checks.

No push, GitHub edits/comments, main merge, force/reset/stash/rebase or deployment was performed. Issue41 is the only feature scope; inherited main commits remain on their original history.
