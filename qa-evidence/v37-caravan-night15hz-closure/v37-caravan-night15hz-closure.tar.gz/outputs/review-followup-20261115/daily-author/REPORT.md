# PR54 / Issue12 author integration, 2026-11-15

Final head `312dfaf2831da06c3d9861c5f355974a5e1526e6`, branch `codex/12-daily-challenges`, clean worktree. Main `e19e0041505acc30bd7e6d950eedcf2feabdb395` is an ancestor. PROTO32 / GAME_VERSION v37.

Local commits:
- `32f651a5829953a38a12041523ef6ba90e6a6636`: ordinary merge; parents `2b59642ea1ab6552c4fe337cf044d8f280fa766b` and `e19e0041505acc30bd7e6d950eedcf2feabdb395`.
- `a1a97aed87f7ce1ed1f3d3571e23fd13af6f9437`: native cross-contract tests and real protocol31 fallback coverage.
- `312dfaf2831da06c3d9861c5f355974a5e1526e6`: archive HTTP test binds port0 instead of choosing a random fixed port.

The merge preserves Daily v5, locked v1-4, UTC readiness/countdown, separate records, finite Swarm and all main Horde/caravan contracts. Main guard aliases and contact ordering are retained. Shared snapshot metadata carries Swarm, caravan and movement ACK together. Main Horde end results continue to omit ordinary achievements; Daily end results retain null achievements and suppress ordinary portal/browser progression.

The integration closes a concrete cross-mode overlap: switching an unlocked PvE lobby into Horde clears Daily state; direct daily packets in Horde cannot enable it; the client excludes daily movement modifiers in Horde. A locked countdown rejects ruleset changes until cancellation. The Daily controls sit inside the PvE section and are disabled in Horde.

PASS: 36 distinct targeted server files (summary.json lists exact commands and latest exits). Canonical Node v24.22.1, executable `/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node`, invocation `node --import <worktree>/pm/test-runtime.mjs <worktree>/app/server/<test>.js`; child runs inherit the same preload via NODE_OPTIONS. The profile covers all Daily suites, native records/restart, real WS24/31 denial, Horde contracts/ACK/resync/real reconnect, offers, caravans, archive/invites, codec losses/recovery, movement, outpost guards and contact geometry. Initial Daily DOM and Horde import failures are preserved in *.initial.log; their mocks/import adaptation was fixed without weakening assertions. Initial run-history test used its inherited random port; its final rerun uses port0 (3/3 pass).

PASS: actual Google Chrome 157.0.8103.51 with --mute-audio on an isolated owned server, OS assigned port62485 and temporary runs directory. Six scenes: 320x568, 390x844 and 568x320, each solo and duo. Real UI switches Horde->PvE, selects Daily, starts via WS, receives native Swarm reward/offer, accepts with touch. HP text140/140 remains fully readable, minimum measured width112px, title-vs-HP/timer overlap0. Solo clock remains158.0233 during choice; each duo moves158.4233->159.6233. Result feedback expires. Screenshots and results.json saved. The server wrapper advances owned-room time and creates the actual cohort solely to reach the reward/offer; these are UI/contract checks, not complete human runs or balance samples.

Browser production source is `32f651a`; both later commits change tests only, and production diff32f651a..312dfaf is empty. Accepted unmodified keyboard/desktop/history behavior is carried by unchanged production handlers and targeted native tests; no independent acceptance is claimed by this author.

Cleanup: childPID46266 exited and is absent; temporary runs directory removed; independent lsof showed no local listener at port62485. See cleanup-final.json. An earlier connect_ex probe reported a connection despite the absent local process/listener; it is retained in cleanup-verified.json and not used as sole local-listener evidence. No network configuration was inspected or changed.

Balance: no new attempts, seed matrices, full simulations or tuning were run. Existing 300 Glass v4 +300 Armor v5 +240 fresh Armor remain the root coordinator publication task. Original daily rules/swarm/decision documents are byte-identical against2b59642; numerical samples remain labeled with their actual historical source/manifest SHAs. Base13c560f and older candidate results do not measure this new e19e004-based candidate. New main caravans introduce guards, XP15% and living-hero healing10%; those can affect Daily outcomes in PvE, while Horde-exclusive changes do not execute there. This is a diff-based influence assessment, not a new balance verdict; do not relabel old data as fresh candidate measurements or automatically request a new full matrix.

NOT VERIFIED HERE: full Server CI on the published exact merge candidate, independent review/acceptance, new-base balance outcomes, FPS/full load or 5-8 new matrix. Root owns publication/current CI and remaining acceptance. No push, GitHub mutation, ready/main merge or deployment was performed.
