import collections,hashlib,json,math,shutil,subprocess
from pathlib import Path
out=Path(__file__).resolve().parent;base=out.parents[2];author=out.parent/'night-author';repo=base/'work/night-horde-caravan-rework'
d=json.loads((out/'replay-01.json').read_text());a=json.loads((author/'attempt-01.json').read_text());packets=d['packets'];tol=1e-7
assert d['verdict']=='PASS' and d['final']['status']=='claimed'
assert d['final']['caravan']['killed']==d['final']['caravan']['total']==32
assert d['final']['elapsed']<180 and d['final']['hero']['hp']>0
assert d['final']==a['final'],'outcome matches author repeat'
assert d['meta']['hashes']==d['finalHashes']==a['meta']['hashes']
assert (out/'PLAN.json').read_bytes()==(author/'PLAN.json').read_bytes()
assert (out/'night-15hz.mjs').read_bytes()==(author/'night-15hz.mjs').read_bytes()
prevseq=0;maxexcess=-1e9;maxfacing=0;gaps=[];epoch=collections.Counter()
for p in packets:
 m=p['msg'];assert m['seq']==prevseq+1;prevseq=m['seq'];epoch[m['epoch']]+=1
 assert m['epoch']==0
 assert abs(p['elapsed']-2/30)<tol,p['elapsed'];gaps.append(p['elapsed'])
 assert abs(p['budget']-160*2/30)<tol,p['budget']
 assert p['acceptedError']<1e-7
 for k in ['x','y']:assert abs(m[k]*10-round(m[k]*10))<1e-6
 for k in ['fx','fy']:assert abs(m[k]*1000-round(m[k]*1000))<1e-6
 v=p['clientVector'];assert abs(math.hypot(v['x'],v['y'])-1)<1e-10
 assert p['localFacing']==v,'facing comes from movement'
 assert m['fx']==math.floor(v['x']*1000+.5)/1000 and m['fy']==math.floor(v['y']*1000+.5)/1000
 maxfacing=max(maxfacing,abs(m['fx']-v['x']),abs(m['fy']-v['y']))
 maxexcess=max(maxexcess,p['distance']-p['budget'])
 assert p['distance']<=p['budget']+.15 and p['maxStep']>p['distance']
globalGaps=[b['time']-a['time'] for a,b in zip(packets,packets[1:])]
assert all(g>=2/30-1e-7 for g in globalGaps), 'no packets faster than15Hz'
gapCounts=collections.Counter(round(g*30) for g in globalGaps)
assert dict(gapCounts)=={2:551,3:1,4:1}
assert len(packets)==554 and d['meta']['plan']['seed']==7111502
assert len(d['reforgeMessages'])==1 and len(d['final']['reforges'])==1
assert d['final']['receipt']['source']=='caravan' and d['final']['receipt']['result']['id']=='haste'
assert d['final']['receipt']['result']['from']==2 and d['final']['receipt']['result']['to']==3
claimBefore=d['claimFrame']['before']['inventory'];claimAfter=d['claimFrame']['after']['inventory']
regenOneTick=claimAfter['pval']['regen']/30;rewardHeal=.2*claimAfter['maxHp'];claimDelta=claimAfter['hp']-claimBefore['hp']
assert math.isclose(claimDelta,rewardHeal+regenOneTick,abs_tol=1e-9)
summary={'scope':'PR77 sole Night-solo positive criterion; no whole-game/PR READY inference','source':d['meta']['head'],'node':d['meta']['node'],'seed':7111502,'attempts':1,'result':'PASS','sourceMatchesAuthor':True,'scriptAndPlanByteEqualToAuthor':True,'authorFinalOutcomeExactMatch':True,'nativeGuardsKilled':32,'elapsed':d['final']['elapsed'],'firstPursuit':d['final']['firstPursuit'],'openAt':d['final']['openAt'],'hpInitial':d['initial']['hero']['hp'],'hpBeforeClaimFrame':claimBefore['hp'],'hpFinal':d['final']['hero']['hp'],'claimFrameDelta':claimDelta,'rewardHeal':rewardHeal,'regenSameFrame':regenOneTick,'receipt':d['final']['receipt'],'packets':len(packets),'packetIntervalMin':min(globalGaps),'packetIntervalMax':max(globalGaps),'globalGapTicksCount':dict(gapCounts),'reportedElapsedBoundary':'elapsed resets at natural offer; global intervals computed from adjacent packet.time','nominalHz':15,'epochCounts':dict(epoch),'seqRange':[1,prevseq],'nativeSpeed':160,'perPacketBudget':160*2/30,'maxDistanceOverBudgetRounding':maxexcess,'maxFacingRoundingError':maxfacing,'sourceHashes':d['meta']['hashes'],'harnessSha256':hashlib.sha256((out/'night-15hz.mjs').read_bytes()).hexdigest(),'planSha256':hashlib.sha256((out/'PLAN.json').read_bytes()).hexdigest(),'rawSha256':hashlib.sha256((out/'replay-01.json').read_bytes()).hexdigest(),'naturalOffersCount':len(d['offers']),'naturalOffers':[{'time':x['time'],'choice':x['choice'],'hp':x['hp']} for x in d['offers']],'damageTaken':d['final']['taken'],'sampledEnemiesMax':max(x['enemies'] for x in d['samples'])}
(out/'verification.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
store=out/'runs-replay-01';storeExisted=store.exists()
if store.exists():shutil.rmtree(store)
check=subprocess.run(['git','diff','--check'],cwd=repo,capture_output=True,text=True)
status=subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True)
cmd=json.loads((out/'replay-01-command.json').read_text())
cleanup={'scope':'single native in-process fixture; no HTTP server/browser/listener was created','fixtureExit':cmd['exit'],'ownedStore':str(store),'storeExistedAfterRun':storeExisted,'storeRemoved':not store.exists(),'gitBeforeStatus':cmd['beforeStatus'],'gitAfterStatus':status,'headBefore':cmd['beforeHead'],'headAfter':cmd['afterHead'],'gitDiffCheckExit':check.returncode,'sourceHashesBeforeAfterEqual':d['meta']['hashes']==d['finalHashes'],'productEdits':False,'gitGhMutations':False}
assert cmd['exit']==0 and not status and check.returncode==0
(out/'cleanup-independent.json').write_text(json.dumps(cleanup,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['result','elapsed','hpInitial','hpBeforeClaimFrame','hpFinal','packets','packetIntervalMin','packetIntervalMax','maxDistanceOverBudgetRounding','maxFacingRoundingError','naturalOffersCount','sampledEnemiesMax','harnessSha256','planSha256','rawSha256']},ensure_ascii=False))
