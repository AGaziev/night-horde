import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import http from 'node:http';
import assert from 'node:assert/strict';
import {once} from 'node:events';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
const here=path.dirname(new URL(import.meta.url).pathname);
const repo='/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/work/night-horde-issue-17';
const old='/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/issue-split/v36/remaining-load-current/sources/17/421a5d117e78bc88bbd78622916943cba2a58245';
const data=fs.mkdtempSync(path.join(os.tmpdir(),'dash30-browser-'));
process.env.HORDE_RUNS_DIR=data;
const {chromium}=await import('/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs');
const {WebSocketServer}=createRequire(repo+'/app/package.json')('ws');
let activeRoot=repo,r,peer,wire=[],back=[],calls=[],browser;
const rows=[];
const server=http.createServer(async(req,res)=>{
 try{
  if(req.url==='/step'){r.step(1/30);r.snapshot();res.end('ok');return;}
  if(req.url==='/prepare'){
   const h=r.heroes.get(1);r.time=815.3;r.startFinale([...r.heroes.values()]);Object.assign(r.fin,{cx:40,cy:-10,r:500,r1:465});r.finaleWall();
   Object.assign(h,{hp:r.qaHp,maxHp:100,ward:0,iframes:0});
   const e=r.spawnEnemy('ghoul',[...r.heroes.values()],1);e.x=h.x+Math.cos(Math.PI/6)*27;e.y=h.y+Math.sin(Math.PI/6)*27;r.qaEnemy=e;
   const hurt=r.hurtPlayer;r.hurtPlayer=function(...a){calls.push({at:a[3],time:this.time,damage:a[1]});return hurt.apply(this,a);};
   r.snapshot();res.end('ok');return;
  }
  if(req.url==='/'){res.setHeader('Content-Type','text/html');res.end('<meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0}canvas{width:390px;height:844px;touch-action:none;background:#14221b}#joy{position:fixed;pointer-events:none}</style><canvas id="surface" width="390" height="844"></canvas><div id="joy" hidden><i></i></div>');return;}
  const pathname=new URL(req.url,'http://localhost').pathname;
  assert.ok(pathname.startsWith('/js/')||pathname.startsWith('/shared/'));
  const file=path.join(activeRoot,'app/public',pathname);
  assert.ok(file.startsWith(path.join(activeRoot,'app/public')+path.sep));
  res.setHeader('Content-Type','text/javascript');res.setHeader('Cache-Control','no-store');res.end(fs.readFileSync(file));
 }catch(e){res.statusCode=500;res.end(String(e));}
});
const wss=new WebSocketServer({server});
wss.on('connection',ws=>{peer=ws;ws.on('message',raw=>{const m=JSON.parse(String(raw));wire.push(m);r.handle(1,m);if(m.t==='qa-barrier')ws.send(JSON.stringify({t:'qa-barrier',n:m.n}));});});
server.listen(0,'127.0.0.1');await once(server,'listening');const port=server.address().port,url='http://127.0.0.1:'+port;
let error;
try{
 browser=await chromium.launch({headless:true,args:['--mute-audio']});
 for(const [label,source]of[['old421',old],['candidate',repo]])for(const hp of[10,100])for(const press of[false,true]){
  activeRoot=source;wire=[];back=[];calls=[];
  const {Room}=await import(pathToFileURL(path.join(source,'app/server/game.js')));
  const {hasActualDash}=await import(pathToFileURL(path.join(source,'app/server/mobility.js')));
  r=new Room('BROWSER30',(pid,m)=>{if(pid===1&&peer?.readyState===1){back.push(structuredClone(m));peer.send(JSON.stringify(m));}});
  for(let i=1;i<=2;i++)r.addPlayer(i,'P'+i,'witch');r.start();r.spawn=()=>{};r.breakAround=()=>{};r.events.next=Infinity;r.peaks=[];r.bossIdx=r.bossAt.length;r.nextEliteT=r.nextInvasionT=Infinity;
  for(const h of r.heroes.values()){h.weapons.clear();h.perk.readyAt=Infinity;}
  r.qaHp=hp;
  const context=await browser.newContext({viewport:{width:390,height:844},hasTouch:true,isMobile:true});const page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto(url);
  await page.evaluate(async({url,start})=>{
   const [{Input},{Game},{Net},{SnapshotDecoder}]=await Promise.all([import('/js/input.js'),import('/js/game.js'),import('/js/net.js'),import('/js/snapshot-codec.js')]);
   const ws=new WebSocket(url.replace('http','ws'));await new Promise(resolve=>ws.onopen=resolve);
   const net=Object.create(Net.prototype);Object.assign(net,{outbox:[],connected:true,transport:'WS',ws,handlers:new Map(),snapDec:new SnapshotDecoder(),keyAskedAt:-Infinity});
   ws.onmessage=e=>net.receive(e.data);
   const game=new Game(net);game.me=1;game.begin(start);net.on('s',m=>game.onSnapshot(m));net.on('dash',m=>game.acceptDash(m));
   const input=new Input(document.querySelector('#surface'),document.querySelector('#joy'));input.setEnabled(true);input.onDash=()=>game.requestDash(input);
   let serial=0,done=0;net.on('qa-barrier',m=>done=m.n);
   const flush=async()=>{const n=++serial;net.send({t:'qa-barrier',n});while(done!==n)await new Promise(resolve=>setTimeout(resolve,1));};
   window.qa={game,input,net,flush};
  },{url,start:r.startMsg()});
  r.snapshot();await page.evaluate(()=>qa.flush());
  const cdp=await context.newCDPSession(page);
  await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{id:1,x:50,y:750}]});
  await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{id:1,x:50+50*Math.cos(Math.PI/6),y:775}]});
  const input=await page.evaluate(()=>({...qa.input.vector(),active:qa.input.joy.active}));assert.ok(input.active);assert.ok(Math.abs(input.x-Math.cos(Math.PI/6))<1e-6);assert.ok(Math.abs(input.y-.5)<1e-6);
  await page.evaluate(async()=>{for(let i=0;i<96;i++){qa.game.update(1/30,qa.input);await qa.flush();await fetch('/step');await qa.flush();}});
  const pos=wire.filter(m=>m.t==='pos').at(-1),ack=await page.evaluate(()=>qa.game.ackSeq);
  assert.equal(pos.x,493.4);assert.equal(pos.y,256);assert.equal(pos.seq,49);assert.equal(ack,49);assert.equal(r.heroes.get(1).posAck,49);
  await page.evaluate(async()=>{await fetch('/prepare');await qa.flush();});
  if(press){await page.keyboard.press('Space');await page.evaluate(()=>qa.flush());assert.ok(r.heroes.get(1).dash);}
  await page.evaluate(async()=>{await fetch('/step');await qa.flush();});
  const h=r.heroes.get(1),e=r.qaEnemy,result={label,hp,press,input,pos,ack,after:{hp:h.hp,st:h.st,path:h.dashPath,actualDash:hasActualDash(h),enemyDistance:Math.hypot(e.x-h.x,e.y-h.y)},dashAck:back.findLast(m=>m.t==='dash'),calls,errors};
  assert.ok(result.after.enemyDistance>28);assert.deepEqual(errors,[]);
  if(label==='candidate'||!press){assert.equal(h.hp,hp);assert.equal(h.st,0);assert.equal(calls.length,0);}else{assert.equal(h.hp,hp-7.68);assert.equal(calls.length,1);}
  if(label==='candidate'&&press){assert.equal(h.dashPath.duration,0);assert.equal(hasActualDash(h),false);}
  rows.push(result);await page.screenshot({path:path.join(here,`touch-${label}-${hp}-${press}.png`)});
  await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await context.close();
 }
}catch(e){error={message:e.message,stack:e.stack};}
finally{
 await browser?.close();for(const ws of wss.clients)ws.terminate();await new Promise(resolve=>wss.close(resolve));await new Promise(resolve=>server.close(resolve));fs.rmSync(data,{recursive:true,force:true});
 fs.writeFileSync(path.join(here,'browser-results.json'),JSON.stringify({node:process.version,browser:browser?.version(),sourceOld:'421a5d1',sourceCandidate:'d3b451957f25d15104b755a35d7932cecbcf001f',scope:'Actual Chromium touch events and native Input/Game.update/Net over real WS into Room; controlled translated-ring/native damage fixture,96 manually advanced30Hz frames; no full product UI or live-frequency/performance claim',rows,error,cleanup:{port,serverClosed:!server.listening,wssClosed:!wss.address(),browserClosed:!browser?.isConnected(),temporaryDataRemoved:!fs.existsSync(data)}},null,2));
}
if(error)throw Error(error.stack);console.log('PASS actual Chromium touch A/B',rows.length);
