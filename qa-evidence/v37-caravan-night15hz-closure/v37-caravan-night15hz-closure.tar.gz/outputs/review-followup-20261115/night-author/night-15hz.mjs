import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
const dir=path.dirname(fileURLToPath(import.meta.url)),plan=JSON.parse(fs.readFileSync(path.join(dir,'PLAN.json'),'utf8'));
const app=path.resolve(process.argv[2]),root=path.dirname(app),output=path.resolve(process.argv[3]);
const {Room}=await import(pathToFileURL(path.join(app,'server/game.js')));
const {CARAVAN,updateCaravan}=await import(pathToFileURL(path.join(app,'server/caravans.js')));
const {WEAPONS,PASSIVES,EVOS,DUOS,TICK_HZ,POS_HZ,MAX_LEVEL,xpForNext}=await import(pathToFileURL(path.join(app,'public/shared/content.js')));
const hash=file=>createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const sourceFiles=['server/game.js','server/caravans.js','server/runlog.js','public/js/game.js','public/js/main.js','public/shared/content.js','server/snapshot-codec.js'];
const head=execFileSync('git',['-C',root,'rev-parse','HEAD'],{encoding:'utf8'}).trim();
assert.equal(head,plan.source);assert.equal(TICK_HZ,30);assert.equal(POS_HZ,15);
for(const [id,lvl]of Object.entries(plan.weapons)){assert.ok(WEAPONS[id]&&!EVOS[id]&&!DUOS[id]);assert.ok(lvl>=1&&lvl<=MAX_LEVEL);}
const meta={plan,head,node:process.version,app,startedAt:new Date().toISOString(),argv:process.argv,hashes:Object.fromEntries(sourceFiles.map(f=>[f,hash(path.join(app,f))])),harnessHash:hash(fileURLToPath(import.meta.url)),planHash:hash(path.join(dir,'PLAN.json'))};
const originalRandom=Math.random;let randomState=plan.seed>>>0;Math.random=()=>((randomState=(1664525*randomState+1013904223)>>>0)/4294967296);
const raw={meta,preparation:[],packets:[],samples:[],guardDeaths:[],offers:[],reforgeMessages:[],freeAim:false,hpRefill:false,invulnerability:false,forcedCombatKills:false};
let r,h,c,active=0;const wallStart=performance.now();
function inventory(){return{level:h.level,xp:h.xp,hp:h.hp,maxHp:h.maxHp,rerolls:h.rerolls,weapons:[...h.weapons].map(([id,w])=>[id,w.lvl]),passives:[...h.passives],pval:{...h.pval}};}
function pickOffer(){
	const score=card=>card.kind==='heal'?(h.hp<h.maxHp*.65?1000:10):card.kind==='rare'?900:card.kind==='weapon'?(h.weapons.has(card.id)?800:600)+(card.rar??0)*10:card.kind==='passive'?(h.passives.has(card.id)?750:500)+(card.rar??0)*10:card.kind==='duo'||card.kind==='evo'?300:100;
	const index=h.offer.reduce((best,card,i)=>score(card)>score(h.offer[best])?i:best,0),card=structuredClone(h.offer[index]);
	raw.offers.push({time:r.time,choice:card,choices:structuredClone(h.offer),hp:h.hp,maxHp:h.maxHp,epoch:h.offerEpoch});
	r.handle(h.pid,{t:'pick',i:index,offerEpoch:h.offerEpoch});
}
function vector(local){
	if(c.status==='open'){const dx=c.x-local.x,dy=c.y-local.y,d=Math.hypot(dx,dy)||1;return{x:dx/d,y:dy/d};}
	const dc=Math.hypot(c.x-local.x,c.y-local.y);let vx,vy;
	const visible=r.enemies.filter(e=>e.caravan&&!e.dead&&Math.hypot(e.x-local.x,e.y-local.y)<=650);
	const last=c.total-c.killed<=4;
	visible.sort((a,b)=>(last?(a.ai==='shield'?0:1)-(b.ai==='shield'?0:1):0)||Math.hypot(a.x-local.x,a.y-local.y)-Math.hypot(b.x-local.x,b.y-local.y));
	const target=dc<850?visible[0]:null;
	if(target){
		const dx=local.x-target.x,dy=local.y-target.y,d=Math.hypot(dx,dy)||1,radius=last&&target.ai==='shield'?110:150;
		const radial=Math.max(-1.5,Math.min(1.5,(radius-d)/70));
		vx=-dy/d+dx/d*radial;vy=dx/d+dy/d*radial;
	}else{const d=dc||1;vx=(c.x-local.x)/d;vy=(c.y-local.y)/d;}
	for(const e of r.enemies){
		if(e.dead)continue;const dx=local.x-e.x,dy=local.y-e.y,d=Math.hypot(dx,dy);
		if(d>1&&d<65){const w=(65-d)/30;vx+=dx/d*w;vy+=dy/d*w;}
	}
	for(const shot of r.hostile){const dx=local.x-shot.x,dy=local.y-shot.y,d=Math.hypot(dx,dy);if(d>1&&d<90){const w=(90-d)/55;vx+=dx/d*w;vy+=dy/d*w;}}
	if(dc>660){vx+=(c.x-local.x)/(dc||1)*.8;vy+=(c.y-local.y)/(dc||1)*.8;}
	const length=Math.hypot(vx,vy)||1;return{x:vx/length,y:vy/length};
}
try{
	r=new Room('NIGHT-15HZ',(pid,msg)=>{if(msg.t==='reforge')raw.reforgeMessages.push({at:r.time,pid,msg:structuredClone(msg)});});
	r.setMode('night');r.addPlayer(1,'Night15','witch');r.start();h=r.heroes.get(1);
	const card=(id,kind)=>{
		h.level++;const def=kind==='weapon'?WEAPONS[id]:PASSIVES[id],entry={id,kind,name:def.name,icon:def.icon};
		if(!def.noRarity)r.setRarity(h,entry,0);else entry.level=(h.passives.get(id)??0)+1;
		h.offer=[entry];r.sendOffer(h);const epoch=h.offerEpoch;r.handle(1,{t:'pick',i:0,offerEpoch:epoch});
		raw.preparation.push({card:structuredClone(entry),inventory:inventory()});
	};
	for(let i=1;i<plan.weapons.bolt;i++)card('bolt','weapon');
	for(const id of ['flask','trail'])for(let i=0;i<plan.weapons[id];i++)card(id,'weapon');
	for(const [id,level]of Object.entries(plan.passives))for(let i=0;i<level;i++)card(id,'passive');
	assert.equal(raw.preparation.length,18);assert.equal(h.level,19);
	assert.deepEqual(Object.fromEntries([...h.weapons].map(([id,w])=>[id,w.lvl])),plan.weapons);
	assert.deepEqual(Object.fromEntries(h.passives),plan.passives);
	for(const [id,value]of Object.entries(plan.commonPval))assert.equal(h.pval[id],value);
	assert.equal(h.mods.ashHops,1);assert.equal(h.maxHp,130);assert.equal(h.hp,h.maxHp);
	assert.equal(Array.from({length:18},(_,i)=>xpForNext(i+1,1)).reduce((a,b)=>a+b,0),1314);
	r.time=315;h.x=h.y=0;h.lastPosT=r.time;h.hostilePos={x:0,y:0};r.bossIdx=r.bossAt.filter(t=>t<r.time).length;r.updateFrozen();
	updateCaravan(r,[h],0);c=r.caravan;assert.ok(c);assert.equal(c.total,32);
	raw.initial={time:r.time,hero:{x:h.x,y:h.y,...inventory()},caravan:structuredClone(c),bossIdx:r.bossIdx,bossAt:r.bossAt,modeDmg:r.modeDmg,modeHp:r.modeHp};
	const local={x:h.x,y:h.y,fx:h.fx,fy:h.fy};let posAccumulator=0,budget=0,seq=0,previousSendTime=r.time,previousSend={x:h.x,y:h.y};
	let firstPursuit=null,firstKill=null,openAt=null,killed=0,nextSample=315;
	for(let frame=0;frame<plan.limits.maxServerSteps&&r.state==='play'&&!['claimed','expired'].includes(c.status);frame++){
		if(performance.now()-wallStart>plan.limits.maxWallSeconds*1000)throw Error('bounded wall runtime exceeded');
		if(h.st!==0)break;
		if(h.offer){
			const before=[r.time,c.progress];for(let i=0;i<12;i++)r.tick(1/30);assert.deepEqual([r.time,c.progress],before);
			pickOffer();r.updateFrozen();local.x=h.x;local.y=h.y;posAccumulator=0;budget=0;previousSend={x:h.x,y:h.y};previousSendTime=r.time;
		}
		const v=vector(local),speed=h.speed*h.mods.speedMul;local.x+=v.x*speed/30;local.y+=v.y*speed/30;
		if(v.x||v.y){local.fx=v.x;local.fy=v.y;}
		posAccumulator+=1/30;budget+=speed/30;
		const before={time:r.time,inventory:inventory(),status:c.status};r.tick(1/30);active=r.time-315;
		if(c.killed!==killed){raw.guardDeaths.push({at:r.time,killed:c.killed,hp:h.hp});killed=c.killed;if(firstKill===null)firstKill=active;}
		if(c.status==='open'&&openAt===null)openAt=active;
		if(c.status==='claimed'){raw.claimFrame={before,after:{time:r.time,inventory:inventory()}};break;}
		if(posAccumulator>=1/15-1e-9&&!r.frozen&&h.st===0){
			const msg={t:'pos',seq:++seq,epoch:h.moveEpoch??0,x:Math.round(local.x*10)/10,y:Math.round(local.y*10)/10,fx:Math.round(local.fx*1000)/1000,fy:Math.round(local.fy*1000)/1000};
			const elapsed=r.time-previousSendTime,distance=Math.hypot(msg.x-previousSend.x,msg.y-previousSend.y);
			assert.ok(distance<=budget+.15,'packet never exceeds accumulated native-speed displacement');
			const serverElapsed=Math.min(1,Math.max(0,r.time-h.lastPosT)),maxStep=speed*serverElapsed*1.5+30;
			assert.ok(distance<=maxStep+.15,'packet stays inside the actual server maxStep');
			r.handle(1,msg);const error=Math.hypot(h.x-msg.x,h.y-msg.y);assert.ok(error<1e-7,'normal native position accepted without clipping');
			raw.packets.push({time:r.time,elapsed,budget,distance,maxStep,clientVector:{...v},localFacing:{x:local.fx,y:local.fy},msg,acceptedError:error});
			assert.equal(h.posAck,seq);previousSend={x:msg.x,y:msg.y};previousSendTime=r.time;posAccumulator-=1/15;budget=0;
		}
		if(firstPursuit===null&&Math.hypot(h.x-c.x,h.y-c.y)<=720)firstPursuit=active;
		if(r.time>=nextSample){raw.samples.push({time:r.time,hp:h.hp,maxHp:h.maxHp,killed:c.killed,x:h.x,y:h.y,caravan:{x:c.x,y:c.y,status:c.status},enemies:r.enemies.filter(e=>!e.dead).length});nextSample+=1;}
	}
	raw.final={status:c.status,state:r.state,time:r.time,elapsed:r.time-315,firstPursuit,firstKill,openAt,hero:{x:h.x,y:h.y,...inventory()},caravan:{x:c.x,y:c.y,total:c.total,killed:c.killed},remaining:r.enemies.filter(e=>e.caravan&&!e.dead).map(e=>({type:e.def.name,hp:e.hp,maxHp:e.maxHp,x:e.x,y:e.y})),taken:r.runLog.p.get(1).taken,reforges:r.runLog.p.get(1).reforges,picks:r.runLog.p.get(1).picks,receipt:h.lastReforge??null,packetCount:raw.packets.length};
	assert.equal(c.status,'claimed','native claim must finish inside the window');assert.equal(c.killed,32);assert.equal(h.st,0);assert.ok(h.hp>0);assert.ok(r.time<495);
	assert.equal(raw.reforgeMessages.length,1);assert.equal(h.lastReforge.source,'caravan');assert.ok(h.lastReforge.result);assert.equal(r.runLog.p.get(1).reforges.filter(x=>x.source==='caravan').length,1);
	raw.verdict='PASS';
}catch(error){raw.verdict='FAIL';raw.error={message:error.message,stack:error.stack};process.exitCode=1;}
finally{
	Math.random=originalRandom;raw.wallMs=performance.now()-wallStart;raw.endedAt=new Date().toISOString();raw.finalHashes=Object.fromEntries(sourceFiles.map(f=>[f,hash(path.join(app,f))]));assert.deepEqual(raw.finalHashes,meta.hashes);
	fs.writeFileSync(output,JSON.stringify(raw,null,2)+'\n');console.log(JSON.stringify({verdict:raw.verdict,error:raw.error?.message,source:head,final:raw.final,wallMs:raw.wallMs},null,2));
}
