# Existing-data handoff: PR54 / PR55 / PR58 / PR59

**PASS: local primary and archives. NOT VERIFIED: external transfer, new-main composition, final product acceptance.**

No new simulation, APP edit, Git operation, GH/API call, process/operator/registry change or publication was performed. All new reports/scripts are confined to this directory; the unchanged evidence builder writes only the four named outputs/issue-split/publication directories.

Read-only revalidation covered2160 physical attempts:300Glass+300Armor+120soloNight+600support+600dash+240separate oldArmor. All9 whole-group gates have done/terminal/scope complete, active0/pending0/failed0/unknown0 and observed masterexit0. Per-attempt raw/source/tuple/runtime/argv/environment/native terminal+Nodeexit proof passed, with zero retries or discarded errors. Eight existing comparator-audit files were also hash-revalidated; accepted baselinea957 is referenced rather than duplicated.

| Package | Primary physical attempts | Files excluding members.json | Bytes | SHA256 |
|---|---:|---:|---:|---|
| v36-daily-v4-v5-corrections | 840 | 8463 | 12433396 | `c97a65fb1bc84fba38c2ca69a06e0d26b830b063f05f6cf17ac522cedf0e08fb` |
| v36-fusion-solo-night-correction | 120 | 1464 | 1971460 | `348c1a2dfe847aead2f156e1e4702b42d1cd8803d975a1b79640a4a9d227d48a` |
| v36-support-current600 | 600 | 5659 | 6743129 | `a2b85e6fdf888f38d58f31dc06e08821599802e4fa6ccf0cd71f543c01e12dbd` |
| v36-dash421-current600 | 600 | 5677 | 14555913 | `a105c84564d428dd88669fbb07fd447a6bee94e8865e1407570bdca3ae961a9f` |

Each archive is at outputs/issue-split/publication/{package}/{package}.tar.gz with members.json and SHA256SUMS. Every tar member was compared against the manifest and current local bytes. Each archive was rebuilt using the same explicit inputs and verified byte-identical. Tar manifest member is one additional file beyond the table count. No binary source assets, .env, .git, node_modules or future author folder is included. Original source.tar copies are intentionally omitted, with their original hashes retained in bindings. The exact historical Git SHA and source manifests identify reconstruction.

The builder excludes.stderr and.plist suffixes. Their original content is preserved as byte-identical.txt aliases under preserved-text/{package}; original-paths.json binds each alias to the original path/hash. Nothing in the old primary was renamed or cleaned. History includes original source/preparation logs and scoped reviewer diagnostic failures. The initial local archive verifier counted supervisor-launch receipts as outcomes; its correction and observed values are recorded in preparation-history.json. This did not indicate a primary failure or cause a new attempt.

## Attribution and result boundaries

- PR54: Glass300 actual8deda7cf6937f5200139dab79a984acca563c2e0 and Armor300 actual2b59642ea1ab6552c4fe337cf044d8f280fa766b. Glass human1..4/smart wins17,19,24,13,30 of60; human4 point21.67% is below25%, Wilson95[13.12,33.62] overlaps target. Armor wins19,22,26,27,34 of60; human3/4 points43.33%/45% exceed40%, Wilson95[31.57,55.90]/[33.09,57.51] overlap target. Separate freshArmor240 retains actual0ab/5115 attribution and different preregistered seeds; it is not v5 or pooled N.
- PR58:120 actual1c93a575bb811a6992134e636b2423aa893e054d at soloNight.65. Human19/60 and smart35/60 versus prior source679:9/60 and23/60; ordinarya957human28/60 remains separate. Other480 can carry only with the archived old679 fixed-roster/readset proof. Existing archive v36-caravans-signatures-main45-complete contains5400 raw files for that source, identified by local manifest/hash; no new public-transfer claim is made.
- PR59:600 actuala99697894432856a05a7a4356bef10634d3c1a9c. Wins26,22,18,21,18,26,15,20,42,42. Human2Night normal/paired-bootstrap disagreement and McNemar≈.092 remain explicit; neither proven regression nor equivalence is claimed. Retired9683partial84/actualexit-15 is retained as excluded history.
- PR55:600 actual421a5d117e78bc88bbd78622916943cba2a58245. Wins22,20,24,27,15,31,13,23,40,40; all paired difference intervals cross0. Touch-input numeric-zero blocker remains on this source. These600 are not relabeled toea9 or later integration.

## Publication and missing proof

The four packages contain the requested missing old primary; no missing physical attempt or source binding was found. This task makes no public transfer. Publisher must supply usable public archive URLs and verify downloaded SHA256/member manifests. Historical baseline pointer: commit1b33f79, qa-evidence/v36-combat-45-complete, SHA8504995a1afdedac6f21dd76d856d51ad2a163fd1921a53c57e6f09020d7aea2. Dailyv3 historical remote readback: commit1f6ffddff53c2d61e76f08552a0a52985ee2fa08, SHAb3116512797e4f257abd8aa986809c181ea85ed2af002b7fc6da6f6b9ab4b434. See source-index.json for these and prior679.

Historical13c-based results do not measure currente19 main with Horde/caravans/lastCrit changes or newly merged branch compositions. To claim carry to a later head, add exact measured-source→target canonical Room import-closure, runner/policy/selector and affected-cell equivalence proof; if that proof fails, obtain separate authorization for the needed measurements. No new N/seed/parameter proposal is made here. Browser/UI/weak-phone/CPU/PvP/production acceptance and final PR READY remain outside these archives.

Full proof: primary-verification.json, archive-proof.json, archive-proofs/*.json, inputs/*.json, build-metadata/*.json, scopes/*.md.
