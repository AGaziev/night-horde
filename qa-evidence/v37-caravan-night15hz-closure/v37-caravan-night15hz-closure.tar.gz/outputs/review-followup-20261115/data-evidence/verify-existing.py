"""Read existing, explicitly closed cohorts; never launch a simulation or rewrite raw."""
from pathlib import Path
import collections
import hashlib
import json
import runpy

HERE = Path(__file__).resolve().parent
# HERE is outputs/review-followup-20261115/data-evidence.
ROOT = HERE.parent.parent / 'issue-split'

def read(p):
    return json.loads(Path(p).read_text())

def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def require(ok, message):
    if not ok:
        raise ValueError(message)

standard = runpy.run_path(str(ROOT / 'v36/current-standard-analysis/analyse.py'))
physical = dict(standard)
exec(compile((ROOT / 'v36/current-subset-analysis/physical_attempt.py').read_text(), 'physical_attempt.py', 'exec'), physical)
SPECS = [
    ('glass-v4', 12, 'v36/current-subset-analysis/runs/20261114T201749.225071Z', 'glass-v4-candidate-audit.json'),
    ('armor-v5', 12, 'v36/current-subset-analysis/runs/20261114T205951.175326Z', 'armor-v5-candidate-audit.json'),
    ('31-solo-night', 31, 'v36/current-subset-analysis/runs/20261114T203247.318347Z', '31-solo-night-candidate-audit.json'),
    ('41', 41, 'v36/current-standard-analysis/runs/20261114T195626.293858Z', '41-audit.json'),
    ('17', 17, 'v36/current-standard-analysis/runs/20261114T211035.145843Z', '17-audit.json'),
]
EXT = {'meta': '.meta.json', 'raw': '.json', 'stderr': '.stderr.txt', 'exit': '.exit.json', 'worker': '.worker.json', 'dispatch': '.dispatch.json', 'start': '.start.json'}

def verify_gate(q, n):
    s, c, t, e = (read(q / f) for f in ['controller-state.json', 'controller-complete.json', 'launchd/started.json', 'launchd/exit.json'])
    require(s['done'] == s['terminal'] == n and s['active'] == s['pending'] == 0 and not s['unknown'], str(q) + ': state')
    require(c['planned'] == c['completed'] == c['terminal'] == c['scopeTarget'] == c['scopeTerminal'] == n and c['failed'] == 0 and not c['unknown'], str(q) + ': complete')
    require(e['observedMasterExitCode'] == 0 and e['masterPID'] == t['masterPID'] == s['masterPID'], str(q) + ': observed exit')
    return {'planned': n, 'done': s['done'], 'terminal': s['terminal'], 'active': 0, 'pending': 0, 'failed': 0, 'unknown': [], 'observedMasterExitCode': 0,
            'hashes': {f: digest(q / f) for f in ['controller-state.json', 'controller-complete.json', 'launchd/started.json', 'launchd/exit.json']}}

def verify_source(q, p, binding):
    source = Path(binding['snapshotPath'])
    require((source / 'SOURCE_SHA').read_text().strip() == binding['candidateSha'], 'SOURCE_SHA')
    require(digest(source / 'SHA256.json') == binding['manifestSHA256'], 'source manifest')
    manifest = read(source / 'SHA256.json')
    for f, expected in manifest.items():
        require(digest(source / f) == expected, 'source bytes ' + str(source / f))
    require(digest(source / 'source.tar') == binding['archiveSHA256'], 'original source archive bytes')
    require(digest(p['node']) == p['nodeBinarySHA256'], 'actual node bytes')
    for f, expected in p['canonicalRunnerHashes'].items():
        require(digest(q / 'harness/pm' / f) == expected, 'canonical harness ' + f)
    if p.get('executionKind') == 'daily':
        require(digest(q / 'daily-selector.mjs') == p['selectorPolicySHA256'], 'selector policy bytes')
    if p.get('executionKind') == 'guarded':
        require(digest(q / 'guard-core.mjs') == p['policyCoreSHA256'] and digest(q / 'guarded-policy.mjs') == p['policySHA256'], 'guard policy bytes')
    return {'sourceSha': binding['candidateSha'], 'base': binding.get('base'), 'sourceManifestSHA256': binding['manifestSHA256'], 'sourceArchiveSHA256': binding['archiveSHA256'], 'sourceFilesByteVerified': len(manifest), 'runtime': p['runtime'], 'nodeBinarySHA256': p['nodeBinarySHA256'], 'canonicalRunnerHashes': p['canonicalRunnerHashes']}

def verify_audit_hashes(audit):
    count = 0
    for a in audit['physicalAttempts']:
        for kind, expected in a['hashes'].items():
            require(digest(Path(a['prefix']).with_suffix(EXT[kind])) == expected, 'old audit raw hash ' + a['prefix'] + EXT[kind])
            count += 1
    return count

result = {'scope': 'Existing immutable cohorts and archive readiness only; no new simulation, statistics search, APP, Git, GH or operator action', 'newSimulationAttempts': 0, 'groups': {}, 'referenceAuditFiles': []}
for label, issue, report_dir, audit_name in SPECS:
    out = ROOT / report_dir
    selection = read(out / 'selection-used.json')
    old = read(out / audit_name)
    group = selection['groups'][label]
    q = Path(group['planDir'])
    p = read(q / 'plan.json')
    binding = read(q / 'candidate-bindings.json')['issues'][str(issue)]
    require(digest(q / 'plan.json') == group['planSHA256'], 'selected plan')
    if 'bindingSHA256' in group:
        require(digest(q / 'candidate-bindings.json') == group['bindingSHA256'], 'selected bindings')
    require(binding['candidateSha'] == group['measuredSourceSha'] == old['actualMeasuredSourceSha'], 'measured source attribution')
    require(not old['failedOrMissing'] and not old.get('originalUnknownRetained', old.get('originalUnknown', [])) and not old.get('selectedRetryOverrides', old.get('overrides', {})), 'old physical audit failure/override')
    gate = verify_gate(q, len(p['attempts']))
    source = verify_source(q, p, binding)
    recovery = read(q / 'active-recovery.json')
    require(not recovery.get('retryOverrides') and not recovery.get('originalUnknown'), 'retry or unknown')
    audited = {a['id']: a for a in old['physicalAttempts']}
    wins = collections.Counter()
    for a in p['attempts']:
        log, proof, _ = physical['load_attempt'](q, p, binding, a, {})
        require(proof['hashes'] == audited[a['id']]['hashes'], 'previous audit hash mismatch')
        wins[a['cell']] += int(log['win'])
    summary = read(out / 'summary.json')
    measured = summary['groups'][label]
    require(summary['analysisScriptSHA256'] == digest(out / 'analyse-used.py') and summary['selectionSHA256'] == digest(out / 'selection-used.json'), 'closed analysis bytes')
    for row in measured['rows']:
        require(row['candidate']['wins'] == wins[row['cell']], 'closed win count differs from primary')
    result['groups'][label] = {'status': 'PASS_EXISTING_PRIMARY', 'analysisDirectory': report_dir, 'planDirectory': str(q.relative_to(ROOT)), 'valid': len(p['attempts']), 'gate': gate, 'source': source, 'winsByCell': dict(sorted(wins.items())), 'physicalArtifactHashesRevalidated': len(p['attempts']) * 7, 'rawErrorsDiscarded': 0, 'retries': 0}
    for ap in out.glob('*audit.json'):
        if ap.name == audit_name:
            continue
        a = read(ap)
        require(not a['failedOrMissing'], 'reference audit failed')
        result['referenceAuditFiles'].append({'path': str(ap.relative_to(ROOT)), 'valid': a['valid'], 'actualMeasuredSourceSha': a['actualMeasuredSourceSha'], 'physicalHashesRevalidated': verify_audit_hashes(a)})

fresh = read(ROOT / 'v36/fresh-armor-closed/summary.json')
fresh_gates = read(ROOT / 'v36/fresh-armor-closed/completion-gates.json')
for name, old in fresh['plans'].items():
    q = Path(fresh_gates[name]['state']['path']).parent
    p = read(q / 'plan.json')
    binding = read(q / 'candidate-bindings.json')['issues']['12']
    require(digest(q / 'plan.json') == old['planSHA256'] and digest(q / 'candidate-bindings.json') == old['bindingSHA256'], 'fresh immutable plan')
    require(binding['candidateSha'] == old['actualMeasuredSourceSha'], 'fresh actual source')
    require(not old['failedOrMissing'] and not old['originalUnknown'] and not old['retryOverrides'], 'fresh failure/unknown/retry')
    gate = verify_gate(q, 60)
    source = verify_source(q, p, binding)
    byid = {a['id']: a for a in old['physicalAttempts']}
    wins = 0
    for a in p['attempts']:
        log, proof, _ = standard['load_attempt'](q, p, binding, a, {})
        require(proof['hashes'] == byid[a['id']]['hashes'], 'fresh previous audit hashes')
        wins += int(log['win'])
    result['groups'][name] = {'status': 'PASS_EXISTING_PRIMARY', 'planDirectory': str(q.relative_to(ROOT)), 'valid': 60, 'arm': old['arm'], 'gate': gate, 'source': source, 'wins': wins, 'physicalArtifactHashesRevalidated': 420}

result['status'] = 'PASS_EXISTING_PRIMARY_2160; future compositions and public transfer NOT_VERIFIED'
(HERE / 'primary-verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'groups': len(result['groups']), 'physicalAttempts': sum(g['valid'] for g in result['groups'].values()), 'referenceAuditFiles': len(result['referenceAuditFiles'])}, indent=2))
