"""Build four explicit existing-evidence packages; no publication or simulation."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent / 'issue-split'

def read(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p, value):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
def external(p): return '../review-followup-20261115/data-evidence/' + p

COMMON = ['prepare-evidence.py', 'runs/final-main45-20261114/baseline-carry-proof.json',
          external('verify-existing.py'), external('primary-verification.json'), external('source-index.json'),
          external('preparation-history.json'),
          '../eight-issues/runs/summarize.py']
GLASS = 'runs/glass-v4-execution-20261114/issue12-glass-v4-8deda7c-lunch'
ARMOR = 'runs/armor-v5-20261114/issue12-armor-v5-2b59642-lunch'
SOLO = 'runs/solo-night31-20261114/issue31-1c93a57-solo-night'
SUPPORT = 'runs/latest-source-20261114/issue41-a996978-latest'
DASH = 'runs/latest-source-20261114/guarded17-421a5d1-latest'
FRESH_GATES = read(ROOT / 'v36/fresh-armor-closed/completion-gates.json')
FRESH_PLANS = [str(Path(g['state']['path']).parent.relative_to(ROOT)) for g in FRESH_GATES.values()]
FRESH_SOURCES = ['runs/fresh-replication-current-20261114/sources/baseline', 'runs/fresh-replication-current-20261114/sources/12']

PACKAGES = {
 'v36-daily-v4-v5-corrections': {
  'pr': 54, 'primary': 840, 'planDirs': [GLASS, ARMOR] + FRESH_PLANS,
  'inputs': [GLASS, ARMOR, *FRESH_PLANS, *FRESH_SOURCES,
    'runs/glass-v4-execution-20261114/durable-master-v5.py', 'runs/glass-v4-execution-20261114/durable-supervise-v3.py', 'runs/glass-v4-execution-20261114/start.log',
    'runs/armor-v5-20261114/durable-master-v5.py', 'runs/armor-v5-20261114/durable-supervise-v3.py', 'runs/armor-v5-20261114/start.log', 'runs/armor-v5-20261114/PREPARED-manifest.json',
    'runs/final-main45-20261114/fresh-replication-preregistration.json',
    'v36/current-subset-analysis/runs/20261114T201749.225071Z', 'v36/current-subset-analysis/runs/20261114T205951.175326Z',
    'v36/current-subset-analysis/GLASS-V4-CLOSED.md', 'v36/current-subset-analysis/glass-public-source-audit.json',
    'v36/current-subset-analysis/armor-v5-closed.log', 'v36/current-subset-analysis/README.md',
    'v36/fresh-armor-closed', 'v36/current-standard-analysis/fresh-armor-preflight',
    'v36/current-standard-analysis/glass-v4-red.log', 'v36/current-standard-analysis/glass-v4-green.log',
    'v36/12-glass-v4-independent/source-proof.json', 'v36/12-glass-v4-independent/REPORT.md',
    'v36/12-armor-v5-independent/source-proof.json', 'v36/12-armor-v5-independent/REPORT.md', 'v36/12-armor-v5-independent/rejects',
    'v36/current-standard-analysis/daily-v3-remote-readback.json'],
  'notes': 'Glass v4 Lunch 300 at 8deda7cf6937f5200139dab79a984acca563c2e0; Armor v5 Lunch 300 at 2b59642ea1ab6552c4fe337cf044d8f280fa766b. Separate old Armor replication 240: 120 baseline actual0ab5f6f and120 v3candidate actual5115e59. Fresh replication is not v5 and is not pooled with standard seeds.',
  'analysis': ['v36/current-subset-analysis/runs/20261114T201749.225071Z', 'v36/current-subset-analysis/runs/20261114T205951.175326Z'],
  'limits': 'Glass human4 13/60=21.67%, Wilson95 [13.12,33.62], below25% by point. Armor v5 human3 26/60=43.33% [31.57,55.90] and human4 27/60=45% [33.09,57.51], above40% by point, intervals wide. Fresh v3 human3 34/60 [44.10,68.43] and human4 28/60 [34.63,59.11] stay separate. No adaptive N or coefficient selection.'},
 'v36-fusion-solo-night-correction': {
  'pr': 58, 'primary': 120, 'planDirs': [SOLO],
  'inputs': [SOLO, 'runs/solo-night31-20261114/start.log', 'runs/solo-night31-20261114/durable-master-v5.py', 'runs/solo-night31-20261114/durable-supervise-v3.py', 'runs/solo-night31-20261114/qa-integrity.json',
    'v36/current-subset-analysis/runs/20261114T203247.318347Z', 'v36/current-subset-analysis/31-solo-closed.log',
    'v36/31-solo-pressure-independent/REPORT.md', 'v36/31-solo-pressure-independent/effective-cells-carry-proof.json',
    'v36/31-solo-pressure-independent/ci-primary', 'v36/current-standard-analysis/31-solo-pressure-red.log', 'v36/current-standard-analysis/31-solo-pressure-green.log',
    'v36/current-standard-analysis/runs/20261114T192222.111582Z/31-audit.json', 'v36/current-standard-analysis/runs/20261114T192222.111582Z/selection-used.json',
    'v36/current-standard-analysis/21-31-publication-build.json'],
  'notes': 'Exactly120 new ordinary soloNight outcomes at1c93a575bb811a6992134e636b2423aa893e054d, dmgMul[0]0.65, cells0/8,60 each. Previous679190c physical600 and a957 ordinary baseline remain distinct references. The other480 prior679 outcomes can carry only under the archived fixed-roster/readset proof and are not120 fresh outcomes or new600.',
  'analysis': ['v36/current-subset-analysis/runs/20261114T203247.318347Z'],
  'limits': 'New human19/60 [21.31,44.23] versus prior9/60 and ordinary28/60; new smart35/60 [45.73,69.94] versus prior23/60. Full paired intervals and method-specific results are retained. Old bb533 failed CI57/58 due to obsolete sim-test expected.75 is preserved beside final1c93 CI58/58; this is history, not failed full-match outcomes.'},
 'v36-support-current600': {
  'pr': 59, 'primary': 600, 'planDirs': [SUPPORT],
  'inputs': [SUPPORT, 'runs/latest-source-20261114/start-41-a996.log', 'runs/latest-source-20261114/prepare-41-a996.log', 'runs/latest-source-20261114/durable-master-v5.py', 'runs/latest-source-20261114/durable-supervise-v3.py',
    'v36/current-standard-analysis/runs/20261114T195626.293858Z', 'v36/current-standard-analysis/41-closed.log',
    'v36/41-window-final-review/source-runtime-binding.json', 'v36/41-window-final-review/main-policy-merge-proof.json',
    'v36/41-window-final-review/REPORT.md', 'v36/41-window-final-review/own-native-initial-float-equality.log',
    'v36/live-current-final/current-retirements.json'],
  'notes': 'Exactly600 outcomes at actuala99697894432856a05a7a4356bef10634d3c1a9c,10 fixed cells60 each, post#45. Retired9683 partial84 with actual masterexit-15 is excluded and retained in retirement metadata. Later policy/deploy-only applicability requires its own source proof; primary is never relabeled.',
  'analysis': ['v36/current-standard-analysis/runs/20261114T195626.293858Z'],
  'limits': 'Wins by cells0..9:26,22,18,21,18,26,15,20,42,42. Human2Night paired normal interval slightly excludes0, bootstrap includes0, exact McNemar p≈0.092; do not call it proven regression or equivalence. #68 remains separate nonblocking debt.'},
 'v36-dash421-current600': {
  'pr': 55, 'primary': 600, 'planDirs': [DASH],
  'inputs': [DASH, 'runs/latest-source-20261114/start-17-421.log', 'runs/latest-source-20261114/prepare-17-421.log', 'runs/latest-source-20261114/drain-for-17.log', 'runs/latest-source-20261114/durable-master-v5.py', 'runs/latest-source-20261114/durable-supervise-v3.py',
    'v36/current-standard-analysis/runs/20261114T211035.145843Z', 'v36/current-standard-analysis/17-closed.log',
    'v36/17-r29-independent/REPORT.md', 'v36/17-r29-independent/final-source-proof.json', 'v36/17-r29-independent/tested-source-proof.json',
    'v36/17-r29-independent/ci-43633531282/primary-proof.json', 'v36/17-r29-independent/ci-wave2-gold-repro.log',
    'v36/live-current-final/current-retirements.json'],
  'notes': 'Exactly600 guarded outcomes at421a5d117e78bc88bbd78622916943cba2a58245;10 fixed cells60 each. The numeric touch-input zero issue at~10^-13 remains open for this source. No attribution to futureea9 or a new composition. Oldc931 unstarted and retired partial30a are not carried.',
  'analysis': ['v36/current-standard-analysis/runs/20261114T211035.145843Z'],
  'limits': 'Wins cells0..9:22,20,24,27,15,31,13,23,40,40. All paired difference intervals cross0. This is not equivalence, acceptance of the numeric-zero fix, or final PR readiness.'},
}

source_index = {
 'baseline': {'archive': 'v36-combat-45-complete.tar.gz', 'sha256': '8504995a1afdedac6f21dd76d856d51ad2a163fd1921a53c57e6f09020d7aea2', 'historicalPublicCommit': '1b33f79', 'path': 'qa-evidence/v36-combat-45-complete', 'measuredSourceSha': 'a957c394460c0f6a67d9ea211c2f5001d64209e1', 'notDuplicated': True},
 'dailyV3': {'archive': 'v36-daily-v3-main45-complete.tar.gz', 'sha256': 'b3116512797e4f257abd8aa986809c181ea85ed2af002b7fc6da6f6b9ab4b434', 'historicalRemoteReadbackCommit': '1f6ffddff53c2d61e76f08552a0a52985ee2fa08', 'path': 'qa-evidence/v36-daily-v3-main45-complete', 'source': '5115e59ceb848e5155f506663573168395cfc1a8'},
 'prior679': {'archive': 'v36-caravans-signatures-main45-complete.tar.gz', 'sha256': '85002f7a79ebf959f94b3448e21bdfc9a92a1369a1a47e8e3427b775c5c9604d', 'localManifest': 'outputs/issue-split/publication/v36-caravans-signatures-main45-complete/members.json', 'source': '679190c7ec5bb979761660593cca0ff1e1da6cbe', 'matchingRawMembers': 5400, 'publicTransferNotVerifiedThisTask': True},
 'limits': ['No web/GH/Git lookup or publication performed in this task.', 'Historical source pointers are existing metadata, not a live availability check.', 'All corrected cohorts use their historical13c-based source, not currente19 main; no inference of joint-composition acceptance.', 'Source archives and binary source assets are excluded by the unchanged builder; recorded public Git commit and source manifests retain reconstruction identity.']}
save(HERE / 'source-index.json', source_index)

summary = []
for name, config in PACKAGES.items():
    aliases = []
    alias_dir = HERE / 'preserved-text' / name
    for relative in config['planDirs']:
        for path in sorted((ROOT / relative).rglob('*')):
            if path.is_file() and path.suffix in {'.stderr', '.plist'}:
                rel = path.relative_to(ROOT)
                target = alias_dir / (str(rel) + '.txt')
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(path.read_bytes())
                aliases.append({'original': str(rel), 'archiveAlias': str(target.relative_to(HERE)), 'sha256': sha(path), 'bytes': path.stat().st_size, 'byteEqual': target.read_bytes() == path.read_bytes()})
    save(alias_dir / 'original-paths.json', {'reason': 'Unchanged builder excludes.stderr/.plist suffixes; byte-preserved text aliases retain exact existing primary content without altering originals.', 'files': aliases})
    scope = HERE / 'scopes' / (name + '.md')
    scope.parent.mkdir(parents=True, exist_ok=True)
    scope.write_text(f'# PR{config["pr"]}: {name}\n\nExisting primary audit PASS; physical attempts in this package: **{config["primary"]}**. Product/balance acceptance and new-main integration are separate.\n\n{config["notes"]}\n\n{config["limits"]}\n\n## Boundaries\n\nNo new simulation, seed, sample size, coefficient, external call, APP/Git/GH/operator change or publication. Archived reports can contain historical preparation/HOLD/READY wording: their original timestamps and scope remain unchanged and do not override the later primary-verification or current limits. No error history or raw bytes are cleaned. The baseline accepted600a957 archive is referenced by source-index.json and not duplicated. Original Dailyv3 and prior679 archives are separately identified; their full raw is not silently counted as new candidate outcomes.\n\nNo old result is evidence for currente19 main with Horde/caravans/lastCrit changes. These packages do not establish whole-PR READY. Any later source carry requires exact canonical closure and policy equality proof against the recorded source, or separately authorized measurement of changed compositions. Physical weak-phone, CPU and production multiplayer acceptance are outside this task.\n\n## Verification\n\nverify-existing.py revalidated all2160 candidate/fresh physical attempts and reference-audit hashes using existing primary logs, exact tuple, per-attempt source/runtime/argv/environment, terminal Room.finish/over/log and observed nativeexit0; all9 controller groups have terminal/done/scope complete and active0/pending0/failed0/unknown0 plus observed masterexit0. Full counts/hashes are in primary-verification.json. Node24.22.1, binarycf52d093e9b728a7e6929a4371fa37d271304383e7e7c9f0f0e32fb00373b32c; canonical runnersb270c568/a35bd680. The unchanged prepare-evidence.py creates deterministic tar.gz/members/SHA256SUMS. Archive bytes, members, raw counts, forbidden paths and a second build are independently checked in the adjacent archive-proof.json outside the archive inputs.\n\n## Existing analyses\n\n' + '\n'.join('- outputs/issue-split/' + p for p in config['analysis']) + '\n')
    inputs = COMMON + config['inputs'] + [external('scopes/' + scope.name), external('preserved-text/' + name)]
    # Never include mutable builder stdout or the archive-proof output as an input.
    save(HERE / 'inputs' / (name + '.json'), {'name': name, 'paths': inputs, 'primaryPhysicalAttempts': config['primary']})
    command = [sys.executable, str(ROOT / 'prepare-evidence.py'), name, *inputs, '--build']
    first = subprocess.run(command, capture_output=True, text=True, check=True)
    metadata = json.loads(first.stdout)
    save(HERE / 'build-metadata' / (name + '.json'), metadata)
    archive = Path(metadata['archive'])
    manifest_path = archive.parent / 'members.json'
    manifest_raw = manifest_path.read_bytes()
    manifest = json.loads(manifest_raw)
    with tarfile.open(archive, 'r:gz') as tar:
        members = tar.getmembers()
        assert len(members) == len(manifest['files']) + 1
        assert len({m.name for m in members}) == len(members)
        assert tar.extractfile('members.json').read() == manifest_raw
        for f in manifest['files']:
            member = tar.getmember('outputs/' + f['path'])
            raw = tar.extractfile(member).read()
            assert len(raw) == f['bytes'] and hashlib.sha256(raw).hexdigest() == f['sha256']
            assert raw == (ROOT.parent / f['path']).read_bytes()
            assert member.isfile() and member.mtime == 0 and member.mode == 0o644
            assert not any(x in {'node_modules', '.git', '.env', '.cache', '__pycache__'} for x in Path(f['path']).parts)
        primary_raw = sum('/raw/' in f['path'] and Path(f['path']).suffixes == ['.json'] for f in manifest['files'])
    assert primary_raw == config['primary'], (name, primary_raw, config['primary'])
    assert sha(archive) == metadata['sha256']
    second = subprocess.run(command, capture_output=True, text=True, check=True)
    assert json.loads(second.stdout) == metadata and manifest_path.read_bytes() == manifest_raw
    assert sha(archive) == metadata['sha256']
    proof = {**metadata, 'primaryPhysicalAttempts': primary_raw, 'status': 'PASS_LOCAL_ARCHIVE', 'archiveMemberCountIncludingManifest': len(members), 'allMemberHashesAndCurrentLocalBytesEqual': True, 'secondBuildByteIdentical': True, 'forbiddenPaths': [], 'binarySourceAssetsIncluded': False, 'textAliases': len(aliases), 'excludedKinds': manifest['excludedFileKinds'], 'publication': 'NOT_PERFORMED; remote transfer/availability NOT_VERIFIED', 'futureMainComposition': 'NOT_VERIFIED'}
    save(HERE / 'archive-proofs' / (name + '.json'), proof)
    summary.append(proof)
    print(json.dumps({k: proof[k] for k in ['archive', 'files', 'primaryPhysicalAttempts', 'archiveBytes', 'sha256', 'status']}, ensure_ascii=False), flush=True)
save(HERE / 'archive-proof.json', summary)
