import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
const repo='/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/work/night-horde-issue-31';
const out=path.dirname(new URL(import.meta.url).pathname);
const [stage,...suites]=process.argv.slice(2),dir=path.join(out,stage),data=path.join(dir,'owned-run-data');
fs.mkdirSync(data,{recursive:true});
const exec=(...args)=>spawnSync('git',args,{cwd:repo,encoding:'utf8'}).stdout.trim();
const attribution={node:process.version,exe:process.execPath,head:exec('rev-parse','HEAD'),main:'e19e0041505acc30bd7e6d950eedcf2feabdb395',mergeHead:exec('rev-parse','--verify','MERGE_HEAD'),diff:exec('diff','--stat'),started:new Date().toISOString()};
fs.writeFileSync(path.join(dir,'attribution.json'),JSON.stringify(attribution,null,2)+'\n');
const results=[];
for(const suite of suites){
 const command=[process.execPath,'--import',path.join(repo,'pm/test-runtime.mjs'),'server/'+suite+'-test.js'];
 const r=spawnSync(command[0],command.slice(1),{cwd:path.join(repo,'app'),encoding:'utf8',timeout:180000,maxBuffer:32*1024*1024,env:{...process.env,HORDE_RUNS_DIR:data,VIBE_APP_KEY:''}});
 const output=(r.stdout??'')+(r.stderr??'')+(r.error?String(r.error):'');
 fs.writeFileSync(path.join(dir,suite+'.log'),output);
 results.push({suite,command,exit:r.status,signal:r.signal,status:r.status===0?'PASS':'FAIL'});
 console.log(`${results.at(-1).status} ${suite}`);
 if(r.status!==0)console.log(output.slice(-1800));
 fs.writeFileSync(path.join(dir,'results.json'),JSON.stringify({attribution,results},null,2)+'\n');
}
fs.rmSync(data,{recursive:true,force:true});
fs.writeFileSync(path.join(dir,'cleanup.json'),JSON.stringify({data,exists:fs.existsSync(data),finished:new Date().toISOString()},null,2)+'\n');
console.log(`${results.filter(r=>r.status==='PASS').length}/${results.length} passed`);
if(results.some(r=>r.status!=='PASS'))process.exitCode=1;
