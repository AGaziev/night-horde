# PR58 / Issue31: author integration report

Final local head: `54fc25b9f0af42b0a5d7d46e83ae7b9434973884` on `codex/31-signature-fusions`.
Worktree: `/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/work/night-horde-issue-31`. Runtime: `/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node` (`v24.22.1`), with `pm/test-runtime.mjs`.
This is the implementing author's verification. It is not independent READY or full product acceptance.

## Commits

- `d2c126632c89af8f5b63493b8fb43cbd9a8ece89`: ordinary merge, parents `1c93a575bb811a6992134e636b2423aa893e054d` and `e19e0041505acc30bd7e6d950eedcf2feabdb395`; tree `bbbe1b522a06551bcb4e291027a2b667abebc98c`. Resolved six files' protocol/version/wording conflicts to GAME v37 / PROTO32. Automatically merged Horde, caravans and the existing feature semantics were checked against both parents.
- `54fc25b9f0af42b0a5d7d46e83ae7b9434973884`: test-only adaptation. The two feature client loaders now rewrite every `/shared/` import after Horde added `horde-content.js`; cancellation/key-recovery assertions remain intact. The actual Hub welcome compatibility tests now include main31 and feature30 reload to32.

No reset, rebase, stash, force, push, GitHub write, main merge or deployment was performed.

## Verification

46 unique native suites PASS. `verification-summary.json` retains each exact command, stage, status and log path. `merge-check` ran on the resolved merge tree recorded above before committing; `harness-after` ran on the final test-only diff before committing it. Later integration suites and invariants ran at the final head; runtime has not changed since the merge commit.

Commands used:

```sh
/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node /Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/review-followup-20261115/fusion-author/verify.mjs merge-check solo-night-pressure fusion-effect-source fusion-focus fusion-inheritance fusion-shield-state finale v20 v22 horde-mode horde-combat horde-round caravan-placement
/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node /Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/review-followup-20261115/fusion-author/verify.mjs harness-before fusion-signature fusion-key-recovery offer-identity sniper-lowfps-warning
/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node /Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/review-followup-20261115/fusion-author/verify.mjs harness-after fusion-signature fusion-key-recovery offer-identity sniper-lowfps-warning
/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node /Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/review-followup-20261115/fusion-author/verify.mjs integration horde-review-game horde-movement-gap horde-resync horde-sniper-origin horde-client horde-client-transport horde-transport horde-compatibility caravans caravans-client movement-client movement-net lobby-invites lobby-invites-client lobby-invites-http contact-order combat-footprint projectile-expiry slash-corner codec forge-log artifacts builds offer-refresh-client
PATH=/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:$PATH npm ci --ignore-scripts --no-audit --no-fund  # cwd=worktree/app; added the lockfile's sole ws dependency
/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node /Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/review-followup-20261115/fusion-author/verify.mjs transport-after-install horde-transport horde-compatibility lobby-invites lobby-invites-http
/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node /Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/review-followup-20261115/fusion-author/verify.mjs related-native hero-perks mr1-review wave2 confluences duos2 fortune-forge
HORDE_RUNS_DIR=/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/review-followup-20261115/fusion-author/invariant-run-data /Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node --import ./pm/test-runtime.mjs /Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/review-followup-20261115/fusion-author/merge-invariants.mjs
```

Initial failures are preserved: two feature loader failures (`ERR_UNSUPPORTED_RESOLVE_REQUEST` for the new shared import) were corrected by the test-only commit; four transport failures (`ERR_MODULE_NOT_FOUND: ws`) were corrected by lockfile dependency installation, then all four passed. The custom comparison helper initially called the newly extended spawnEnemy positional parameter against the old engine, which ignored it and consumed placement RNG; both engines now receive the common three-argument API and identical positions afterward. Both rejected fixture logs remain separately named; they do not indicate a product regression.

`merge-invariants.json` records the focused integration checks:

- Exact deep equality of MODES, all39 DUOS definitions, EVOS, PASSIVES, WEAPONS and FINALE with `1c93a57`; this is a content-preservation comparison, not a new39-recipe combat audit. Solo Night remains damage0.65 / HP1.8; other mode/group entries retain the feature's prior values.
- Both standard modes, live2→1: existing ordinary enemy and boss HP/maxHP/damage/damage multiplier scale exactly once to the current solo entry; zero RNG draws; repeated removal changes nothing.
- Four1-second PvE controls at time100 (Night/Lunch, one/two heroes) with orb+knives and an actual boss: state, damage attribution, timing and RNG consumption match pre-merge feature code under the same controlled random stream. They are short integration controls, not terminal outcomes or balance samples. Old game code is loaded from Git with relative imports resolved against current dependencies, which remain unchanged for these compared mechanics; only GAME_VERSION metadata differs.
- Active Horde: a native offerEpoch pick creates orb from bolt+lightning, frees one slot, retires source missiles, retains independent knife missiles and the might artifact; actual Room ticks dispatch only orb+knives and credit only those sources. Horde pressure remains1/1 and no caravan is created.
- Ten main modules match e19 exactly: caravans, Horde mode/combat/shared content, outposts, Net, main UI dispatch, Horde UI, server transport and invitations. Ten Room methods match e19 exactly: step chronology, rescaleGroup, updatePlayers, moveEnemies, updateHostile, guard dispatch, onPos, bossTick, bossStep and spawnEnemy.
- Feature client shotEvent/effect and renderer visualWeapons remain identical to the accepted pre-merge feature paths. Fresh native lost-cancel→wire-key recovery, current client protocol tests, actual WS/SSE Horde compatibility/resync and invitation HTTP paths passed.

## Evidence carry and limits

The former600 outcomes and the root-audited120 new0.65 outcomes keep their original runtime/source/baseline attribution. I did not rerun, rename or modify those raw results. Content equality supports carrying the measured tuning choice and unchanged signature definitions. Short matched controls and unchanged main methods support integration of the ordinary combat paths. They do not establish new full-run win rates on e19: caravans appear during35–55% of standard runs, add guards/rewards, and consume RNG. Historical totals must not be presented as fresh outcomes measured on the new main.

Prior browser evidence may be carried narrowly for the unchanged feature inventory/rendering/cancellation paths based on the method/content equality and fresh native client/key checks. No fresh Chrome/mobile/FPS run was made in this task, so no browser result is relabelled as measured on54fc25b. Current main's Horde/caravan UI was retained; ordinary movement, client status/telegraphs and network controls received targeted native checks. Independent reviewers determine sufficiency of this carry for their area.

Full local sim-test, buildcraft benchmark, FPS, new seed/sample/parameter matrices and a new general39-recipe audit were deliberately not run. Full Linux Server CI remains for root after publication, then independent applicable reviews; this report does not declare READY.

## Cleanup

`cleanup.json`: tracked and untracked worktree clean; no owned Node processes with worktree cwd; no suite run-data directories; invariant data absent. Test servers' own teardown closes ephemeral clients/listeners and removes their temporary directories. The worktree's installed ignored node_modules remains for normal development; no game data or persistent test server remains. Reports/helpers/logs were written only in this assigned output folder; other worktrees and shared QA registries/raw were not changed.
