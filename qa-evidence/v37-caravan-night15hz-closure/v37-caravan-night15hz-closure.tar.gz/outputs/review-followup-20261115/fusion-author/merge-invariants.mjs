import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
const repo='/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/work/night-horde-issue-31';
const out=path.dirname(new URL(import.meta.url).pathname),before='1c93a575bb811a6992134e636b2423aa893e054d',main='e19e0041505acc30bd7e6d950eedcf2feabdb395';
const git=(...args)=>execFileSync('git',args,{cwd:repo,encoding:'utf8'}).trim();
const loadOld=async(file,revision=before)=>{
 const url=pathToFileURL(path.join(repo,file));
 const source=git('show',revision+':'+file).replace(/from (['"])(\.[^'"]+)\1/g,(_,q,specifier)=>'from '+JSON.stringify(new URL(specifier,url).href));
 return import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
};
const {Room}=await import(pathToFileURL(path.join(repo,'app/server/game.js')));
const {Room:BeforeRoom}=await loadOld('app/server/game.js');
const content=await import(pathToFileURL(path.join(repo,'app/public/shared/content.js')));
const oldContent=await loadOld('app/public/shared/content.js');
for(const key of ['MODES','DUOS','EVOS','PASSIVES','WEAPONS','FINALE'])assert.deepEqual(content[key],oldContent[key],key+' must retain the previously measured feature settings');
assert.equal(Object.keys(content.DUOS).length,39);
assert.equal(content.MODES.night.dmgMul[0],.65);assert.equal(content.MODES.night.hpMul[0],1.8);
const results={head:git('rev-parse','HEAD'),before,main,node:process.version,contentEquality:['MODES','DUOS','EVOS','PASSIVES','WEAPONS','FINALE'],duos:39,scaling:[],pveRng:[],horde:[]};
const close=(a,b,message)=>assert.ok(Math.abs(a-b)<1e-8*Math.max(1,Math.abs(b)),message+`: ${a} != ${b}`);
for(const mode of ['night','lunch']){
 const r=new Room('SCALING',()=>{});r.setMode(mode);r.addPlayer(1,'One','ranger');r.addPlayer(2,'Two','witch');r.start();r.time=100;
 const alive=[...r.heroes.values()];
 const enemy=r.spawnEnemy('skel',alive,content.enemyHpScale(r.nt,2));
 const boss=r.spawnEnemy('boss',alive,content.bossHpScale(r.nt,2,0));
 const beforeRows=[enemy,boss].map(e=>({hp:e.hp,maxHp:e.maxHp,dmg:e.dmg,dmgMul:e.dmgMul}));
 let draws=0;const original=Math.random;Math.random=()=>{draws++;return .5;};
 try{
  r.removePlayer(2);
  assert.equal(r.modeDmg,mode==='night'?.65:.75);assert.equal(r.modeHp,mode==='night'?1.8:1.9);
  for(const [i,e] of [enemy,boss].entries()){
   const scale=e.boss?content.bossHpScale:content.enemyHpScale;
   const hpK=scale(r.nt,1)/scale(r.nt,2)*content.modeHpMul(mode,1)/content.modeHpMul(mode,2);
   const dmgK=content.enemyDmgScale(r.nt,1)/content.enemyDmgScale(r.nt,2)*content.modeDmgMul(mode,1)/content.modeDmgMul(mode,2);
   close(e.hp,beforeRows[i].hp*hpK,mode+' HP');close(e.maxHp,beforeRows[i].maxHp*hpK,mode+' maxHP');
   close(e.dmg,beforeRows[i].dmg*dmgK,mode+' damage');close(e.dmgMul,beforeRows[i].dmgMul*dmgK,mode+' damage multiplier');
  }
  const once=[enemy,boss].map(e=>({hp:e.hp,maxHp:e.maxHp,dmg:e.dmg,dmgMul:e.dmgMul}));
  r.removePlayer(2);assert.deepEqual([enemy,boss].map(e=>({hp:e.hp,maxHp:e.maxHp,dmg:e.dmg,dmgMul:e.dmgMul})),once,'duplicate departure cannot rescale twice');
  assert.equal(draws,0,'2→1 scaling is RNG neutral');
  results.scaling.push({mode,modeHp:r.modeHp,modeDmg:r.modeDmg,rngDraws:draws,ordinary:once[0],boss:once[1],duplicateDepartureUnchanged:true});
 }finally{Math.random=original;}
}
function pveScene(Engine,mode,count){
 let draws=0;const original=Math.random,stream=[.13,.78,.42,.96,.27,.61,.08,.83];Math.random=()=>stream[draws++%stream.length];
 try{
  const room=new Engine('CONTROL',()=>{});room.setMode(mode);
  for(let i=1;i<=count;i++)room.addPlayer(i,'P'+i,'ranger');
  room.start();room.time=100;room.enemies=[];const h=room.heroes.get(1);h.x=h.y=0;
  h.weapons=new Map([['orb',{lvl:1,t:0}],['knives',{lvl:3,t:0}]]);
  for(const [i,type] of ['skel','brute','boss'].entries()){
   const e=room.spawnEnemy(type,[...room.heroes.values()],1);Object.assign(e,{x:100+i*45,y:0,hp:1e6,maxHp:1e6,speed:0,dmg:0});
  }
  for(let i=0;i<30;i++)room.tick(1/30);
  assert.equal(room.state,'play');assert.equal(room.caravan??null,null,'control predates the new caravan window');
  return {draws,time:room.time,heroes:[...room.heroes.values()].map(h=>({hp:h.hp,xp:h.xp,level:h.level,dmg:h.dmg,dmgBy:h.dmgBy,weapons:[...h.weapons]})),enemies:room.enemies.map(e=>({id:e.id,type:e.type,x:e.x,y:e.y,hp:e.hp,dmg:e.dmg,boss:e.boss})),fx:room.fx};
 }finally{Math.random=original;}
}
for(const mode of ['night','lunch'])for(const count of [1,2]){
 const old=pveScene(BeforeRoom,mode,count),current=pveScene(Room,mode,count);
 assert.deepEqual(current,old,'ordinary PvE signature scene retains state and RNG before caravan progression');
 results.pveRng.push({mode,count,seconds:1,rngDraws:current.draws,identicalState:true,bossIncluded:true});
}
{
 const room=new Room('HORDE',()=>{});room.addPlayer(1,'Director','witch');assert.equal(room.setRuleset('horde'),null);room.addPlayer(2,'Hero','ranger');assert.equal(room.start(),true);
 const hero=room.heroes.get(2);room.time=100;hero.x=hero.y=0;hero.perk.readyAt=Infinity;
 hero.weapons=new Map([['bolt',{lvl:3,t:0}],['lightning',{lvl:3,t:0}],['knives',{lvl:3,t:0}]]);
 hero.passives.set('might',2);room.recalcMods(hero);
 const enemy=room.spawnEnemy('brute',[hero],1,[130,0]);Object.assign(enemy,{hp:1e6,maxHp:1e6,speed:0,dmg:0});room.rebuildGrid();
 room.updateWeapon(hero,'bolt',hero.weapons.get('bolt'),1/30);room.updateWeapon(hero,'knives',hero.weapons.get('knives'),1/30);
 const consumed=new Set(room.projectiles.filter(p=>p.src.weapon==='bolt').map(p=>p.id)),unrelated=new Set(room.projectiles.filter(p=>p.src.weapon==='knives').map(p=>p.id));
 assert.ok(consumed.size>0&&unrelated.size>0);
 const native=room.castWeapon,dispatch=[];room.castWeapon=function(h,id,...args){dispatch.push(id);return native.call(this,h,id,...args);};
 hero.offer=[room.duoCard(hero,{id:'orb',a:'bolt',b:'lightning'})];room.sendOffer(hero);
 room.handle(hero.pid,{t:'pick',i:0,offerEpoch:hero.offerEpoch});
 assert.ok(hero.weapons.has('orb'));assert.equal(hero.weapons.size,2);assert.equal(hero.passives.get('might'),2);
 assert.ok(room.projectiles.every(p=>!consumed.has(p.id)));assert.ok([...unrelated].every(id=>room.projectiles.some(p=>p.id===id)));
 for(let i=0;i<30;i++)room.tick(1/30);
 assert.ok(dispatch.includes('orb')&&dispatch.includes('knives'));assert.ok(!dispatch.includes('bolt')&&!dispatch.includes('lightning'));
 assert.ok(hero.dmgBy.orb>0&&hero.dmgBy.knives>0);assert.equal(hero.dmgBy.bolt??0,0);assert.equal(hero.dmgBy.lightning??0,0);
 assert.equal(room.modeDmg,1);assert.equal(room.modeHp,1);assert.equal(room.caravan,null);assert.equal(room.state,'play');
 assert.equal(room.weaponContext,undefined);results.horde.push({nativePick:true,seconds:1,dispatch:[...new Set(dispatch)],damageBy:hero.dmgBy,modeDmg:room.modeDmg,modeHp:room.modeHp,consumedIds:[...consumed],unrelatedIds:[...unrelated],passiveRetained:true});
}
const unchangedMain=['app/server/caravans.js','app/server/horde-mode.js','app/server/horde-combat.js','app/public/shared/horde-content.js','app/server/outposts.js','app/public/js/net.js','app/public/js/main.js','app/public/js/horde-ui.js','app/server/server.js','app/server/lobby-invites.js'];
for(const file of unchangedMain)assert.equal(fs.readFileSync(path.join(repo,file),'utf8').trim(),git('show',main+':'+file),file+' must retain main');
results.mainModuleEquality=unchangedMain;
const {Room:MainRoom}=await loadOld('app/server/game.js',main);
const mainMethods=['step','rescaleGroup','updatePlayers','moveEnemies','updateHostile','confineGuard','onPos','bossTick','bossStep','spawnEnemy'];
for(const method of mainMethods)assert.equal(Room.prototype[method].toString(),MainRoom.prototype[method].toString(),method+' must retain current main chronology/guards/movement/scaling');
results.mainMethodEquality=mainMethods;
const loadClient=async(revision)=>{
 const file='app/public/js/game.js';
 const text=(revision?git('show',revision+':'+file):fs.readFileSync(path.join(repo,file),'utf8')).replaceAll("'/shared/", "'"+pathToFileURL(path.join(repo,'app/public/shared/')).href);
 return import('data:text/javascript;base64,'+Buffer.from(text).toString('base64'));
};
const {Game:Client}=await loadClient(),{Game:OldClient}=await loadClient(before);
const retainedClientMethods=['shotEvent','effect'];
for(const method of retainedClientMethods)assert.equal(Client.prototype[method].toString(),OldClient.prototype[method].toString(),method+' keeps previously accepted fusion rendering/cancellation semantics');
results.clientMethodEquality=retainedClientMethods;
const renderer=fs.readFileSync(path.join(repo,'app/public/js/render.js'),'utf8'),oldRenderer=git('show',before+':app/public/js/render.js');
const visualWeapons=s=>s.match(/const visualWeapons = .*;/)?.[0];
assert.ok(visualWeapons(renderer));assert.equal(visualWeapons(renderer),visualWeapons(oldRenderer));
results.visualWeaponsUnchanged=true;
fs.writeFileSync(path.join(out,'merge-invariants.json'),JSON.stringify(results,null,2)+'\n');
console.log(JSON.stringify(results,null,2));
