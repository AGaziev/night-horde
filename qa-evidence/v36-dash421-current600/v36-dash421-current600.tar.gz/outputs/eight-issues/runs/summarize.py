import pathlib,json,math,statistics,re,collections,random,datetime
OUT=pathlib.Path(__file__).resolve().parent;PLAN=json.loads((OUT/'plan.json').read_text())
def mapping(rev):
 content=(OUT/rev/'app/public/shared/content.js').read_text();cf=(OUT/rev/'app/public/shared/confluences.js').read_text()
 h={m[0]:m[1] for m in re.findall(r'\n\s*(\w+):\s*\{[^}]*?weapon:\s*\x27(\w+)\x27',content[content.index('export const HEROES'):content.index('// Run modes')],re.S)}
 duos={}
 block=content[content.index('export const DUOS'):content.index('export const EVOS')]
 for m in re.finditer(r'\n\t(\w+):\s*\{(.*?)(?=\n\t\w+:\s*\{|\Z)',block,re.S):
  parts=re.search(r'parts:\s*\[([^]]+)\]',m[2]);
  if parts:duos[m[1]]=re.findall(r"'(\w+)'",parts[1])
 for m in re.finditer(r"\n\s*(\w+):\s*duo\([^\n]*?\[([^]]+)\]",cf):duos[m[1]]=re.findall(r"'(\w+)'",m[2])
 evos={}
 for m in re.finditer(r'\n\t(\w+):\s*\{(.*?)(?=\n\t\w+:\s*\{|\Z)',content[content.index('export const EVOS'):],re.S):
  src=re.search(r"from:\s*'(\w+)'",m[2]);
  if src:evos[m[1]]=src[1]
 return h,duos,evos
MAP={r:mapping(r) for r in ['baseline','candidate']}
def weaponsAt(t,at,rev):
 h,d,e=MAP[rev];owned={h[t['hero']]}; uncertain=False
 for pick in t['picks']:
  when,_,action,id,kind=pick[:5]
  if when>at:break
  if action!='pick':continue
  if kind=='weapon':owned.add(id)
  if kind=='duo':
   for part in d.get(id,[]):owned.discard(part)
   owned.add(id)
  if kind=='evo':owned.discard(e.get(id));owned.add(id)
  if kind=='imprint':uncertain=True
 return len(owned),sorted(owned),uncertain

def wilson(w,n):
 if not n:return None
 z=1.96;p=w/n;den=1+z*z/n;c=(p+z*z/2/n)/den;h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
 return [round((c-h)*100,2),round((c+h)*100,2)]
def pairStats(pairs):
 n=len(pairs)
 if not n:return {'n':0}
 d=[int(c['win'])-int(b['win']) for b,c in pairs];m=statistics.mean(d);se=statistics.stdev(d)/math.sqrt(n) if n>1 else 0
 return dict(n=n,deltaPP=round(m*100,2),pairedNormal95CI=[round((m-1.96*se)*100,2),round((m+1.96*se)*100,2)],lostWins=sum(b['win'] and not c['win'] for b,c in pairs),gainedWins=sum(not b['win'] and c['win'] for b,c in pairs))
def stats(rs,rev):
 death=collections.Counter();deathmin=collections.Counter();boss={};duos=collections.Counter();mid=[];midids=[];uncertain=0;validation=[];supports=collections.Counter();downs=[]
 for r in rs:
  for t in r['team']:
   for x in t['deaths']:death[x['from']]+=1;deathmin[int(x['t']//60)+1]+=1;downs.append(x['t'])
   for when,id in t['duos']:duos[id]+=1
   if r['time']>=r['runLength']/2:
    n,ids,u=weaponsAt(t,r['runLength']/2,rev);mid.append(n);midids.append({'runId':r['id'],'pid':t['pid'],'weapons':ids});uncertain+=u
   n,ids,u=weaponsAt(t,r['time']+1,rev)
   if not u and n!=len(t['build']['weapons']):validation.append({'runId':r['id'],'pid':t['pid'],'reconstructed':ids,'actual':t['build']['weapons']})
   supports.update(t.get('support',{}))
  for b in r['bosses']:
   row=boss.setdefault(b['type'],dict(encounters=0,kills=0,damage=0,hp=0,dps=[],secondsToKill=[]));row['encounters']+=1;row['kills']+=b['killedAt'] is not None;row['damage']+=b['dmg'];row['hp']+=b['hp'];row['dps'].append(b['dps']);
   if b['sec'] is not None:row['secondsToKill'].append(b['sec'])
 for row in boss.values():row['meanDpsWhenNear']=round(statistics.mean(row['dps']),2);row['medianSecondsToKill']=statistics.median(row['secondsToKill']) if row['secondsToKill'] else None;row['damageFraction']=round(row['damage']/row['hp'],4) if row['hp'] else None;del row['dps']
 wins=sum(r['win'] for r in rs);fin=[r['finale'] for r in rs if r['finale'] and r['finale'].get('at') is not None]
 return dict(terminal=len(rs),wins=wins,winPercent=round(wins*100/len(rs),2) if rs else None,wilson95=wilson(wins,len(rs)),medianTerminalSeconds=statistics.median(r['time'] for r in rs) if rs else None,deathCauses=dict(death),deathMinutes=dict(sorted(deathmin.items())),downs=len(downs),medianDownSeconds=statistics.median(downs) if downs else None,bosses=boss,meanBossDamagePerRun=round(statistics.mean(sum(b['dmg'] for b in r['bosses']) for r in rs),2) if rs else None,duos=dict(duos),midWeaponsMean=round(statistics.mean(mid),3) if mid else None,midWeaponsDistribution=dict(sorted(collections.Counter(mid).items())),midPlayers=len(mid),midRuns=sum(r['time']>=r['runLength']/2 for r in rs),midImprintUncertain=uncertain,midWeaponRows=midids,inventoryEndValidationMismatches=validation,finale=dict(reached=len(fin),gold=sum(f.get('grade')==2 for f in fin),silver=sum(f.get('grade')==1 for f in fin),lost=sum(f.get('grade',0)==0 for f in fin)),supportTotals=dict(supports),budgetOverruns=[r['id'] for r in rs if r['time']>r['runLength']+.11])
rows=[];statuses=[]
for ci,cell in enumerate(PLAN['cells']):
 data={};by={}
 for rev in ['baseline','candidate']:
  rs=[];by[rev]={};failed=[];notstarted=[]
  for a in [a for a in PLAN['attempts'] if a['cell']==ci]:
   f=OUT/f"raw/{rev}/{a['id']}.meta.json"
   m=json.loads(f.read_text()) if f.exists() else None
   status='terminal' if m and m.get('terminalProof') is True else 'notStarted' if not m or m.get('executionStatus')=='notStarted' else 'failed'
   statuses.append(dict(revision=rev,id=a['id'],seed=a['seed'],K0=a['K0'],status=status))
   if status=='terminal':
    r=json.loads((OUT/f"raw/{rev}/{a['id']}.json").read_text())['logs'][0];rs.append(r);by[rev][a['id']]=r
   elif status=='failed':failed.append(m)
   else:notstarted.append(a['id'])
  data[rev]=stats(rs,rev);data[rev].update(failed=failed,notStarted=notstarted)
 pairs=[(b,by['candidate'][id]) for id,b in by['baseline'].items() if id in by['candidate']]
 rows.append(dict(cell=ci,**cell,**data,paired=pairStats(pairs),complete=len(pairs)==60 and not data['baseline']['failed'] and not data['candidate']['failed']))
result=dict(generatedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline=PLAN['baseline'],candidate=PLAN['candidate'],runtime=PLAN['runtime'],metricsNotes=['Death means every down event, including revivable coop downs; death minute is floor(t/60)+1','Midrun inventory reconstructed from canonical hero weapon and chronological weapon/evo/duo picks; imprint rows marked uncertain','Midrun inventory excludes runs that ended before midpoint; denominator explicit','Boss damage and finale reach are affected by survival/progression and are not standalone causal DPS metrics','Paired CI is a normal approximation of per-pair binary win differences; Wilson intervals for individual win rates','Initial candidate paused on root request after significant first-cell regression; notStarted counts are not simulation errors'],rows=rows)
(OUT/'summary-initial.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');(OUT/'attempt-status-initial.json').write_text(json.dumps(statuses,indent=2)+'\n')
print('cell | bot N mode | baseline terminal/wins | candidate terminal/wins | paired delta95CI')
for x in rows:print(x['cell'],x['bot'],x['players'],x['mode'],x['baseline']['terminal'],x['baseline']['wins'],x['candidate']['terminal'],x['candidate']['wins'],x['paired'])
print('inventory end mismatches',sum(len(x[r]['inventoryEndValidationMismatches']) for x in rows for r in ['baseline','candidate']))
