#!/usr/bin/env python3
"""Package explicitly selected local QA paths without credentials or dependencies.

No publication occurs here. Every input file is hashed; raw bytes are preserved.
Archives are deterministic and reproducible from their member manifests.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

ROOT = Path(__file__).resolve().parent
OUTPUTS = ROOT.parent
ALLOWED = {'.json', '.jsonl', '.js', '.mjs', '.cjs', '.py', '.md', '.txt', '.log', '.csv', '.css', '.html', '.sha256', '.toml', '.yaml', '.yml', '.diff', '.patch'}
SKIP_PARTS = {'node_modules', '.git', '.cache', '__pycache__'}
SECRET = re.compile(rb'(?:vibe_api_[A-Za-z0-9_-]{20,}|gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|Bearer[ \t]+[A-Za-z0-9_-]{25,})')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('name')
    parser.add_argument('paths', nargs='+', help='Paths relative to outputs/issue-split')
    parser.add_argument('--build', action='store_true')
    parser.add_argument('--include-qa-png', action='store_true', help='Include isolated QA screenshots, excluding app and frozen source assets')
    args = parser.parse_args()
    if not re.fullmatch(r'[a-zA-Z0-9_-]+', args.name):
        raise SystemExit('Unsafe archive name')
    files = {}
    skipped = {}
    for relative in args.paths:
        source = (ROOT / relative).resolve()
        if not source.is_relative_to(OUTPUTS) or not source.exists():
            raise SystemExit(f'Input outside scope or missing: {relative}')
        for path in ([source] if source.is_file() else source.rglob('*')):
            rel = path.relative_to(OUTPUTS)
            if any(part in SKIP_PARTS for part in rel.parts):
                skipped['dependency-or-cache'] = skipped.get('dependency-or-cache', 0) + 1
                continue
            if path.is_symlink():
                # Alias targets must be passed explicitly as inputs; never walk
                # a symlink or silently include a path outside this scope.
                skipped['symlink-alias:' + str(rel)] = str(path.readlink())
                continue
            if not path.is_file():
                continue
            # Binary source assets and copies of source .tar are available via
            # public Git revisions. Immutable output-only source variants are
            # included as text and retain their original module hashes.
            qa_png = args.include_qa_png and path.suffix == '.png' and not {'app', 'frozen', 'final'}.intersection(rel.parts)
            if path.suffix not in ALLOWED and path.name not in {'SOURCE_SHA', 'HEAD', 'PAUSE'} and not qa_png:
                skipped[path.suffix or 'no-suffix'] = skipped.get(path.suffix or 'no-suffix', 0) + 1
                continue
            raw = path.read_bytes()
            if SECRET.search(raw):
                raise SystemExit(f'Potential credential; no archive written: {rel}')
            files[str(rel)] = (raw, hashlib.sha256(raw).hexdigest())
    manifest = {
        'name': args.name,
        'inputs': args.paths,
        'primaryBytesPreserved': True,
        'credentialPatternScan': 'PASS; zero matches in included files',
        'qaScreenshotsIncluded': args.include_qa_png,
        'excludedFileKinds': skipped,
        'sourceReconstruction': 'Use the public Git commit recorded by each source manifest; output-only source variants are included. Binary source assets, original source .tar duplicates and node_modules are omitted. Isolated QA PNG screenshots are included only with the explicit opt-in flag.',
        'files': [{'path': key, 'bytes': len(raw), 'sha256': digest} for key, (raw, digest) in sorted(files.items())],
    }
    destination = ROOT / 'publication' / args.name
    destination.mkdir(parents=True, exist_ok=True)
    manifest_bytes = (json.dumps(manifest, indent=2, ensure_ascii=False) + '\n').encode()
    (destination / 'members.json').write_bytes(manifest_bytes)
    if args.build:
        import gzip
        archive = destination / (args.name + '.tar.gz')
        with archive.open('wb') as output:
            with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0, compresslevel=6) as compressed:
                with tarfile.open(fileobj=compressed, mode='w') as tar:
                    for key, (raw, _) in sorted(files.items()):
                        info = tarfile.TarInfo('outputs/' + key)
                        info.size, info.mtime, info.mode = len(raw), 0, 0o644
                        tar.addfile(info, io.BytesIO(raw))
                    info = tarfile.TarInfo('members.json')
                    info.size, info.mtime, info.mode = len(manifest_bytes), 0, 0o644
                    tar.addfile(info, io.BytesIO(manifest_bytes))
        digest = hashlib.sha256(archive.read_bytes()).hexdigest()
        (destination / 'SHA256SUMS').write_text(f'{digest}  {archive.name}\n')
        print(json.dumps({'files': len(files), 'rawBytes': sum(len(v[0]) for v in files.values()), 'archiveBytes': archive.stat().st_size, 'sha256': digest, 'archive': str(archive)}, indent=2))
    else:
        print(json.dumps({'files': len(files), 'rawBytes': sum(len(v[0]) for v in files.values()), 'manifest': str(destination / 'members.json'), 'build': False}, indent=2))

if __name__ == '__main__':
    main()
