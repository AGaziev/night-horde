import pathlib,json,os,sys,subprocess,time,datetime,hashlib,traceback
D=pathlib.Path(__file__).resolve().parent;P=D.parent;Q=(D/sys.argv[1]).resolve();kind=json.loads((Q/'plan.json').read_text()).get('executionKind','combat');plan=json.loads((Q/'plan.json').read_text());auth=json.loads((Q/'launch-authorized.json').read_text());bind=json.loads((Q/'candidate-bindings.json').read_text())['issues'];assert auth['authorized']is True;assert hashlib.sha256((Q/'plan.json').read_bytes()).hexdigest()==auth['planSHA256'];assert hashlib.sha256(pathlib.Path(plan['node']).read_bytes()).hexdigest()==plan['nodeBinarySHA256']
for n,h in plan['canonicalRunnerHashes'].items():assert hashlib.sha256((Q/'harness/pm'/n).read_bytes()).hexdigest()==h
for b in bind.values():assert pathlib.Path(b['snapshotPath'],'SOURCE_SHA').read_text().strip()==b['candidateSha']
scope=json.loads((Q/'execution-scope.json').read_text());assert kind in ['combat','daily','guarded'];assert scope['issues']==plan['matrixIssues'];held=[]
if kind=='guarded':
 assert hashlib.sha256((Q/'guard-core.mjs').read_bytes()).hexdigest()==plan['policyCoreSHA256']
 assert hashlib.sha256((Q/'guarded-policy.mjs').read_bytes()).hexdigest()==plan['policySHA256']
lock=Q/'controller.lock'
with lock.open('x')as f:json.dump({'pid':os.getpid(),'session':os.getsid(0),'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'detached':True},f)
overrides=json.loads((Q/'active-recovery.json').read_text())['retryOverrides']if(Q/'active-recovery.json').exists()else{}
def atomic(path,obj):
 tmp=path.with_name(path.name+'.tmp-'+str(os.getpid()))
 with tmp.open('w')as f:json.dump(obj,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 os.replace(tmp,path)
def stem(a):
 if a['attemptId']in overrides:return pathlib.Path(overrides[a['attemptId']]['retryPrefix'])
 b=bind[str(a['issue'])];r=Q/'raw'/('issue-'+str(a['issue']))/b['candidateSha'];return r/a['dailyRule']/a['id']if'dailyRule'in a else r/a['id']
def eligible(a):
 if(P/'PAUSE').exists()or(Q/'PAUSE').exists()or(D/'source-holds'/(bind[str(a['issue'])]['candidateSha']+'.json')).exists():return False
 f=Q/('PAUSE-issue-'+str(a['issue']))
 if not f.exists():return True
 try:return json.loads(f.read_text()).get('sourceSha')not in [None,bind[str(a['issue'])]['candidateSha']]
 except Exception:return False
pending=[];active={};done={};unknown=[]
for a in sorted(plan['attempts'],key=lambda a:(a['cell'],a['K0'],plan['matrixIssues'].index(a['issue']))):
 s=stem(a);mf=s.with_suffix('.meta.json')
 if a['issue'] not in scope['issues']:
  held.append({'attemptId':a['attemptId'],'issue':a['issue'],'status':'terminal-historical'if mf.exists()else 'UNKNOWN-held'if s.with_suffix('.start.json').exists()else 'notStarted-held'})
  if mf.exists():done[a['attemptId']]=json.loads(mf.read_text())
  continue
 if mf.exists():done[a['attemptId']]=json.loads(mf.read_text())
 elif s.with_suffix('.start.json').exists():unknown.append({'attemptId':a['attemptId'],'reason':'existingunfinishedstart; neverauto-replay','prefix':str(s)})
 else:pending.append(a)
assert not unknown, 'Unresolved eligible start: fail closed, no auto-retry'
def dispatch(a):
 b=bind[str(a['issue'])];s=stem(a);s.parent.mkdir(parents=True,exist_ok=True);cmd=[plan['node'],'--random-seed='+str(a['seed']),plan['canonicalRunner'],str(a['players']),'1',a['bot']];env={'PATH':str(pathlib.Path(plan['node']).parent)+':/usr/bin:/bin','APP':b['snapshotPath']+'/app','MODE':a['mode'],'K0':str(a['K0']),'LANG':'C','TZ':'UTC'}
 if kind=='daily':env.update(DAILY_RULE=a['dailyRule'],DAILY_DAY=a['dailyDay'])
 m={**a,'status':'started','revision':'candidate','sourceSha':b['candidateSha'],'baselineSha':plan['baseline'],'runtime':plan['runtime'],'nodeBinarySHA256':plan['nodeBinarySHA256'],'canonicalRunnerHashes':plan['canonicalRunnerHashes'],'command':cmd,'environment':env,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'durableSupervisorVersion':2,'sourceBindingManifestSHA256':b['manifestSHA256'],'playContract':plan.get('playContract')}
 for key in ['policySHA256','policyCoreSHA256','canonicalBaseRunner','selectorPolicySHA256']:
  if key in plan:m[key]=plan[key]
 if a['attemptId']in overrides:m['explicitRecovery']=overrides[a['attemptId']]
 with s.with_suffix('.start.json').open('x')as f:json.dump(m,f,indent=2);f.flush();os.fsync(f.fileno())
 cfg={'stem':str(s),'planDir':str(Q),'kind':kind,'metadata':m,'command':cmd,'environment':env}
 for key in ['expectedDailyContracts','selectorPolicySHA256','guardPolicyParameters','dashParameters','playContract','expectedDailyVersion']:
  if key in plan:cfg[key]=plan[key]
 cp=s.with_suffix('.dispatch.json');atomic(cp,cfg);log=s.with_suffix('.supervisor.log').open('ab');p=subprocess.Popen([sys.executable,str(D/'durable-supervise-v3.py'),str(cp)],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);log.close();atomic(s.with_suffix('.supervisor-launch.json'),{'pid':p.pid,'config':str(cp),'masterPID':os.getpid(),'executionScope':scope['issues'],'scopeTarget':scope['targetTerminal'],'scopeTerminal':sum(m.get('terminalProof')is True and m['issue']in scope['issues']for m in done.values()),'heldHistorical':len(held),'heldNotStarted':sum(h['status']=='notStarted-held'for h in held),'heldUnknown':sum(h['status']=='UNKNOWN-held'for h in held),'at':datetime.datetime.now(datetime.timezone.utc).isoformat()});return p
try:
 while pending or active:
  cap=max(0,min(9,int((Q/'worker-limit.json').read_text())))
  while len(active)<cap:
   i=next((i for i,a in enumerate(pending)if eligible(a)),None)
   if i is None:break
   a=pending.pop(i)
   try:active[a['attemptId']]=(a,dispatch(a))
   except Exception as e:unknown.append({'attemptId':a['attemptId'],'error':repr(e)});atomic(Q/'PAUSE',{'reason':'dispatchunknown; noauto-retry','attemptId':a['attemptId']})
  for key,(a,p)in list(active.items()):
   s=stem(a)
   if s.with_suffix('.meta.json').exists():
    m=json.loads(s.with_suffix('.meta.json').read_text());done[key]=m;del active[key]
    if m.get('exitUnknown'):unknown.append({'attemptId':key,'reason':'supervisorcouldnotobserveNodeexit'})
   elif p.poll()is not None:
    unknown.append({'attemptId':key,'reason':'supervisorendedwithoutmetadata','supervisorExit':p.returncode,'prefix':str(s)});del active[key];atomic(Q/'PAUSE',{'reason':'workerexitunknown; noauto-retry'})
  state={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'done':len(done),'terminal':sum(m.get('terminalProof')is True for m in done.values()),'active':len(active),'pending':len(pending),'unknown':unknown,'historicalInterruptedPhysicalAttempts':len(json.loads((Q/'active-recovery.json').read_text())['originalUnknown']),'paused':(P/'PAUSE').exists()or(Q/'PAUSE').exists(),'activeAttempts':[{'attemptId':k,'supervisorPID':p.pid,'prefix':str(stem(a))}for k,(a,p)in active.items()],'masterPID':os.getpid(),'executionScope':scope['issues'],'scopeTarget':scope['targetTerminal'],'scopeTerminal':sum(m.get('terminalProof')is True and m['issue']in scope['issues']for m in done.values()),'heldHistorical':len(held),'heldNotStarted':sum(h['status']=='notStarted-held'for h in held),'heldUnknown':sum(h['status']=='UNKNOWN-held'for h in held)};state['issueCounts']={str(i):{'terminal':sum(m.get('terminalProof')is True for m in done.values()if m['issue']==i),'recorded':sum(m['issue']==i for m in done.values())}for i in plan['matrixIssues']};atomic(Q/'controller-state.json',state);time.sleep(.25)
 atomic(Q/'controller-complete.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'planned':len(plan['attempts']),'completed':len(done),'terminal':sum(m.get('terminalProof')is True for m in done.values()),'failed':sum(not m.get('terminalProof')for m in done.values()),'unknown':unknown,'historicalInterruptedPhysicalAttempts':len(json.loads((Q/'active-recovery.json').read_text())['originalUnknown']),'durableObservedExitRequiredForNewAttempts':True,'executionScope':scope['issues'],'scopeTarget':scope['targetTerminal'],'scopeTerminal':sum(m.get('terminalProof')is True and m['issue']in scope['issues']for m in done.values()),'heldHistorical':held})
 if unknown or sum(m.get('terminalProof')is True and m['issue']in scope['issues']for m in done.values())!=scope['targetTerminal']:raise SystemExit(2)
finally:
 if lock.exists():lock.rename(Q/('controller-finished-'+str(os.getpid())+'.json'))
