import { createGuard, POLICY } from './guard-core.mjs';
const { Room } = await import(process.env.APP + '/server/game.js');
const { DASH } = await import(process.env.APP + '/public/shared/mobility.js');
const constants = await import(process.env.APP + '/public/shared/content.js');
const decide = createGuard({ DASH, ...constants });
const originalHandle = Room.prototype.handle, originalTick = Room.prototype.tick;
const records = [], pending = new Map(), vetoes = {}, requests = new WeakMap();
let identityMismatches = 0;
let attempted = 0, rejected = 0, cooldownViolations = 0, iframesAdded = 0;
const damage = (r, pid) => Object.values(r.runLog?.p?.get(pid)?.taken ?? {}).reduce((a, b) => a + b, 0);
Room.prototype.handle = function (pid, msg) {
  if (msg?.t === 'pos') {
    const h = this.heroes.get(pid), dx = msg.x - (h?.x ?? 0), dy = msg.y - (h?.y ?? 0);
    const choice = decide(this, h, dx, dy);
    if (choice.press) {
      attempted++;
      const epoch = h.moveEpoch ?? 0, beforeIframes = h.iframes, ready = h.dashReadyAt ?? 0;
      let counters=requests.get(this); if(!counters)requests.set(this,counters=new Map());
      const run=this.runLog?.id, request=Math.max(counters.get(pid)??0,h.dashRequest??0)+1, expiresAt=Date.now()+1000;
      counters.set(pid,request); let reply=null; const send=this.send;
      this.send=function(to,m,...rest){if(to===pid&&m.t==='dash'&&m.request===request)reply=m;return send.call(this,to,m,...rest);};
      try{originalHandle.call(this,pid,{t:'dash',run,request,expiresAt,x:choice.direction[0],y:choice.direction[1]});}finally{this.send=send;}
      if(!reply||reply.run!==run||reply.request!==request)identityMismatches++;
      if ((h.moveEpoch ?? 0) > epoch) {
        if (this.time + 1e-8 < ready) cooldownViolations++;
        if (h.iframes > beforeIframes + 1e-8) iframesAdded++;
        const rec = { run, request, expiresAt, ack: reply, pid, at: this.time, readyAt: h.dashReadyAt, from: [h.x, h.y],
          direction: choice.direction, hpBefore: h.hp, takenBefore: damage(this, pid),
          iframesBefore: beforeIframes, epoch: h.moveEpoch,
          threat: choice.threat, predictedEnd: choice.predictedEnd, clearMargin: choice.clearMargin };
        records.push(rec); pending.set(pid, rec);
      } else rejected++;
    } else vetoes[choice.reason] = (vetoes[choice.reason] ?? 0) + 1;
    return originalHandle.call(this, pid, { ...msg, epoch: h?.moveEpoch ?? 0 });
  }
  return originalHandle.call(this, pid, msg);
};
Room.prototype.tick = function (...args) {
  const value = originalTick.apply(this, args);
  for (const [pid, rec] of pending) {
    const h = this.heroes.get(pid);
    if (!h || !h.dash || h.st !== 0 || this.state !== 'play') {
      Object.assign(rec, { endedAt: this.time, to: h ? [h.x, h.y] : null, hpAfter: h?.hp,
        actualHpDamage: damage(this, pid) - rec.takenBefore, alive: h?.st === 0,
        state: this.state, distance: h ? Math.hypot(h.x - rec.from[0], h.y - rec.from[1]) : null });
      pending.delete(pid);
    }
  }
  return value;
};
try {
 if(process.env.CONTRACT_SMOKE==='1'){
  const r=new Room('GUARD-SMOKE',()=>{});r.addPlayer(1,'Smoke','knight');r.start();r.spawn=()=>{};r.bossAt=[];r.peaks=[];r.nextEliteT=r.nextInvasionT=Infinity;r.events.tick=()=>{};
  const h=r.heroes.get(1);h.x=h.y=0;h.weapons.clear();h.perk.readyAt=Infinity;r.time=100;
  r.hostile.push({id:1,x:-20,y:0,vx:300,vy:0,r:5,life:3,dmg:1,from:'contract-smoke'});
  r.handle(1,{t:'pos',x:1,y:0,fx:1,fy:0});
  for(let i=0;i<5;i++)r.tick(1/30);
  if(records.length!==1||rejected!==0||identityMismatches!==0||pending.size!==0||records[0].request!==h.dashRequest||records[0].run!==r.runLog.id||!records[0].ack.ok)throw new Error('GUARDED_NATIVE_METADATA_CONTRACT_FAILED');
  const dashEnd=[h.x,h.y];if(Math.abs(Math.hypot(...dashEnd)-180)>1e-8)throw new Error('NATIVE_DASH_NOT_180');
  r.handle(1,{t:'pos',x:h.x+5,y:h.y,fx:1,fy:0});
  if(Math.abs(h.x-dashEnd[0]-5)>1e-8||h.y!==dashEnd[1]||h.lastPosT!==r.time||h.dash)throw new Error('ORDINARY_POST_DASH_MOVEMENT_REJECTED');
  console.log(JSON.stringify({smokeOnly:true,notFullSimulation:true,sourceSha:process.env.SOURCE_SHA,accepted:records.length,run:records[0].run,request:records[0].request,expiresAt:records[0].expiresAt,nativeAck:records[0].ack,dashEnd,ordinaryPostDashEnd:[h.x,h.y],ordinaryPostDashAccepted:true,policyCoreUnchanged:true}));
 }else await import(new URL('./harness/pm/run-sim.mjs', import.meta.url));
}
finally {
  process.stderr.write('DASH_POLICY_METRICS ' + JSON.stringify({ policy: 'fixed guarded-use all10 protocol29',
    version: 1, requestMetadataVersion: 1, identityMismatches, parameters: POLICY, canonicalChoicesAndMovementUnmodified: true,
    noExtraRngCalls: true, dash: DASH, attempted, accepted: records.length, rejected,
    cooldownViolations, iframesAdded, damagingDashes: records.filter(r => r.actualHpDamage > 0).length,
    unfinishedDashes: pending.size, vetoes, records }) + '\n');
}
