# READY_TO_REGISTER_HOLD0 — guarded17-421a5d1-latest

Prepared exactly one new immutable600 guarded candidate plan for **421a5d117e78bc88bbd78622916943cba2a58245**. Actual PR/CI binding base13c560f4d5f16a12333d167806f9a5b20e601c4a; logical comparison baseline0ab and measured baselinea957 labels/raw remain unchanged. Root's `../../../v36/live-current-final/main-13c-combat-carry.json` is hash-bound in the plan; no baseline rerun or historical outcome relabeling.

Plan SHA256 **4abd5deaa726c25a2e434d251dcdd273476312dda8fe30170301a21935b4d7ac**. Full source/archive/manifest/CI hashes are in `FINAL-PREPARED.json` and `candidate-bindings.json`; extracted300 source files were rechecked after smoke. Source is a clean git archive of app+pm from exact final421.

## Verified gates

- Finite independent numeric producer review: `../../../v36/17-r29-independent/REPORT.md`. Original9 producer and selected10 adjacent cases PASS, own native Input/Game35/20 oldULP→exactzero,26/15 projectionzero and true nearest-interior movement retained. CODE / READY_TO_MEASURE only; no full balance or frequency claim.
- Current [CI43633531282](https://github.com/AGaziev/night-horde/actions/runs/43633531282) primary **70/70 PASS**, Linux Node24.22.2. Checkout07cb2fcb863049dbc8a9f38a887124999450b9e6 parents13c/421, tree=head; ZIP digest/all suites/logs/revisions/results verified. `../../../v36/17-r29-independent/ci-43633531282/primary-proof.json`. Prior8bc CI failure and root's test-only gold-oracle correction remain preserved, not hidden by a rerun.
- Canonical600 tuples exactly unchanged,10×60, same130000+i+cell*1000 seeds, K0=i and hero rosters. FixedN/no stop on success. All600 notStarted; fresh raw prefix for421, zero historical outcomes carried.
- Canonical Node24.22.1 SHA256cf52d093e9b728a7e6929a4371fa37d271304383e7e7c9f0f0e32fb00373b32c. Canonical run-sim/sim-runner hashes unchanged. Guard core **594a1a7054af3cd13285721c82ed4b80d43a39729c856c8251712f933e5c6dd7**, guarded policy **b02d8bc7eeb3771f54e29cf8b3f7ca936d58a10ddfa46bf92c56c1c187a0b74b**, identical to accepted fixed policy; no tuning or policy rewrite.
- Two bounded five-tick native play→manualfinish/log-identity smokes PASS (solo night,4-player lunch, PROTO30). Four fixed metadata trials130000–130003 PASS with actual native ACK/run/request/expiresAt, one accepted dash, endpoint180 then accepted ordinary185, no metadata mismatch/cooldown/iframe/unfinished violation. `own-smoke.meta.json` and raw logs. These are contract smokes, **not full matches**, and are excluded from600.

## State and ownership

**NOT REGISTERED.** rootArmedfalse, worker-limit0, authorizedfalse, INITIAL_READINESS_HOLD present, raw empty, no bootstrap/master/controller. Owned CPU workers0. No registry/operator call occurred. c931 remains forbidden/unstarted; old30a57,307278,0c243 and all retired/partial plans/raw were untouched. Shared controllers and other issue plans were not edited.

The registration script is prepared and syntax-checked only. Root's next step, if registration is authorized:

```sh
python3 /Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/issue-split/runs/latest-source-20261114/register-17-421.py
```

It appends only this HOLD0 registry entry under the sole operator lock and never launches. After registration, root must separately arm this readiness, verify live gates/shared free capacity and explicitly authorize start. Future command form, **not executed here**:

```sh
python3 /Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/issue-split/runs/final-a25-r16/qa-control.py start-verified-current guarded17-421a5d1-latest N --root-confirmed
```

N must fit the shared maximum9 including reserved/inflight workers. No direct bootstrap, second operator, retry or old-source admission.
