import { chromium } from '/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
import { spawn, execFileSync } from 'node:child_process';
import { once } from 'node:events';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
const repo = new URL('../../work/night-horde-asymmetric/', import.meta.url).pathname;
const out = new URL('./', import.meta.url).pathname;
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pr38-finite-'));
const report = { sha: execFileSync('git', ['rev-parse','HEAD'], {cwd:repo,encoding:'utf8'}).trim(), node: process.version, checks: [], errors: [] };
report.tree = execFileSync('git', ['write-tree'], {cwd:repo,encoding:'utf8'}).trim();
const child = spawn(process.execPath, ['--import', repo+'pm/test-runtime.mjs', '--import', out+'fixture.mjs', repo+'app/server/server.js'], {cwd:repo, env:{...process.env,PORT:'34385',HORDE_RUNS_DIR:dir,VIBE_APP_KEY:''},stdio:['ignore','pipe','pipe']});
const exited = once(child, 'exit'); let output = '', port;
child.stdout.on('data', data=>{output+=data;port=Number(output.match(/FINITE_PORT:(\d+)/)?.[1]);});
child.stderr.on('data', data=>output+=data);
const sleep = ms=>new Promise(r=>setTimeout(r,ms)); let browser;
try {
 for(let i=0;!port&&i<100;i++) await sleep(40);
 assert.ok(port,output); const origin='http://127.0.0.1:'+port;
 browser=await chromium.launch({headless:true,args:['--mute-audio']});
 report.browser=browser.version();
 const dc=await browser.newContext({viewport:{width:1366,height:768}}),hc=await browser.newContext({viewport:{width:1366,height:768}});
 const d=await dc.newPage(),h=await hc.newPage(),w=await (await browser.newContext({viewport:{width:1366,height:768}})).newPage();
 for(const p of [d,h,w])p.on('pageerror',e=>report.errors.push(String(e)));
 await d.goto(origin);await d.locator('#menu-create').click();await d.locator('[data-ruleset="horde"]').click();
 const code=await d.locator('#lobby-code').textContent();
 await h.goto(origin);await h.locator('#menu-code').fill(code);await h.locator('#menu-join').click();
 await w.goto(origin);await w.locator('#menu-code').fill(code);await w.locator('#menu-join').click();
 await d.waitForFunction(()=>__nh.state.lobby?.players.length===3);await d.locator('#lobby-start').click();
 await d.locator('.horde-pack-select').first().waitFor();
 await d.locator('.horde-pack-select').first().click();
 assert.equal(await d.evaluate(()=>document.activeElement?.classList.contains('horde-pack-select')),true);
 await d.keyboard.press('Escape');
 assert.equal(await d.locator('.horde-pack-select').first().getAttribute('aria-pressed'),'false');
 await d.locator('.horde-pack-select').first().focus();await d.keyboard.press('Space');
 assert.equal(await d.locator('.horde-pack-select').first().getAttribute('aria-pressed'),'true');
 report.checks.push({name:'focused troop button Escape cancels and native Space selects',result:'PASS'});
 const fixture=async action=>{const r=await fetch(origin+'/__pr38_fixture',{method:'POST',body:JSON.stringify({action})});assert.ok(r.ok,await r.clone().text());return r.json();};
 await h.evaluate(()=>{const send=__nh.net.send.bind(__nh.net);window.finiteSend=send;__nh.net.send=m=>{if(m.t!=='pos')send(m);};});
 await fixture('idle');
 for(let i=0;i<35;i++){await h.evaluate(()=>finiteSend({t:'pos',x:0,y:0}));await sleep(30);}
 const before=await fixture('position');await h.evaluate(()=>finiteSend({t:'pos',x:1700,y:0}));await sleep(30);
 const jumped=await fixture('position');assert.ok(jumped.x-before.x<35,JSON.stringify({before,jumped}));
 report.checks.push({name:'real WS idle packets cannot bank a 195-unit leap',before,jumped,result:'PASS'});

 await fixture('idle');await h.evaluate(()=>finiteSend({t:'pos',x:0,y:0,seq:9001}));await sleep(1150);
 const heldBefore=await fixture('position');await h.evaluate(()=>finiteSend({t:'pos',x:1700,y:0,seq:9002}));await sleep(40);
 const heldAfter=await fixture('position');assert.ok(heldAfter.x-heldBefore.x<=5.51,JSON.stringify({heldBefore,heldAfter}));assert.equal(heldAfter.ack,9002);
 report.checks.push({name:'held pos1.1s over real production WS expires credit and preserves ACK',heldBefore,heldAfter,result:'PASS'});
 await fixture('idle');await h.evaluate(()=>finiteSend({t:'pos',x:0,y:0}));await sleep(1150);
 await d.evaluate(()=>{const s=__nh.game.hordeState;__nh.net.send({t:'horde',roundId:s.roundId,action:'spawn',pack:'swarm',x:665,y:0,seq:s.lastSeq+1});});
 await sleep(50);const pending=await fixture('position');assert.equal(pending.pending,1,JSON.stringify(pending));
 await h.evaluate(()=>finiteSend({t:'pos',x:1700,y:0}));await sleep(30);const pacedStart=await fixture('position');
 await h.evaluate(x=>{const at=performance.now();window.qaPace=setInterval(()=>finiteSend({t:'pos',x:x+150*(performance.now()-at)/1000,y:0}),1000/30);},pacedStart.x);
 await sleep(2050);await h.evaluate(()=>clearInterval(qaPace));const formation=await fixture('position');assert.equal(formation.manual,12,JSON.stringify(formation));
 report.checks.push({name:'held pos cannot cancel a genuinely paid native formation665',pending,pacedStart,formation,result:'PASS'});
 const armed=await fixture('blast');await sleep(1100);await h.evaluate(()=>finiteSend({t:'pos',x:1700,y:0}));await sleep(160);
 const blasted=await fixture('position');assert.ok(blasted.x<6&&blasted.hp<140,JSON.stringify(blasted));
 report.checks.push({name:'held position under native chill does not escape its warned blast',armed,blasted,result:'PASS'});
 for(const action of ['sniper-control','sniper-displaced']){
  const setup=await fixture(action);await h.waitForFunction(()=>__nh.game.blines.length===5);
  const lanes=await h.evaluate(()=>__nh.game.blines.map(l=>({x:l.x1,y:l.y1,remaining:l.life,deadline:l.life+l.serverStart})));
  assert.ok(lanes.every(l=>l.x===0&&l.y===0),JSON.stringify({setup,lanes}));
  assert.ok(lanes.every(l=>Math.abs(l.deadline-setup.deadline)<1e-6));
  await h.screenshot({path:out+action+'.png'});const fired=await fixture('sniper-fire');
  await h.waitForFunction(()=>__nh.game.myRow()[3]<100);
  assert.equal(fired.shots.length,5);assert.ok(fired.shots.every(s=>s.x===0&&s.y===0));assert.ok(Math.abs(fired.hp-90.445)<1e-6,JSON.stringify(fired));
  report.checks.push({name:'native paid sniper/Ward/resync/key warning matches volley '+action,setup,lanes,fired,result:'PASS'});
 }
 for(const action of ['pre-key','post-key']) {
  const setup=await fixture(action);
  await h.waitForFunction(id=>__nh.game.shots.has(id)&&__nh.game.warns.some(w=>w.r===180),setup.knife,{timeout:1500});
  await sleep(100);
  const visible=await h.evaluate(id=>({knife:__nh.game.shots.has(id),warnings:__nh.game.warns.filter(w=>w.r===180).length,time:__nh.game.latest()?.tm}),setup.knife);
  assert.equal(visible.warnings,1,action); // Knife may have hit by this point; the first-key wait already observed it.
  await h.screenshot({path:out+action+'.png'});
  await sleep(1100);const born=await fixture('position');assert.equal(born.bossAdds,12);
  report.checks.push({name:'Lord warning and fresh native knife survive '+action+' resync',setup,visible,born,result:'PASS'});
 }
 assert.deepEqual(report.errors,[]);
} catch(error) { report.failure=String(error.stack);process.exitCode=1;console.error(error); }
finally { if(browser)await browser.close();child.kill();await exited;fs.rmSync(dir,{recursive:true,force:true});report.cleanup={appStopped:true,tempRunsRemoved:!fs.existsSync(dir)};fs.writeFileSync(out+'browser-report.json',JSON.stringify(report,null,2));fs.writeFileSync(out+'server.log',output);console.log(JSON.stringify(report)); }
