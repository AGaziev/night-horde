import { Server } from 'node:http';
import { HORDE_PACKS } from '../../work/night-horde-asymmetric/app/public/shared/horde-content.js';
import { Room } from '../../work/night-horde-asymmetric/app/server/game.js';
let room;
const start = Room.prototype.start;
Room.prototype.start = function (...args) { const result = start.apply(this, args); if (this.isHorde) room = this; return result; };
const tick = Room.prototype.tick;
Room.prototype.tick = function (...args) { if (!this.qaManual) return tick.apply(this,args); };
const emit = Server.prototype.emit;
Server.prototype.emit = function (event, req, res, ...args) {
 if (event !== 'request' || req.url !== '/__pr38_fixture') return emit.call(this, event, req, res, ...args);
 let body = '';
 req.on('data', (part) => body += part);
 req.on('end', () => {
  try {
   const { action } = JSON.parse(body);
   if (!room) throw Error('No owned Horde room');
   const hero = [...room.heroes.values()][0];
   if (['idle','pre-key','post-key','blast'].includes(action)) room.qaManual = false;
   if (action === 'idle') {
    room.time = 10; room.enemies = []; room.projectiles = []; room.fx = []; room.hostile = []; room.timers = [];
    for (const h of [...room.heroes.values()].slice(1)) { h.x = -700; h.y = 0; h.weapons.clear(); }
    room.horde.pending = [];
    hero.x = hero.y = 0; hero.speed = 150; hero.hp = hero.maxHp = 10000; hero.weapons.clear();
    hero.hordeMoveAt = room.time; hero.hordeMoveCredit = 0; hero.lastPosT = room.time;
    room.horde.combat.status.clear(); room.snapshot();
    res.end(JSON.stringify({ time: room.time })); return;
   }
   if (action === 'position') { res.end(JSON.stringify({ time: room.time, x: hero.x, hp: hero.hp, ack: hero.posAck, manual: room.enemies.filter(e => e.hordeSource === 'manual').length, bossAdds: room.enemies.filter(e => e.hordeSource === 'boss-add').length, pending: room.horde.pending.length })); return; }

   if (action === 'blast') {
    room.enemies=[]; room.hostile=[]; room.blasts=[]; room.fx=[]; room.timers=[];
    hero.x=hero.y=0; hero.speed=150; hero.hp=hero.maxHp=140; hero.iframes=0; hero.ward=0; hero.weapons.clear(); hero.perk.readyAt=Infinity;
    hero.hordeMoveAt=room.time; hero.hordeMoveCredit=0; room.horde.combat.status.clear(); room.horde.combat.chill(hero,{duration:3});
    room.addBlast(0,0,100,8,0,null,1,1.2); room.snapshot();res.end(JSON.stringify({deadline:room.time+1.2}));return;
   }
   if (action.startsWith('sniper-')) {
    if (action==='sniper-fire') {
     const {sniper,deadline}=room.qaSniper; room.time=deadline; room.sniperTick(sniper,hero,550,sniper.windT);
     const shots=room.hostile.map(s=>({x:s.x,y:s.y}));
     while(room.hostile.length){room.time+=1/30;room.updateHostile(1/30);}room.snapshot();
     res.end(JSON.stringify({shots,hp:hero.hp}));return;
    }
    room.qaManual=true; room.enemies=[];room.hostile=[];room.projectiles=[];room.fx=[];room.blasts=[];room.timers=[];room.horde.pending=[];
    const heroes=[...room.heroes.values()],ward=heroes[1];if(!ward)throw Error('Two heroes required');
    heroes.forEach(h=>{h.weapons.clear();h.perk.readyAt=Infinity;h.mods.critChance=0;h.iframes=0;h.hp=h.maxHp=100;});
    hero.x=550;hero.y=0;ward.x=0;ward.y=action==='sniper-displaced'?60:200;
    room.time=160;room.horde.build.packs.snipers=1;room.horde.resource=room.horde.resourceCap;
    const error=room.horde.buy(HORDE_PACKS.snipers,-1100,0);if(error)throw Error(error);
    room.time=room.horde.pending[0].at;room.horde.tick(0,heroes);
    const cohort=room.enemies.filter(e=>e.hordeSource==='manual');cohort.forEach((e,i)=>{e.x=-1100;e.y=-200-i*100;});
    const sniper=cohort.find(e=>e.ai==='sniper');sniper.x=sniper.y=0;sniper.shotT=0;
    room.sniperTick(sniper,hero,550,0);const deadline=room.time+sniper.windT;room.snapshot();
    ward.weapons.set('ward',{lvl:1,t:0,bashT:Infinity});room.updateWeapon(ward,'ward',ward.weapons.get('ward'),0);room.rebuildGrid();room.hurtPlayer(ward,8,'ghoul');
    room.time+=.2;room.sniperTick(sniper,hero,550,.2);room.resync(hero.pid);room.snapshot();
    room.qaSniper={sniper,deadline};res.end(JSON.stringify({current:[sniper.x,sniper.y],aim:[sniper.aimX,sniper.aimY],deadline,remaining:sniper.windT}));return;
   }
   if (!['pre-key', 'post-key'].includes(action)) throw Error('Unknown fixture');
   room.time = 100; room.enemies = []; room.projectiles = []; room.hostile = []; room.fx = []; room.timers = [];
   hero.x = hero.y = 0; hero.hp = hero.maxHp = 10000; hero.iframes = 0; hero.fx = 1; hero.fy = 0;
   const boss = room.spawnBoss('boss', [hero]); boss.x = 150; boss.y = 0; boss.bcd = 0; boss.bt2 = 1;
   room.lordTick(boss, hero, 150, 0, false);
   if (action === 'post-key') room.snapshot();
   hero.weapons = new Map([['knives', { lvl: 1, t: 0 }]]); room.rebuildGrid();
   room.updateWeapon(hero, 'knives', hero.weapons.get('knives'), 0.1); hero.weapons.clear();
   const knife = room.fx.find(e => e[0] === 'shot');
   if (!knife) throw Error('No native knife launch');
   room.resync(hero.pid);
   res.end(JSON.stringify({ knife: knife[1], deadline: room.time + boss.def.call.warn, radius: boss.def.call.ring + 20, expectedAdds: Math.round(boss.def.call.count * (1 + .25 * (room.heroes.size - 1))) }));
  } catch (error) { res.statusCode = 500; res.end(String(error.stack)); }
 });
 return true;
};
const listen = Server.prototype.listen;
Server.prototype.listen = function (...args) { args[0] = 0; this.once('listening', () => console.log('FINITE_PORT:' + this.address().port)); return listen.apply(this, args); };
