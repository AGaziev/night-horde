PASS scoped — два конечных остатка MR38 закрыты на проверенном `ccb6b5906cb9646f653d95ffb3d48a8feaa52a0a`; результаты перенесены на final HEAD `f1011dd2c0d60fe268ae387df406f0fa37877069` по побайтному равенству runtime. STATUS: PASS. Общий READY по PR не заявляется: браузер и финальный CI проверяет root.

Независимый проверяющий: `horde_residuals_independent`; в реализации продуктового кода не участвовал. Авторы: movement `f60e11911a43056ce280a39b6862f1c11015cae4` — root; sniper `b11b149bdd645473f76790465da6d08916ddb0c3` — agent `horde_sniper_fix`; merge current main/v37 — root. Старое основание: `e7271a2da67ee588d71dd668033664b643ca6480`. Проверяемая ветка при начале и конце финального прохода чистая, HEAD совпал с SOURCEFREEZE.

| Исходное замечание / контроль | Старый e7271a2 | Frozen ccb6b59 |
| --- | --- | --- |
| Только pos удержан 1,1 s, WS/ping открыт | скачок 165 | 5,5; тот же момент/resync не добавляет движение; ACK 3 |
| Реально оплаченная swarm в x665, цена 24, затем paced 150/s | held: x465, 0 бойцов, возврат 80; paced: x300, 12 | held: x305,5, 12 бойцов; paced: x300, 12; остаток ресурса 56, возврата нет |
| Предупреждённый native blast + native chill 0,82 | held: x135,3, 140 HP; regular: x4,51, 132 HP | held и regular: x4,51, 132 HP; уйти ретроактивно нельзя |
| Обычный paced ввод, jitter 120 ms, chill, ACK | PASS | PASS; те же 51,5/66,26 ед., ACK 9, повторный пакет в тот же момент без бонуса |
| Paid snipers 46 → native aim → native Ward I push −60 → Hub rejoin → native key → Game → native volley/HP | 5 полос из y−60, залп y0; герой вне всех полос (ближайшая 40,53), HP 100→90,445 | 0 расхождений: полосы и залп y0, то же попадание показано центральной полосой |
| No displacement | 0 расхождений, HP 100→90,445 | 0 расхождений, HP 100→90,445 |
| Zero saved origin и fallback без aimX/Y | zero-origin раскрывает дефект; fallback совпал с текущей y−60, HP 100 | zero-origin сохранён через ??; fallback совпал с текущей y−60, HP 100 |
| Deadline / repeated Hub restore | deadline 162,9; remaining 0,7→0,6 | то же; восстановление не продлевает предупреждение |
| Принятые Lord warning и fresh Knife через первый key | не повторялись этим проходом | 2/2 PASS через --test-name-pattern |

Собственная оснастка дала 7 групп результатов / 9 отдельных native Room-сцен для каждого SHA. Негативный baseline PASS означает успешное подтверждение старых дефектов. Candidate PASS означает выполнение исправленных критериев. Реальные loopback WebSocketServer/клиенты передают JSON в неизменённый Hub.handle; ключи проходят native SnapshotEncoder/Decoder и Game. Первый gap удержан также по wall time: old 1175 ms, candidate 1168 ms с работающим ping.

Границы: это адресная native приёмка, не production server.js listener и не браузер. Clock Room.time управляется явно. Sniper и blast используют явно подготовленные геометрию/build/щит героя; сами покупка, списание/возврат, спавн, Ward push, залп и HP — штатные методы. Числа подготовленных сцен не оценивают частоту сочетания в живых играх. Browser и свежий GitHub CI проверяет root; мной они не проверялись. Общий PvP/баланс/FPS/fullsim аудит не проводился.

Адресный просмотр merged contracts: `game.js` сохраняет `HORDE_POS_JITTER_SECONDS=0.2` и расчёт одного tick для stale; `nativeLanes` и `sniperTick` используют одинаковые `aimX ?? x`, `aimY ?? y`. `updateCaravan` остался в PvE-ветке; readiness и исключения far-teleport проверяют оба типа guard; Horde confine/retire сохранены. Все семь прежних bare confineGuard-вызовов обращаются к `this.confineGuard`; dispatcher вызывает проверяющие свои маркеры outpost/caravan helpers. Отдельного общего аудита caravan не делалось.

Фактические команды, все exit 0, Node v24.22.1/macOS:

```sh
/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node --import /Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/work/night-horde-asymmetric/pm/test-runtime.mjs /Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/pr38-review-residuals-20261115/independent/residuals-independent.mjs /Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/pr38-review-residuals-20261115/independent/source-e7271a2 e7271a2da67ee588d71dd668033664b643ca6480 old
/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node --import /Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/pr38-review-residuals-20261115/independent/source-ccb6b59/pm/test-runtime.mjs /Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/pr38-review-residuals-20261115/independent/residuals-independent.mjs /Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/pr38-review-residuals-20261115/independent/source-ccb6b59 ccb6b5906cb9646f653d95ffb3d48a8feaa52a0a fixed
/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node --test --test-name-pattern='Lord call warning|resync suppression excludes fresh knife' /Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/pr38-review-residuals-20261115/independent/source-ccb6b59/app/server/horde-resync-test.js
```

Первичные результаты: `old-native.jsonl`, `candidate-native.jsonl`, `candidate-controls.tap`; оснастка `residuals-independent.mjs`, source/SHA256/команды — `manifest.json`. Исходники каждого SHA взяты через git archive в outputs, checkout не менялся.

Cleanup проверяется asserts после каждого encounter: оба клиентских и серверных конца реально закрыты, server.address() == null, server.clients.size == 0, hub.rooms/players очищены. И old, и candidate: 9 закрытых сцен, 0 open sockets, 0 listening servers, 0 retained hubs. Процессы прогонов завершились exit 0. Созданы только файлы внутри этого каталога; APP/Git commits/push/merge/GH messages, CTQ и ветка17 не затронуты.

Read-only carry после последнего commit: единственный diff `ccb6b59..f1011dd` — `app/server/horde-client-test.js` (fake DOM `.contains`). `git diff --exit-code ccb6b5906cb9646f653d95ffb3d48a8feaa52a0a..f1011dd2c0d60fe268ae387df406f0fa37877069 -- app ':!app/server/horde-client-test.js'` дал exit 0 и пустой diff; списки Git blob ID + путей всего остального app совпали полностью (SHA256 в `source-carry.json`). Native/контроли не перезапускались: дельта их runtime не меняет. Последний read-only status чистый, HEAD `f1011dd2c0d60fe268ae387df406f0fa37877069`.
