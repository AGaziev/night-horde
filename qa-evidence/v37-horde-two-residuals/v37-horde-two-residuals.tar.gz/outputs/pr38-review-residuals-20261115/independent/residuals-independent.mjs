import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {once} from 'node:events';
import {setTimeout as delay} from 'node:timers/promises';
import WebSocket, {WebSocketServer} from '../../../work/night-horde-asymmetric/app/node_modules/ws/wrapper.mjs';

const source = path.resolve(process.argv[2]);
const label = process.argv[3] || 'unspecified';
const expected = process.argv[4] || 'observe';
const {Hub} = await import(pathToFileURL(path.join(source, 'app/server/game.js')));
const {SnapshotDecoder} = await import(pathToFileURL(path.join(source, 'app/public/js/snapshot-codec.js')));
const {HORDE_PACKS} = await import(pathToFileURL(path.join(source, 'app/public/shared/horde-content.js')));
const {PLAYER_RADIUS} = await import(pathToFileURL(path.join(source, 'app/public/shared/content.js')));
const clientText = fs.readFileSync(path.join(source, 'app/public/js/game.js'), 'utf8')
 .replaceAll("'/shared/", "'" + pathToFileURL(path.join(source, 'app/public/shared/')).href);
const {Game} = await import('data:text/javascript;base64,' + Buffer.from(clientText).toString('base64'));
const rows = [];
let cleanedScenes=0;
const near = (a,b) => Math.abs(a-b) < 1e-7;
const result = (name,data) => {rows.push({name,...data}); console.log(JSON.stringify(rows.at(-1)));};

// Real loopback sockets, native Hub routing and native snapshot codec. Only the
// encounter clock is advanced explicitly; no production listener/storage is used.
async function encounter(heroType='knight') {
 const peers = new Map(), clients=[];
 const hub = new Hub((pid,msg,json) => {
  const socket=peers.get(pid);
  if(socket?.readyState===WebSocket.OPEN) socket.send(json ?? JSON.stringify(msg));
 });
 const server = new WebSocketServer({host:'127.0.0.1',port:0});
 await once(server,'listening'); let nextPid=0, ping=0;
 server.on('connection', socket => {
  const pid=++nextPid; peers.set(pid,socket); hub.addPlayer(pid,'Independent '+pid,'independent-'+pid); hub.welcome(pid);
  socket.on('message', bytes => hub.handle(pid,JSON.parse(bytes.toString())));
  socket.on('close',()=>peers.delete(pid));
 });
 async function connect() {
  const socket=new WebSocket('ws://127.0.0.1:'+server.address().port), frames=[], decoder=new SnapshotDecoder();
  const client={socket,frames,decoder}; clients.push(client);
  socket.on('message', bytes=>{const m=JSON.parse(bytes.toString());frames.push(m);});
  await once(socket,'open');
  client.wait=async(predicate,from=0)=>{const until=Date.now()+2000; while(Date.now()<until){const m=frames.slice(from).find(predicate);if(m)return m;await delay(1);}throw Error('Missing frame '+JSON.stringify(frames.slice(from).map(m=>m.t)));};
  client.pid=(await client.wait(m=>m.t==='welcome')).pid;
  client.send=async(msg)=>{const mark=frames.length,c='independent-'+(++ping);socket.send(JSON.stringify(msg));socket.send(JSON.stringify({t:'ping',c}));await client.wait(m=>m.t==='pong'&&m.c===c,mark);};
  return client;
 }
 const director=await connect(), player=await connect();
 await director.send({t:'create',ruleset:'horde',hero:'knight'});
 const room=hub.players.get(director.pid).room;
 await player.send({t:'join',code:room.code,hero:heroType,heroes:[heroType]});
 await director.send({t:'start'});
 assert.equal(room.state,'play'); const hero=room.heroes.get(player.pid);assert.ok(hero);
 const mode=room.horde;
 const pos=async(x,y=0,seq)=>player.send({t:'pos',x,y,seq});
 const buy=async(pack,x,y)=>{
  const before=mode.resource,mark=director.frames.length;
  await director.send({t:'horde',roundId:mode.roundId,action:'spawn',pack,x,y,seq:mode.lastSeq+1});
  assert.equal(mode.pending.length,1,JSON.stringify(director.frames.slice(mark)));
  const cost=mode.packCost(HORDE_PACKS[pack]);assert.equal(before-mode.resource,cost);
  return {before,cost,paid:mode.resource,deadline:mode.pending[0].at};
 };
 const key=async()=>{
  const from=player.frames.length;room.snapshot();await player.send({t:'ping',c:'flush'});
  const wire=player.frames.slice(from).find(m=>m.t==='s');assert.ok(wire);
  const plain=player.decoder.decode(wire);assert.ok(plain);return {wire,plain};
 };
 const restore=async()=>{
  const from=player.frames.length;await player.send({t:'join',code:room.code});
  const frames=player.frames.slice(from), start=frames.find(m=>m.t==='start'), state=frames.find(m=>m.t==='horde-resync');
  assert.ok(start&&state);assert.ok(frames.indexOf(start)<frames.indexOf(state));
  const game=new Game({send(){}});game.me=hero.pid;game.begin(start);game.onHordeResync(state);
  const {wire,plain}=await key(); assert.equal(wire.K,1,'native rejoin requests a full key');
  game.onSnapshot(plain);game.view.tm=plain.tm;game.teleTm=plain.tm;game.applyEffects();game.updateEffects(0);
  return {game,state,wire};
 };
 const close=async()=>{const all=[...clients.map(c=>c.socket),...server.clients];const closed=all.filter(s=>s.readyState!==WebSocket.CLOSED).map(s=>once(s,'close'));for(const s of all)s.terminate();await Promise.all(closed);await new Promise(r=>server.close(r));hub.rooms.clear();hub.players.clear();assert.equal(server.clients.size,0);assert.equal(server.address(),null);assert.equal(hub.rooms.size,0);assert.equal(hub.players.size,0);cleanedScenes++;};
 return {hub,room,mode,hero,director,player,pos,buy,key,restore,close};
}

async function run(name,fn){const f=await encounter();try{await fn(f);}finally{await f.close();}}

await run('held-pos-jump',async f=>{
 await f.pos(0,0,1); const begin=Date.now();
 // While only pos is held, native Hub ping remains active on the same open WS.
 for(let n=1;n<=33;n++){await delay(1000/30);f.room.time=n/30;if(n===16||n===33)await f.player.send({t:'ping',c:n});}
 if(Date.now()-begin<1100)await delay(1100-(Date.now()-begin));
 await f.pos(1700,0,2);const jump=f.hero.x;
 const restored=await f.restore();await f.pos(1700,0,3);const afterRepeat=f.hero.x;
 const {plain}=await f.key();const ack=plain.pa.find(x=>x[0]===f.hero.pid);
 assert.ok(ack&&ack[1]===3);assert.equal(afterRepeat,jump);
 result('held-pos-jump',{jump,afterRepeat,ack,wsOpen:f.player.socket.readyState===WebSocket.OPEN,simulationGap:1.1,wallMs:Date.now()-begin,resyncAfterJump:!!restored.state});
 if(expected==='fixed')assert.ok(jump<=5.5+1e-7);
 if(expected==='old')assert.ok(near(jump,165));
});

async function packScene(held){let data;await run('paid-pack',async f=>{
 await f.pos(0,0,1);
 for(let n=1;n<=33;n++){f.room.time=n/30;if(!held)await f.pos(0,0,n+1);else if(n===16)await f.player.send({t:'ping',c:'alive'});}
 const payment=await f.buy('swarm',665,0);await f.pos(1700,0,35);const initialJump=f.hero.x;
 for(let n=1;n<=60;n++){f.room.time=1.1+n/30;await f.pos(f.hero.x+5,0,35+n);}
 f.mode.tick(0,[f.hero]);await f.director.send({t:'ping',c:'birth-flush'});const units=f.room.enemies.filter(e=>e.hordeSource==='manual');
 data={held,initialJump,x:f.hero.x,...payment,units:units.length,resource:f.mode.resource,cancelled:f.director.frames.some(m=>m.t==='err'&&/отменён/.test(m.msg)),born:units.map(e=>[e.hordePack,e.x,e.y])};
 });return data;}
const paced=await packScene(false),held=await packScene(true);result('paid-swarm-A-B',{paced,held});
assert.equal(paced.units,12);assert.equal(held.units,expected==='old'?0:12);assert.equal(held.cancelled,expected==='old');

async function blastScene(held){let data;await run('warned-blast',async f=>{
 // Prepared hostile-blast fixture; native chill, warning, explosion and damage.
 f.hero.perk.readyAt=Infinity;await f.pos(0,0,1);f.mode.combat.chill(f.hero,{duration:3});
 f.room.addBlast(0,0,100,8,0,null,1,1.1);const hp=f.hero.hp,warning=f.room.fx.find(e=>e[0]==='warn');
 for(let n=1;n<33;n++){f.room.time=n/30;if(!held)await f.pos(0,0,n+1);}
 f.room.time=1.1;await f.pos(1700,0,35);f.room.updateBlasts();
 data={held,x:f.hero.x,hpBefore:hp,hpAfter:f.hero.hp,warning,slow:f.mode.heroSpeedMul(f.hero)};
 });return data;}
const regularBlast=await blastScene(false),heldBlast=await blastScene(true);result('chilled-blast-A-B',{regular:regularBlast,held:heldBlast});
assert.ok(regularBlast.hpAfter<regularBlast.hpBefore);
assert.equal(heldBlast.hpAfter<heldBlast.hpBefore,expected!=='old');

await run('paced-jitter-slow',async f=>{
 await f.pos(0,0,1);let x=0,seq=1;
 for(const interval of [1/30,1/30,.12,1/30,.09,1/30]){f.room.time+=interval;x+=150*interval;await f.pos(x,0,++seq);assert.ok(near(f.hero.x,x));}
 const fastX=f.hero.x;f.mode.combat.chill(f.hero,{duration:3});
 f.room.time+=.12;x+=150*.82*.12;await f.pos(x,0,++seq);assert.ok(near(f.hero.x,x));
 const mark=f.hero.x;await f.pos(1700,0,++seq);assert.equal(f.hero.x,mark);
 const {plain}=await f.key();assert.equal(plain.pa.find(a=>a[0]===f.hero.pid)[1],seq);
 result('paced-jitter-slow',{fastX,slowX:f.hero.x,ack:seq,interval120msAccepted:true,repeatedPosBonus:0});
});

function lineDistance(point,lane){const dx=lane.x2-lane.x1,dy=lane.y2-lane.y1;const k=Math.max(0,Math.min(1,((point.x-lane.x1)*dx+(point.y-lane.y1)*dy)/(dx*dx+dy*dy)));return Math.hypot(point.x-lane.x1-dx*k,point.y-lane.y1-dy*k);}
async function sniperScene(displaced,omitAim=false){const f=await encounter('witch');try{
 // Explicit geometry/build fixture, but purchase, carrier, aim, Ward knockback,
 // Hub join, key codec, Game recovery, native volley and HP are all native.
 f.room.time=160;f.mode.build.packs.snipers=1;
 const payment=await f.buy('snipers',-1000,0);f.room.time=payment.deadline;f.mode.tick(0,[f.hero]);
 const units=f.room.enemies.filter(e=>e.hordeSource==='manual');assert.equal(units.length,5);
 const sniper=units.find(e=>e.ai==='sniper');for(const e of units){e.x=-1000;e.y=-1000;}
 sniper.x=0;sniper.y=0;f.hero.x=500;f.hero.y=0;sniper.shotT=0;
 assert.equal(f.room.sniperTick(sniper,f.hero,500,0),true);const deadline=f.room.time+sniper.windT;
 const original=f.room.fx.filter(e=>e[0]==='bline');assert.equal(original.length,5);
 // Flush first key before displacement, reproducing reconnect after original aim.
 await f.key();const origin={x:sniper.aimX,y:sniper.aimY};
 if(displaced){
  f.hero.x=0;f.hero.y=60;f.hero.weapons=new Map([['ward',{lvl:1,t:12}]]);f.hero.ward=1;f.hero.wardMax=1;
  f.room.rebuildGrid();f.room.hurtPlayer(f.hero,1,'independent-trigger');assert.equal(f.hero.ward,0);assert.ok(near(sniper.y,-60));
 }
 f.hero.x=500;f.hero.y=0;f.hero.iframes=0;f.hero.hostilePos={x:500,y:0};
 if(omitAim){delete sniper.aimX;delete sniper.aimY;}
 f.room.time+=.2;f.room.sniperTick(sniper,f.hero,500,.2);
 const {game,state}=await f.restore();assert.equal(state.lanes.length,5);assert.equal(game.blines.length,5);
 for(const l of state.lanes)assert.ok(near(state.time+l.remaining,deadline));
 assert.deepEqual(game.blines.map(l=>[l.x1,l.y1,l.x2,l.y2,l.w,l.life]),state.lanes.map(l=>[l.x1,l.y1,l.x2,l.y2,l.w,l.remaining]));
 const rendered=game.blines.map(({x1,y1,x2,y2,w,life})=>({x1,y1,x2,y2,w,life}));
 f.room.time+=.1;f.room.sniperTick(sniper,f.hero,500,.1);const again=await f.restore();
 for(const l of again.state.lanes)assert.ok(near(again.state.time+l.remaining,deadline));
 const hp=f.hero.hp;const remaining=sniper.windT;f.room.time+=remaining;f.room.sniperTick(sniper,f.hero,500,remaining+1e-8);
 const shots=f.room.hostile.map(s=>({x:s.x,y:s.y,vx:s.vx,vy:s.vy}));assert.equal(shots.length,5);
 const mismatches=state.lanes.filter((l,i)=>!near(l.x1,shots[i].x)||!near(l.y1,shots[i].y));
 const distances=state.lanes.map(l=>lineDistance(f.hero,l));
 const outsideAllLanes=distances.every((d,i)=>d>PLAYER_RADIUS+state.lanes[i].w/2);
 f.room.time+=3.1;f.room.updateHostile(3.1);
 const data={displaced,omitAim,payment,unitCount:units.length,aim:origin,current:{x:sniper.x,y:sniper.y},deadline,restoreTime:state.time,remaining:state.lanes[0].remaining,repeatedRemaining:again.state.lanes[0].remaining,rendered,shots,mismatchCount:mismatches.length,distances,outsideAllLanes,hpBefore:hp,hpAfter:f.hero.hp};
 result('sniper-'+(omitAim?'fallback':displaced?'displaced':'control'),data);
 if(expected==='fixed')assert.equal(mismatches.length,0);
 if(expected==='old'&&displaced&&!omitAim)assert.equal(mismatches.length,5);
 if(expected==='old'&&displaced&&!omitAim)assert.equal(outsideAllLanes,true);
 if(!displaced||omitAim)assert.equal(mismatches.length,0);
 if(!displaced||!omitAim)assert.ok(f.hero.hp<hp,'actual native volley hits the target on the original central lane');
 return data;
 }finally{await f.close();}}
await sniperScene(true);await sniperScene(false);await sniperScene(true,true);

assert.equal(cleanedScenes,9);
console.log(JSON.stringify({summary:{label,source,expected,node:process.version,platform:process.platform,cases:rows.length,cleanup:{scenes:cleanedScenes,openSockets:0,listeningServers:0,retainedHubs:0},status:'PASS'},rows}));
