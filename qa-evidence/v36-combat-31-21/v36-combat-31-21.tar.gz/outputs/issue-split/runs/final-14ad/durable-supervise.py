import pathlib,json,os,sys,subprocess,datetime,time,hashlib,traceback
cfgpath=pathlib.Path(sys.argv[1]);cfg=json.loads(cfgpath.read_text());stem=pathlib.Path(cfg['stem']);Q=pathlib.Path(cfg['planDir']);m=cfg['metadata'];cmd=cfg['command'];env=cfg['environment']
def atomic(path,obj):
 path=pathlib.Path(path);tmp=path.with_name(path.name+'.tmp-'+str(os.getpid()))
 with tmp.open('w')as f:json.dump(obj,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 os.replace(tmp,path)
def f(s):return stem.with_suffix(s)
t0=time.monotonic();out=f('.json');err=f('.stderr.txt');observed=None
try:
 with out.open('xb')as stdout,err.open('xb')as stderr:
  p=subprocess.Popen(cmd,env=env,cwd=Q,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
  atomic(f('.worker.json'),{'supervisorPID':os.getpid(),'nodePID':p.pid,'command':cmd,'configSHA256':hashlib.sha256(cfgpath.read_bytes()).hexdigest(),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()})
  timedout=False
  try:code=p.wait(timeout=240)
  except subprocess.TimeoutExpired:timedout=True;p.kill();code=p.wait()
 observed={'observedExitCode':code,'nodePID':p.pid,'supervisorPID':os.getpid(),'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timeout':timedout,'durationSeconds':time.monotonic()-t0}
 atomic(f('.exit.json'),observed)
 m.update(exitCode=code,observedExitRecord=str(f('.exit.json')),observedExit=observed,durationSeconds=observed['durationSeconds'])
 data=json.loads(out.read_text());logs=data['logs'];cs=data['completion'];l=logs[0];c=cs[0]
 expected={k:m[k]for k in ['players','heroes','mode','bot']};actual={'players':len(l['team']),'heroes':[h['hero']for h in l['team']],'mode':l['mode'],'bot':data['pick']};proof=len(logs)==len(cs)==1 and c['terminal']is True and c['state']=='over'and c['finishCalls']==1 and c['logId']==l['id'];tupleOK=actual==expected and data['N']==m['players'];m.update(completionProof=proof,tupleProof=tupleOK,actualTuple=actual,expectedTuple=expected,completion=cs,win=l['win'],budgetOverrun=l['time']>l['runLength']+.11,terminalProof=code==0 and proof and tupleOK and not timedout)
 if cfg['kind']=='daily':
  lines=[x for x in err.read_text().splitlines()if x.startswith('DAILY_SELECTOR_METRICS ')];assert len(lines)==1;dm=json.loads(lines[0].split(' ',1)[1]);assert len(dm['records'])==1;rec=dm['records'][0];contract=rec['contract'];dp=dm['actualHostSelector']is True and dm['actualLockDaily']is True and dm['noExtraRngCalls']is True and contract['version']==2 and contract['id']==m['dailyRule']and contract['day']==m['dailyDay']and contract['mode']==m['mode']and contract['players']==m['players']and contract['mods']==cfg['expectedDailyContracts'][m['dailyRule']]and rec['finished']is True and rec['terminalState']=='over'and rec['logId']==l['id']and rec['loggedContract']==l['daily']==contract and rec['swarmWins']<=2;m.update(dailyContractProof=dp,dailyContract=contract,dailyTelemetry=rec,selectorPolicySHA256=cfg['selectorPolicySHA256'],terminalProof=m['terminalProof']and dp)
 if cfg['kind']=='guarded':
  lines=[x for x in err.read_text().splitlines()if x.startswith('DASH_POLICY_METRICS ')];assert len(lines)==1;dm=json.loads(lines[0].split(' ',1)[1]);gp=dm['parameters']==cfg['guardPolicyParameters']and dm['dash']==cfg['dashParameters']and dm['canonicalChoicesAndMovementUnmodified']is True and dm['noExtraRngCalls']is True and dm['attempted']==dm['accepted']+dm['rejected']and dm['accepted']==len(dm['records'])and dm['identityMismatches']==dm['cooldownViolations']==dm['iframesAdded']==dm['unfinishedDashes']==0;m.update(guardedPolicyProof=gp,requestMetadataProof=dm['identityMismatches']==0,guardedInputMetrics={k:dm[k]for k in ['attempted','accepted','rejected','identityMismatches','cooldownViolations','iframesAdded','damagingDashes','unfinishedDashes','vetoes']},terminalProof=m['terminalProof']and gp)
except Exception as e:
 m.update(terminalProof=False,error=repr(e),supervisorDiagnostic=traceback.format_exc())
 if observed is None:m.update(exitUnknown=True,executionStatus='EXIT_UNKNOWN',exitCode=None)
m.update(finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='terminal'if m.get('terminalProof')else'exitUnknown'if m.get('exitUnknown')else'failed')
atomic(f('.meta.json'),m)
if not m.get('terminalProof'):
 hold={'attemptId':m['attemptId'],'sourceSha':m['sourceSha'],'reason':'durableactualcontractfailure-or-exitunknown; nofallback/noretry'}
 atomic(Q/('PAUSE-issue-'+str(m['issue']))if cfg['kind']=='combat'else Q/'PAUSE',hold)
