# #31 solo Night pressure — SCOPED READY / balance INCOMPLETE

**SCOPED READY: scalar implementation, effective-cell carry, exact full CI and ONE120 execution preparation. Full-match balance acceptance remains INCOMPLETE until the planned120 results exist.** No important regression found in this narrow change. Independent reviewer did not edit the app, tests, registry or operator. Review-master was applied; no new confirmed finding required another verifier. Product critique preceded the authored patch; it is not outcome evidence for the new coefficient.

Final head **1c93a575bb811a6992134e636b2423aa893e054d**, current base **13c560f4d5f16a12333d167806f9a5b20e601c4a**, PR58. Previous measured candidate **679190c7ec5bb979761660593cca0ff1e1da6cbe**; ordinary measured reference **a957c394460c0f6a67d9ea211c2f5001d64209e1** remains separate. Initial authored/merged headbb533131 and its failed CI are retained as history, not relabeled successful.

Git author of final test-only commit: Сергей Конев. Reviewer: independent runs/eight_balance_acceptance, not an app author/coauthor for this implementation. No code findings remain open in this scoped review.

## Code and affected behavior

The only canonical production change is content.js Night.dmgMul[0]0.75→0.65 plus its explanatory comment. HP1.8, group/Lunch arrays and all39 signature definitions are otherwise byte-equal. modeDmgMul indexes the existing player bucket; resetSim applies it, native spawn damage propagates it into contact/projectile channels, and hurtPlayer applies trait/armor/guard then minimum1. The implementation changes13.33% of that pre-armor scalar, not a predicted win rate or a uniform final-HP-loss percentage. No new RNG draw/input or weapon dispatch is introduced. Existing rescaleGroup2→1 reaches the changed entry and rescales a living enemy through the same formula.

Read the six new test bodies and exact CI native output: armor0/2/100 actual hurt/floor cases, existing-enemy2→1 rescale, Lunchsolo and Nightduo controls.6/6PASS. These are actual CI executions, not six new local reruns. Author's old4RED/2controls account was not used in place of this independent source/primary check. A short additional plan smoke was necessary only to bind the new archived APP to standard native play/finish/log transport: two five-tick manual scenes passed, natural full-match attempts0. No broad weapon/strength/performance audit was repeated.

## Carry boundaries

`effective-cells-carry-proof.json` independently compares the12-module canonical Room import closure from679 to final1c93 and both canonical runners. The reachable production module set is unchanged; only the one content scalar/comment differs. Main13c's deployment HTTP entry/server.js and deploy/CI tools are outside this import graph. Ordinary a957→main13c Room closure and canonical runner bytes are also equal. This is a command/path proof, not HTTP/deployment/UI/CPU/network acceptance.

New cells0/8 are human1Night and smart1Night. Other8 fixed-roster canonical cells1–7/9 can carry480 outcomes from **actual679**: Lunch never reads the changed mode entry; Nightgroups use entries1–3, and canonical bots never remove/offline members. Do not call this600 fresh results or relabel carried raw1c93. A live coop shrinking2→1 is explicitly a changed transition, covered by the native check rather than silently included in fixedN carry. Human/smart Night each require60 new candidate outcomes. Smart Lunch loss remains disclosed and outside the patch; scoped strength tradeoffs remain unchanged.

## Exact full CI

Final [Server CI43635356333](https://github.com/AGaziev/night-horde/actions/runs/43635356333): **58/58PASS**, all current server *-test.js files covered, Node24.22.2. Artifact headers name head1c93/base13c; checkout23610240a25f6634e8291f7dbc8dfed877508247 has those exact parents and its tree equals finalhead. Primary run/checkout/revisions/results/logs and hashes are retained under `ci-primary/43635356333`; measurement uses the unchanged Node24.22.1 binarycf52d093.

Prior run43634412380 onbb533 was57/58: sim-test.js:2044 expected obsolete.75 while actual.65; new native pressure suite passed. It was not a CPU-threshold failure. Finalbb533→1c93 changes only that expected table in sim-test.js; production is byte-identical. Old primary failure/logs remain under their original run directory.

## Prepared operational handoff

Exactly one immutable120 plan is at `runs/solo-night31-20261114/issue31-1c93a57-solo-night`: original cells0/8,60 each, seeds130000–130059/138000–138059,K00–59, original eight-hero rotation, ordinary canonical policy, exact Git archive app+pm/SOURCE_SHA/flatSHA256. Actual Node24.22.1 and canonical hashesb270c568/a35bd680 pass. Masterv5/supervisorv3 are byte-equal accepted copies. Comparison references keep actual679 and actuala957 separate. No adapter, gameplay env overrides, sample adaptation, old raw substitution or retry is configured.

**HOLD0 / NOT_REGISTERED:** PAUSE present, worker0, rootArmedfalse, launch-authorizedfalse, rawempty, no bootstrap/master/Node full attempt. `register.py` is prepared and syntax-checked only, never executed; it would append one HOLD entry through the existing operator lock and preserve every old registry entry/root key. Root retains registration, arm, shared max9 budget and confirmed start. `HANDOFF.md` has exact paths/commands. New plan/source bindings are immutable; historical679/bb533/a957/UNKNOWN/retired evidence was not altered. No app commits or publication were performed by this role.
