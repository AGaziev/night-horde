from pathlib import Path
import argparse,ast,collections,csv,datetime,hashlib,json,math,random,re,statistics

OUT=Path(__file__).resolve().parent
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def require(ok,message):
 if not ok:raise ValueError(message)
def tuple_key(a):return {k:a[k]for k in ['id','cell','bot','players','mode','seed','K0','heroes']}
def gate(g):
 if g.get('planDir')is None:return {'status':'UNBOUND','reason':g.get('note','future explicit binding required')}
 q=Path(g['planDir']);paths={k:q/f for k,f in [('state','controller-state.json'),('complete','controller-complete.json'),('exit','launchd/exit.json'),('started','launchd/started.json')]}
 if any(not p.exists()for p in paths.values()):return {'status':'WAIT_CONTROLLER_COMPLETION','missing':[k for k,p in paths.items()if not p.exists()],'candidateRawRead':False}
 s,c,e,t=(read(paths[k])for k in ['state','complete','exit','started']);counts={k:s.get(k)for k in ['done','terminal','active','pending','unknown']};ok=s.get('active')==s.get('pending')==0 and s.get('terminal')==s.get('done')==600 and not s.get('unknown')and c.get('scopeTarget')==c.get('scopeTerminal')==c.get('completed')==600 and c.get('failed',0)==0 and not c.get('unknown')and e.get('observedMasterExitCode')==0 and e.get('masterPID')==t.get('masterPID')
 return {'status':'ELIGIBLE_COMPLETE600'if ok else'WAIT_OR_INVALID_CONTROLLER','counts':counts,'observedMasterExitCode':e.get('observedMasterExitCode'),'controllerPaths':{k:str(v)for k,v in paths.items()},'controllerHashes':{k:sha(v)for k,v in paths.items()},'candidateRawRead':False}

def source_plan(g,selection,canonical=None):
 q=Path(g['planDir']);p=read(q/'plan.json');require(sha(q/'plan.json')==g['planSHA256'],'selected plan hash changed');require(len(p['attempts'])==600,'fixed600 plan required');require(p['runtime']==selection['runtime']and p['nodeBinarySHA256']==selection['nodeBinarySHA256'],'runtime identity mismatch');require(sha(p['node'])==p['nodeBinarySHA256'],'actual Node binary hash mismatch')
 require(all(p['canonicalRunnerHashes'][k]==v for k,v in selection['canonicalRunnerHashes'].items()),'canonical runner declarations mismatch')
 for n,h in p['canonicalRunnerHashes'].items():require(sha(q/'harness/pm'/n)==h,'actual runner bytes mismatch: '+n)
 ids=[a['id']for a in p['attempts']];require(len(set(ids))==600,'duplicate logical id');require(collections.Counter(a['cell']for a in p['attempts'])=={i:60 for i in range(10)},'must have60 planned tuples in each of10cells')
 if canonical is not None:require([tuple_key(a)for a in p['attempts']]==[tuple_key(a)for a in canonical['attempts']],'candidate tuples differ from baseline')
 rec=read(q/'active-recovery.json');over=rec.get('retryOverrides',{});require(not over if g.get('noOverrides')else True,'baseline override must remain0')
 b=read(q/'candidate-bindings.json')['issues'][str(g['issue'])];require(b['candidateSha']==g['measuredSourceSha'],'binding source differs from selected actual source');require(b['candidateSha']not in selection['forbiddenCandidateSources']or g['issue']==45,'retired candidate cannot be selected');s=Path(b['snapshotPath']);require((s/'SOURCE_SHA').read_text().strip()==b['candidateSha'],'snapshot SOURCE_SHA mismatch');require(sha(s/'SHA256.json')==b['manifestSHA256'],'source manifest hash mismatch')
 for f,h in read(s/'SHA256.json').items():require(sha(s/f)==h,'source file changed: '+f)
 if p.get('executionKind')=='daily':require(p['expectedDailyVersion']==3,'daily v3 required');require(sha(q/'daily-selector.mjs')==p['selectorPolicySHA256'],'selector bytes mismatch');require(p['expectedDailyContracts']['armor']=={'armor':1,'speed':.9},'wrong Armor v3 modifier')
 if p.get('executionKind')=='guarded':require(sha(q/'guard-core.mjs')==p['policyCoreSHA256']and sha(q/'guarded-policy.mjs')==p['policySHA256'],'guard wrapper/core bytes mismatch')
 if g.get('carryProof'):
  proof=read(g['carryProof']);require(sha(g['carryProof'])==g['carryProofSHA256'],'carry proof changed');require(proof['before']==g['measuredSourceSha']and proof['after']==g['outcomeApplicableHead']and proof['serverSharedCanonicalAndOtherClientLeavesIdentical']is True,'UI-only carry endpoints/scope mismatch')
 return q,p,b,rec,over

def prefix(q,b,a,over):
 if a['attemptId']in over:return Path(over[a['attemptId']]['retryPrefix'])
 d=q/'raw'/('issue-'+str(a['issue']))/b['candidateSha'];return d/a['dailyRule']/a['id']if'dailyRule'in a else d/a['id']

def swarm_validate(rec,players,source):
 errors=[];co=rec.get('finalCohorts',[]);aw=rec.get('awards',[]);resolved=rec.get('resolutions',[]);require(len(co)<=2 and len(resolved)<=2 and rec.get('swarmWins',0)<=2,'Swarm finite first2 cap violated');content=(source/'app/public/shared/content.js').read_text();m=re.search(r'export const OLD_GEM_SHARE\s*=\s*([\d.]+)',content);require(m is not None,'cannot independently parse XP sharing constant');share=float(m[1]);require('Math.round((5 + (level - 1) * 8) * teamXpMul(players))'in content,'XP formula changed; review analyser before use');seen=set();successful=[]
 for c in co:
  require(all(isinstance(c[k],int)and not isinstance(c[k],bool)and c[k]>=0 for k in ['spawned','killed']),'invalid actual-born counters');require(c['killed']<=c['spawned'],'killed exceeds actually tagged births');require(c['at']<c['end'],'invalid cohort phase')
  if c['resolved']:require(c['success']==(c['spawned']>=1 and c['killed']*10>=c['spawned']*7),'success differs from70%actual-born criterion')
  if c['success']:successful.append(c)
 require(rec.get('swarmWins',0)==len(successful),'wins/cohort mismatch')
 for w in aw:
  matches=[c for c in successful if c['id']==w['cohort']and c['end']-1e-7<=w['at']<=c['end']+.11];require(len(matches)==1,'award outside successful native resolution');c=matches[0];key=(c['id'],c['end'],w['pid']);require(key not in seen,'duplicate observed cohort/pid award');seen.add(key);require(1<=w['pid']<=players,'award recipient outside team');next_xp=math.floor((5+(w['levelBefore']-1)*8)*(players/(1+share*(players-1)))+.5);expected=next_xp*.15;require(abs(w['amount']-expected)<1e-8 and abs(w['expected']-expected)<1e-8,'award not15%independently computed next level')
 require(len(aw)==len(successful)*players,'missing/extra first native award per recipient/cohort')
 for r in resolved:
  matches=[c for c in co if(c['id'],c['end'])==(r['id'],r['end'])];require(len(matches)==1 and r['resolved']and r['spawned']==matches[0]['spawned']and r['killed']==matches[0]['killed'],'resolution counters changed after native boundary')
 return {'cohorts':len(co),'resolved':sum(c['resolved']for c in co),'successful':len(successful),'actualBorn':sum(c['spawned']for c in co),'killed':sum(c['killed']for c in co),'observedAwards':len(aw),'totalAwardInput':sum(w['amount']for w in aw),'duplicateObservedAwardKeys':0,'formula15PercentVerified':True,'spawnCountNotAssumed':True}

def load_attempt(q,p,b,a,over):
 s=prefix(q,b,a,over);paths={k:s.with_suffix(v)for k,v in [('meta','.meta.json'),('raw','.json'),('stderr','.stderr.txt'),('exit','.exit.json'),('worker','.worker.json'),('dispatch','.dispatch.json'),('start','.start.json')]};require(all(x.is_file()for x in paths.values()),'missing physical artefact: '+str(s));m,d,e,w,cfg,start=(read(paths[k])for k in ['meta','raw','exit','worker','dispatch','start']);require(m.get('terminalProof')is True and m.get('exitCode')==0,'metadata not successful terminal');require(e['observedExitCode']==0 and e['timeout']is False,'native exit is not observed0');require(m.get('observedExit')==e and Path(m['observedExitRecord'])==paths['exit'],'exit receipt binding mismatch');require((e['nodePID'],e['supervisorPID'])==(w['nodePID'],w['supervisorPID']),'worker/exit PID mismatch');require(w['configSHA256']==sha(paths['dispatch']),'worker/config hash mismatch')
 if 'sourceBindingManifestSHA256'in m:require(m['sourceBindingManifestSHA256']==start['sourceBindingManifestSHA256']==cfg['metadata']['sourceBindingManifestSHA256']==b['manifestSHA256'],'per-attempt source manifest binding mismatch')
 require(m['sourceSha']==start['sourceSha']==b['candidateSha'],'actual source differs from measured source');require(all(m[k]==start[k]==a[k]for k in ['id','cell','players','heroes','mode','bot','seed','K0','attemptId']),'metadata tuple differs from plan');require(m['runtime']==p['runtime']and m['nodeBinarySHA256']==p['nodeBinarySHA256']and m['canonicalRunnerHashes']==p['canonicalRunnerHashes'],'per-attempt runtime/harness identity mismatch')
 expected=[p['node'],'--random-seed='+str(a['seed']),p['canonicalRunner'],str(a['players']),'1',a['bot']];require(m['command']==cfg['command']==w['command']==start['command']==expected,'actual argv differs from frozen tuple');env=m['environment'];require(env==cfg['environment']==start['environment']and env['APP']==b['snapshotPath']+'/app'and env['MODE']==a['mode']and env['K0']==str(a['K0']),'actual environment/source mismatch');require(not set(env)&{'NODE_OPTIONS','MODE_HP','MODE_DMG','FIN_HP','FIN_DMG','FIN_RATE','FIN_REVIVE','LATE_HP','LATE_DMG','H_OVR','FLEE'},'undeclared gameplay override');require(cfg['metadata']['sourceSha']==b['candidateSha']and cfg['metadata']['command']==expected,'dispatch metadata source/argv mismatch')
 require(len(d['logs'])==len(d['completion'])==1,'must have one log and completion');l=d['logs'][0];c=d['completion'][0];require(type(l['win'])is bool and l['win']==c['win']==m['win'],'win consistency');require(c['terminal']is True and c['state']=='over'and c['finishCalls']==1 and c['logId']==l['id'],'native Room.finish/over/log proof mismatch');require(d['N']==l['players']==a['players']and d['pick']==a['bot']and l['mode']==a['mode']and[h['hero']for h in l['team']]==a['heroes'],'raw actual tuple mismatch');budget=900 if a['mode']=='night'else 600;require(l['runLength']==c['runLength']==budget and 0<=c['time']<=budget+.11 and abs(l['time']-c['time'])<=.051,'native play budget/time mismatch');daily=None;sw=None
 if p.get('executionKind')=='daily':
  require(env['DAILY_RULE']==a['dailyRule']and env['DAILY_DAY']==a['dailyDay'],'actual selector input mismatch');lines=[x for x in paths['raw'].with_suffix('.stderr.txt').read_text().splitlines()if x.startswith('DAILY_SELECTOR_METRICS ')];require(len(lines)==1,'one native Daily telemetry record required');dm=json.loads(lines[0].split(' ',1)[1]);require(dm['actualHostSelector']and dm['actualLockDaily']and dm['noExtraRngCalls']and len(dm['records'])==1,'Daily host/lock proof mismatch');rec=dm['records'][0];daily=rec['contract'];require(m['dailyContractProof']is True and m['dailyContract']==l['daily']==daily==rec['loggedContract'],'Daily log/metadata binding mismatch');require(daily['version']==a['dailyVersion']==3 and daily['id']==a['dailyRule']and daily['day']==a['dailyDay']and daily['mode']==a['mode']and daily['players']==a['players']and daily['mods']==p['expectedDailyContracts'][a['dailyRule']],'actual v3/modifier contract mismatch');require(rec['finished']and rec['terminalState']=='over'and rec['logId']==l['id']and rec==m['dailyTelemetry'],'Daily telemetry identity mismatch');require(daily['mods']!={'armor':2,'speed':.9},'old Armor contract selected')
  if a['dailyRule']=='swarm':sw=swarm_validate(rec,a['players'],Path(b['snapshotPath']))
 if p.get('executionKind')=='guarded':require(m.get('guardedPolicyProof')is True and m.get('requestMetadataProof')is True,'guard native metadata/input proof missing')
 audit={'logicalAttemptId':a['attemptId'],'id':a['id'],'cell':a['cell'],'seed':a['seed'],'K0':a['K0'],'actualMeasuredSourceSha':b['candidateSha'],'prefix':str(s),'actualRunLogId':l['id'],'hashes':{k:sha(v)for k,v in paths.items()},'explicitRecovery':m.get('explicitRecovery'),'nativeExit0':True,'terminalTupleProof':True}
 return l,audit,sw

def audit_group(g,selection,canonical=None):
 q,p,b,rec,over=source_plan(g,selection,canonical);data={};rows=[];errors=[];sw=[]
 for a in p['attempts']:
  try:l,row,t=load_attempt(q,p,b,a,over);data[a['id']]=l;rows.append(row);sw.extend([t]if t else [])
  except Exception as e:errors.append({'logicalAttemptId':a['attemptId'],'id':a['id'],'prefix':str(prefix(q,b,a,over)),'reason':repr(e)})
 return data,{'actualMeasuredSourceSha':g['measuredSourceSha'],'outcomeApplicableHead':g.get('outcomeApplicableHead',g['measuredSourceSha']),'planned':600,'valid':len(data),'failedOrMissing':errors,'physicalAttempts':rows,'originalUnknownRetained':rec.get('originalUnknown',[]),'selectedRetryOverrides':over,'swarm':{'records':len(sw),'totals':{k:sum(x[k]for x in sw)for k in ['cohorts','resolved','successful','actualBorn','killed','observedAwards','totalAwardInput','duplicateObservedAwardKeys']},'coverage':'First recorded native award per recipient/cohort; native resolved latch/source contract prevents repeated resolution. No attribution of other XP calls.'}if sw else None},p,b

def old_engine(selection):
 path=Path(selection['legacyStatsSource']);tree=ast.parse(path.read_text());ns={'OUT':OUT,'math':math,'statistics':statistics,'collections':collections,'re':re};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(path),'exec'),ns);return ns
def paired(pairs,seed,iterations):
 d=[int(c['win'])-int(b['win'])for b,c in pairs];n=len(d);mean=statistics.mean(d);se=statistics.stdev(d)/math.sqrt(n);lost=d.count(-1);gained=d.count(1);discordant=lost+gained;rng=random.Random(seed);boot=sorted(sum(rng.choices(d,k=n))*100/n for _ in range(iterations));p=min(1,2*sum(math.comb(discordant,i)for i in range(min(lost,gained)+1))/(2**discordant))if discordant else 1
 return {'n':n,'deltaPP':round(mean*100,2),'pairedNormal95CI':[round((mean-1.96*se)*100,2),round((mean+1.96*se)*100,2)],'bootstrap95CI':[round(boot[math.floor(.025*(iterations-1))],2),round(boot[math.ceil(.975*(iterations-1))],2)],'bootstrapIterations':iterations,'bootstrapSeed':seed,'lostWins':lost,'gainedWins':gained,'discordantPairs':discordant,'bothWin':sum(b['win']and c['win']for b,c in pairs),'bothLose':sum(not b['win']and not c['win']for b,c in pairs),'exactMcNemarTwoSided':p}
def target(stat,bot,selection):
 t=selection['targets'][bot];lo,hi=t.get('minPercent'),t.get('maxPercent');point=stat['winPercent'];ci=stat['wilson95'];bad=(lo is not None and point<lo)or(hi is not None and point>hi);status='POINT_IN_RANGE'
 if lo is not None and ci[1]<lo:status='CI_BELOW_TARGET'
 elif hi is not None and ci[0]>hi:status='CI_ABOVE_TARGET'
 elif bad:status='POINT_OUTSIDE_TARGET_CI_OVERLAPS'
 return {'target':t,'status':status,'pointDeviationPP':round(point-lo,2)if lo is not None and point<lo else round(point-hi,2)if hi is not None and point>hi else 0,'notAutomaticProductVerdict':True}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--selection',default=str(OUT/'selection.json'));ap.add_argument('--baseline-only',action='store_true');ap.add_argument('--groups',nargs='*');args=ap.parse_args();sel=read(args.selection);proof=read(sel['baselineProof']);require(sha(sel['baselineProof'])==sel['baselineProofSHA256']and proof['baseline']==sel['logicalBase']and proof['measuredSource']==sel['baseline']['measuredSourceSha']and proof['newBaselineRuns']==0,'baseline reuse proof identity/hash mismatch');require(len(sel['groups'])==8,'selection must name exactly8standard groups');require(all(g.get('measuredSourceSha')not in sel['forbiddenCandidateSources']for g in sel['groups'].values()if g.get('measuredSourceSha')),'retired candidate bound');stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ');dest=OUT/'runs'/stamp;dest.mkdir(parents=True);(dest/'selection-used.json').write_bytes(Path(args.selection).read_bytes());(dest/'analyse-used.py').write_bytes(Path(__file__).read_bytes());result={'at':stamp,'selectionPath':str(Path(args.selection).resolve()),'selectionSHA256':sha(args.selection),'analysisScriptSHA256':sha(__file__),'legacyStatsSourceSHA256':sha(sel['legacyStatsSource']),'baselineMeasuredSourceSha':sel['baseline']['measuredSourceSha'],'baselineLogicalBase':sel['logicalBase'],'candidatePartialOutcomesRead':False,'groups':{},'metricsNotes':['Every down event is counted, including revivable coop downs.','Midpoint inventory excludes early-ended runs; imprint uncertainty and end-inventory mismatches are explicit.','Boss damage/finale reach are survival/progression-sensitive, not standalone causal DPS.','Smart QUALITY target is approximately no higher than75%, not a75%minimum.','No adaptive N, tuning, fresh replication data or auto source discovery.']};bg=gate(sel['baseline']);require(bg['status']=='ELIGIBLE_COMPLETE600','baseline controller not complete with actual exit0');base,ba,bp,bb=audit_group(sel['baseline'],sel);save(dest/'baseline-audit.json',ba);require(ba['valid']==600 and not ba['failedOrMissing'],'baseline physical600 audit failed');result['baselineAudit']={'status':'PASS','valid':600,'file':str(dest/'baseline-audit.json'),'rawSHAAttributionUnchanged':True};engine=old_engine(sel);engine['MAP']={'baseline':engine['mapping'](bb['snapshotPath'])};wanted=set(args.groups or sel['groups']);require(wanted<=set(sel['groups']),'unknown group label')
 if not args.baseline_only:
  for label,g in sel['groups'].items():
   if label not in wanted:result['groups'][label]={'status':'NOT_REQUESTED','candidateRawRead':False};continue
   complete=gate(g);result['groups'][label]=complete
   if complete['status']!='ELIGIBLE_COMPLETE600':continue
   try:data,audit,p,b=audit_group(g,sel,bp)
   except Exception as e:result['groups'][label]={'status':'INCOMPLETE_AUDIT','error':repr(e),'candidateStatsComputed':False};continue
   save(dest/(label+'-audit.json'),audit)
   if len(data)!=600 or audit['failedOrMissing']:result['groups'][label]={'status':'INCOMPLETE_AUDIT','audit':str(dest/(label+'-audit.json')),'valid':len(data),'failedOrMissing':audit['failedOrMissing'],'candidateStatsComputed':False};continue
   engine['MAP']['candidate']=engine['mapping'](b['snapshotPath']);cells=[]
   for ci,cell in enumerate(p['cells']):
    ids=[a['id']for a in p['attempts']if a['cell']==ci];require(len(ids)==60,'fixed60cell required');bs=[base[i]for i in ids];cs=[data[i]for i in ids];bst=engine['stats'](bs,'baseline');cst=engine['stats'](cs,'candidate');cells.append({'cell':ci,**cell,'baseline':bst,'candidate':cst,'paired':paired(list(zip(bs,cs)),sel['bootstrapSeed'],sel['bootstrapIterations']),'targetDeviation':target(cst,cell['bot'],sel)})
   result['groups'][label]={'status':'MEASURED_COMPLETE_NOT_PRODUCT_ACCEPTANCE','valid':600,'measuredSourceSha':g['measuredSourceSha'],'outcomeApplicableHead':g.get('outcomeApplicableHead',g['measuredSourceSha']),'carryProof':g.get('carryProof'),'audit':str(dest/(label+'-audit.json')),'sourceAttributionNeverRelabeled':True,'rows':cells,'swarmTelemetryAudit':audit['swarm']}
 save(dest/'summary.json',result)
 with(dest/'cells.csv').open('w')as f:
  w=csv.writer(f);w.writerow(['dataset','cell','bot','N','mode','baselineWins','wins','n','Wilson95','deltaPP','pairedNormal95','pairedBootstrap95','lost','gained','McNemar','targetDeviation'])
  for label,d in result['groups'].items():
   for r in d.get('rows',[]):w.writerow([label,r['cell'],r['bot'],r['players'],r['mode'],r['baseline']['wins'],r['candidate']['wins'],r['candidate']['terminal'],r['candidate']['wilson95'],r['paired']['deltaPP'],r['paired']['pairedNormal95CI'],r['paired']['bootstrap95CI'],r['paired']['lostWins'],r['paired']['gainedWins'],r['paired']['exactMcNemarTwoSided'],r['targetDeviation']['status']])
 save(OUT/'LATEST.json',{'at':stamp,'summary':str(dest/'summary.json'),'baselineAudit':str(dest/'baseline-audit.json'),'groupsRequested':[]if args.baseline_only else sorted(wanted)});print('BASELINE PASS600',dest);print({k:v['status']for k,v in result['groups'].items()})
if __name__=='__main__':main()
