from pathlib import Path
import argparse,ast,collections,csv,datetime,hashlib,importlib.util,json
OUT=Path(__file__).resolve().parent
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def need(ok,msg):
 if not ok:raise ValueError(msg)

def closed(g,n):
 if g.get('planDir')is None:return {'status':'UNBOUND','candidateRawRead':False,'reason':g.get('note')}
 q=Path(g['planDir']);files={k:q/v for k,v in [('state','controller-state.json'),('complete','controller-complete.json'),('started','launchd/started.json'),('exit','launchd/exit.json')]}
 if any(not p.exists()for p in files.values()):return {'status':'WAIT_COMPLETION','candidateRawRead':False,'missing':[k for k,p in files.items()if not p.exists()]}
 r={k:read(p)for k,p in files.items()};s,c,t,e=(r[k]for k in ['state','complete','started','exit'])
 good=s.get('done')==s.get('terminal')==s.get('scopeTarget')==s.get('scopeTerminal')==n and s.get('active')==s.get('pending')==0 and not s.get('unknown')and c.get('planned')==c.get('completed')==c.get('terminal')==c.get('scopeTarget')==c.get('scopeTerminal')==n and c.get('failed')==0 and not c.get('unknown')and e.get('observedMasterExitCode')==0 and e.get('masterPID')==t.get('masterPID')==s.get('masterPID')and e.get('launchdEntryPID')==t.get('launchdEntryPID')
 return {'status':'ELIGIBLE_COMPLETE'if good else'WAIT_OR_INVALID_CONTROLLER','planned':n,'candidateRawRead':False,'evidence':{k:{'path':str(p),'sha256':sha(p),'record':r[k]}for k,p in files.items()}}

def subset_source(g,sel,std,canonical):
 q=Path(g['planDir']);p=read(q/'plan.json');b=read(q/'candidate-bindings.json')['issues'][str(g['issue'])];rec=read(q/'active-recovery.json');cells=g['selectedCells'];n=g['fixedAttempts']
 need(sha(q/'plan.json')==g['planSHA256']and sha(q/'candidate-bindings.json')==g['bindingSHA256'],'selected immutable plan/binding changed')
 need(n in [120,300]and n==len(cells)*60 and len(p['attempts'])==p['finiteTarget']==n and len(set(cells))==len(cells),'invalid fixed subset size')
 need(collections.Counter(a['cell']for a in p['attempts'])=={ci:60 for ci in cells}and len({a['id']for a in p['attempts']})==n,'not60unique attempts per selectedcell')
 keys=['id','cell','bot','players','mode','seed','K0','heroes'];projection=lambda aa:[{k:a[k]for k in keys}for a in aa]
 need(projection(p['attempts'])==projection([a for a in canonical['attempts']if a['cell']in cells]),'subset tuples differ from original canonical plan')
 need(p['runtime']==std['runtime']and p['nodeBinarySHA256']==std['nodeBinarySHA256']and sha(p['node'])==p['nodeBinarySHA256'],'actualNode identity mismatch')
 need(p['canonicalRunnerHashes']==std['canonicalRunnerHashes'],'canonical declarations mismatch')
 for f,h in p['canonicalRunnerHashes'].items():need(sha(q/'harness/pm'/f)==h,'canonical runner bytes changed')
 need(p['executionKind']==g['executionKind']and p['noStopOnSuccess']is True,'execution kind/N policy mismatch')
 need(b['candidateSha']==g['measuredSourceSha']and b['candidateSha']not in sel['forbiddenCandidateSources'],'source is mismatched or explicitly retired')
 source=Path(b['snapshotPath']);need((source/'SOURCE_SHA').read_text().strip()==b['candidateSha'],'SOURCE_SHA mismatch');need(sha(source/'SHA256.json')==b['manifestSHA256']==g['sourceManifestSHA256'],'source manifest binding mismatch')
 for f,h in read(source/'SHA256.json').items():need(sha(source/f)==h,'source file changed:'+f)
 need(sha(source/'source.tar')==b['archiveSHA256'],'source archive hash changed')
 need(not rec.get('retryOverrides')and not rec.get('originalUnknown')and not rec.get('additionalAttemptHistory')and rec.get('noAutomaticUnknownRetry')is True,'unknown/retry override is not authorized by this selection')
 if g['executionKind']=='daily':
  need(p['expectedDailyVersion']==g['expectedDailyVersion']and p['expectedDailyVersion']in[4,5],'wrong explicitly selected Daily version')
  need(p['expectedDailyContracts']==g['expectedDailyContracts'],'actual expected modifiers differ from explicit selection')
  need(sha(q/'daily-selector.mjs')==p['selectorPolicySHA256']and p['canonicalRunner']==str(q/'daily-selector.mjs'),'actual Daily selector changed')
  need(all(a['dailyVersion']==p['expectedDailyVersion']and a['dailyRule']in p['expectedDailyContracts']for a in p['attempts']),'perattempt Daily version/rule mismatch')
  text=(q/'daily-selector.mjs').read_text();need(not any(s in text for s in ['Math.random','randomBytes','randomInt','randomUUID']),'observer may add RNG draws; review required')
 else:need(p['canonicalRunner']==str(q/'harness/pm/run-sim.mjs')and all('dailyRule'not in a for a in p['attempts']),'ordinary canonical command expected')
 return q,p,b

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--selection',default=str(OUT/'selection.json'));ap.add_argument('--groups',nargs='+',default=['glass-v4']);args=ap.parse_args();sel=read(args.selection)
 need(sha(sel['standardHelper'])==sel['standardHelperSHA256']and sha(sel['standardSelection'])==sel['standardSelectionSHA256'],'pinned standard helper/selection changed')
 need(sha(OUT/'physical_attempt.py')==sel['physicalValidatorSHA256'],'subset physical validator changed')
 spec=importlib.util.spec_from_file_location('standard_closed',sel['standardHelper']);H=importlib.util.module_from_spec(spec);spec.loader.exec_module(H)
 # Literal inherited function is verified to differ in only the expected-version expression and its diagnostic.
 original=ast.get_source_segment(Path(sel['standardHelper']).read_text(),next(n for n in ast.parse(Path(sel['standardHelper']).read_text()).body if isinstance(n,ast.FunctionDef)and n.name=='load_attempt'))
 adapted=(OUT/'physical_attempt.py').read_text().split('\n',1)[1].rstrip();need(adapted.replace("daily['version']==a['dailyVersion']==p['expectedDailyVersion']","daily['version']==a['dailyVersion']==3").replace('actual plan-version/modifier contract mismatch','actual v3/modifier contract mismatch')==original.rstrip(),'physical validation changed beyond permitted version adaptation')
 ns=dict(vars(H));exec(compile(adapted,str(OUT/'physical_attempt.py'),'exec'),ns);load=ns['load_attempt'];std=read(sel['standardSelection']);canonical=read(sel['canonicalTuplePlan']);need(sha(sel['canonicalTuplePlan'])==sel['canonicalTuplePlanSHA256'],'canonical tuple plan changed')
 wanted=set(args.groups);need(wanted<=set(sel['groups']),'unknown subset group');stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ');dest=OUT/'runs'/stamp;dest.mkdir(parents=True)
 for name,path in [('selection-used.json',args.selection),('analyse-used.py',__file__),('physical-attempt-used.py',OUT/'physical_attempt.py'),('standard-helper-used.py',sel['standardHelper'])]:(dest/name).write_bytes(Path(path).read_bytes())
 result={'at':stamp,'analysisScriptSHA256':sha(__file__),'selectionSHA256':sha(args.selection),'standardHelperSHA256':sha(sel['standardHelper']),'physicalValidatorSHA256':sha(OUT/'physical_attempt.py'),'noOldScriptOrDataMutation':True,'newSimulationAttempts':0,'candidatePartialOutcomesRead':False,'groups':{},'metricNotes':['All intervals are unadjusted; no automatic equivalence/noninferiority or balance verdict.','Each comparator remains a separate matched60 reference, never pooled.','Downs include revivable coop downs; midpoint inventory excludes early terminal runs.','Native boss damage/finale are survival/progression-sensitive, not isolated DPS.']}
 for label,g in sel['groups'].items():
  if label not in wanted:result['groups'][label]={'status':'NOT_REQUESTED','candidateRawRead':False};continue
  gate=closed(g,g['fixedAttempts']);result['groups'][label]=gate
  if gate['status']!='ELIGIBLE_COMPLETE':continue
  try:q,p,b=subset_source(g,sel,std,canonical)
  except Exception as e:result['groups'][label]={'status':'INCOMPLETE_SOURCE','error':repr(e),'statsComputed':False,'completionGate':gate};continue
  selectedIds={a['id']for a in p['attempts']};datasets={};audits={};sources={'candidate':b};plans={'candidate':p};locations={'candidate':q};eligible=True
  # Verify all requested whole600 comparison gates before reading any physical outcomes.
  refgates={r:closed(sel['references'][r],600)for r in g['comparisons']}
  if any(v['status']!='ELIGIBLE_COMPLETE'for v in refgates.values()):result['groups'][label]={'status':'INCOMPLETE_REFERENCE_GATE','referenceGates':refgates,'statsComputed':False};continue
  for r in g['comparisons']:
   try:
    rq,rp,rb,rec,over=H.source_plan(sel['references'][r],std,canonical)
    need(not over and not rec.get('originalUnknown')and not rec.get('additionalAttemptHistory'),'reference retry/unknown not authorized')
    locations[r],plans[r],sources[r]=rq,rp,rb
   except Exception as e:result['groups'][label]={'status':'INCOMPLETE_REFERENCE_SOURCE','reference':r,'error':repr(e),'statsComputed':False};eligible=False;break
  if not eligible:continue
  for arm,source in sources.items():
   aq,pa=locations[arm],plans[arm];physical=[];errors=[];data={}
   for a in pa['attempts']:
    if a['id']not in selectedIds:continue
    try:
     l,row,_=(load if arm=='candidate'else H.load_attempt)(aq,pa,source,a,{})
     stem=H.prefix(aq,source,a,{});m=H.read(stem.with_suffix('.meta.json'));need(m.get('revision')=='candidate'and m.get('playLogProof',True)is True,'revision/playlog proof mismatch')
     if pa['executionKind']!='daily':need(l.get('daily')is None,'ordinary comparator has Daily contract')
     if pa['executionKind']=='daily':need(m['selectorPolicySHA256']==pa['selectorPolicySHA256'],'perattempt selector hash mismatch')
     data[a['id']]=l;physical.append(row)
    except Exception as e:errors.append({'id':a['id'],'attemptId':a['attemptId'],'error':repr(e)})
   datasets[arm]=data;audits[arm]={'actualMeasuredSourceSha':source['candidateSha'],'sourceManifestSHA256':source['manifestSHA256'],'sourceArchiveSHA256':source['archiveSHA256'],'selectedPlanned':len(selectedIds),'wholeReferencePlanCount':len(pa['attempts']),'valid':len(data),'failedOrMissing':errors,'overrides':{},'originalUnknown':[],'physicalAttempts':physical}
   save(dest/(label+'-'+arm+'-audit.json'),audits[arm])
  if any(a['valid']!=g['fixedAttempts']or a['failedOrMissing']for a in audits.values()):result['groups'][label]={'status':'INCOMPLETE_PHYSICAL_AUDIT','auditCounts':{a:{k:v[k]for k in ['valid','failedOrMissing']}for a,v in audits.items()},'statsComputed':False};continue
  engine=H.old_engine(std);engine['MAP']={arm:engine['mapping'](sb['snapshotPath'])for arm,sb in sources.items()};rows=[]
  for ci in g['selectedCells']:
   ids=[a['id']for a in p['attempts']if a['cell']==ci];need(len(ids)==60,'exact60 percell required');logs={a:[d[i]for i in ids]for a,d in datasets.items()};stats={a:engine['stats'](ls,a)for a,ls in logs.items()};cell=p['cells'][ci];rows.append({'cell':ci,**cell,'candidate':stats['candidate'],'references':{a:stats[a]for a in g['comparisons']},'comparisons':{a:H.paired(list(zip(logs[a],logs['candidate'])),sel['bootstrapSeed'],sel['bootstrapIterations'])for a in g['comparisons']},'candidateTargetDeviation':H.target(stats['candidate'],cell['bot'],std),'referenceTargetDeviations':{a:H.target(stats[a],cell['bot'],std)for a in g['comparisons']}})
  result['groups'][label]={'status':'MEASURED_COMPLETE_NOT_PRODUCT_ACCEPTANCE','actualMeasuredSourceSha':b['candidateSha'],'valid':g['fixedAttempts'],'selectedCells':g['selectedCells'],'completionGate':gate,'referenceCompletionGates':refgates,'auditCounts':{a:{k:v[k]for k in ['actualMeasuredSourceSha','selectedPlanned','wholeReferencePlanCount','valid','failedOrMissing']}for a,v in audits.items()},'rows':rows,'oldPhysicalOutcomesNotRelabeled':True}
 save(dest/'summary.json',result)
 with(dest/'cells.csv').open('w')as f:
  w=csv.writer(f);w.writerow(['group','cell','bot','N','mode','candidateWins','n','candidateWilson95','comparator','comparatorWins','deltaPP','pairedNormal95','pairedBootstrap95','lost','gained','McNemar','targetDeviation'])
  for label,group in result['groups'].items():
   for r in group.get('rows',[]):
    for arm,pair in r['comparisons'].items():w.writerow([label,r['cell'],r['bot'],r['players'],r['mode'],r['candidate']['wins'],60,r['candidate']['wilson95'],arm,r['references'][arm]['wins'],pair['deltaPP'],pair['pairedNormal95CI'],pair['bootstrap95CI'],pair['lostWins'],pair['gainedWins'],pair['exactMcNemarTwoSided'],r['candidateTargetDeviation']['status']])
 save(OUT/'LATEST.json',{'at':stamp,'summary':str(dest/'summary.json'),'groupsRequested':sorted(wanted)});print(dest);print({k:v['status']for k,v in result['groups'].items()})

if __name__=='__main__':main()
