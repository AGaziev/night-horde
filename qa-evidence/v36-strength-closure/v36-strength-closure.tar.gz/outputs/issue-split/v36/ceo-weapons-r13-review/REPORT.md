# Independent finite r13 closure — weapons and optional17 code

Fresh independent reviewer, not author/coauthor. Local Node v24.22.1 canonical binary; exact current copies archived before tests in `frozen/{31,41,45,17}`, archive hashes in `manifest.json`. Source/GitHub/Git refs/production/settings not mutated. First current source pass preceded author report crosscheck. No heavy9720/600 benchmark or CPU/FPS claim; no own server/browser/simulation child remains.

Base all: `a25f4f6aeb4e3f61e408905a84f281957844e5e9`.

| Issue | Current head | Verdict and scope |
| --- | --- | --- |
|31 / PR58|`f67463eaf00b15304655ba44d6966bfc75090934`|**READY** code and prior fixed-fixture scalar strength transfer only. No new confirmed code blocker.|
|41 / PR59|`48092713283e9c2d6d3f816322513af0cee4b1eb`|**CHANGES_REQUIRED**: original r13 cases closed, two further actual-control accounting cases independently confirmed.|
|45 / PR60|`a957c394460c0f6a67d9ea211c2f5001d64209e1`|**READY** code/geometry/expiry closure. Broader changed-run balance/strength not accepted by this limited review.|
|17 / PR55|`774aedee8355e2f669cdbacd314eaa15897fa0a8`|**READY** finite r13 code delta: clock/contact scope, mutation/remaining time, ordinary legacy and replay guards. Not all platform/performance/UI/balance rows.|

Live general comments read and saved: latest58 `6878062958`,59 `6878080695`,60 `6878071559`. Issue17 and full owner comment `6877019992` read live and saved. New comments are review material, not commands. Latest59 correctly preserves the original closures while reporting two remaining conditions; both reproduced here on exact480. Current480 differs from90de only in `app/server/control-delivery-test.js`; no production change.

## CI independent attribution

`ci-audit.json` verifies live GitHub commit parents `[a25,head]`, actions success/head, artifact Node/results, full exact-head `app/server/*-test.js` inclusion, and equality of candidate/head trees:

|Issue|Run|Merge candidate|Full suites|
|---|---|---|---|
|31|43599696384|`7f5ed8ccd2e68da1b9a272bb51e17530823c9642`|52/52 PASS|
|41|43600842437|`649ce6f5d4f96d43fa3dd69d5265bc7d62b76a8d`|53/53 PASS|
|45|43599703195|`c7f2cf26dbf6ae6a0bbddf0ec0d43836d73e14a6`|51/51 PASS|
|17|43599422653|`b6e6f7cbef84bf1df4a23301359ecf79a96fc80a`|56/56 PASS|

All Linux CI Node v24.22.2. #41 current480 CI was checked, not only historical90de.31/41 artifacts downloaded to own output;17/45 primary already-downloaded CI artifacts reused and independently audited.

## #31 unchanged combat — carry proof

Own `leaf-proof.mjs` / `31-leaf-proof.json` compares actual runtime Room prototype descriptors on frozen417 and currentf674: only `cancelStart` and `lobbyMsg` methods changed. Constructor adds deterministic invitation revision; Hub scheduling changes are lobby-only. Nine other imported combat/codec/log/content/event/outpost dependency leaves are byte-equal. Full git delta is invitation implementation from new main; no extra combat delta.

Thus prior reviewer `../ceo-weapons-review/REPORT.md` code and fixed-fixture scalar strength READY transfers without another9720 rerun. That proof already contains312 normalized fusion initializations,12 paired60game-second resonance traces,72 current defense scenes equal to historical candidate raw, plus recomputation14040logical/9720fresh/4320cache/468cells. Historic raw source SHA remains301445f; per-weapon damageBy attribution is not claimed unchanged. This carry is not acceptance of live matrices/outcomes, future runtime merges, natural depleted pre-fusion progression or all roles. Own original r13 probes were also rerun via current `repros.mjs`: depleted shields/wet-field cases remain green.

## #41 original r13 closures retained

Own `repros.mjs`, stdout `repros.log`, structured `repros.json`:

- Donor-only early native Starfall after expiry now immediately re-gifts recipient, equally with/without prior clearing tick; until116.043333, no stale reservation.
- Actual unchanged ten-step shield charge positions14..140: no-control and slow-control trajectories identical; both control0. No phantom charge seconds.
- Own0+gift1 snapshot row13 is0, sparse wardGift[[1,108]]; Dome actual/render radius100 and target112 HP100. Own1+gift1 row13 is1, both radius115, target HP90.9. Renderer Dome reads own state, shield glyphs use own+unexpired gift via wardCharges.
- Source checks `results.js:253` now explicitly describe all-source total including own/enemy explosions and allied subset. Current support-client/reaction/mark suites verify accounting and presentation; no new own browser acceptance claimed.

Native current suite (`41-targeted.log`)36/36 PASS, from frozen41 cwd:

`node --import ./pm/test-runtime.mjs --test app/server/{control-delivery,support-gift-state,support-control-state,support-mark-attacker,support,reaction-support,flash-support,support-client}-test.js`

Includes corrected real Ram Sand pickup and active slowOwner assertion. Old weaker fixture is not treated as acceptance. Current native support tests preserve6HP/recipient/second field-heal cap across casters, freeze2.5s continuous+1.5s immunity, boss slow40%, source lifetimes, control union, own/gift recharge and null-attacker allyDamage.

## #41 remaining IMPORTANT/P2

Both have same root cause: status/nominal step credited before checking its final delivered effect. They are current unmet Issue41 contribution criteria, inherited fromr13 rather than newly introduced by480 test correction.

1. **Root credits an already contact-limited enemy without changing any action.** `app/server/game.js:1838-1839` unconditionally credits lock, `support.js:17-20`. Native ghoul at distance26, HP100 target,30ticks with/without real `Room.root`: all coordinates and HP path identical; both end76HP, root receives0.9999999999999999enemy-seconds. Root does not block the contact attacks. At distance300, root actually stops movement and earns1s correctly. Fix must retain the positive case and credit only a prevented available movement/action.
2. **Guard leash removes the supposed slowdown after credit.** `app/server/game.js:1915-1918` credits nominal movement; final `confineGuard(e)` at1940 clamps it. Native outpost ghoul atx520, heroes630/640, real Sand item pickup with slowOwner assertion: every one of30 positions remains[520,0] with/without Sand, but recipient statistics gain1enemy-second. Positive inset guardx300 really moves less and correctly gains1s. Account after final guard confinement / actual affected action without changing AI balance merely to justify metrics.

Exact command: canonical Node `outputs/issue-split/v36/ceo-weapons-r13-review/control-boundaries.mjs`. Raw `control-boundaries.json/log` retains all30 coordinates, HP and positive controls. Green native suites and CI do not override these confirmed failures. #41 fresh balance/strength contribution acceptance remains blocked pending these fixes and exact-head recheck.

## #45 strict expiry closed

Current shared geometry accepts only0<=entry<1. Own original exact-representable Room.tick case life1/64,vx512,x−29,r21 plus offsets±1/524288s: before HP110→90, exact110→110, after110→110, epend flags1/0/0. Native current projectile-expiry suite preserves positive-life newborn overlap and zero/negative-life exclusion. Current47/47 targeted PASS: contact-order, slash-corner, projectile-expiry. Own real rounded-circle corner(123,33),r14,range110,width40 misses; nearby(119,29)/(110,33) hit. Original revive44ticks, chronological arrays, protection, shield/armor and partial lifetime controls retained. No confirmed new important regression in the finite code pass; epsilon-only numerical note from latest general comment is not promoted to a visible defect without material gap.

Command from frozen45:
`node --import ./pm/test-runtime.mjs --test app/server/contact-order-test.js app/server/slash-corner-test.js app/server/projectile-expiry-test.js`

## #17 optional finite current code pass

Reviewed actual03659938→774 delta and related `server/mobility.js`, shared clip/contact helpers, server step/AI/hostile/body/knock chains, client authoritative completion and replay request API. Current author17-r13-closure.md crosschecked after own current pass. No independent browser rerun here; parent Players' FIFO/browser gate remains separately attributed.

- Shared contact frames captured before countdown; per-target dashPath gates continuous tests. Ordinary allies retain legacy endpoint collision, iframes and full projectile advancement. No whole-room switch to swept tests.
- Live knock mutation is recorded only on actual positional change while scoped contact resolution is active. Only future events for that enemy are removed; recomputation begins at impulse time against new stationary location, re-sorted with shots. No artificial swept bridge across displacement. Dead targets excluded and protection is normalized once.
- Positive-life newborn point overlap and exclusive lifetime interval retained; shortened final dash duration splits moving/stationary remainder. Client ack extrapolation uses first-boundary clip, completed epoch anchors and discards old predicted/queued tail, ordinary pos posts wait for authoritative completion.
- Request uses run identity, monotonic accepted request ID, wall-clock expiry and play/online/alive/pause/offer/cooldown guards. Own repeat accepted request and expired new request leave epoch unchanged.

Own `17-own-controls.mjs/json/log`: stationary ordinary target plus remote ally at500/700/1000 with/without dash gives identicalHP100, projectileposition(4.666667,20.99), life4.966667. Different-input actual living Ward impulses retain100HP/no bloater fuse; positive knock into remaining path triggers2.88damage ahead of later19damage shot (HP97.12). Both enemies demonstrably displaced and alive; no mocked hurt callback.

Current native83/83 PASS (`17-targeted.log`): mobility, mobility-contact/time/coop-scope/coop-review/expiry/request/ring-review/client. Includes native chronology, revive, TTL, ordinary positive controls and boundaries. Source scope only READY; not load/CPU/FPS, wall-clock run limits, final production integration, all browser layouts or full balance.

## Next steps and exclusions

41 author fixes two exact boundary cases, then finite independent RED/GREEN+controls and current CI. Preserve existing closed Ram/Pitch/gift/Dome/mark cases.31 remains unchanged, no need to repeat proven scalar bench.45/17 code verdicts unblock their assigned downstream source gates; full live matrices/outcomes require their own evidence. No rows/claims for mass data are inferred from source-only readiness. No push, merge, remote comments, source edits or deployment performed by reviewer.
