from pathlib import Path
import re,subprocess,hashlib,json
w=Path.cwd();out=w/'../../outputs/issue-split/v36/ceo-r16/41';out=out.resolve();before=out/'before';todo=[Path('app/server/game.js'),Path('app/package.json')];seen=set();rows=[]
while todo:
 p=todo.pop()
 if p in seen:continue
 seen.add(p);b=(w/p).read_bytes();dest=before/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);rows.append(dict(path=str(p),sha256=hashlib.sha256(b).hexdigest()))
 if p.suffix=='.js':
  for s in re.findall(r"(?:\bfrom\s*|\bimport\s*)['\"]([^'\"]+)['\"]",b.decode()):
   if s.startswith('.'):todo.append(((w/p).parent/s).resolve().relative_to(w))
(out/'before-manifest.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),files=rows),indent=2));print(len(rows),'before leaves frozen')
