# Issue41 — r16 author handoff

Owner comment: [6878080695](https://github.com/AGaziev/night-horde/pull/59#issuecomment-6878080695).

SOURCE FREEZE: `7e2d195d49de4e7c4910142449b3e75394f3dad7` (parent `48092713283e9c2d6d3f816322513af0cee4b1eb`), maina25/PROTO29/GAME_VERSIONv36 unchanged. One logical local commit: accounting observer + regression tests + contract clarification. No push/amend/force, no31/45 changes, no new balance/full/performance runs.

P2 fixed locally:

- Root at contact: ghoul0/hero26 has identical30 actual Room.tick paths and HP with/without root; contribution is now0. Available locomotion or a genuinely paused/prevented action is required. Far root, pending Spitter attack and actual freeze/contact prevention retain1 unique enemy-second.
- Guard leash: actual Sand pickup with asserted owner/lifetime, heroes630/640, ghoul and skel at520. Both plain/controlled projected endpoints clamp to the same point; contribution is now0. Inset guard slowdown remains effective and retains1 enemy-second. Slow accounting happens after final clamp, using the observed separation displacement for both projections. Actual collision/AI/RNG are never replayed.

Native RED on exact480:7 cases,3 fail (contact root, leash ghoul/skel),4 positive controls pass. Raw all cases retained in `red-cases.json`; initial attempt logs also retained. GREEN: all7 A/B cases; final targeted suite43/43 includes corrected real-pickup Ram/charge and all relevant r13 shield/control/mark/client regressions. Syntax3/3. Runtime Node24.22.1 with `--import ./pm/test-runtime.mjs`.

Strict no-physics/RNG evidence:

- `before-manifest.json` and `before/` preserve the exact original12-file import snapshot before mutation.
- `prove-source.py` / `source-proof.json`:11 existing dependency files byte-equal. Removing only enumerated accounting imports/locals/counter predicates restores the entire old game.js byte-for-byte. Every actual movement, separation, clamp, hurt, AI timer and RNG statement retains original text/order. The new pure observer has no actor-field writes, actual AI calls or Math.random calls. No caps, parameters, masks, healing/gifts or ownership rules change.
- `gameplay-proof.mjs` / `.json` / `.log`:13 old→new native scenarios produce exact matching per-tick coordinates, HP, action clocks and RNG draw counts. These include controlled and untreated variants. The control metadata intentionally differs on the false-credit cases.
- `physics.diff` contains the complete production delta. Canonical sim drivers contain no support.control decision input. This supports outcome-only applicability under unchanged harness/runtime/attempt tuples; old support.control values are NOT current acceptance evidence. Resource performance and independent acceptance remain open; no CPU/FPS claim under concurrent simulations.

Primary regressions are committed as `app/server/control-boundaries-test.js`. Other primary logs: `red.log`, `green.log`, `final-targeted.log`, `green-cases.json`. All scripts/metadata live here, not/tmp. No own active process/port or temporary dependency symlink remains; tree clean. Root owns publication/new CI and independent replay of both r16 negatives. Author does not grant READY.
