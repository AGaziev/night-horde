from pathlib import Path
import hashlib,json,re,subprocess
w=Path('outputs/issue-split/v36/ceo-weapons-r16-review/frozen/41');out=Path('outputs/issue-split/v36/ceo-r16/41');manifest=json.loads((out/'before-manifest.json').read_text());changes=[]
for row in manifest['files']:
 p=row['path'];now=(w/p).read_bytes();prior=(out/'before'/p).read_bytes()
 if now!=prior:changes.append(p)
assert changes==['app/server/game.js'],changes
p='app/server/game.js';s=(w/p).read_text();before=(out/'before'/p).read_text();projected=s
projected=projected.replace("import { projectControlPoint, controlPointDiffers, controlScale as observedControlScale, lockDelivered } from './control-observation.js';\n",'')
projected=projected.replace('\n\t\t\tlet controlMotion = null;','')
projected=projected.replace("if (locked) {\n\t\t\t\t\t\tconst actualEnd = projectControlPoint(e, e.x, e.y), plainStep = Math.min(d, e.speed * dt);\n\t\t\t\t\t\tconst plainEnd = projectControlPoint(e, e.x + dx / d * plainStep, e.y + dy / d * plainStep);\n\t\t\t\t\t\tif (controlPointDiffers(actualEnd[0], actualEnd[1], plainEnd)) controlTick(e, now, dt, 'lock');\n\t\t\t\t\t}", "if (locked && e.speed > 0 && (dx || dy)) controlTick(e, now, dt, 'lock');")
projected=projected.replace("if (lockDelivered(e, best, alive, now, dt, speedMul * (fog && this.events.inFog(e) ? FOG_DEF.speedMul : 1))) controlTick(e, now, dt, 'lock');", "controlTick(e, now, dt, 'lock');")
projected=projected.replace("if (controlScale < 1) {\n\t\t\t\t\tconst plainStep = Math.min(speed / controlScale * dt, maxStep);\n\t\t\t\t\tif (step < plainStep) controlMotion = [dx * (plainStep - step), dy * (plainStep - step)];\n\t\t\t\t}", "if (controlScale < 1 && step < Math.min(speed / controlScale * dt, maxStep)) controlTick(e, now, dt, 'movement');")
projected=projected.replace("} finally {\n\t\t\t\t// Keep the observed separation displacement; do not replay collision/AI/RNG.\n\t\t\t\tconst plainEnd = controlMotion && projectControlPoint(e, e.x + controlMotion[0], e.y + controlMotion[1]);\n\t\t\t\tconfineGuard(e);\n\t\t\t\tif (plainEnd && controlPointDiffers(e.x, e.y, plainEnd)) controlTick(e, now, dt, 'movement');\n\t\t\t}", "} finally { confineGuard(e); }")
projected=projected.replace("\n\t\tconst scale = controlled ? observedControlScale(e, this.time) : 1;\n\t\tconst plainEnd = scale < 1 ? projectControlPoint(e, ox + dx * speed / scale * dt, oy + dy * speed / scale * dt) : null;",'')
projected=projected.replace("if (plainEnd && controlPointDiffers(e.x, e.y, plainEnd)) controlTick(e, this.time, dt, 'movement');", "if (controlled && (e.x !== ox || e.y !== oy)) controlTick(e, this.time, dt, 'movement');")
assert projected==before,'unclassified engine source delta'
observer=(w/'app/server/control-observation.js').read_text()
assert 'Math.random' not in observer
assert not re.search(r'\b(?:e|target|h)\.\w+\s*(?:=(?!=)|\+=|-=|\+\+|--)',observer),'actor writes in read-only observer'
assert not re.search(r'\b(?:bossTick|dashTick|sniperTick|rangedTick|hurtPlayer|hurtEnemy|confineGuard)\s*\(',observer),'actual engine replay'
oldGameHash=hashlib.sha256(before.encode()).hexdigest();newGameHash=hashlib.sha256(s.encode()).hexdigest()
result=dict(before=manifest['head'],head='7e2d195d49de4e7c4910142449b3e75394f3dad7',existingGraphLeaves=len(manifest['files']),unchangedExistingLeaves=len(manifest['files'])-1,gameBeforeSHA256=oldGameHash,gameAfterSHA256=newGameHash,projectedGameSHA256=hashlib.sha256(projected.encode()).hexdigest(),projectedGameByteEqual=True,observerSHA256=hashlib.sha256(observer.encode()).hexdigest(),actorMutation=False,AIReplay=False,extraRNGCalls=False,classification=['existing source changes limited to control attribution calls/locals and import','exact pre-existing movement, separation, clamp, hurt, AI timer and RNG statements preserved in original order','observer reads existing state and projects points through same leash clamp without mutation','control.control metadata changes; not transferable as an old metric'],outcomes='Source proof supports outcome-only applicability between these heads; no new balance or READY claim.')
Path('outputs/issue-split/v36/ceo-weapons-r16-review/41-source-proof-recheck.json').write_text(json.dumps(result,indent=2));print('Strict projection PASS:',len(manifest['files'])-1,'existing leaves exact; entire projected game.js byte-equal; no observer AI/RNG/actor writes')
