# Independent final r16 closure — code/weapons scope

Reviewer is independent, not author/coauthor. **READY for the scoped code/defect closure of both current candidates.** Overall live balance, performance, browser/product and release gates are not accepted by this report.

| Issue / PR | Exact reviewed head | CI merge candidate | Scope verdict |
| --- | --- | --- | --- |
|17 /55|`0c1324b3571aa4aeb6366f69397901b98d08d889`|`b6b4e70c5e47f7141ccc99ccb0a794ba0adc5651`|READY: target selection, legacy callback/endpoint scope, guard preparation requeue; prior native contact/replay controls retained|
|41 /59|`7e2d195d49de4e7c4910142449b3e75394f3dad7`|`a7894c0be91ce62d3e95345f6b434e337151d6ed`|READY: actual-contribution accounting, both r16 originals and positive controls, unchanged physics/RNG scope|

Base and current live main: `a25f4f6aeb4e3f61e408905a84f281957844e5e9`. Before tests both current trees were frozen through git archive with archiveSHA256 in `manifest.json`; no app edits, Git mutations, remote comments, production changes, heavy simulations or performance measurements. Current worktrees remained clean. Own active processes/listeners0; `cleanup.json`.

## Review order and primary evidence

Read current full source deltas/callers and live CEO comments first, then independently replayed originals and positive/negative controls, then crosschecked author material. Full live general comments saved as `55-general.json` / `59-general.json`, exact owner17 r16 body `17-r16-owner.json`. Latest inspected comments55 `6878080489`,59 `6878413358`; requirements from59 r16 `6878080695` retained. Author41 report/source proof and native source tests were crosschecked after the own first pass. Author17 current source regression tests and current `17-r16-endpoint-green/results.json` were inspected as supplied evidence; no browser run was attributed to this reviewer.

Local runtime: canonical `/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node`, Node v24.22.1. Commands from workspace root:

- `node outputs/issue-split/v36/ceo-weapons-r16-review/17-own-closure.mjs`
- `node outputs/issue-split/v36/ceo-weapons-r16-review/41-own-closure.mjs`

Structured raw and stdout retained as matching `.json` / `.log`. Both scripts compare exact original frozen774/480 to exact new frozen0c13/7e2 and use real Room.tick / fireHostile / item pickup / native outposts / Ward displacement, not mocked damage callbacks.

## #17 — both r16 findings closed

**Original target steal**, `server/game.js:2338-2364`, new legacy reservation consumer2289-2300:

- Exact time0, native Spitter fireHostile from(−10,0) toward(50,0), stationary hero(0,0), other hero(50,0) dashes left. Old774: no dash HP97.12/100, with dash100/97.12. New0c13: both97.12/100. The earlier ordinary start/end overlap participates without a universal ordinary sweep.
- Earlier dasher positive (ordinary18, dasher20) correctly hits dasher; tie and reversed hero Map select deterministic pid1. Ordinary short0.01s protection expires at its legacy endpoint callback and takes damage; long1s protection consumes shot without damage. Own Ward and innate Knight shield absorb once, later dasher unharmed.
- Native weapon-phase observation confirms ordinary Ward remains intact until ordinary callback phase; target arbitration does not prematurely invoke ordinary hurt/knock effects.
- Remote ally at500/700/1000 plus original endpoint-miss shot(−3,20.99) leaves stationary HP100 with/without dash. Shot endpoint4.6666666667,20.99 and life1.9666666667 match exactly; no double advance. Born/lifetime clipping remains restricted to dash geometry. Reservation is cleared per contact pass, and shot is consumed once.

**Preparation requeue**, `server/game.js:2374`: initial and recalculated body contacts now both reject a preparing outpost guard. Own actual native outpost creation, two dashers, real Ward knock, alternative x39 input: old774 preparing guard hits100→90.202; new0c13 preserves100, guard still alive and actually displaced into remaining path. Ready guard positive still hits90.202 on both revisions. Fix preserves chronological recomputation, not blanket suppression.

Current native regression run from frozen17, `17-targeted.log`: **95/95 PASS**, suites mobility-target-review, mobility-guard-requeue, mobility, mobility-client, mobility-contact, mobility-time, mobility-coop-scope, mobility-coop-review, mobility-expiry, mobility-request, mobility-ring-review. Command form `node --import ./pm/test-runtime.mjs --test app/server/<name>-test.js`. Existing relative geometry, queued impulse, body/shot ordering, remaining-time, protection, expiry and replay controls retained. No new confirmed important regression found in this finite pass.

The earlier report's scoped17 READY on774 was superseded by the independently confirmed r16 P2. It was never a global all-roles acceptance; green83 tests did not refute the later native geometry. New current READY here relies on the explicit original RED/new GREEN and preserved controls above.

## #41 — both r16 findings closed, physics preserved

Own `41-own-closure.json` records six old/new paired native30-tick scenes, each with full timeline: coordinates, both hero HP/iframes, attack clocks, all enemies and projectiles, RNG draw count.

- Contact-root26: root and no-root have identical path and HP100→76. Old480 falsely credits1 enemy-second; current7e2 credits0.
- Guard520, heroes630/640, real Sand pickup with asserted slowOwner/expiry: all30 final points520,0, HP100 on controlled/plain; old480+1, current0.
- Positive far-root, inset-guard Sand, freeze preventing contact damage and root pausing a real pending Spitter attack remain1 unique enemy-second and show actual path/HP/action differences. Freeze contact now100HP versus untreated76. Pending attack positive shows different attack/shot progression and untreated96.72HP.
- For every controlled scene, **old/new physical timelines and RNG draw counts are exactly equal** (26 or27 draws). Only contribution metadata changes. No AI/collision/RNG replay is used to justify the counter.

Source/callers: `moveEnemies:1844-1845` uses pure lock-delivery observation; movement accounting runs after final leash projection in `finally:1949-1953`; bossStep performs an analogous comparison. Own runtime descriptors show only moveEnemies/bossStep changed. Seven separately checked combat/content/support/event/perk/outpost leaves byte-equal to480.

After own proof, vetted author `prove-source.py` was replayed against our immutable new source with **own output only**, as `41-source-proof-recheck.py/json`:11 existing graph leaves byte-equal; removing enumerated observation imports/locals/counter predicates restores old game.js byte-for-byte. Existing physics, separation, clamp, hurt, action timers and RNG statements retain text/order. Observer has no actor-field writes, actual AI calls or Math.random. This supports physics/outcome-only applicability between480 and7e2 with identical harness/runtime/attempt tuples; historical support.control metrics must not be relabeled as current values.

Observer branch audit covers lock vs movement, freeze contact vs root, ready ranged/sniper/shield/exploder actions, returning guards, ordinary/ranged/sniper/flee/zig locomotion, controlled boss step and final guard projection. Native current regression set `41-targeted.log`: **43/43 PASS**, control-boundaries, control-delivery, support-gift-state, support-control-state, support-mark-attacker, support, reaction-support, flash-support, support-client. It retains corrected Ram pickup, unaffected charge0, source lifetimes/union, boss40% cap, freeze2.5s+1.5s immunity, field-heal6HP/recipient/second, independent gifts, Dome state and mark subset accounting.

## Fresh full CI audit

Own downloaded primary artifacts: `ci-43603471252/`, `ci-43603519508/`. `ci-audit.json` independently verifies live actions head/success, actual checkout SHA and `[a25,head]` parents, merge candidate tree=head tree, complete exact-head `app/server/*-test.js` list and all PASS/exit0:

- #17 run43603471252, Node v24.22.2, **58/58 PASS**; candidate `b6b4e70c5e47f7141ccc99ccb0a794ba0adc5651`.
- #41 run43603519508, Node v24.22.2, **54/54 PASS**; candidate `a7894c0be91ce62d3e95345f6b434e337151d6ed`.

## Boundaries / handoff

No new confirmed important code finding remains in the assigned final r16 scenarios/calling chains. This concludes finite code/defect closure. No mass balance/outcome dataset was rerun or accepted; #17 target-selection physics can change actual outcomes, while #41 unchanged-physics proof does not transfer old contribution counters. Existing #31 fixed-fixture strength carry and #45 scoped code/TTL READY are untouched. Root coordinates remaining roles, full matrices and any release. Own servers/browsers/heavy jobs started0, owned active processes/ports0, foreign jobs untouched.
