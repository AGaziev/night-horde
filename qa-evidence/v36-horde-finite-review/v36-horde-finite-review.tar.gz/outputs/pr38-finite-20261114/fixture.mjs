import { Server } from 'node:http';
import { Room } from '../../work/night-horde-asymmetric/app/server/game.js';
let room;
const start = Room.prototype.start;
Room.prototype.start = function (...args) { const result = start.apply(this, args); if (this.isHorde) room = this; return result; };
const emit = Server.prototype.emit;
Server.prototype.emit = function (event, req, res, ...args) {
 if (event !== 'request' || req.url !== '/__pr38_fixture') return emit.call(this, event, req, res, ...args);
 let body = '';
 req.on('data', (part) => body += part);
 req.on('end', () => {
  try {
   const { action } = JSON.parse(body);
   if (!room) throw Error('No owned Horde room');
   const hero = [...room.heroes.values()][0];
   if (action === 'idle') {
    room.time = 10; room.enemies = []; room.projectiles = []; room.fx = []; room.hostile = []; room.timers = [];
    hero.x = hero.y = 0; hero.speed = 150; hero.hp = hero.maxHp = 10000; hero.weapons.clear();
    hero.hordeMoveAt = room.time; hero.hordeMoveCredit = 0; hero.lastPosT = room.time;
    room.horde.combat.status.clear(); room.snapshot();
    res.end(JSON.stringify({ time: room.time })); return;
   }
   if (action === 'position') { res.end(JSON.stringify({ time: room.time, x: hero.x, manual: room.enemies.filter(e => e.hordeSource === 'manual').length, bossAdds: room.enemies.filter(e => e.hordeSource === 'boss-add').length, pending: room.horde.pending.length })); return; }
   if (!['pre-key', 'post-key'].includes(action)) throw Error('Unknown fixture');
   room.time = 100; room.enemies = []; room.projectiles = []; room.hostile = []; room.fx = []; room.timers = [];
   hero.x = hero.y = 0; hero.hp = hero.maxHp = 10000; hero.iframes = 0; hero.fx = 1; hero.fy = 0;
   const boss = room.spawnBoss('boss', [hero]); boss.x = 150; boss.y = 0; boss.bcd = 0; boss.bt2 = 1;
   room.lordTick(boss, hero, 150, 0, false);
   if (action === 'post-key') room.snapshot();
   hero.weapons = new Map([['knives', { lvl: 1, t: 0 }]]); room.rebuildGrid();
   room.updateWeapon(hero, 'knives', hero.weapons.get('knives'), 0.1); hero.weapons.clear();
   const knife = room.fx.find(e => e[0] === 'shot');
   if (!knife) throw Error('No native knife launch');
   room.resync(hero.pid);
   res.end(JSON.stringify({ knife: knife[1], deadline: room.time + boss.def.call.warn, radius: boss.def.call.ring + 20 }));
  } catch (error) { res.statusCode = 500; res.end(String(error.stack)); }
 });
 return true;
};
const listen = Server.prototype.listen;
Server.prototype.listen = function (...args) { args[0] = 0; this.once('listening', () => console.log('FINITE_PORT:' + this.address().port)); return listen.apply(this, args); };
