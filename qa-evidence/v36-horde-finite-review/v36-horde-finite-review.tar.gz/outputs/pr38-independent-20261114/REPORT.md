# PR38 — READY: finite independent delta acceptance

Reviewer: batch_platform (not Horde author); author: asymmetric_backend. Scope assigned by CEO: owner comment6861642284's three remaining items and directly affected main-merge contracts. No source edits, commits, push, PR comments/thread resolutions, external notifications, production calls, full matches or performance runs.

Exact head **e7271a2da67ee588d71dd668033664b643ca6480**, base **13c560f4d5f16a12333d167806f9a5b20e601c4a**, PROTO31/v36. Worktree clean. Read live Issue37, PR38, latest general comments (including owner6861642284 and author6883074829), inline comments0, prior finite report and three fix commits3abfc25/51af8c9/bcc4690. The existing PR remains one Issue37; no additional feature scope was added here.

## Closed original items

| Owner item | Source and independent result |
| --- | --- |
| P2 / original ID10: idle movement credit cancels a paid spawn or bypasses slow | onPos discards unspent interval credit only in Horde; server time still supplies the next allowance. Four original-family native cases PASS: same-tick/resync/slow budget, paced normal movement, actual paid order yields12manual units, current chill cannot escape its warned blast. Real WS/Chrome idle packets then request1700 gives5.5units (formerly195). |
| P2 / original ID4: resync removes Lord warning and fresh Knife | lordTick stores warning geometry/carrier/original deadline in the actual timer. resyncState includes live timer warnings and suppresses only events represented by recovered state; fresh hero shots remain deliverable. Two selected native original cases PASS. Actual Room/Hub/WS/production Game/Renderer in Chrome: pre-key and post-key recovery each show exactly one r180warning and a native Knife. drawWarns executes with the restored circle, screenshot visually checked. Both produce12boss-add at the original timer; no warning restart. |
| P3: focused troop button swallows Escape | Escape is handled before interactive-focus filter; Space remains native. Native PASS plus real focused click→Esc clears aria-pressed and focused Space selects. |

## Main merge continuity

Eight selected adjacent native tests PASS plus one combat-footprint assertion script PASS. No complete old35Horde-case/general weapon audit was repeated.

- #45: shared combat-geometry, Room.updateHostile and slash are byte-equal to main; actual swept relative projectile contact, newborn/TTL limits and fixed slash world footprints retain their native controls. Early updateHostile remains before horde.combat.tick/updatePlayers in Room.step.
- #10: Net.onSnapshot and discardPositions byte-equal to main. Selected controls retain ordinary1100ms lag movement, bounded outgoing-pos acknowledgement stall, delayed pause-tail discard, and SSE queue filtering/order. Horde adds only the director restriction to the merged prediction path.
- Horde role/start contracts: three selected role/protocol native cases PASS. Real browser waits for Horde lobby ACK, verifies director-alone Start stays disabled after350ms and valid one-director/one-hero composition enables it. Capacity remains5Horde/8PvE; director is not a hero.
- #44: lobby-invites service, Room.cancelStart and complete handleLobbyInvites route are byte-equal to main, preserving nonce, before/after-await retry guard, unknown-delivery behavior and maxMembers fallback. The sole UI delta makes countdown disable Start without overwriting the role validator; browser/native role controls cover that merge interaction. No real notifications were sent.
- #7: deploy runner/test and signed handleDeployStatus route byte-equal to main; no deployment or data probe was invoked. Client/server contract is PROTO31, v36 metadata remains. Source hashes/equality checks: main-contract-source-comparison.json.

## Evidence and attribution

Author's19targeted native /4Chrome checks at bcc4690 are supplied evidence (`outputs/pr38-finite-20261114/report.md`, browser-report.json and original RED log); they are not counted as independent passes here. Independently executed on merged e727: **7original-family +8merge-adjacent native tests (15/15), one footprint script, and4/4Chrome checks**. Native commands/log hashes are in native-execution.json. Local Node24.22.1 binary SHA256cf52d093e9b728a7e6929a4371fa37d271304383e7e7c9f0f0e32fb00373b32c. Chrome157.0.8103.51 headless, desktop1366x768, --mute-audio, separate role contexts, real local server/WS/client; VIBE_APP_KEY empty.

The browser preparation reuses the author's controlled fixture, explicitly setting time100/ring/boss state, clearing ambient entities/weapons and giving high HP to isolate recovery. It invokes native Lord/Knife code and retains actual30Hz/server WS/render delivery; it does not claim a natural12minute boss approach or a full PvP match. Independent additions record wire/Renderer evidence and role eligibility. `browser-attempt2-report.json`, scripts, server log, screenshots retain primary. The first attempt asserted role eligibility immediately after sending ruleset before its lobby ACK and exited early; `browser-report.json`/browser-execution.log remain preserved. One corrected script adds the missing ACK wait and passes. This was a harness synchronization defect, not a product finding. No further retry.

## Full Server CI

[Run43633974699](https://github.com/AGaziev/night-horde/actions/runs/43633974699): **61/61 suites PASS**, Node24.22.2/Linux Ubuntu24.04. Downloaded server-test-logs once, parsed the full results list and revisions; checkout **a34acce215a7de3e126e6580467461cf96118b5f** has exact parents **13c560f** and **e7271a2** and its tree equals tested head. Complete primary files, run/artifact metadata, source/parents and SHA256s: ci-43633974699/receipt.json. CI success supplements the functional gate; it is not a PvP balance claim.

## Scope and cleanup

No blocker remains in this finite assigned delta. Earlier accepted original10findings are carried only in unchanged scope/context; this review does not reassert full statistical PvP balance, full15minute live matches, long/multi-room load or production network. Current fixes do not alter match-duration/finish/economy/scaling rules; no new duration/strength matrix is justified by this delta. New intervals have functional exploit/positive controls above, with no universal latency/FPS claim.

Both browser attempts awaited server/browser close and removed temp history. PIDs11839/13809 absent, ephemeral ports65466/49186 have no listener (lsof primary); all finite native commands exited0, final browser driver exited0. Cleanup.json and freeze.json preserve exact authority/evidence. **CPU_FREE**. CEO owns final merge/release; this report does not perform them.
