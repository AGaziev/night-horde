# Independent Issue41 r17 — code, counters and outcome-only carry

Reviewer independent, not author/coauthor. Exact head `30d10c5bfea097ff2e60bc2b5879047d0987d1c1`, base/current live main `a25f4f6aeb4e3f61e408905a84f281957844e5e9`.

- **CODE / current contribution counters: READY** for the assigned r17 originals, calling chains and retained controls.
- **600-outcome dataset integrity and 7e2→30d OUTCOMES_ONLY carry: READY**, with unchanged physical engine/readset proof below.
- **Overall balance target acceptance: INCOMPLETE**, not granted by this finite review. Four human point estimates fall outside25–40%; all paired95 intervals include0, which is not evidence of equivalence/no regression. Product/runs must assess these deviations explicitly.

Own source archive/hash `manifest.json` was frozen before testing. Full live owner6878941453/general comments saved and read. Source/calling-chain pass and own original RED/new GREEN preceded author REPORT/source-proof crosscheck. Only this output directory written; no app/Git/GitHub/production mutation, full match, heavy benchmark or performance/CPU/FPS claim. Canonical local Node24.22.1. Cleanup0 owned processes/ports, foreign workers untouched, clean current worktree (`cleanup.json`).

## Independent original reproduction and persisted counters

Command from workspace root: `node outputs/issue-split/v36/ceo-weapons41-r17-review/own-cases.mjs`. Structured raw `own-cases.json`, stdout `own-cases.log` preserve exact old7e2 and current30d behavior, both complete physical traces and RNG counts. Real Room.tick, TrapI/updateWeapon/updateTraps and WhipI, real Sand pickup and two actual ENEMY_TYPES.skel actors were used. Native `Room.finish` executed; assertions checked support in snapshot, final log and result card, not just h.support.

1. **Actual suppressed shield turning:** native TrapI roots Shield at contact with active dash cooldown, initial105°. Without root final56.2985874° and WhipI at0.9s deals2.8; rooted remains105° and takes14. These physical outcomes/RNG exactly match old7e2; old counter0 is now1 enemy-second consistently in native/snapshot/log/card. An aligned0° shield has identical root/plain traces and correctly retains0.
2. **Two real skeletons, guard edge:** actorA520, frozenB502.5, heroes26/27; Sand owned hero1, native freeze owned hero2. All30 full traces of BOTH actors, heroes/shot states and RNG counts31 match with/without Sand. Old Sand false1 becomes0 in all persisted outputs. Other owner's legal freeze1 remains1, and per-tick total control stays within the two-enemy union. Inset guarded and ordinary separation positives retain Sand1 + freeze1 and genuinely differ from plain movement.
3. For all five scenario families, old/new physical traces and RNG draw counts are equal; only intended contribution metadata changes. Older single-guard/contact-root, ordinary action-lock/freeze, source/union/caps, gift/Dome/mark controls remain green in the current native set.

Own current native regression command from frozen41: `node --import ./pm/test-runtime.mjs --test app/server/<suite>-test.js`. Eleven suites: control-shield-turn, control-separation, control-boundaries, control-delivery, support-gift-state, support-control-state, support-mark-attacker, support, reaction-support, flash-support, support-client. **51/51 PASS**, zero skipped/cancelled (`targeted.log`). `leash-skel` now passes the actual skeleton type, not a ghoul fixture mislabeled as skeleton.

## Read-only separation and strict physical applicability

Reviewed native Grid.query/key and actual separation loop against projectControlSeparation: same floor bounds, cx-then-cy bucket order, insertion order, ±32000 key clamp, self skip, overlap predicate and count of at most10 actual overlaps; projected query footprint comes from the plain endpoint. Same local separation formula followed by leash projection. Actor/grid/query arrays are not modified and actual AI/query/collision callbacks are not replayed.

Own `projection-readonly.mjs/json/log` independently compares the observer to a local numeric reference based on the real query order in **73 cases**: crossing/negative/extreme grid boundaries, reversed insertion order, limits0/1/2/10, and coincident unknown. Actors, grid buckets and q1/q2/q3 are frozen; grid mutations, actual query and RNG are replaced with throw guards during observation. All outputs/reference and pre/post state equality pass. This checks observer purity/semantics, not CPU performance.

Exact coincident projection or an actual jitter overlap is unresolved and conservatively receives0; this is a documented measurement boundary, **not proof of zero control effect**. The native random-overlap regression retains exactly the original single RNG draw. The observer is a per-actor mathematical projection on observed neighbor state, not an alternate multi-agent simulation.

After own pass, vetted author `prove-source.py` was replayed on our immutable source with own output only: `source-proof-recheck.py/json`. Eleven existing runtime graph leaves byte-identical7e2→30d; removing only enumerated bookkeeping edits reconstructs entire old game.js byte-for-byte. Actual movement/separation/clamp, hurt, turn/AI clocks and RNG text/order unchanged. Observer static checks forbid actor/grid writes, actual turn/AI/collision/query re-execution and extra RNG. Own physical/RNG A/B provides runtime corroboration.

Readset check: canonical run-sim/sim-runner have no support/control decision input; h.support.control is incremented as telemetry, serialized in snapshot/RunLog/card, not read by physics, bot policy, victory, finish or loot decisions. Imported content/perks/events/outposts/support and harness hashes remain exact. Hence canonical physical outcomes and unchanged non-control metrics may carry7e2→30d at the same runtime/attempt tuples. Historic control totals cannot carry.

## Independent600/pairs/raw audit

`audit-outcomes.py`, `outcome-audit.json/log` independently validate1200 selected raw/meta SHA256 files:600 baseline +600 candidate7e2, each unique logical ID, exact planned seed/K0/hero roster/bot/mode/player tuple, Node24.22.1 binary hash and canonical runner hashes. All candidate600 have durable supervisorv2 exit0/no timeout, terminal over, exactly one Room.finish, matching actual logID/win, and600 paired baseline IDs. No missing, duplicates, unresolved attempts or recovery overrides. Active game-time bounds900/600 retained; no wall-clock/performance acceptance claimed.

Measured baseline remains f4a40dc; accepted canonical baseline corea25 is carried by the existing proof chain. `baseline-proof-chain.json` independently verifies previous-proof fingerprint and20 before/after graph fingerprints against Git. Neither old baseline nor7e2 raw is relabeled as newly measured30d.

All published physical metric fields were recomputed from raw with the inspected shared pure reducers: wins/Wilson, paired changes, death causes/minutes/downs, terminal times, boss damage/DPS/kill times, duos, reconstructed mid/end weapon inventories, finale grades and budget limits. Independent direct win/paired counting additionally matches the reducer: wins `[25,13,21,20,14,26,18,16,39,34]`. Published support.control is explicitly removed from comparison/acceptance. Old raw retains its old metric/source attribution.

| Cell | Baseline | Candidate | Wilson95 candidate | Delta pp / paired95 | Target point |
| --- | --- | --- | --- | --- | --- |
| human 1 night | 26/60 | 25/60 (41.67%) | [30.06, 54.27] | -1.67 / [-9.02, 5.69] | OUTSIDE |
| human 1 lunch | 17/60 | 13/60 (21.67%) | [13.12, 33.62] | -6.67 / [-15.83, 2.49] | OUTSIDE |
| human 2 night | 24/60 | 21/60 (35.0%) | [24.17, 47.64] | -5.0 / [-18.52, 8.52] | within |
| human 2 lunch | 22/60 | 20/60 (33.33%) | [22.73, 45.94] | -3.33 / [-14.71, 8.05] | within |
| human 3 night | 12/60 | 14/60 (23.33%) | [14.44, 35.44] | 3.33 / [-9.82, 16.48] | OUTSIDE |
| human 3 lunch | 25/60 | 26/60 (43.33%) | [31.57, 55.9] | 1.67 / [-9.25, 12.58] | OUTSIDE |
| human 4 night | 20/60 | 18/60 (30.0%) | [19.9, 42.51] | -3.33 / [-14.71, 8.05] | within |
| human 4 lunch | 17/60 | 16/60 (26.67%) | [17.13, 39.01] | -1.67 / [-14.42, 11.08] | within |
| smart 1 night | 40/60 | 39/60 (65.0%) | [52.36, 75.83] | -1.67 / [-11.54, 8.21] | within |
| smart 1 lunch | 36/60 | 34/60 (56.67%) | [44.1, 68.43] | -3.33 / [-12.61, 5.95] | within |

Human targets outside at point estimate: solo night41.67% (baseline43.33%), solo lunch21.67% (baseline28.33%), trio night23.33% (baseline20%), trio lunch43.33% (baseline41.67%). Three were already outside at baseline; solo lunch newly crosses the point target. For solo lunch: −6.67pp, paired95[−15.83,+2.49]pp,6 lost/2 gained wins. Median terminal462.65→445.55s, mid weapons3→3.04, finale reached22→21 and gold5→5/silver12→8/lost5→8, mean boss damage51974.23→49749.43. These are observed exploratory comparisons; interval crossing0 does not establish no material regression. All60-run cell estimates remain uncertain; no blanket calibration READY.

## Fresh full CI

Own primary artifacts `ci-43609178065/`, audit `ci-audit.json`: final exact head30d, actual merge candidate `a6e768a752118b9ac0be897ef3985731f4b23000`, parents `[a25,30d]`, candidate tree equals head tree. **56/56 PASS**, Linux Node24.22.2, full exact-head app/server/*-test.js suite list and exit0 verified; not only overall workflow status.

## Handoff

No new confirmed important code finding remains in this finite assigned pass. CODE/counter READY and OUTCOMES_ONLY carry support the next product/runs assessment; four target-point deviations and uncertainty remain explicit. No current-control acceptance is inferred from historic600 counter values; fresh native checks supply that evidence. No new600 needed for this proven accounting-only source delta. #31/#45 unchanged and not re-reviewed here. Own final processes/ports0, no foreign job touched.
