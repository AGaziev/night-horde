# Issue41 / CEO comment6878941453 — r17 frozen author handoff

Source: `30d10c5bfea097ff2e60bc2b5879047d0987d1c1` on `codex/41-support-control`; before `7e2d195d49de4e7c4910142449b3e75394f3dad7`. RuntimeNodev24.22.1. Maina25/PROTO29/GAME_VERSION36 preserved. #31f674/#45a957 untouched. No push/amend/force.

## Changes

- Native TrapI suppression of Shield turning is credited as a defensive action. Rooted Shield remains105° and receives14 Whip damage; unrooted reaches56.298587° and receives2.8. Counter now1 enemy-second vs original0; alignedShield negative remains0. Actual turn/attack/AI statements unchanged.
- Slow bookkeeping independently projects the plain endpoint through native bucket/candidate order, ten-overlap limit, separation math and final leash clamp. Two actual skeletons at520/502.5 have identical complete30-tick traces with/without actual Sand pickup; Sand now0 instead of1. Other hero's real freeze remains1, so attribution is not confused. Inset/ordinary separation positives retain1. Shared grid/query arrays, actors and RNG are read-only.
- Exact random-overlap projection is unresolved and conservatively not credited; this is a measurement boundary, not proof that the status has zero effect. Native overlap still performs its original single jitter RNG draw. This is local per-actor mathematical projection on observed neighbors, not a full alternate multi-agent replay.
- Existing leash-skel regression now really spawns/asserts a skeleton; separate test-only commit.

## Commits

```
30d10c5bfea097ff2e60bc2b5879047d0987d1c1 Project each control path through read-only separation and leash geometry
a0d3d1956992847656c40438f066693fa1d22f90 Credit native trap control that prevents shield turning at contact
5303ecbc0aeecab2eda8472e83b8112e781f27f8 Exercise the leash-skel boundary case with an actual skeleton
```

## Evidence

- Original RED: `red.log`, `red-cases.json`, exact old runtime graph `before/` + `before-manifest.json`. Two valid metric defects; physical behaviors positive. Initial failed trap-placement/helper initialization fixtures are retained separately and are not counted as product failures.
- GREEN: `final-targeted.log` —51/51 native assertions across11 profile files, zero skipped/cancelled. `shield-stage.log` additionally checks exact angle-only staged source before its logical commit. Raw `shield-green-cases.json`, `separation-green-cases.json`, `boundaries-green-cases.json`.
- `gameplay-proof.mjs` / `.log` / `.json` and `gameplay-proof-summary.json`:11/11 old→new native complete traces, HP, shot state, shield angles and RNG counts identical excluding only support.control metadata. Full BOTH-skeleton traces included.
- `prove-source.py`, `source-proof.log/json`, `physics.diff`: removing explicitly listed accounting edits reconstructs the entire old game.js byte-for-byte; all11 other existing runtime leaves byte-equal. Observer static guards forbid actor/grid writes, AI/collision/query replay and extra RNG.
- Syntax checks5/5 and `git diff --check` PASS before final commit. `source-manifest.json` binds exact frozen runtime/test/doc bytes to final GitHEAD; `frozen/` is immutable evidence, not a new Git source.
- `cleanup.json`: clean worktree; no owned native/browser/HTTP process or port; no shared jobs stopped.

Replay (from worktree):

```sh
/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node --import ./pm/test-runtime.mjs --test app/server/control-shield-turn-test.js app/server/control-separation-test.js app/server/control-boundaries-test.js app/server/control-delivery-test.js app/server/support-control-state-test.js app/server/support-test.js app/server/support-client-test.js app/server/support-gift-state-test.js app/server/support-mark-attacker-test.js app/server/flash-support-test.js app/server/reaction-support-test.js
python3 ../../outputs/issue-split/v36/ceo-r17/41/prove-source.py
/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node --import ./pm/test-runtime.mjs ../../outputs/issue-split/v36/ceo-r17/41/gameplay-proof.mjs
```

Author targeted gate PASS. Independent review/CI remains root-owned; no authorREADY, full-suite/performance claim or final support-metadata acceptance. Existing7e2 outcome-only runs may carry only after root's strict source projection review; old control metadata does not carry. Causal12/31 preparation remains HOLD0 and was not extended.
