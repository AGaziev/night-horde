from pathlib import Path
import json,re,hashlib,subprocess
w=Path.cwd();out=(w/'../../outputs/issue-split/v36/ceo-r17/41').resolve();manifest=json.loads((out/'before-manifest.json').read_text());changed=[]
for r in manifest['files']:
 p=r['path'];a=(out/'before'/p).read_bytes();b=(w/p).read_bytes()
 if a!=b:changed.append(p)
assert sorted(changed)==['app/server/control-observation.js','app/server/game.js'],changed
before=(out/'before/app/server/game.js').read_text();s=(w/'app/server/game.js').read_text();projected=s.replace('projectControlPoint, projectControlSeparation, controlPointDiffers','projectControlPoint, controlPointDiffers')
projected=projected.replace('let controlMotion = null, controlPlainEnd = null, controlRandomOverlap = false;', 'let controlMotion = null;')
projected=projected.replace('speedMul * (fog && this.events.inFog(e) ? FOG_DEF.speedMul : 1), this.grid, e.r + MAX_ENEMY_R, SEPARATION_NEIGHBORS))', 'speedMul * (fog && this.events.inFog(e) ? FOG_DEF.speedMul : 1)))')
projected=projected.replace('if (step < plainStep) controlMotion = [e.x + dx * plainStep, e.y + dy * plainStep];', 'if (step < plainStep) controlMotion = [dx * (plainStep - step), dy * (plainStep - step)];')
projected=projected.replace('\n\t\t\t\tif (controlMotion) controlPlainEnd = projectControlSeparation(this.grid, e, controlMotion[0], controlMotion[1], e.r + MAX_ENEMY_R, SEPARATION_NEIGHBORS);','')
projected=projected.replace('\n\t\t\t\t\t\tcontrolRandomOverlap = true;','')
projected=projected.replace('// Compare independently projected separation, never the slowed displacement.\n\t\t\t\t// Random-overlap frames have no identifiable deterministic counterfactual.', '// Keep the observed separation displacement; do not replay collision/AI/RNG.\n\t\t\t\tconst plainEnd = controlMotion && projectControlPoint(e, e.x + controlMotion[0], e.y + controlMotion[1]);')
projected=projected.replace("if (controlPlainEnd && !controlRandomOverlap && controlPointDiffers(e.x, e.y, controlPlainEnd)) controlTick(e, now, dt, 'movement');", "if (plainEnd && controlPointDiffers(e.x, e.y, plainEnd)) controlTick(e, now, dt, 'movement');")
assert projected==before,'unclassified actual engine delta'
observer=(w/'app/server/control-observation.js').read_text();assert 'Math.random' not in observer
assert not re.search(r'\b(?:e|o|target|h|grid)\.\w+\s*(?:=(?!=)|\+=|-=|\+\+|--)',observer),'actor/grid field writes'
assert not re.search(r'\b(?:turnShield|bossTick|dashTick|sniperTick|rangedTick|hurtPlayer|hurtEnemy|confineGuard|query)\s*\(',observer),'actual AI/collision/query method replay'
assert not re.search(r'grid\.cells\.(?:set|delete|clear)\s*\(',observer),'grid mutation'
H=lambda b:hashlib.sha256(b).hexdigest();result=dict(before=manifest['head'],head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),existingSnapshotFiles=len(manifest['files']),unchangedFiles=len(manifest['files'])-2,gameBeforeSHA256=H(before.encode()),projectedGameSHA256=H(projected.encode()),gameAfterSHA256=H(s.encode()),entireProjectedGameByteEqual=True,observerSHA256=H(observer.encode()),actualPhysicsStatementsReordered=False,actualAIOrCollisionCalledAgain=False,actorOrGridWritesInObserver=False,extraRNGCalls=False,randomOverlapPolicy='unresolved; conservatively not credited, not proof of zero effect',projectionScope='per-actor local mathematical projection on read neighbor state; not a full alternate multi-agent simulation')
(out/'source-proof.json').write_text(json.dumps(result,indent=2));(out/'physics.diff').write_text(subprocess.check_output(['git','diff',manifest['head'],'--','app/server/game.js','app/server/control-observation.js'],text=True));print('PASS full projected game.js byte-equal7e2;11 other existing files exact;no actor/grid/AI/query/RNG effects')
