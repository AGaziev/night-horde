from pathlib import Path
import json, math, statistics, collections, hashlib, datetime, ast, re, random, csv

ROOT=Path(__file__).resolve().parents[4]
OUT=Path(__file__).resolve().parent
R=ROOT/'outputs/issue-split/runs/final-14ad'
old=ROOT/'outputs/eight-issues/runs/summarize.py'
tree=ast.parse(old.read_text())
ns={k:v for k,v in globals().copy().items()}
ns['OUT']=R
exec(compile(ast.Module(body=[x for x in tree.body if isinstance(x,ast.FunctionDef)],type_ignores=[]),str(old),'exec'),ns)
mapping,stats,pairStats=ns['mapping'],ns['stats'],ns['pairStats']
baselineProv=json.loads((R/'baseline-provenance.json').read_text())
base={};audit=[];fail=[]
def load(prefix, a, expectedSha, daily=False):
    prefix=Path(prefix);mp=prefix.with_suffix('.meta.json');rp=prefix.with_suffix('.json')
    if not mp.exists():return None
    m=json.loads(mp.read_text());d=json.loads(rp.read_text()) if rp.exists() else {}
    co=d.get('completion',[]);co=[co] if isinstance(co,dict) else co
    logs=d.get('logs',[])
    ok=m.get('terminalProof') is True and m.get('exitCode')==0 and m.get('sourceSha')==expectedSha and len(co)==len(logs)==1
    if ok:
        l=logs[0];c=co[0]
        ok=c.get('terminal') is True and c.get('state')=='over' and c.get('finishCalls')==1 and c.get('logId')==l['id'] and c.get('win')==l['win'] and l['players']==a['players'] and l['mode']==a['mode'] and d['pick']==a['bot'] and [t['hero'] for t in l['team']]==a['heroes'] and m['seed']==a['seed'] and m['K0']==a['K0']
    if daily and ok:
        c=m.get('dailyContract',{});ok=m.get('dailyContractProof') is True and c.get('version')==2 and c.get('id')==a['dailyRule'] and c.get('day')==a['dailyDay'] and c.get('mode')==a['mode'] and c.get('players')==a['players']
    if not ok:
        fail.append({'logical':a.get('attemptId',a['id']),'prefix':str(prefix),'reason':'metadata/tuple/terminal/source/daily proof mismatch'});return None
    audit.append({'logical':a.get('attemptId',a['id']),'sourceSha':expectedSha,'prefix':str(prefix),'rawSHA256':hashlib.sha256(rp.read_bytes()).hexdigest(),'metaSHA256':hashlib.sha256(mp.read_bytes()).hexdigest(),'durable':m.get('durableSupervisorVersion'),'explicitRecovery':m.get('explicitRecovery'),'workerReceipt':prefix.with_suffix('.exit.json').exists()})
    return l,m

cp=json.loads((R/'combat/plan.json').read_text());cells=cp['cells']
first={a['id']:a for a in cp['attempts'] if a['issue']==41}
for p in baselineProv:
    a=first[p['id']];v=load(p['rawPrefix'],a,p['measuredSourceSha'])
    if v:base[a['id']]=v[0]
ns['MAP']={'baseline':mapping(str(R/'baseline'))}
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baselineMeasured':cp['measuredBaseline'],'baselineAcceptedCore':'a25f4f6aeb4e3f61e408905a84f281957844e5e9','runtime':cp['runtime'],'baselineValid':len(base),'selectedPhysicalAttempts':audit,'failures':fail,'datasets':{}}
swarm=[]
for kind,issues in [('combat',[41])]:
    q=ROOT/'outputs/issue-split/runs/final-a25-r16/issue41-7e2d195';plan=json.loads((q/'plan.json').read_text());bind=json.loads((q/'candidate-bindings.json').read_text())['issues'];rec=json.loads((q/'active-recovery.json').read_text());over=rec['retryOverrides']
    groups=collections.defaultdict(dict);tele=collections.defaultdict(list);missing=collections.defaultdict(list)
    for a in plan['attempts']:
        if a['issue'] not in issues:continue
        b=bind[str(a['issue'])];label=str(a['issue']) if kind=='combat' else '12-'+a['dailyRule']
        s=q/'raw'/('issue-'+str(a['issue']))/b['candidateSha'];s=s/a['dailyRule']/a['id'] if kind=='daily' else s/a['id']
        if a['attemptId'] in over:s=Path(over[a['attemptId']]['retryPrefix'])
        v=load(s,a,b['candidateSha'],kind=='daily')
        if v:
            groups[label][a['id']]=v[0]
            if kind=='daily':tele[label].append(v[1]['dailyTelemetry'])
        else:missing[label].append(a['id'])
    for label,data in groups.items():
        issue=int(label.split('-')[0]);binding=bind[str(issue)];ns['MAP']['candidate']=mapping(binding['snapshotPath']);rows=[]
        for ci,cell in enumerate(cells):
            ids=[a['id'] for a in plan['attempts'] if a['issue']==issue and a['cell']==ci and (kind=='combat' or '12-'+a['dailyRule']==label)]
            rs={i:data[i] for i in ids if i in data};bs=[base[i] for i in ids if i in base];pairs=[(base[i],r) for i,r in rs.items() if i in base]
            bstat=stats(bs,'baseline');cstat=stats(list(rs.values()),'candidate');pa=pairStats(pairs);disc=pa.get('lostWins',0)+pa.get('gainedWins',0)
            pa['exactMcNemarTwoSided']=min(1,2*sum(math.comb(disc,i) for i in range(min(pa.get('lostWins',0),pa.get('gainedWins',0))+1))/2**disc) if disc else 1
            rows.append({'cell':ci,**cell,'complete':len(rs)==60,'baseline':bstat,'candidate':cstat,'paired':pa,'missingLogicalIds':[i for i in ids if i not in rs]})
        result['datasets'][label]={'measuredSourceSha':binding['candidateSha'],'validSelected':len(data),'planned':600,'historicalRecoveryCount':len(rec['originalUnknown']),'selectedRecoveryCount':sum(a.get('explicitRecovery') is not None for a in audit if a['sourceSha']==binding['candidateSha']),'rows':rows}
        if kind=='daily':
            bad=[];ct=collections.Counter();awardValues=[];cohorts=[]
            for t in tele[label]:
                co=t.get('finalCohorts',[]);aw=t.get('awards',[])
                for c in co:
                    ct['cohorts']+=1;ct['resolved']+=bool(c.get('resolved'));ct['success']+=bool(c.get('success'));cohorts.append(c)
                    if c.get('resolved') and c.get('success') != (c['spawned']>0 and c['killed']*10>=c['spawned']*7):bad.append(('criterion',c))
                seen=set()
                for w in aw:
                    key=(w['cohort'],w['pid']);ct['awards']+=1;awardValues.append(w['amount'])
                    if key in seen or abs(w['amount']-w['expected'])>1e-8:bad.append(('award',w))
                    seen.add(key)
            result['datasets'][label]['dailyTelemetry']={'records':len(tele[label]),'counts':dict(ct),'bad':bad,'totalAwardXP':sum(awardValues),'cohorts':cohorts}

result['selectedPhysicalAttempts']=audit;result['failures']=fail
result['metricAcceptance']={'scope':'physical outcomes only','support.control':'EXCLUDED: owner6878941453; historical metadata retained, not final actual-contribution acceptance'}
(OUT/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
with (OUT/'cells.csv').open('w') as f:
    w=csv.writer(f);w.writerow(['dataset','bot','N','mode','complete','baseWins','wins','n','Wilson95','deltaPP','paired95','lost','gained','exactMcNemar'])
    for label,ds in result['datasets'].items():
        print('DATASET',label,ds['validSelected'])
        for r in ds['rows']:
            p=r['paired'];c=r['candidate'];w.writerow([label,r['bot'],r['players'],r['mode'],r['complete'],r['baseline']['wins'],c['wins'],c['terminal'],c['wilson95'],p.get('deltaPP'),p.get('pairedNormal95CI'),p.get('lostWins'),p.get('gainedWins'),p.get('exactMcNemarTwoSided')]);print(r['cell'],c['wins'],c['terminal'],'base',r['baseline']['wins'],'W',c['wilson95'],'delta',p.get('deltaPP'),p.get('pairedNormal95CI'),'p',p.get('exactMcNemarTwoSided'))
print('FAILURES',len(fail),'BASE',len(base),'AT',result['at'])
