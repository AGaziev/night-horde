import pathlib,json,subprocess,sys,os,datetime
Q=pathlib.Path(sys.argv[1]).resolve();L=Q/'launchd';job=json.loads((L/'job.json').read_text());assert job['keepAlive']is False;assert job['planDir']==str(Q)
def save(p,o):
 t=p.with_name(p.name+'.tmp-'+str(os.getpid()))
 with t.open('w')as f:json.dump(o,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 os.replace(t,p)
p=subprocess.Popen([sys.executable,job['masterProgram'],str(Q)],stdin=subprocess.DEVNULL)
save(L/'started.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'launchdEntryPID':os.getpid(),'masterPID':p.pid,'label':job['label'],'domain':job['domain'],'noAutomaticRetry':True})
code=p.wait();save(L/'exit.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'observedMasterExitCode':code,'masterPID':p.pid,'launchdEntryPID':os.getpid(),'label':job['label'],'noAutomaticRetry':True});sys.exit(code)
