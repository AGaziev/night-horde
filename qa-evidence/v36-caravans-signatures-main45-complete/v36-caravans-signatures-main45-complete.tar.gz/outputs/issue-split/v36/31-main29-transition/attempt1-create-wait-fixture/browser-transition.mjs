import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {setTimeout as wait} from 'node:timers/promises';
import {chromium} from '/Users/s.konev/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';

const out=new URL('./',import.meta.url).pathname,port=34631,url=`http://127.0.0.1:${port}`;
const sources={main:path.join(out,'main'),candidate:path.join(out,'candidate')};
const children=[],fds=[],wire=[],navigations=[],resources=[],resourceTasks=[],errors=[],stages=[];
let browser,page,candidate,request=0,phase='main';
const result={sourceMain:'0ab5f6fd29c293511b149664c42f7a2268e527d8',sourceCandidate:'679190c7ec5bb979761660593cca0ff1e1da6cbe',runtime:process.version,port};
const runs=fs.mkdtempSync(path.join(out,'owned-runs-'));
const wrapper=`
const {Room}=await import(${JSON.stringify(path.join(sources.candidate,'app/server/game.js'))});
const rooms=new Map(),start=Room.prototype.start;
Room.prototype.start=function(){const value=start.call(this);rooms.set(this.code,this);this.spawn=()=>{};this.events.next=Infinity;return value;};
process.on('message',m=>{
 try{
  const r=rooms.get(m.code);if(!r)throw Error('unknown owned room');
  if(m.cmd==='prepare'){
   if(m.restart)r.start();r.enemies=[];r.projectiles=[];r.fx=[];
   const [h,ally]=r.heroes.values();if(!ally)throw Error('actual ally must have joined');
   h.weapons=new Map([['bolt',{lvl:3,t:999}],['lightning',{lvl:3,t:999}],['flask',{lvl:3,t:999}]]);ally.weapons=new Map([['bolt',{lvl:3,t:999}]]);
   r.addProjectile(h,'bolt',0,0,10,Infinity,300,null,0,{x:h.x+80,y:h.y,src:{weapon:'bolt'}});const consumed=r.projectiles.at(-1).id;
   r.addProjectile(ally,'bolt',0,0,10,Infinity,300,null,0,{x:ally.x+80,y:ally.y,src:{weapon:'bolt'}});const unrelated=r.projectiles.at(-1).id;
   r.qa={pid:h.pid,consumed,unrelated};r.snapshot();process.send({request:m.request,data:{...r.qa,owners:[h.pid,ally.pid]}});return;
  }
  if(m.cmd==='fuse'){
   const h=r.heroes.get(r.qa.pid);if(!r.fuseDuo(h,{id:'orb',parts:['bolt','lightning'],level:1}))throw Error('native fusion rejected');
   const cancellation=r.fx.filter(ev=>ev[0]==='cancel').map(ev=>[...ev]);let dropped=null;
   if(m.drop){const send=r.send;r.send=(pid,msg,json)=>{if(pid===h.pid){dropped=JSON.parse(json);return;}return send(pid,msg,json);};try{r.snapshot();}finally{r.send=send;}r.snapshot();}else r.snapshot();
   process.send({request:m.request,data:{...r.qa,cancellation,dropped,serverProjectiles:r.projectiles.map(p=>p.id),ledger:[...r.consumedAttacks.values()]}});return;
  }
  throw Error('unknown owned command');
 }catch(error){process.send({request:m.request,error:error.stack});}
});
await import(${JSON.stringify(path.join(sources.candidate,'app/server/server.js'))});
`;
fs.writeFileSync(path.join(out,'candidate-server.mjs'),wrapper);

function launch(name){
 const file=name==='candidate'?path.join(out,'candidate-server.mjs'):path.join(sources.main,'app/server/server.js');
 const fd=fs.openSync(path.join(out,`${name}-server.log`),'w');fds.push(fd);
 const child=spawn(process.execPath,[file],{cwd:sources[name],env:{...process.env,PORT:String(port),VIBE_APP_KEY:'',HORDE_RUNS_DIR:path.join(runs,name)},stdio:['ignore',fd,fd,...(name==='candidate'?['ipc']:[])]});
 const state={name,child,exit:once(child,'exit'),stopped:false};children.push(state);return state;
}
async function stop(state){if(state.stopped)return;if(state.child.exitCode===null)state.child.kill('SIGTERM');await state.exit;state.stopped=true;}
async function ready(){for(let i=0;i<100;i++){if(await fetch(url+'/health').then(r=>r.ok,()=>false))return;await wait(30);}throw Error('owned server not ready');}
function ipc(cmd,code,extra={}){const id=++request;return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{candidate.child.off('message',listener);reject(Error('owned IPC timeout'));},5000);const listener=m=>{if(m.request!==id)return;clearTimeout(timer);candidate.child.off('message',listener);if(m.error)reject(Error(m.error));else resolve(m.data);};candidate.child.on('message',listener);candidate.child.send({cmd,code,request:id,...extra});});}

try{
 const main=launch('main');await ready();
 browser=await chromium.launch({headless:true,args:['--mute-audio','--disable-features=LocalNetworkAccessChecks']});result.browserVersion=browser.version();
 const context=await browser.newContext({viewport:{width:1280,height:800}});page=await context.newPage();
 await page.addInitScript(()=>{const n=Number(sessionStorage.getItem('qa.navCount')||0)+1;sessionStorage.setItem('qa.navCount',String(n));window.__qaNavigation=n;});
 page.on('pageerror',e=>errors.push({phase,message:e.message}));
 page.on('framenavigated',frame=>{if(frame===page.mainFrame())navigations.push({phase,url:frame.url(),at:Date.now()});});
 page.on('websocket',ws=>{const endpoint=ws.url();ws.on('framereceived',ev=>{let data;try{data=JSON.parse(ev.payload.toString());}catch{return;}for(const msg of [].concat(data))wire.push({direction:'received',phase,endpoint,msg,at:Date.now()});});ws.on('framesent',ev=>{let msg;try{msg=JSON.parse(ev.payload.toString());}catch{return;}wire.push({direction:'sent',phase,endpoint,msg,at:Date.now()});});});
 page.on('response',response=>{const pathname=new URL(response.url()).pathname;if(!['/','/js/game.js','/js/net.js','/js/snapshot-codec.js'].includes(pathname))return;const responsePhase=phase;resourceTasks.push(response.body().then(body=>{const sha256=crypto.createHash('sha256').update(body).digest('hex');resources.push({phase:responsePhase,pathname,status:response.status(),sha256});fs.writeFileSync(path.join(out,`${responsePhase}-${pathname==='/'?'index.html':path.basename(pathname)}`),body);}).catch(error=>resources.push({phase:responsePhase,pathname,error:error.message})));});
 await page.goto(url);await page.waitForFunction(()=>window.__nh?.net.connected);
 assert.equal(await page.evaluate(async()=>(await import('/js/snapshot-codec.js')).PROTO),29);
 await page.locator('#menu-create').click();await page.locator('#lobby-start').click();await page.waitForFunction(()=>__nh.game.latest());
 await page.evaluate(()=>sessionStorage.setItem('qa.sentinel','same-real-tab'));
 result.before=await page.evaluate(async()=>({proto:(await import('/js/snapshot-codec.js')).PROTO,nav:window.__qaNavigation,sid:sessionStorage.getItem('nh.sid'),reloadGuard:sessionStorage.getItem('nh.protoReload'),sentinel:sessionStorage.getItem('qa.sentinel'),ach:localStorage.getItem('nh.ach'),duos:localStorage.getItem('nh.duos')}));
 assert.equal(result.before.nav,1);assert.equal(result.before.reloadGuard,null);await page.screenshot({path:path.join(out,'main29-before-restart.png')});stages.push('real main29 page playing');
 await stop(main);phase='candidate';candidate=launch('candidate');await ready();
 // No page.reload/goto, forced version constants, mock welcome, old-resource route or manual reconnect.
 await page.waitForFunction(()=>window.__qaNavigation===2&&window.__nh?.net.connected,null,{timeout:20000});
 result.after=await page.evaluate(async()=>({proto:(await import('/js/snapshot-codec.js')).PROTO,nav:window.__qaNavigation,navigationType:performance.getEntriesByType('navigation')[0]?.type,sid:sessionStorage.getItem('nh.sid'),reloadGuard:sessionStorage.getItem('nh.protoReload'),sentinel:sessionStorage.getItem('qa.sentinel'),ach:localStorage.getItem('nh.ach'),duos:localStorage.getItem('nh.duos'),currentLedger:__nh.game.consumedAttacks instanceof Set}));
 assert.equal(result.after.proto,30);assert.equal(result.after.nav,2);assert.equal(result.after.navigationType,'reload');assert.ok(+result.after.reloadGuard>0);assert.equal(result.after.sentinel,result.before.sentinel);assert.equal(result.after.ach,result.before.ach);assert.equal(result.after.duos,result.before.duos);assert.equal(result.after.currentLedger,true);
 assert.ok(wire.some(e=>e.direction==='received'&&e.phase==='candidate'&&e.msg.t==='welcome'&&e.msg.v===30&&new URL(e.endpoint).searchParams.get('v')==='29'));
 assert.ok(wire.some(e=>e.direction==='received'&&e.phase==='candidate'&&e.msg.t==='welcome'&&e.msg.v===30&&new URL(e.endpoint).searchParams.get('v')==='30'));
 await page.screenshot({path:path.join(out,'candidate30-after-natural-reload.png')});stages.push('actual welcome30 caused one natural reload');
 await page.locator('#menu-create').click();const code=await page.evaluate(()=>__nh.state.lobby.code);
 const guestContext=await browser.newContext(),guest=await guestContext.newPage();await guest.goto(url);await guest.locator('#menu-code').fill(code);await guest.locator('#menu-join').click();await guest.locator('#lobby-ready').click();await page.waitForFunction(()=>__nh.state.lobby.players.length===2);await page.locator('#lobby-start').click();await page.waitForFunction(()=>__nh.game.latest());
 result.fusions=[];
 for(const drop of [true,false]){
  const ids=await ipc('prepare',code,{restart:!drop});await page.waitForFunction(ids=>__nh.game.shots.has(ids.consumed)&&__nh.game.shots.has(ids.unrelated),ids);
  const from=wire.length,fused=await ipc('fuse',code,{drop});await page.waitForFunction(ids=>!__nh.game.shots.has(ids.consumed)&&__nh.game.shots.has(ids.unrelated),ids);
  assert.ok(!fused.serverProjectiles.includes(ids.consumed)&&fused.serverProjectiles.includes(ids.unrelated));assert.deepEqual(fused.cancellation,[['cancel',0,ids.consumed]]);assert.ok(fused.ledger.some(([kind,id])=>kind===0&&id===ids.consumed));
  const client=await page.evaluate(ids=>({consumed:__nh.game.shots.has(ids.consumed),unrelated:__nh.game.shots.has(ids.unrelated),ledger:[...__nh.game.consumedAttacks]}),ids);
  if(drop){assert.ok(fused.dropped);assert.ok(wire.slice(from).some(e=>e.direction==='sent'&&e.msg.t==='kf'));assert.ok(wire.slice(from).some(e=>e.direction==='received'&&e.msg.consumedAttacks?.some(([kind,id])=>kind===0&&id===ids.consumed)));}
  result.fusions.push({drop,ids,fused,client});await page.screenshot({path:path.join(out,`current30-${drop?'lost-cancel-key':'native-cancel'}.png`)});
 }
 await Promise.all(resourceTasks);
 for(const pathname of ['/','/js/game.js','/js/net.js','/js/snapshot-codec.js']){const p=pathname==='/'?'index.html':pathname.slice(1),expected=crypto.createHash('sha256').update(fs.readFileSync(path.join(sources.candidate,'app/public',p))).digest('hex');assert.ok(resources.some(r=>r.phase==='candidate'&&r.pathname===pathname&&r.sha256===expected),'real candidate resource '+pathname);}
 assert.deepEqual(errors,[]);stages.push('fresh current Game obeyed live cancel and recovered lost cancel by native key; ally shot retained');result.pass=true;
 console.log('PASS actual main29→candidate30 automatic reload, current resources, native cancel/key and unrelated ally projectile');
}finally{
 result.stages=stages;result.navigations=navigations;result.resources=resources;result.wire=wire;result.pageErrors=errors;fs.writeFileSync(path.join(out,'browser-results.json'),JSON.stringify(result,null,2));
 await browser?.close();for(const state of children)await stop(state);for(const fd of fds)fs.closeSync(fd);fs.rmSync(runs,{recursive:true,force:true});fs.writeFileSync(path.join(out,'browser-cleanup.json'),JSON.stringify({children:children.map(s=>({name:s.name,pid:s.child.pid,stopped:s.stopped})),port,runsRemoved:!fs.existsSync(runs),browserClosed:true},null,2));
}
