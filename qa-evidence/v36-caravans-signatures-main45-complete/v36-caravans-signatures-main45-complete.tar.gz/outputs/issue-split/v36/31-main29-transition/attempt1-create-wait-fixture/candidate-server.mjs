
const {Room}=await import("/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/issue-split/v36/31-main29-transition/candidate/app/server/game.js");
const rooms=new Map(),start=Room.prototype.start;
Room.prototype.start=function(){const value=start.call(this);rooms.set(this.code,this);this.spawn=()=>{};this.events.next=Infinity;return value;};
process.on('message',m=>{
 try{
  const r=rooms.get(m.code);if(!r)throw Error('unknown owned room');
  if(m.cmd==='prepare'){
   if(m.restart)r.start();r.enemies=[];r.projectiles=[];r.fx=[];
   const [h,ally]=r.heroes.values();if(!ally)throw Error('actual ally must have joined');
   h.weapons=new Map([['bolt',{lvl:3,t:999}],['lightning',{lvl:3,t:999}],['flask',{lvl:3,t:999}]]);ally.weapons=new Map([['bolt',{lvl:3,t:999}]]);
   r.addProjectile(h,'bolt',0,0,10,Infinity,300,null,0,{x:h.x+80,y:h.y,src:{weapon:'bolt'}});const consumed=r.projectiles.at(-1).id;
   r.addProjectile(ally,'bolt',0,0,10,Infinity,300,null,0,{x:ally.x+80,y:ally.y,src:{weapon:'bolt'}});const unrelated=r.projectiles.at(-1).id;
   r.qa={pid:h.pid,consumed,unrelated};r.snapshot();process.send({request:m.request,data:{...r.qa,owners:[h.pid,ally.pid]}});return;
  }
  if(m.cmd==='fuse'){
   const h=r.heroes.get(r.qa.pid);if(!r.fuseDuo(h,{id:'orb',parts:['bolt','lightning'],level:1}))throw Error('native fusion rejected');
   const cancellation=r.fx.filter(ev=>ev[0]==='cancel').map(ev=>[...ev]);let dropped=null;
   if(m.drop){const send=r.send;r.send=(pid,msg,json)=>{if(pid===h.pid){dropped=JSON.parse(json);return;}return send(pid,msg,json);};try{r.snapshot();}finally{r.send=send;}r.snapshot();}else r.snapshot();
   process.send({request:m.request,data:{...r.qa,cancellation,dropped,serverProjectiles:r.projectiles.map(p=>p.id),ledger:[...r.consumedAttacks.values()]}});return;
  }
  throw Error('unknown owned command');
 }catch(error){process.send({request:m.request,error:error.stack});}
});
await import("/Users/s.konev/Documents/Codex/2026-11-10/vibecode-vibecode-deploy-api-api-vibe/outputs/issue-split/v36/31-main29-transition/candidate/app/server/server.js");
