# #31: реальная вкладка main29 → кандидат30

**SCOPED READY** для owner6880837407: переход клиента и последующая обработка cancel/key. Base main `0ab5f6fd29c293511b149664c42f7a2268e527d8`, candidate **`679190c7ec5bb979761660593cca0ff1e1da6cbe`**. Никаких branch APP edits, commit/push или полных матчей/профилей. Это не READY по текущему балансу/5–8.

## Настоящий переход

`browser-transition.mjs` поднимает actual main server/client из проверенного Git-tree0ab, затем останавливает только свой main process и запускает actual candidate на том же owned127.0.0.1:34631. Вкладка остаётся открытой. Оба app-copy сверены по каждому Gitblob (main130/candidate135 файлов), `source-copies.json`; dependencyws8.22.1 — readonly symlink, приложение не патчилось. Source main взят из archived17-main45-baseline, SOURCE_SHA0ab; никакого fakewelcome, ручной заменыPROTO, routeстарыхфайлов, page.reload или ручного reconnect.

Node24.22.1; actual Chromium **151.0.7922.34**, headless `--mute-audio`. Main29 начал реальную игру. После restart естественный Net увидел unknown oldSID, штатно получил новую сессию, подключился всё ещё сv29 и получил actualwelcome30. ProductionNet вызвал location.reload. Та же вкладка имеет navigationType=reload, счётчик1→2; после загрузки новаяWSv30 получаетwelcome30 без третьей навигации. Сентинел sessionStorage сохранился; ordinaryprogresskeys были пустыми и осталисьпустыми — сохранность заполненного прогресса этим сценарием не заявляется. Точный SID изменился из-за двух разных in-memory серверов; browsercontext/origin/storageне менялись.

До/послеactualHTTPbodies дляindex.html,game.js,net.js,snapshot-codec.js имеют Git-source hashes. Новый Game содержит текущий consumedAttacksSet. Primarybrowser-results.json содержит обаwelcome, URLv29/v30, обе навигации, восемь resourcehashes, безpageerrors; browser-execution.json связывает scriptSHA/source/runtime/exit0. Before/after screenshots рядом.

## Текущий Game после reload

В том же текущем браузере реально создан co-op с другим браузерным игроком. Test-only IPC экипирует исходныеуровни и создаёт два native addProjectile — своего и союзника, обаbolt. Настоящий Room.fuseDuo убирает только свою атаку и создаёт cancel/ledger; сообщения отправляются actualsnapshotencoder→WS→productionNet/Game.

- Потеря единственного cancel-пакета: serverwrapper намеренно теряет ровно одну готовую snapshotdelivery хозяину, затем отправляет следующую. НастоящийNet обнаруживает разрыв и посылаетkf; actualkey сconsumedAttacks удаляет свой №1, союзный №2 остаётся.
- НовыйnativeRoom.start сбрасывает сервер/клиент ledger и позволяет повторное использованиеID1/2. Обычный nativecancel снова удаляет только свойID1, союзныйID2остаётся.

Сценарий не выдаётся за естественный loot/forge/playthrough: только IPCподготовка условий, реальные методы/кодек/транспорт/клиент. No fabricatedcancel/key. Native replay отдельно:8 файлов, **13/13 PASS**, all39 signature/inheritance loops, shield state, attribution, focus, actualkey/cancel/latespawn/repeatedkey/newrun и Netprotocolcompat. native.log/native-execution.json.

Первая попытка дошла до успешной реальной автоматической перезагрузки, затем fixture прочитал state.lobby до асинхронного ответаcreate. Она сохранена целиком вattempt1-create-wait-fixture, включаяcleanup; добавлено ожидание настоящего WS-lobby, продукт не исправлялся. Final attempt2 — весь сценарийPASS. Это не потерянная или переименованная попытка.

## Первичка CI

Run[43618470806](https://github.com/AGaziev/night-horde/actions/runs/43618470806), attempt1, completed/success. Primaryartifactserver-test-logs ZIP SHA256f76b20b896b00b70a4e8ef31c1540099bb753711d6bda83e0a20eaaa1b129da3: **56/56 PASS**, Node24.22.2/Linux. revisions.txt называет checkout7cbe3b15a4c07db7c6167307942d94d68bc87e77, PRhead679190c иbase0ab. GitHubcommitprimary подтверждает двух родителейbase/head; checkouttree2bf14c21ab99bebda876e115ad77c002210fa638 точно равенHEAD679tree. ci-proof.json, ci-run/jobs/artifacts/checkout-commit.json иci-primary/ с56логами сохранены. Критическиеfusion-key-recovery/offer-identityлоги прочитаны, а не толькоSUCCESSbadge. Это независимая верификация существующего CI, не локальный повтор полного набора и не новоеperformanceизмерение.

## Строгая применимость fb18 → 679

canonical-carry-proof.json +prove-canonical.py/canonical-replay.log: **14runtimeleaves** game dependency graph, включаяpackage/lock; единственное отличие — объявлениеPROTO29→30 и поясняющий комментарий вpublicsnapshot-codec. После явно классифицированной замены весьgraphbyte-equal. run-sim/sim-runner/buildcraft-bench —3 файла byte-equal. Canonicalbot создаёт Room напрямую, не server.js/Hub.welcome; clientProto остаётся пустым, isLegacy(pid) defaults to currentPROTO иfalse на обеих версиях. ДругихPROTObranches вAI/physics нет. Сигнатуры, параметры.54/HP, RNG/hurt/movement/phaseorder не менялись.

Следовательно, **только измерения, уже применимые кfb18**, могут переноситься на679 для canonicalphysics при тех жеNode/deps/tuples/seed/K0/heroes/harness/env. Это не переносUI (он проверенсвежим браузером), не доказательство для старых417/a25результатов и не перенос на реальныеphysicalfixes#17/#41. Новая600/репликация не запускалась; решения оsourcebindings/futurebalance принадлежат root/runs.

cleanup.json: оба ownedserverPIDзавершены, браузер закрыт, runsдиректорияудалена, порт34631свободен, своихNode0, WT31чистый. Во времяquietUI21 никакихNode/browser/nativeпроцессов не было; запуск продолжен послеrootCPU_FREE. ЧужиеDailyworkersнетронуты, CPU/FPSclaimsнет.
