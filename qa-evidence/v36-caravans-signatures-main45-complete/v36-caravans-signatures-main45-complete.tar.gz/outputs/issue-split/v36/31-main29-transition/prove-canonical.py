from pathlib import Path
import hashlib,json,subprocess

out=Path(__file__).resolve().parent
root=out.parents[3]
repo=root/'work/night-horde-issue-31'
proof=json.loads((out/'canonical-carry-proof.json').read_text())
show=lambda ref,p:subprocess.check_output(['git','show',f'{ref}:{p}'],cwd=repo)
old=b'export const PROTO = 29; // Updated client state contracts require older pages to reload before resuming.'
new=b'export const PROTO = 30; // Updated feature contracts require a UI newer than the combat-only PROTO 29 page.'
for row in proof['graphFiles']:
    a,b=show(proof['from'],row['path']),show(proof['to'],row['path'])
    assert hashlib.sha256(a).hexdigest()==row['beforeSHA256']
    assert hashlib.sha256(b).hexdigest()==row['afterSHA256']
    if a!=b:
        assert row['path']=='app/public/js/snapshot-codec.js' and b.count(new)==1
        b=b.replace(new,old)
    assert a==b,row['path']
for row in proof['harness']:
    a,b=show(proof['from'],row['path']),show(proof['to'],row['path'])
    assert a==b and hashlib.sha256(a).hexdigest()==row['sha256']
ci=json.loads((out/'ci-proof.json').read_text())
assert hashlib.sha256((out/'ci-server-test-logs.zip').read_bytes()).hexdigest()==ci['artifactSHA256']
results=json.loads((out/'ci-primary/results.json').read_text())
assert len(results['results'])==56 and all(r['status']=='PASS' for r in results['results'])
commit=json.loads((out/'ci-checkout-commit.json').read_text())
assert [p['sha']for p in commit['parents']]==[ci['base'],ci['head']]
assert commit['commit']['tree']['sha']==subprocess.check_output(['git','rev-parse',ci['head']+'^{tree}'],cwd=repo,text=True).strip()
print('PASS14 runtime leaves +3 canonical harness files: protocol declaration/comment only; CI56/56 exact parents/tree/artifact verified')
