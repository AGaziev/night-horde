import fs from 'node:fs';import path from 'node:path';import {pathToFileURL}from'node:url';import crypto from'node:crypto';
const out=path.dirname(new URL(import.meta.url).pathname),manifest=JSON.parse(fs.readFileSync(out+'/sources.json')),rows=[];
const seeded=seed=>()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
for(const revision of['baseline','candidate']){const dir=manifest[revision].source,{Room}=await import(pathToFileURL(dir+'/app/server/game.js'));
 for(const level of[1,3])for(const build of['plain','rapid'])for(const seed of[11,29,73]){
  const random=Math.random;Math.random=seeded(seed);try{
   const r=new Room('PULL',()=>{});r.addPlayer(1,'P','knight');r.start();r.time=100;r.enemies=[];r.breakAround=()=>{};const h=r.heroes.get(1);h.x=h.y=0;h.perk.readyAt=Infinity;h.hp=h.maxHp=1e12;h.weapons=new Map([['orbit',{lvl:level+2,t:.2}],['aura',{lvl:level+2,t:.2}]]);h.passives=new Map((build==='rapid'?['might','haste','echo','area','hourglass']:[]).map(id=>[id,3]));r.recalcMods(h);h.hp=h.maxHp=1e12;r.fuseDuo(h,{id:'whirlwind',parts:['orbit','aura'],level});
   const enemies=[];for(let i=0;i<36;i++){const e=r.spawnEnemy('ghoul',[h],1),a=Math.random()*Math.PI*2,d=45+Math.random()*235;Object.assign(e,{x:Math.cos(a)*d,y:Math.sin(a)*d,hp:1e12,maxHp:1e12,speed:60,dmg:0,shotT:Infinity});enemies.push(e);}
   let displacement=0,movedTargets=0;const original=r.whirlwindTick.bind(r);r.whirlwindTick=(...args)=>{const before=enemies.map(e=>[e.x,e.y]);const result=original(...args);for(let i=0;i<enemies.length;i++){const d=Math.hypot(enemies[i].x-before[i][0],enemies[i].y-before[i][1]);displacement+=d;if(d>1e-9)movedTargets++;}return result;};
   for(let i=1;i<=1800;i++){const t=i/30;r.time=100+t;r.tickNo++;r.lightBudget=8;const x=18*Math.sin(1.2*t),y=12*Math.sin(.7*t),dx=x-h.x,dy=y-h.y,len=Math.hypot(dx,dy);if(len){h.fx=h.mvx=dx/len;h.fy=h.mvy=dy/len;h.movedT=r.time;}h.x=x;h.y=y;r.moveEnemies(1/30,[h]);r.rebuildGrid();r.updateBuffs([h]);for(const[id,w]of h.weapons)r.updateWeapon(h,id,w,1/30);r.updateProjectiles(1/30);r.updateColdWaves(1/30);r.updateBlasts();r.updateOrbs(1/30);r.updateTimers();r.updateTraps(1/30);r.updatePuddles(1/30);r.fx=[];}
   rows.push({revision,sha:manifest[revision].sha,level,build,seed,seconds:60,displacementWorldUnits:displacement,movedTargetTicks:movedTargets,damage:h.dmg});
  }finally{Math.random=random;}
 }
}
fs.writeFileSync(out+'/whirlwind-pull.json',JSON.stringify({harnessSHA256:crypto.createHash('sha256').update(fs.readFileSync(new URL(import.meta.url))).digest('hex'),node:process.version,note:'Actual displacement inside whirlwindTick only; not status-seconds and not invented prevented damage. Same crowd setup and full cast pipeline as main bench.',rows},null,2)+'\n');console.log(JSON.stringify({rows:rows.length,minimumDisplacement:Math.min(...rows.map(x=>x.displacementWorldUnits))}));
