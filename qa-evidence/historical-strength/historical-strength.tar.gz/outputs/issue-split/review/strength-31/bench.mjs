import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const out=path.dirname(new URL(import.meta.url).pathname),manifest=JSON.parse(fs.readFileSync(path.join(out,'sources.json')));
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const plan={base:manifest.baseline.sha,head:manifest.candidate.sha,node:process.version,nodeBinarySHA256:hash(fs.readFileSync(process.execPath)),harnessSHA256:hash(fs.readFileSync(new URL(import.meta.url))),seeds:[11,29,73],levels:[1,3],seconds:60,windows:[8,30,60],steadyWindow:[30,60],builds:{plain:[],rapid:['might','haste','echo','area','hourglass']},scenes:['stationaryBoss','crowd','movingBoss'],fixture:{hero:'knight',heroPerk:'disabled',damageTargetHP:1e12,enemyCount:{stationaryBoss:1,crowd:36,movingBoss:1},bossRadius:38,crowdSpeed:60,stationaryBossX:85,movingBossRadius:200,movingBossRadiansPerSecond:1.6,heroMotion:'x=18*sin(1.2*t), y=12*sin(0.7*t)',motionNote:'Moving boss follows imposed circle for hit geometry; its speed is not reduced by status. Crowd uses real Room.moveEnemies and status consumers.',pipeline:'Room.moveEnemies -> updateBuffs -> updateWeapon -> updateProjectiles -> updateColdWaves -> updateBlasts -> updateOrbs -> updateTimers -> updateTraps -> updatePuddles',disabled:'ordinary spawn, events, pickups, breakables, boss special AI, offers and hero innate perks',fusion:'real fuseDuo from parts at3/5, then optional free-slot weaponIII/V; includes actual synergy',freeWeapon:'first of bolt/knives/aura outside consumed pair; hypothetical immediate acquisition, not natural progression'},workers:1,performanceClaim:false};
assert.equal(plan.nodeBinarySHA256,manifest.nodeSHA256);fs.writeFileSync(path.join(out,'plan.json'),JSON.stringify(plan,null,2)+'\n');
assert.ok(!fs.existsSync(path.join(out,'raw.jsonl')),'Raw evidence is immutable; choose a new output folder for another run');
const raw=fs.openSync(path.join(out,'raw.jsonl'),'wx');
const engines={};for(const revision of ['baseline','candidate']){const dir=manifest[revision].source;engines[revision]={Room:(await import(pathToFileURL(path.join(dir,'app/server/game.js')))).Room,C:await import(pathToFileURL(path.join(dir,'app/public/shared/content.js')))};}
const seeded=seed=>()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
function create(engine,ids,level,build,seed,scene,setup='fusion',players=1,manualFusion=false){
 const {Room,C}=engine,r=new Room('STRENGTH',()=>{});for(let i=1;i<=players;i++)r.addPlayer(i,'P'+i,i===1?'knight':'ranger');r.start();r.time=100;r.enemies=[];r.breakAround=()=>{};
 const h=r.heroes.get(1);for(const a of r.heroes.values()){a.x=a.y=0;a.weapons.clear();a.hp=a.maxHp=1e12;a.perk.readyAt=Infinity;}h.passives=new Map(build.map(id=>[id,3]));r.recalcMods(h);h.hp=h.maxHp=1e12;
 const D=C.DUOS[ids],part=level+2,free=['bolt','knives','aura'].find(id=>!D.parts.includes(id));
 if(setup==='singleA')h.weapons.set(D.parts[0],{lvl:part,t:.2});
 else if(setup==='singleB')h.weapons.set(D.parts[1],{lvl:part,t:.2});
 else if(manualFusion)h.weapons.set(ids,{lvl:level,t:0});
 else {
  for(const id of D.parts)h.weapons.set(id,{lvl:part,t:.2});
  if(setup!=='pair'){assert.equal(r.fuseDuo(h,{id:ids,parts:D.parts,level}),true);if(setup==='freeSlot')h.weapons.set(free,{lvl:part,t:.2});}
 }
 const enemies=[];for(let i=0;i<(scene==='crowd'?36:1);i++){const e=r.spawnEnemy(scene==='crowd'?'ghoul':'brute',[h],1),a=Math.random()*Math.PI*2,d=45+Math.random()*235;Object.assign(e,{x:scene==='crowd'?Math.cos(a)*d:scene==='movingBoss'?200:85,y:scene==='crowd'?Math.sin(a)*d:0,hp:1e12,maxHp:1e12,speed:scene==='crowd'?60:0,dmg:0,shotT:Infinity,boss:scene!=='crowd',bk:null});if(e.boss)e.r=38;enemies.push(e);}
 const metric={union:0,freeze:0,root:0,slow:0,pullDistance:0,knockDistance:0,bossFrozenTicks:0,bossRootTicks:0};
 for(const[name,key]of [['anchorPull','pullDistance'],['knock','knockDistance']]){const original=r[name].bind(r);r[name]=(...args)=>{const before=enemies.map(e=>[e.x,e.y]);const value=original(...args);for(let i=0;i<enemies.length;i++)metric[key]+=Math.hypot(enemies[i].x-before[i][0],enemies[i].y-before[i][1]);return value;};}
 return {r,h,enemies,metric,free,ally:r.heroes.get(2)};
}
function frame(state,time,scene,{exactOrigin=false,stationaryX=null}={}){
 const {r,h,enemies,metric}=state,dt=1/30;r.time=100+time;r.tickNo++;r.lightBudget=8;r.hitFx=0;r.critFx=0;r.dieFx=0;r.reactFx=0;
 const x=exactOrigin?0:18*Math.sin(1.2*time),y=exactOrigin?0:12*Math.sin(.7*time),dx=x-h.x,dy=y-h.y,len=Math.hypot(dx,dy);if(len>0){h.fx=h.mvx=dx/len;h.fy=h.mvy=dy/len;h.movedT=r.time;}h.x=x;h.y=y;h.iframes=Math.max(0,h.iframes-dt);
 if(scene==='movingBoss'){enemies[0].x=200*Math.cos(time*1.6);enemies[0].y=200*Math.sin(time*1.6);}if(stationaryX!==null){enemies[0].x=stationaryX;enemies[0].y=0;}
 for(const e of enemies){const freeze=e.frozenT>r.time,root=e.rootT>r.time,slow=e.slowT>r.time&&e.slow>0;metric.freeze+=freeze?dt:0;metric.root+=root?dt:0;metric.slow+=slow?dt:0;metric.union+=freeze||root||slow?dt:0;if(e.boss){metric.bossFrozenTicks+=freeze;metric.bossRootTicks+=root;}}
 r.moveEnemies(dt,[...r.heroes.values()]);r.rebuildGrid();r.updateBuffs([...r.heroes.values()]);for(const[id,w]of h.weapons)r.updateWeapon(h,id,w,dt);r.updateProjectiles(dt);r.updateColdWaves(dt);r.updateBlasts();r.updateOrbs(dt);r.updateTimers();r.updateTraps(dt);r.updatePuddles(dt);r.fx=[];
}
function measure(engine,revision,id,level,buildName,scene,setup,seed){
 const original=Math.random;Math.random=seeded(seed);
 try{
  const state=create(engine,id,level,plan.builds[buildName],seed,scene,setup),samples={};
  for(let i=1;i<=1800;i++){frame(state,i/30,scene);if([240,900,1800].includes(i))samples[i/30]={damage:state.h.dmg,controlUnion:state.metric.union};}
  const {h,metric}=state;assert.ok(Number.isFinite(h.dmg));assert.ok(metric.union<=state.enemies.length*60+1e-6);assert.equal(metric.bossFrozenTicks,0);assert.equal(metric.bossRootTicks,0);
  return {revision,sourceSha:manifest[revision].sha,id,level,build:buildName,scene,setup,seed,freeWeapon:setup==='freeSlot'?state.free:null,damage:h.dmg,dps:h.dmg/60,steadyDps:(h.dmg-samples[30].damage)/30,metrics:metric,samples,damageBy:h.dmgBy};
 }finally{Math.random=original;}
}
const cached=new Map(),rows=[],errors=[];let count=0;
for(const revision of ['baseline','candidate'])for(const id of Object.keys(engines[revision].C.DUOS)){
 for(const level of plan.levels)for(const build of Object.keys(plan.builds))for(const scene of plan.scenes)for(const setup of ['singleA','singleB','pair','fusion','freeSlot'])for(const seed of plan.seeds){
  let row;try{const part=setup==='singleA'?engines[revision].C.DUOS[id].parts[0]:setup==='singleB'?engines[revision].C.DUOS[id].parts[1]:null;const key=part&&[revision,part,level,build,scene,seed].join(':');if(key&&cached.has(key))row={...cached.get(key),id,setup,reusedDeterministicMeasurement:key};else{row=measure(engines[revision],revision,id,level,build,scene,setup,seed);if(key)cached.set(key,row);}rows.push(row);}catch(error){row={revision,id,level,build,scene,setup,seed,error:String(error.stack)};errors.push(row);}fs.writeSync(raw,JSON.stringify(row)+'\n');count++;
 }
 console.log(JSON.stringify({revision,id,rows:count,errors:errors.length}));
}
fs.closeSync(raw);
const mean=a=>a.reduce((s,x)=>s+x,0)/a.length;
const comparisons=[];
for(const id of Object.keys(engines.candidate.C.DUOS))for(const level of plan.levels)for(const build of Object.keys(plan.builds))for(const scene of plan.scenes){const values={};for(const revision of ['baseline','candidate']){values[revision]={};for(const setup of ['singleA','singleB','pair','fusion','freeSlot']){const select=rows.filter(r=>r.revision===revision&&r.id===id&&r.level===level&&r.build===build&&r.scene===scene&&r.setup===setup);values[revision][setup]={samples:select.length,dps:mean(select.map(x=>x.dps)),steadyDps:mean(select.map(x=>x.steadyDps)),controlEnemySeconds:mean(select.map(x=>x.metrics.union)),pullDistance:mean(select.map(x=>x.metrics.pullDistance)),knockDistance:mean(select.map(x=>x.metrics.knockDistance))};}}comparisons.push({id,level,build,scene,values});}
const defense=[];
for(const revision of ['baseline','candidate'])for(const id of Object.keys(engines[revision].C.DUOS).filter(id=>engines[revision].C.DUOS[id].parts.includes('ward')||id==='censer'))for(const level of [1,3])for(const setup of ['pair','fusion'])for(const seed of plan.seeds){const original=Math.random;Math.random=seeded(seed);try{const s=create(engines[revision],id,level,[],seed,'stationaryBoss',setup,2);s.enemies[0].x=40;s.h.hp=s.h.maxHp=5000;s.ally.hp=500;s.ally.maxHp=10000;let healing=0,blocked=0,incoming=0;for(let i=1;i<=1800;i++){const before=s.ally.hp;frame(s,i/30,'stationaryBoss');healing+=Math.max(0,s.ally.hp-before);if(i%30===0){s.h.iframes=0;const hp=s.h.hp;s.r.hurtPlayer(s.h,10,'strength');incoming+=10;blocked+=10-(hp-s.h.hp);}}defense.push({revision,sourceSha:manifest[revision].sha,id,level,setup,seed,incoming,blocked,healing,damage:s.h.dmg,controlEnemySeconds:s.metric.union});}finally{Math.random=original;}}
const gravity=[];
for(const revision of ['baseline','candidate'])for(const level of [1,2,3])for(const scene of ['stationaryBoss','movingBoss']){const original=Math.random;Math.random=seeded(11);try{const s=create(engines[revision],'gravitybell',level,[],11,scene,'fusion',1,true),samples={};for(let i=1;i<=3600;i++){frame(s,i/30,scene,{exactOrigin:true,stationaryX:scene==='stationaryBoss'?100:null});if([90,240,900,3600].includes(i))samples[i/30]=s.h.dmg;}gravity.push({revision,sourceSha:manifest[revision].sha,level,scene,manualEquipWithoutSynergy:true,samples});}finally{Math.random=original;}}
let mismatches=[];for(const revision of ['baseline','candidate'])for(const[file,expected]of Object.entries(manifest[revision].runtimeFilesSHA256)){const actual=hash(fs.readFileSync(path.join(manifest[revision].source,file)));if(actual!==expected)mismatches.push({revision,file});}
const result={plan,manifest,rows:rows.length,errors,comparisons,defense,gravity,sourceReadback:{mismatches,unchanged:mismatches.length===0},interpretation:'Damage/control/block/healing measurements on fixed fixtures only. No universal fusion>pair DPS threshold, win-rate, natural acquisition, CPU or FPS claim.'};fs.writeFileSync(path.join(out,'results.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({complete:true,rows:rows.length,errors:errors.length,defense:defense.length,gravity:gravity.length,sourceMismatches:mismatches.length}));if(errors.length||mismatches.length)process.exitCode=1;
