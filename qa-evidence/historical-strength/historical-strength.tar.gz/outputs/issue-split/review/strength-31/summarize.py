import pathlib,json,math,hashlib
P=pathlib.Path(__file__).resolve().parent
r=json.loads((P/'results.json').read_text());raw=[json.loads(line)for line in(P/'raw.jsonl').read_text().splitlines()]
assert not r['errors'] and r['sourceReadback']['unchanged']
expected=39*2*2*3*5*3*2
assert len(raw)==r['rows']==expected
key=lambda a:tuple(a[k]for k in['revision','id','level','build','scene','setup','seed'])
assert len({key(a)for a in raw})==expected
index={key(a):a for a in raw};control=[]
for a in raw:
 if a['revision']!='candidate' or a['setup']not in ['singleA','singleB','pair']:continue
 k=list(key(a));k[0]='baseline';b=index[tuple(k)]
 if any(abs(a[k]-b[k])>1e-7 for k in ['damage','dps','steadyDps'])or any(abs(a['metrics'][k]-b['metrics'][k])>1e-7 for k in ['union','freeze','root','slow','pullDistance','knockDistance']):control.append({'tuple':key(a),'baseline':b,'candidate':a})
def avg(v):return sum(v)/len(v)
def rounded(v):return round(v,3)
utility=[]
for id in sorted({a['id']for a in r['defense']}):
 for level in [1,3]:
  row={'id':id,'level':level,'values':{}}
  for revision in['baseline','candidate']:
   row['values'][revision]={}
   for setup in['pair','fusion']:
    a=[v for v in r['defense']if v['id']==id and v['level']==level and v['revision']==revision and v['setup']==setup]
    row['values'][revision][setup]={k:rounded(avg([v[k]for v in a]))for k in ['incoming','blocked','healing','damage']}
  utility.append(row)
summary={'base':r['plan']['base'],'head':r['plan']['head'],'node':r['plan']['node'],'nodeBinarySHA256':r['plan']['nodeBinarySHA256'],'harnessSHA256':r['plan']['harnessSHA256'],'logicalRows':expected,'freshMeasurements':sum('reusedDeterministicMeasurement'not in a for a in raw),'componentCacheReuses':sum('reusedDeterministicMeasurement'in a for a in raw),'comparisonCells':len(r['comparisons']),'errorCount':len(r['errors']),'sourceUnchanged':r['sourceReadback']['unchanged'],'bossFrozenTicks':sum(v['metrics']['bossFrozenTicks']for v in raw),'bossRootTicks':sum(v['metrics']['bossRootTicks']for v in raw),'nonFusionControlPairs':len(raw)//2*3//5,'nonFusionControlMismatches':control,'defense':utility,'gravity':r['gravity'],'resultsSHA256':hashlib.sha256((P/'results.json').read_bytes()).hexdigest(),'rawSHA256':hashlib.sha256((P/'raw.jsonl').read_bytes()).hexdigest()}
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
out=['# Fresh standalone #31 strength measurements','',f"Base `{summary['base']}`, head `{summary['head']}`, Node `{summary['node']}`.",'','Actual 60-second casts, seeds11/29/73, real fusion with its synergy. I/III correspond to partsIII/V. Moving boss follows imposed motion; crowd follows real movement/status consumers. Free-slot weapon is supplied immediately atIII/V and is an optimistic upper-bound acquisition scene. Values below are DPS; no universal fusion/pair pass threshold.','']
for build in ['plain','rapid']:
 out += ['## '+build,'','Each cell is `I old/new/pair/+slot ; III old/new/pair/+slot` over the complete60s. Detailed steady30–60s and each seed are in results/raw.','','| Duo | Stationary boss | Crowd | Moving boss |','|---|---|---|---|']
 for id in [x['id']for x in r['comparisons']if x['level']==1 and x['build']==build and x['scene']=='stationaryBoss']:
  cells=[]
  for scene in ['stationaryBoss','crowd','movingBoss']:
   parts=[]
   for level in[1,3]:
    c=next(x for x in r['comparisons']if x['id']==id and x['level']==level and x['build']==build and x['scene']==scene)
    values=[c['values']['baseline']['fusion']['dps'],*[c['values']['candidate'][k]['dps']for k in['fusion','pair','freeSlot']]]
    parts.append('/'.join(f'{v:.1f}'for v in values))
   cells.append(' ; '.join(parts))
  out.append('| '+id+' | '+' | '.join(cells)+' |')
out+=['','## Defense/healing','', '60 seconds,600 incoming HP to the owner,10HP once per second. Hero innate shield disabled. Target HP fixed; only effective restored ally HP is counted. No #41 field-healing cap is installed in either revision.','','| Duo/level | Blocked pair old/new | Blocked fusion old/new | Healed pair old/new | Healed fusion old/new |','|---|---|---|---|---|']
for a in utility:
 vals=[]
 for metric,setup in [('blocked','pair'),('blocked','fusion'),('healing','pair'),('healing','fusion')]:vals.append('/'.join(f"{a['values'][rev][setup][metric]:.1f}"for rev in['baseline','candidate']))
 out.append('| '+a['id']+'/'+str(a['level'])+' | '+' | '.join(vals)+' |')
out+=['','## Source and fixture controls','',f"Logical rows: {expected}; fresh simulations: {summary['freshMeasurements']}; explicitly cached identical single-weapon fixtures: {summary['componentCacheReuses']}. Non-fusion baseline/candidate pairs checked: {summary['nonFusionControlPairs']}; mismatches: {len(control)}. Boss frozen/root ticks: {summary['bossFrozenTicks']}/{summary['bossRootTicks']}. Source hashes unchanged at readback.",'','Control union seconds, freeze/root/slow occupancy, actual pull/knock displacement, every source damage entry, all per-seed windows and exact manifests are retained in primaryJSON. Those metrics are reported separately rather than converted into fictional prevented damage.']
(P/'table.md').write_text('\n'.join(out)+'\n')
print(json.dumps({k:summary[k]for k in ['logicalRows','freshMeasurements','componentCacheReuses','comparisonCells','errorCount','sourceUnchanged','nonFusionControlPairs','bossFrozenTicks','bossRootTicks']}))
print('nonFusionControlMismatches',len(control))
